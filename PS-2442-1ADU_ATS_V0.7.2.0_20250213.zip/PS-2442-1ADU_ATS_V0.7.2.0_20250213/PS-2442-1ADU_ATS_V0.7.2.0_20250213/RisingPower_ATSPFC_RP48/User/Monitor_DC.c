/****************************************************************************
 *	File	Monitor_DC.c
 * 	Brief	DC input signals handler
 * 			- Vbulk Detection
 * 			- Vbulk OVP Detection
 * 			- AC1 Aux Power voltage
 * 			- AC2 Aux Power voltage
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/25 - 1st release
 ****************************************************************************/
#include <string.h>
#include "Peripheral.h"
#include "Monitor_DC.h"
#include "Monitor_AC.h"
#include "SERV_ADCFilter.h"
#include "Handler_ATS.h"
#include "SERV_LOG.h"


/****************************************************************************
*	Private parameter definition 
****************************************************************************/

#define MOMIDC_Bits_OVW                         0x0004
#define MOMIDC_Bits_UVW                         0x0010

/* ITIC used */
#define BULK_OVP_ITIC_SetDelay                  6000        // unit is ms

/* VBulk Good */
#define BULK_DcGood_ThresholdClearHigh			4900		// unit is 0.1V
#define BULK_DcGood_ThresholdSetHigh			4800		// unit is 0.1V
#define BULK_DcGood_ThresholdSetLow				3800		// unit is 0.1V
#define BULK_DcGood_ThresholdClearLow			3500	    // unit is 0.1V
#define BULK_DcGood_SetDelay					0			// unit is ms
#define BULK_DcGood_ClearDelay					0			// unit is ms

/* VBulk OVP */
#define BULK_OVP_FastThreshold					5000		// unit is 0.1V
#define BULK_OVP_SlowThreshold					BULK_DcGood_ThresholdClearHigh
#define BULK_OVP_ClearThreshold					BULK_DcGood_ThresholdSetHigh
#define BULK_OVP_FastDelay						3			// unit is ms
#define BULK_OVP_SlowDelay						5000		// unit is ms
#define BULK_OVP_ClearDelay						0			// unit is ms
#define BULK_ITIC_OVP_Threshold                 5000        // unit is 0.1V
#define BULK_ITIC_OVP_ClearThreshold            4700        // unit is 0.1V

/* VBulk OVW */
#define BULK_OVW_SetThreshold                   4800
#define BULK_OVW_ClearThreshold                 4700
#define BULK_OVW_SetDelay                       100          // unit is ms
#define BULK_OVW_ClearDelay                     0            // unit is ms

/* VBulk UVP */
#define BULK_UVP_SetThreshold					BULK_DcGood_ThresholdClearLow
#define BULK_UVP_ClearThreshold					BULK_DcGood_ThresholdSetLow
#define BULK_UVP_SetDelay						0			// unit is ms
#define BULK_UVP_ClearDelay						0			// unit is ms

/* VBulk UVW */
#define BULK_UVW_SetThreshold                   3600
#define BULK_UVW_ClearThreshold                 3700
#define BULK_UVW_SetDelay                       0           // unit is ms
#define BULK_UVW_ClearDelay                     0           // unit is ms


#define AUX_DcGood_ThresholdClearHigh			142			// unit is 0.1V
#define AUX_DcGood_ThresholdSetHigh				140			// unit is 0.1V
#define AUX_DcGood_ThresholdSetLow				110			// unit is 0.1V
#define AUX_DcGood_ThresholdClearLow			107		    // unit is 0.1V
#define AUX_DcGood_SetDelay						0			// unit is 10ms
#define AUX_DcGood_ClearDelay					0			// unit is 10ms

#define AUX_OVP_SetThreshold					AUX_DcGood_ThresholdClearHigh
#define AUX_OVP_ClearThreshold					AUX_DcGood_ThresholdSetHigh
#define AUX_OVP_SetDelay						1			// 10ms, unit is 10ms
#define AUX_OVP_ClearDelay						1			// 10ms, unit is 10ms

#define AUX_UVP_SetThreshold					AUX_DcGood_ThresholdClearLow	
#define AUX_UVP_ClearThreshold					AUX_DcGood_ThresholdSetLow
#define AUX_UVP_SetDelay						12			// 120ms, unit is 10ms
#define AUX_UVP_ClearDelay						1			// 10ms, unit is 10ms


/* DC Average fileter */
// DC_Filter_A + DC_Filter_B = 1
#define DC_Filter_A								(f32_t)0.1
#define DC_Filter_B								(f32_t)0.9

/****************************************************************************
*	Private macro definition
****************************************************************************/ 

/****************************************************************************
*	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
*	Private structure definition 
****************************************************************************/

/****************************************************************************
*	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 586 -> 560
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Delay, ".TI.ramfunc");
#pragma CODE_SECTION(MoniDC_RealValue_Cal, ".TI.ramfunc");
#pragma CODE_SECTION(MoniDC_UpdateFlag, ".TI.ramfunc");
#pragma CODE_SECTION(MoniDC_1ms_Periodically_Process, ".TI.ramfunc");
#pragma CODE_SECTION(MoniDC_10ms_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(MoniDC_Clear_Vbulk_OVFault, ".TI.ramfunc");
//#pragma CODE_SECTION(MoniDC_Clear_Vbulk_UVFault, ".TI.ramfunc");
//#pragma CODE_SECTION(MoniDC_Check_Vbulk_UVFault, ".TI.ramfunc");
#endif


/****************************************************************************
*	Private variable declaration
****************************************************************************/
u16_t u16VBulkOVP_CNT = 0;
sMoniDC_t tsMoniDC[MoniDC_Tag_Num];

/***************************************************************************
*   brief  Delay method
*   note   
****************************************************************************/
static u16_t Delay(u16_t* u16Delay)
{
	if (*u16Delay == 0)
	{
		return 1;
	}
	else
	{
		*u16Delay -= 1;
		return 0;
	}
}

/***************************************************************************
*   brief  Update Real value
*   note   at 1ms system time
*   para   u16RealRMS_WF unit is 0.1V/A
*          u16RealInstant unit is 0.1V/A
****************************************************************************/
static void MoniDC_RealValue_Cal(sMoniDC_t *psMoni)
{
    f32_t f32Value, f32Out;
	u16_t u16TempIn;

	u16TempIn = *psMoni->pu16ADC_Q12;
	f32Value = (f32_t)u16TempIn / Q12_;
	f32Out = f32Value * psMoni->f32Cali_Gain + psMoni->f32Cali_Offset + 0.5;	//rounding
	
	// VBulk fault inject value
    if (psMoni->nFlag.u16Bits.u1FIJ == TRUE && psMoni->eTag == MoniDC_Tag_Vbulk)
    {
        if (GET_MOMIDC_VBULK_OVP)
        {
            psMoni->u16RealInstant = 5030; // 503V
            psMoni->u16RealRMS_WF  = 5030;
        }
        else if (GET_MOMIDC_VBULK_UVP)
        {
            psMoni->u16RealInstant = 3400; // 340V
            psMoni->u16RealRMS_WF  = 3400;
        }
    }
    else
    {
        // Normal detect
        if (f32Out > 0)
        {
            psMoni->u16RealInstant = (u16_t)f32Out;
        }
        else
        {
            psMoni->u16RealInstant = 0;
        }

        psMoni->u16RealRMS_WF = (u16_t)((f32_t)psMoni->u16RealInstant * DC_Filter_A + (f32_t)psMoni->u16RealRMS_WF * DC_Filter_B);
    }
	
	if (psMoni->eTag == MoniDC_Tag_Vbulk)
	{
        // Vbulk DEC
        u16TempIn = *psMoni->pu16ADC1_Q12;
        f32Value = (f32_t)u16TempIn / Q12_;
        f32Out = f32Value * psMoni->f32Cali_Gain + psMoni->f32Cali_Offset + 0.5;

        if (f32Out > 0)
        {
           psMoni->u16RealInstant1 = (u16_t)f32Out;
        }
        else
        {
           psMoni->u16RealInstant1 = 0;
        }

        psMoni->u16RealRMS_WF1 = (u16_t)((f32_t)psMoni->u16RealInstant1 * DC_Filter_A + (f32_t)psMoni->u16RealRMS_WF1 * DC_Filter_B);

        // Vbulk OVP2
        u16TempIn = *psMoni->pu16ADC2_Q12;
        f32Value = (f32_t)u16TempIn / Q12_;
        f32Out = f32Value * psMoni->f32Cali_Gain + psMoni->f32Cali_Offset + 0.5;

        if (f32Out > 0)
        {
           psMoni->u16RealInstant2 = (u16_t)f32Out;
        }
        else
        {
           psMoni->u16RealInstant2 = 0;
        }

        psMoni->u16RealRMS_WF2 = (u16_t)((f32_t)psMoni->u16RealInstant2 * DC_Filter_A + (f32_t)psMoni->u16RealRMS_WF2 * DC_Filter_B);
	}
}

/***************************************************************************
*   brief  Monitor Vac peak for ITIC 140%, 200% to avoid VBulk OVP cause PSU shut down
*   note   at 1ms system time
****************************************************************************/
static inline void MoniDC_VBulkOVP_ITIC_Delay(sMoniDC_t *psMoni)
{
//    if (psMoni->nFlag.u16Bits.u1OVP == FALSE)
//    {
//        if (GET_APPLY_AC_ITIC_FLAG == TRUE)
//        {
//            u16VBulkOVP_CNT = BULK_OVP_ITIC_SetDelay;
//            psMoni->sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerDisable;
//        }
//
//        if (Delay(&u16VBulkOVP_CNT) && psMoni->sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable == TriggerDisable)
//        {
//            psMoni->sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover;
//        }
//    }

    if (psMoni->nFlag.u16Bits.u1OVP == FALSE)
    {
        if (GET_MOMIAC_VAC1_ITIC || GET_MOMIAC_VAC2_ITIC)
        {
            u16VBulkOVP_CNT = BULK_OVP_ITIC_SetDelay;
            psMoni->sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerDisable;
        }

        if (Delay(&u16VBulkOVP_CNT) && psMoni->sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable == TriggerDisable)
        {
            psMoni->sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover;
        }
    }
}

/***************************************************************************
*   brief  Update VBulk OVW
*   note   1. VBulk have 3 detection paths, if any of two path detect OVP,  represent VBulk OVP
*          2. If VBulk is OVP now , must 3 detect paths voltage less than Threshold then recover
*          3. VBulk OVP have two-stage protection , one is slow-OVP(490V delay5s) , two is fast-OVP(500V delay3ms)
*          4. at 1ms system time
****************************************************************************/
static inline void MoniDC_UpdateFlag_VBulk_OVW_UVW(sMoniDC_t *psMoni, sSingleThreshold_t* psConfig, u16_t *u16Flag)
{
    u16_t u16DoubleFaultCNT = 0;

    if (psConfig->eTriggerType == TriggerDisable)
    {
        *u16Flag &= (~psConfig->u16SetBits);    //Clear bit
        psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
        psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
    }
    else
    {
        // Upper Limit , VBulk OVW detect
        if (psConfig->eLimitType == Limit_Upper)
        {
            u16DoubleFaultCNT = 0;

            if (psMoni->u16RealRMS_WF > psConfig->i16SetThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealRMS_WF1 > psConfig->i16SetThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealRMS_WF2 > psConfig->i16SetThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (u16DoubleFaultCNT > 1)
            {
                if ((Delay(&psConfig->sVar.u16SetDelay)) &&
                    (psMoni->nFlag.u16Bits.u1OVW == FALSE))
                {
                    psMoni->nFlag.u16Bits.u1OVW = TRUE;
                }

                psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
            }
            else
            {
                /* Prevent ripple during threshold */
                if (psConfig->sVar.u16SetDelay < psConfig->sConst.u16SetDelay)
                {
                    psConfig->sVar.u16SetDelay ++;
                }
            }

            // VBulk OVW recover
            u16DoubleFaultCNT = 0;

            if (psMoni->u16RealRMS_WF < psConfig->i16ClearThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealRMS_WF1 < psConfig->i16ClearThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealRMS_WF2 < psConfig->i16ClearThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (u16DoubleFaultCNT == 3)
            {
                if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
                    (psMoni->nFlag.u16Bits.u1OVW == TRUE))
                {
                    psMoni->nFlag.u16Bits.u1OVW = FALSE;
                }

                psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
            }
            else
            {
                /* Prevent ripple during threshold */
                if (psConfig->sVar.u16ClearDelay < psConfig->sConst.u16ClearDelay)
                {
                    psConfig->sVar.u16ClearDelay ++;
                }
            }
        }
        else
        {
            // Lower Limit , VBulk UVW detect
            u16DoubleFaultCNT = 0;

            if (psMoni->u16RealInstant < psConfig->i16SetThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealInstant1 < psConfig->i16SetThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealInstant2 < psConfig->i16SetThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (u16DoubleFaultCNT > 1)
            {
                if ((Delay(&psConfig->sVar.u16SetDelay)) &&
                    (psMoni->nFlag.u16Bits.u1UVW == FALSE))
                {
                    psMoni->nFlag.u16Bits.u1UVW = TRUE;
                }

                psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
            }

            // VBulk UVW recover
            u16DoubleFaultCNT = 0;

            if (psMoni->u16RealInstant > psConfig->i16ClearThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealInstant1 > psConfig->i16ClearThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (psMoni->u16RealInstant2 > psConfig->i16ClearThreshold)
            {
                u16DoubleFaultCNT++;
            }

            if (u16DoubleFaultCNT == 3)
            {
                if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
                    (psMoni->nFlag.u16Bits.u1UVW == TRUE))
                {
                    psMoni->nFlag.u16Bits.u1UVW = FALSE;
                }

                psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
            }
        }
    }

}

/***************************************************************************
*   brief  Update DC Source Status - OverVoltage
*   note   1. VBulk have 3 detection paths, if any of two path detect OVP,  represent VBulk OVP
*          2. If VBulk is OVP now , must 3 detect paths voltage less than Threshold then recover
*          3. VBulk OVP have two-stage protection , one is slow-OVP(490V delay5s) , two is fast-OVP(500V delay3ms)
*          4. at 1ms system time
****************************************************************************/
static inline void MoniDC_UpdateFlag_OverVoltage(sMoniDC_t *psMoni)
{
	u16_t u16DoubleFaultCNT;
	sDualThreshold_t* psConfig = &psMoni->sConfig.sOVP;

	if (psMoni->eTag == MoniDC_Tag_Vbulk)
	{
		// Over Voltage Protect (slow)
		if (psConfig->nTriggerType.u16Bits.u2ProtectEnable == TriggerDisable)
		{
			psMoni->nFlag.u16Bits.u1OVP = FALSE;
			psConfig->sVar.u16WarningDelay = psConfig->sConst.u16WarningDelay;
			psConfig->sVar.u16RecoverDelay = psConfig->sConst.u16RecoverDelay;
		}
		else if (psConfig->nTriggerType.u16Bits.u2ProtectEnable == TriggerLatch)
		{
            psMoni->nFlag.u16Bits.u1OVP = TRUE;
		}
		else
		{
			u16DoubleFaultCNT = 0;
			
			if (psMoni->u16RealInstant > psConfig->i16WarningThreshold)
			{
				u16DoubleFaultCNT++;
			}

			if (psMoni->u16RealInstant1 > psConfig->i16WarningThreshold)
			{
				u16DoubleFaultCNT++;
			}

			if (psMoni->u16RealInstant2 > psConfig->i16WarningThreshold)
			{
				u16DoubleFaultCNT++;
			}
			
			if (u16DoubleFaultCNT > 1)
			{
				if ((Delay(&psConfig->sVar.u16WarningDelay)) &&
					(psMoni->nFlag.u16Bits.u1OVP == FALSE))
				{
					psMoni->nFlag.u16Bits.u1OVP = TRUE;
                    psMoni->u16OVP_CNT += 1;
					psConfig->nTriggerType.u16Bits.u2ProtectEnable = TriggerLatch;
				}

				psConfig->sVar.u16RecoverDelay = psConfig->sConst.u16RecoverDelay;
			}
            else
            {
                /* Prevent ripple during threshold */
                if (psConfig->sVar.u16WarningDelay < psConfig->sConst.u16WarningDelay)
                {
                    psConfig->sVar.u16WarningDelay ++;
                }
            }
		}
	
		// Over Voltage Protect (Fast)
		if (psConfig->nTriggerType.u16Bits.u2ProtectEnable == TriggerDisable)
		{
			psMoni->nFlag.u16Bits.u1OVP = FALSE;
			psConfig->sVar.u16ProtectDelay = psConfig->sConst.u16ProtectDelay;
			psConfig->sVar.u16RecoverDelay = psConfig->sConst.u16RecoverDelay;
		}
		else
		{
			u16DoubleFaultCNT = 0;
			
			if (psMoni->u16RealInstant > psConfig->i16ProtectThreshold)
			{
				u16DoubleFaultCNT++;
			}

			if (psMoni->u16RealInstant1 > psConfig->i16ProtectThreshold)
			{
				u16DoubleFaultCNT++;
			}

			if (psMoni->u16RealInstant2 > psConfig->i16ProtectThreshold)
			{
				u16DoubleFaultCNT++;
			}
			
			if (u16DoubleFaultCNT > 1)        
			{
				if ((Delay(&psConfig->sVar.u16ProtectDelay)) &&
					(psMoni->nFlag.u16Bits.u1OVP == FALSE))
				{
					psMoni->nFlag.u16Bits.u1OVP = TRUE;
					psMoni->u16OVP_CNT += 1;
					psConfig->nTriggerType.u16Bits.u2ProtectEnable = TriggerLatch;
				}

				psConfig->sVar.u16RecoverDelay = psConfig->sConst.u16RecoverDelay;
			}
            else
            {
                /* Prevent ripple during threshold */
                if (psConfig->sVar.u16ProtectDelay < psConfig->sConst.u16ProtectDelay)
                {
                    psConfig->sVar.u16ProtectDelay ++;
                }
            }
		}

		// Over Voltage Recover
		u16DoubleFaultCNT = 0;
		
		if (psMoni->u16RealInstant < psConfig->i16RecoverThreshold)
		{
			u16DoubleFaultCNT++;
		}

		if (psMoni->u16RealInstant1 < psConfig->i16RecoverThreshold)
		{
			u16DoubleFaultCNT++;
		}

		if (psMoni->u16RealInstant2 < psConfig->i16RecoverThreshold)
		{
			u16DoubleFaultCNT++;
		}
		
		if (u16DoubleFaultCNT == 3)
		{
			if ((Delay(&psConfig->sVar.u16RecoverDelay)) &&
				(psMoni->nFlag.u16Bits.u1OVP == TRUE))
			{
				if (psConfig->nTriggerType.u16Bits.u2ProtectEnable == TriggerAutoRecover)
				{
					psMoni->nFlag.u16Bits.u1OVP = FALSE;
				}
			}

			psConfig->sVar.u16ProtectDelay = psConfig->sConst.u16ProtectDelay;
			psConfig->sVar.u16WarningDelay = psConfig->sConst.u16WarningDelay;
		}
	}
	// MoniDC_Tag_VAux
	else
	{
		// Over Voltage Protect
		if (psConfig->nTriggerType.u16Bits.u2ProtectEnable == TriggerDisable)
		{
			psMoni->nFlag.u16Bits.u1OVP = FALSE;
			psConfig->sVar.u16ProtectDelay = psConfig->sConst.u16ProtectDelay;
			psConfig->sVar.u16RecoverDelay = psConfig->sConst.u16RecoverDelay;
		}
		else
		{
			if (psMoni->u16RealInstant > psConfig->i16ProtectThreshold)          
			{
				if ((Delay(&psConfig->sVar.u16ProtectDelay)) &&
					(psMoni->nFlag.u16Bits.u1OVP == FALSE))
				{
					psMoni->nFlag.u16Bits.u1OVP = TRUE;			
				}

				psConfig->sVar.u16RecoverDelay = psConfig->sConst.u16RecoverDelay;
			}
		}
	
		// Over Voltage Recover
		if (psMoni->u16RealInstant < psConfig->i16RecoverThreshold)
		{
			if ((Delay(&psConfig->sVar.u16RecoverDelay)) &&
				((psMoni->nFlag.u16Bits.u1OVP == TRUE) ||
			 	 (psMoni->nFlag.u16Bits.u1OVW == TRUE)))
			{
				if (psConfig->nTriggerType.u16Bits.u2WarningEnable == TriggerAutoRecover)
				{
					psMoni->nFlag.u16Bits.u1OVW = FALSE;
				}
				
				if (psConfig->nTriggerType.u16Bits.u2ProtectEnable == TriggerAutoRecover)
				{
					psMoni->nFlag.u16Bits.u1OVP = FALSE;
				}
			}

			psConfig->sVar.u16ProtectDelay = psConfig->sConst.u16ProtectDelay;
			psConfig->sVar.u16WarningDelay = psConfig->sConst.u16WarningDelay;
		}
	}
}

/***************************************************************************
*   brief  Update DC Source Status - UnderVoltage
*   note   1. VBulk-UVP mechanism same as VBulk-OVP , have 3 detection paths
*          2. at 1ms system time
****************************************************************************/
static inline void MoniDC_UpdateFlag_UnderVoltage(sMoniDC_t *psMoni)
{
	u16_t u16DoubleFaultCNT;
	u16_t u16tripleClearCNT;
	sSingleThreshold_t* psConfig = &psMoni->sConfig.sUVP;
	
	if (psConfig->eTriggerType == TriggerDisable)
	{
		psMoni->nFlag.u16Bits.u1UVP = FALSE;
		psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
	}
	else
	{
		if (psMoni->eTag == MoniDC_Tag_Vbulk)
		{
	        if (psConfig->eTriggerType == TriggerLatch)
	        {
	            psMoni->nFlag.u16Bits.u1UVP = TRUE;
	        }
	        else
	        {
	            u16DoubleFaultCNT = 0;
	            u16tripleClearCNT = 0;

	            if (psMoni->u16RealInstant < psConfig->i16SetThreshold)
	            {
	                u16DoubleFaultCNT++;
	            }
	            else if (psMoni->u16RealInstant > psConfig->i16ClearThreshold)
	            {
	                u16tripleClearCNT++;
	            }

	            if (psMoni->u16RealInstant1 < psConfig->i16SetThreshold)
	            {
	                u16DoubleFaultCNT++;
	            }
	            else if (psMoni->u16RealInstant1 > psConfig->i16ClearThreshold)
	            {
	                u16tripleClearCNT++;
	            }

	            if (psMoni->u16RealInstant2 < psConfig->i16SetThreshold)
	            {
	                u16DoubleFaultCNT++;
	            }
	            else if (psMoni->u16RealInstant2 > psConfig->i16ClearThreshold)
	            {
	                u16tripleClearCNT++;
	            }

	            if (u16DoubleFaultCNT > 1)
	            {
	                if ((Delay(&psConfig->sVar.u16SetDelay)) &&
	                    (psMoni->nFlag.u16Bits.u1UVP == FALSE))
	                {
	                    psMoni->nFlag.u16Bits.u1UVP = TRUE;
	                    psMoni->u16UVP_CNT += 1;
	                }

	                psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
	            }
	            else if (u16tripleClearCNT == 3)
	            {
	                if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
	                    (psMoni->nFlag.u16Bits.u1UVP == TRUE))
	                {
	                    psMoni->nFlag.u16Bits.u1UVP = FALSE;
	                }

	                psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
	            }
	        }
		}
		// MoniDC_Tag_VAux
		else
		{
			if (psMoni->u16RealInstant < psConfig->i16SetThreshold)
			{
				if ((Delay(&psConfig->sVar.u16SetDelay)) &&
					(psMoni->nFlag.u16Bits.u1UVP == FALSE))
				{
					psMoni->nFlag.u16Bits.u1UVP = TRUE;
				}

				psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
			}
			else if (psMoni->u16RealInstant > psConfig->i16ClearThreshold)
			{
				if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
					(psMoni->nFlag.u16Bits.u1UVP == TRUE) &&
					(psConfig->eTriggerType == TriggerAutoRecover))
				{
					psMoni->nFlag.u16Bits.u1UVP = FALSE;
				}

				psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
			}
		}	
	}
}

/***************************************************************************
*   brief  Update DC Source Flag - DC Good
*   note   at 1ms system time
****************************************************************************/
static inline void MoniDC_UpdateFlag_SourceGood(sMoniDC_t *psMoni)
{
	sBetweenThreshold_t* psConfig = &psMoni->sConfig.sSourceGood;
	
	if (psConfig->eTriggerType == TriggerDisable)
	{
		psMoni->nFlag.u16Bits.u1Good = FALSE;
		psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
	}
	else
	{		
		if ((psMoni->u16RealInstant < psConfig->i16SetThresholdHigh) &&
			(psMoni->u16RealInstant > psConfig->i16SetThresholdLow) &&
			(psMoni->nFlag.u16Bits.u1OVP == FALSE) &&
			(psMoni->nFlag.u16Bits.u1UVP == FALSE))		
		{
			if ((Delay(&psConfig->sVar.u16SetDelay)) &&
				(psMoni->nFlag.u16Bits.u1Good == FALSE))
			{
				psMoni->nFlag.u16Bits.u1Good = TRUE;	
			}

			psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
		}
		else if ((psMoni->u16RealInstant < psConfig->i16ClearThresholdLow) ||
				 (psMoni->u16RealInstant > psConfig->i16ClearThresholdHigh))
		{
			if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
				(psMoni->nFlag.u16Bits.u1Good == TRUE) &&
				(psConfig->eTriggerType == TriggerAutoRecover))		
			{
				psMoni->nFlag.u16Bits.u1Good = FALSE;
			}

			psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		}
	}
}

/***************************************************************************
*   brief  Update DC flag
*   note   at 1ms system time
****************************************************************************/
static void MoniDC_UpdateFlag(sMoniDC_t *psMoni)
{
    if (psMoni->eTag == MoniDC_Tag_Vbulk)
    {
        MoniDC_UpdateFlag_VBulk_OVW_UVW(psMoni, &psMoni->sConfig.sOVW, &psMoni->nFlag.u16All);  // Monitor VBulk OVW
        MoniDC_UpdateFlag_VBulk_OVW_UVW(psMoni, &psMoni->sConfig.sUVW, &psMoni->nFlag.u16All);  // Monitor VBulk UVW
        MoniDC_VBulkOVP_ITIC_Delay(psMoni); // Disable OVP when ITIC occur

    }

	MoniDC_UpdateFlag_OverVoltage(psMoni);
	MoniDC_UpdateFlag_UnderVoltage(psMoni);
    MoniDC_UpdateFlag_SourceGood(psMoni);
}

/***************************************************************************
*   brief  DcSource periodically Process at 1ms system time
*   note   
****************************************************************************/
void MoniDC_1ms_Periodically_Process(void)
{
	MoniDC_RealValue_Cal(&tsMoniDC[MoniDC_Tag_Vbulk]);
	MoniDC_UpdateFlag(&tsMoniDC[MoniDC_Tag_Vbulk]);
}

/***************************************************************************
*   brief  DcSource periodically Process at 10ms system time
*   note   
****************************************************************************/
void MoniDC_10ms_Periodically_Process(void)
{
	MoniDC_RealValue_Cal(&tsMoniDC[MoniDC_Tag_VAux1]);
	MoniDC_RealValue_Cal(&tsMoniDC[MoniDC_Tag_VAux2]);

	if (GET_MOMIAC_VAC1_DROP == FALSE)
	{
		MoniDC_UpdateFlag(&tsMoniDC[MoniDC_Tag_VAux1]);
	}
	else if (tsMoniDC[MoniDC_Tag_VAux1].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable != TriggerLatch)	//for fault injection
	{
		tsMoniDC[MoniDC_Tag_VAux1].nFlag.u16All = 0;
	}

	if (GET_MOMIAC_VAC2_DROP == FALSE)
	{
		MoniDC_UpdateFlag(&tsMoniDC[MoniDC_Tag_VAux2]);
	}
	else if (tsMoniDC[MoniDC_Tag_VAux2].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable != TriggerLatch)	//for fault injection
	{
		tsMoniDC[MoniDC_Tag_VAux2].nFlag.u16All = 0;
	}
}

/***************************************************************************
*   brief  Update DC Calibration gain and offset value
*   note   
****************************************************************************/
void UpdateMoniDCCalibration(eMoniDCTag_t eTag)
{
	tsMoniDC[eTag].f32Cali_Gain = tsMoniDC[eTag].psCali->f32CaliGain / 100;	 //unit is 0.1V
	tsMoniDC[eTag].f32Cali_Offset = ((f32_t)tsMoniDC[eTag].psCali->i16Offset * 10) / CALI_OFFSET_GAIN;
}

/***************************************************************************
*   brief  Clear Vbulk OV Fault
*   note   
****************************************************************************/
void MoniDC_Clear_Vbulk_OVFault(void)
{
	tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1OVP = FALSE;
	tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover;
}

/***************************************************************************
*   brief  Clear Vbulk UV Fault
*   note   
****************************************************************************/
/*
void MoniDC_Clear_Vbulk_UVFault(void)
{
	tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1UVP = FALSE;
	tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sUVP.eTriggerType = TriggerDisable;
}
*/
/***************************************************************************
*   brief  Start Monitor Vbulk UV Fault
*   note   
****************************************************************************/
void MoniDC_Check_Vbulk_UVFault(void)
{
	tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sUVP.eTriggerType = TriggerAutoRecover;
    tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sUVW.eTriggerType = TriggerAutoRecover;
}

/***************************************************************************
*   brief  Return DC source address
*   note   
****************************************************************************/
sMoniDC_t* GetMoniDCRef(eMoniDCTag_t eTag)
{
	return &tsMoniDC[eTag];
}

/****************************************************************************
*	Brief	Monitor DC initialize
*	Note	
****************************************************************************/
void MoniDC_Initialize(void)
{
    u16_t i;
	
    for (i=0; i<MoniDC_Tag_Num; i++)
    {
        memset(&tsMoniDC[i], 0, sizeof(tsMoniDC[i]));
    }

	tsMoniDC[MoniDC_Tag_Vbulk].eType = MoniDC_Type_VBulk;
	tsMoniDC[MoniDC_Tag_VAux1].eType = MoniDC_Type_VAux;
	tsMoniDC[MoniDC_Tag_VAux2].eType = MoniDC_Type_VAux;

	tsMoniDC[MoniDC_Tag_Vbulk].psCali = Calibration_GetCoefficient(eCalibration_Tag_VBus);
	tsMoniDC[MoniDC_Tag_VAux1].psCali = Calibration_GetCoefficient(eCalibration_Tag_VAuxiliary);
	tsMoniDC[MoniDC_Tag_VAux2].psCali = Calibration_GetCoefficient(eCalibration_Tag_VAuxiliary);

	for (i=0; i<MoniDC_Tag_Num; i++)
    {
		tsMoniDC[i].eTag = (eMoniDCTag_t)i;
		
		UpdateMoniDCCalibration((eMoniDCTag_t)i);
		
		if (tsMoniDC[i].eType == MoniDC_Type_VBulk)
		{
            /* VBulk Good */
			tsMoniDC[i].sConfig.sSourceGood.eTriggerType = TriggerAutoRecover;
			tsMoniDC[i].sConfig.sSourceGood.i16SetThresholdHigh = BULK_DcGood_ThresholdSetHigh;
			tsMoniDC[i].sConfig.sSourceGood.i16SetThresholdLow = BULK_DcGood_ThresholdSetLow;
			tsMoniDC[i].sConfig.sSourceGood.i16ClearThresholdHigh = BULK_DcGood_ThresholdClearHigh;
			tsMoniDC[i].sConfig.sSourceGood.i16ClearThresholdLow = BULK_DcGood_ThresholdClearLow;
			tsMoniDC[i].sConfig.sSourceGood.sConst.u16SetDelay = BULK_DcGood_SetDelay;
			tsMoniDC[i].sConfig.sSourceGood.sConst.u16ClearDelay = BULK_DcGood_ClearDelay;
			tsMoniDC[i].sConfig.sSourceGood.sVar.u16SetDelay = tsMoniDC[i].sConfig.sSourceGood.sConst.u16SetDelay;
			tsMoniDC[i].sConfig.sSourceGood.sVar.u16ClearDelay = tsMoniDC[i].sConfig.sSourceGood.sConst.u16ClearDelay;

            /* VBulk OVP */
			tsMoniDC[i].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover;
			tsMoniDC[i].sConfig.sOVP.nTriggerType.u16Bits.u2WarningEnable = TriggerAutoRecover;
			tsMoniDC[i].sConfig.sOVP.i16ProtectThreshold = BULK_OVP_FastThreshold;
			tsMoniDC[i].sConfig.sOVP.i16WarningThreshold = BULK_OVP_SlowThreshold;
			tsMoniDC[i].sConfig.sOVP.i16RecoverThreshold = BULK_OVP_ClearThreshold;
			tsMoniDC[i].sConfig.sOVP.sConst.u16ProtectDelay = BULK_OVP_FastDelay;
			tsMoniDC[i].sConfig.sOVP.sConst.u16WarningDelay = BULK_OVP_SlowDelay;
			tsMoniDC[i].sConfig.sOVP.sConst.u16RecoverDelay = BULK_OVP_ClearDelay;
			tsMoniDC[i].sConfig.sOVP.sVar.u16ProtectDelay = tsMoniDC[i].sConfig.sOVP.sConst.u16ProtectDelay;
			tsMoniDC[i].sConfig.sOVP.sVar.u16WarningDelay = tsMoniDC[i].sConfig.sOVP.sConst.u16WarningDelay;
			tsMoniDC[i].sConfig.sOVP.sVar.u16RecoverDelay = tsMoniDC[i].sConfig.sOVP.sConst.u16RecoverDelay;

            /* VBulk OVW */
            tsMoniDC[i].sConfig.sOVW.eTriggerType = TriggerAutoRecover;
            tsMoniDC[i].sConfig.sOVW.eLimitType   = Limit_Upper;
            tsMoniDC[i].sConfig.sOVW.u16SetBits   = MOMIDC_Bits_OVW;
            tsMoniDC[i].sConfig.sOVW.i16SetThreshold = BULK_OVW_SetThreshold;
            tsMoniDC[i].sConfig.sOVW.i16ClearThreshold = BULK_OVW_ClearThreshold;
            tsMoniDC[i].sConfig.sOVW.sConst.u16SetDelay = BULK_OVW_SetDelay;
            tsMoniDC[i].sConfig.sOVW.sConst.u16ClearDelay = BULK_OVW_ClearDelay;
            tsMoniDC[i].sConfig.sOVW.sVar.u16SetDelay = tsMoniDC[i].sConfig.sOVW.sConst.u16SetDelay;
            tsMoniDC[i].sConfig.sOVW.sVar.u16ClearDelay = tsMoniDC[i].sConfig.sOVW.sConst.u16ClearDelay;

            /* VBulk UVP */
			tsMoniDC[i].sConfig.sUVP.eTriggerType = TriggerDisable;
			tsMoniDC[i].sConfig.sUVP.i16SetThreshold = BULK_UVP_SetThreshold;
			tsMoniDC[i].sConfig.sUVP.i16ClearThreshold = BULK_UVP_ClearThreshold;
			tsMoniDC[i].sConfig.sUVP.sConst.u16SetDelay = BULK_UVP_SetDelay;
			tsMoniDC[i].sConfig.sUVP.sConst.u16ClearDelay = BULK_UVP_ClearDelay;
			tsMoniDC[i].sConfig.sUVP.sVar.u16SetDelay = tsMoniDC[i].sConfig.sUVP.sConst.u16SetDelay;
			tsMoniDC[i].sConfig.sUVP.sVar.u16ClearDelay = tsMoniDC[i].sConfig.sUVP.sConst.u16ClearDelay;

			/* VBulk UVW */
            tsMoniDC[i].sConfig.sUVW.eTriggerType = TriggerDisable;
            tsMoniDC[i].sConfig.sUVW.eLimitType   = Limit_Lower;
            tsMoniDC[i].sConfig.sUVW.u16SetBits   = MOMIDC_Bits_UVW;
            tsMoniDC[i].sConfig.sUVW.i16SetThreshold = BULK_UVW_SetThreshold;
            tsMoniDC[i].sConfig.sUVW.i16ClearThreshold = BULK_UVW_ClearThreshold;
            tsMoniDC[i].sConfig.sUVW.sConst.u16SetDelay = BULK_UVW_SetDelay;
            tsMoniDC[i].sConfig.sUVW.sConst.u16ClearDelay = BULK_UVW_ClearDelay;
            tsMoniDC[i].sConfig.sUVW.sVar.u16SetDelay = tsMoniDC[i].sConfig.sUVW.sConst.u16SetDelay;
            tsMoniDC[i].sConfig.sUVW.sVar.u16ClearDelay = tsMoniDC[i].sConfig.sUVW.sConst.u16ClearDelay;
		}
		else if (tsMoniDC[i].eType == MoniDC_Type_VAux)
		{
			tsMoniDC[i].sConfig.sSourceGood.eTriggerType = TriggerAutoRecover;
			tsMoniDC[i].sConfig.sSourceGood.i16SetThresholdHigh = AUX_DcGood_ThresholdSetHigh;
			tsMoniDC[i].sConfig.sSourceGood.i16SetThresholdLow = AUX_DcGood_ThresholdSetLow;
			tsMoniDC[i].sConfig.sSourceGood.i16ClearThresholdHigh = AUX_DcGood_ThresholdClearHigh;
			tsMoniDC[i].sConfig.sSourceGood.i16ClearThresholdLow = AUX_DcGood_ThresholdClearLow;
			tsMoniDC[i].sConfig.sSourceGood.sConst.u16SetDelay = AUX_DcGood_SetDelay;
			tsMoniDC[i].sConfig.sSourceGood.sConst.u16ClearDelay = AUX_DcGood_ClearDelay;			
			tsMoniDC[i].sConfig.sSourceGood.sVar.u16SetDelay = tsMoniDC[i].sConfig.sSourceGood.sConst.u16SetDelay;
			tsMoniDC[i].sConfig.sSourceGood.sVar.u16ClearDelay = tsMoniDC[i].sConfig.sSourceGood.sConst.u16ClearDelay;

			tsMoniDC[i].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover;
			tsMoniDC[i].sConfig.sOVP.nTriggerType.u16Bits.u2WarningEnable = TriggerAutoRecover;
			tsMoniDC[i].sConfig.sOVP.i16ProtectThreshold = AUX_OVP_SetThreshold;
			tsMoniDC[i].sConfig.sOVP.i16WarningThreshold = AUX_OVP_SetThreshold;
			tsMoniDC[i].sConfig.sOVP.i16RecoverThreshold = AUX_OVP_ClearThreshold;
			tsMoniDC[i].sConfig.sOVP.sConst.u16ProtectDelay = AUX_OVP_SetDelay;
			tsMoniDC[i].sConfig.sOVP.sConst.u16WarningDelay = AUX_OVP_SetDelay;
			tsMoniDC[i].sConfig.sOVP.sConst.u16RecoverDelay = AUX_OVP_ClearDelay;
			tsMoniDC[i].sConfig.sOVP.sVar.u16ProtectDelay = tsMoniDC[i].sConfig.sOVP.sConst.u16ProtectDelay;
			tsMoniDC[i].sConfig.sOVP.sVar.u16WarningDelay = tsMoniDC[i].sConfig.sOVP.sConst.u16WarningDelay;
			tsMoniDC[i].sConfig.sOVP.sVar.u16RecoverDelay = tsMoniDC[i].sConfig.sOVP.sConst.u16RecoverDelay;

			tsMoniDC[i].sConfig.sUVP.eTriggerType = TriggerAutoRecover;
			tsMoniDC[i].sConfig.sUVP.i16SetThreshold = AUX_UVP_SetThreshold;
			tsMoniDC[i].sConfig.sUVP.i16ClearThreshold = AUX_UVP_ClearThreshold;
			tsMoniDC[i].sConfig.sUVP.sConst.u16SetDelay = AUX_UVP_SetDelay;
			tsMoniDC[i].sConfig.sUVP.sConst.u16ClearDelay = AUX_UVP_ClearDelay;
			tsMoniDC[i].sConfig.sUVP.sVar.u16SetDelay = tsMoniDC[i].sConfig.sUVP.sConst.u16SetDelay;
			tsMoniDC[i].sConfig.sUVP.sVar.u16ClearDelay = tsMoniDC[i].sConfig.sUVP.sConst.u16ClearDelay;
		}		
    }

	tsMoniDC[MoniDC_Tag_Vbulk].pu16ADC_Q12 = &GET_ADCFilter_DC_VBulk_OVP1;
	tsMoniDC[MoniDC_Tag_Vbulk].pu16ADC1_Q12 = &GET_ADCFilter_DC_VBulk_DET;
	tsMoniDC[MoniDC_Tag_Vbulk].pu16ADC2_Q12 = &GET_ADCFilter_DC_VBulk_OVP2;
	tsMoniDC[MoniDC_Tag_VAux1].pu16ADC_Q12 = &GET_ADCFilter_DC_VAUX1;
	tsMoniDC[MoniDC_Tag_VAux2].pu16ADC_Q12 = &GET_ADCFilter_DC_VAUX2;
}

