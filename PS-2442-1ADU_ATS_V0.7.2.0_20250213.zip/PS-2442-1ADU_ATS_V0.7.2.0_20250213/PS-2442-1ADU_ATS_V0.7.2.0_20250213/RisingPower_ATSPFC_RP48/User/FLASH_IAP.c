/** @file       FLASH_IAP.c
 *  @author     Adonis Wang
 *  @brief      In Application Programming
 *  @version    2.0
 *  @history    modify from ollie chen
 */

#include <string.h>
#include "F28x_Project.h"
#include "CONFIG_RisingPower.h"
#include "FLASH_CommonRam.h"
#include "FLASH_IAP.h"
#include "Peripheral.h"
#include "SERV_CRC.h"
#include "Handler_ATS.h"
#include "CANBus_Server.h"



/****************************************************************************
	Private parameter definition
****************************************************************************/

/* Active image Flash Sector */
#define ACTIVE_IMAGE_FLASH_SECTOR       (FLASH_B0_S4 | FLASH_B0_S5 | FLASH_B0_S6 | FLASH_B0_S7 | FLASH_B0_S8 | FLASH_B0_S9 | FLASH_B0_S10 | FLASH_B0_S11 | FLASH_B0_S12 | FLASH_B0_S13 | FLASH_B0_S14 | FLASH_B0_S15)

/* Backup image Flash Sector */
#define BACKUP_IMAGE_FLASH_SECTOR       (FLASH_B1_S4 | FLASH_B1_S5 | FLASH_B1_S6 | FLASH_B1_S7 | FLASH_B1_S8 | FLASH_B1_S9 | FLASH_B1_S10 | FLASH_B1_S11 | FLASH_B1_S12 | FLASH_B1_S13 | FLASH_B1_S14 | FLASH_B1_S15)

#define UAP_IMAGE_VALID_KEY             0x55AA

/** Word length of UAP stamp, In order to coordinate with Flash programming by ECC feature,
 *  This size should be 8 words
 */
#define UAP_IMAGE_STAMP_SIZE            8

// Program information block size
#define PIB_SIZE                		60

// Revision Control Block size
#define RCB_SIZE                		76


/****************************************************************************
	Private macro definition
****************************************************************************/


#define IAP_FLAG_BIT_ERASE_BACKUP_IMAGE				(0x0001)
#define IAP_FLAG_BIT_VERIFY_IMAGE_CHECKSUM			(0x0002)
#define IAP_FLAG_BIT_INSPECT_BACKUP_IMAGE			(0x0004)
#define IAP_FLAG_BIT_ASKING_PERMISSION				(0x0008)
#define IAP_FLAG_BIT_SWITCH_MODE					(0x0010)


#define UapCodeEntry        (void   (*)(void))ACTIVE_IMAGE_UAP_ADDRESS
#define BootCodeEntry       (void   (*)(void))BOOT_ENTRY_ADDRESS



/****************************************************************************
	Private enumeration definition
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 542 -> 160
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(IAP_IsSupportedMcuType, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_IsValidCodeID, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_IsHWCompatibleImage, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_IsFWCompatibleImage, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_IsImageHeaderAcceptable, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_EraseBackupImage, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_VerifyImageChecksum, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_IsValidImage, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_WriteImageStamp, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_InspectImageAttribute, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_InspectBackupImage, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_AskingSwitchPermission, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_SwitchMode, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_Background_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_Reset, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_ReceiveBuff_Reset, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_Program_START, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_HEADER_START, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_HEADER_DTAT, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_HEADER_STOP, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_BLOCK_START, ".TI.ramfunc");
#pragma CODE_SECTION(IAP_BLOCK_DTAT, ".TI.ramfunc");
#pragma CODE_SECTION(IAP_BLOCK_STOP, ".TI.ramfunc");
//#pragma CODE_SECTION(IAP_Program_STOP, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declare
****************************************************************************/
/**
 *  @brief  Application stamp is used to identify application image is valid or NOT
 *  @note   This variable should be located at specified address and only be declared in application image
 */

#pragma DATA_SECTION (pu16ApplicationStamp, "APP_STAMP_SEC");
const u16_t pu16ApplicationStamp[UAP_IMAGE_STAMP_SIZE] = {UAP_IMAGE_VALID_KEY, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000};


/**
 *  @brief  Declare Program information block
 *  @note	Reserved
 */

#pragma DATA_SECTION (pu16ProgramInfoBlock, "APP_PIB_SEC");

const u16_t pu16ProgramInfoBlock[PIB_SIZE] =
{
	0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
	0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF,
	0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
	0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF,
	0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
	0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF,
	0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
	0x88, 0x99, 0xAA, 0xBB
};


/**
 *  @brief  Declare Revision Control Block
 *  @note	Reserved
 */

#pragma DATA_SECTION (pu16RevisionControlBlock, "APP_RCB_SEC");

const u16_t pu16RevisionControlBlock[RCB_SIZE] =
{
	0x00FF, 0x0000, 0x000F, 0xFFF0, 0x00FF, 0xFFFF, 0x00FF, 0xFFFF,
	0x000F, 0xFFF0, 0x00FF, 0x00FF, 0x0000, 0x0000, 0x0000, 0x0000,
	0x00FF, 0x0000, 0x0000, 0xFF00, 0x0000, 0xFF00, 0x00FF, 0x0000,
	0x00FF, 0x00FF, 0x00FF, 0xF0FF, 0x0000, 0x0000, 0x0000, 0x0000,
	0x00FF, 0x0000, 0x0000, 0xFF00, 0x0000, 0xFF00, 0x00FF, 0xFFFF,
	0x00F0, 0x000F, 0x00FF, 0xFFFF, 0x0000, 0x0000, 0x0000, 0x0000,
	0x00FF, 0x0000, 0x0000, 0xFF00, 0x0000, 0xFF00, 0x00FF, 0x0000,
	0x00FF, 0x00FF, 0x00FF, 0x0FFF, 0x0000, 0x0000, 0x0000, 0x0000,
	0x00FF, 0xFFFF, 0x000F, 0xFFF0, 0x0000, 0xFF00, 0x00FF, 0xFFFF,
	0x000F, 0xFFF0, 0x00FF, 0x00FF
};


sIapHandler_t tsIapHandler;


/**
 *  @brief  Enter UAP Mode Process
 *  @retval None
 */
static void Main_EnterUapMode(void)
{
    /* Disable all interrupt and clear all interrupt flags */
    DINT;
    IER = 0x0000;
    IFR = 0x0000;
    
    /* Jump to UAP Code */
    (*UapCodeEntry)();
}


/**
 *  @brief  Enter Boot Mode Process
 *  @retval None
 */
static void Main_EnterBootMode(void)
{
    /* Disable all interrupt and clear all interrupt flags */
    DINT;
    IER = 0x0000;
    IFR = 0x0000;
    
    /* Jump to Boot Code */
    (*BootCodeEntry)();
}

/**
 *  @brief  IAP request callback handler
 *  @param  u16Request: Request send from IAP
 *  @retval FALSE: Request had been denied
 *  @retval TRUE: Request had been accepted
 */
static u16_t Main_IapRequest_Handler(u16_t u16Request)
{
    u16_t u16Response = RequestDenied;
    
    switch (u16Request)
    {
        case eIAP_ASKING_PERMIT_TO_SWITCH_MODE:
			u16Response = Is_Ready_to_Switch();
            break;

        case eIAP_REQUEST_ENTER_UAP_MODE:
                   
            // Stop Peripheral
            Peripheral_Stop();
            
            // Enter UAP Mode
            Main_EnterUapMode();
            break;    

        case eIAP_REQUEST_ENTER_BOOT_MODE:

            // Stop Peripheral
            Peripheral_Stop();
            
            // Enter Boot Mode
            Main_EnterBootMode();
            break;
         
        default:
            u16Response = RequestDenied;
            break;
    }
	
    return u16Response;
}


/**
 *  @brief  Check target MCU type is supported
 *  @note   According to PSU Upgrade Protocol, MCU type is the same as boot loader location
 *          This function is a part of verify image header progress
 *  @param  u8McuType: This value could be one of following values
 *                      -@arg MCU_TYPE_PRIMARY (0x01): Primary MCU 
 *                      -@arg MCU_TYPE_SECONDARY (0x02): Secondary MCU
 *                      -@arg MCU_TYPE_ATS (0x03): ATS MCU
 *  @retval FALSE: Target MCU type is not supported
 *  @retval TRUE: Target MCU type is supported
 */
static u16_t IAP_IsSupportedMcuType(u8_t u8McuType)
{
    if (u8McuType == MCU_TYPE)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 *  @brief  Check Image code ID is suitable with Device ID
 *  @note   This function is a part of verify image header progress
 *  @param  pu8ImageCodeID: Pointer to start byte to Code ID
 *  @retval FALSE: Code ID is mismatched
 *  @retval TRUE: Code ID is suitable
 */
static u16_t IAP_IsValidCodeID(u8_t* pu8ImageCodeID)
{
    if (strncmp(DEVICE_ID, (const char*)pu8ImageCodeID, DEVICE_ID_LEN) == 0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 *  @brief  Check Image is suitable with current hardware
 *  @param  pu8ImageHWCC: Pointer to Hardware Compatible Code of Image with ASCII format
 *  @retval FALSE: Image and hardware is conflict
 *  @retval TRUE: Image and hardware is suitable
 */
static u16_t IAP_IsHWCompatibleImage(u8_t* pu8ImageHWCC)
{   
    if (strncmp(HARDWARE_COMPATIBLE_REVISION, (const char*)pu8ImageHWCC, DEVICE_FWCR_LEN) == 0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 *  @brief  Check Image is suitable with current Firmware
 *  @param  pu8ImageFWCC: Pointer to Firmware Compatible Code of Image with ASCII format
 *  @retval FALSE: Image and Firmware is conflict
 *  @retval TRUE: Image and Firmware is suitable
 */
static u16_t IAP_IsFWCompatibleImage(u8_t pu8ImageFWCC)
{
	i16_t iImageFWCC = (i16_t)pu8ImageFWCC;
	
    if (iImageFWCC >= FIRMWARE_COMPATIBLE_REVISION)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 *  @brief  Check Image header is acceptable
 *  @param  pu8Header: Pointer to start byte of image header
 *  @retval FALSE:
 *  @retval TRUE:
 */
static u16_t IAP_IsImageHeaderAcceptable(void)
{
    memcpy(&tsIapHandler.sImageHeader, tsIapHandler.pu8UploadData, IMAGE_HEADER_SIZE);
    
    if ((IAP_IsSupportedMcuType(*tsIapHandler.sImageHeader.pu8Location) == TRUE) &&
        (IAP_IsValidCodeID(tsIapHandler.sImageHeader.pu8CodeID) == TRUE) &&
        (IAP_IsHWCompatibleImage(tsIapHandler.sImageHeader.pu8ImageHWCC) == TRUE) &&
        (IAP_IsFWCompatibleImage(*tsIapHandler.sImageHeader.pu8MajorRevision) == TRUE))
    {
    	tsIapHandler.u32MaxProgramBlocks_image = (u32_t)(__LByteToWord(tsIapHandler.sImageHeader.pu8LastIndex));		
		tsIapHandler.nStatus.u8Bits.u1ImageReceiving = 1;
				
        return TRUE;
    }
    else
    {
    	tsIapHandler.nStatus.u8Bits.u1UnsupportedImage = 1;
		
        return FALSE;
    }
}

/**
 *  @brief  Erase backup image
 *  @retval None
 */
static inline void IAP_EraseBackupImage(void)
{
	tsIapHandler.nProgressFlag.u16Bits.u1Erasebackupimage = 0;

	if (PeriFlash_Erase(BACKUP_IMAGE_FLASH_SECTOR) == FALSE)
	{
		tsIapHandler.nStatus.u8Bits.u1RecoverCorruptImage = 1;
		PeriDacB_SetValue(PERI_DAC_0V0);
	}
	else
	{
		PeriDacB_SetValue(PERI_DAC_1V5);
	}
}

/**
 *  @brief  Verify Image Checksum
 *  @retval None
 */
static inline void IAP_VerifyImageChecksum(void)
{
	tsIapHandler.nProgressFlag.u16Bits.u1VerifyImageChecksum = 0;

	if (tsIapHandler.u16FileCrc == __LByteToWord(tsIapHandler.sImageHeader.pu8ImageCRC))
    {
    	tsIapHandler.nProgressFlag.u16Bits.u1DenyUpload = 1;
        tsIapHandler.nProgressFlag.u16Bits.u1InspectBackupImage = 1;
    }
    else
    {
        tsIapHandler.nStatus.u8Bits.u1RecoverCorruptImage = 1;
    }
}

/**
 *  @breif  Check Image Stamp
 *  @param  sImageLocator: Value of sImageLocator_t type Structure which contents the stamp location
 *  @retval FALSE: Image is not valid
 *  @retval TRUE: Image is valid
 */
static u16_t IAP_IsValidImage(sImageLocator_t sImageLocator)
{
    if (*((u32_t*)sImageLocator.u32Address_Stamp) == UAP_IMAGE_VALID_KEY)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 *  @brief  Write Image Stamp
 *  @param  sImageLocator: Value of sImageLocator_t type Structure which contents the stamp location
 *  @retval FALSE: Write Image Stamp Failed
 *  @retval TRUE: Write Image Stamp Success
 */
static u16_t IAP_WriteImageStamp(sImageLocator_t sImageLocator)
{
//    u16_t pu16ImageStamp[8] = {UAP_IMAGE_VALID_KEY, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000};
//    return (PeriFlash_Program(sImageLocator.u32Address_Stamp, pu16ImageStamp, 8));

    return (PeriFlash_Program(sImageLocator.u32Address_Stamp, tsIapHandler.u16StoreImageStamp, 8));
}

/**
 *  @brief  Check image key and write image stamp
 *  @retval FALSE: image stamp is invalid
 *  @retval TRUE: image stamp is valid
 */
static u16_t IAP_InspectImageAttribute(sImageLocator_t sLocator)
{
	if (IAP_IsValidImage(sLocator) == TRUE)
	{
		return TRUE;
	}
	else if (IAP_WriteImageStamp(sLocator) == TRUE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/**
 *  @brief  Inspect Backup Image
 *  @retval None
 */
static inline void IAP_InspectBackupImage(void)
{
	tsIapHandler.nProgressFlag.u16Bits.u1InspectBackupImage = 0;

    if (IAP_InspectImageAttribute(tsIapHandler.psImageLocator[eIMAGE_TAG_BACKUP]) == TRUE)
    {
    	tsIapHandler.nProgressFlag.u16Bits.u1AskingPermission = 1;
        tsIapHandler.nStatus.u8Bits.u1ImageReceiving = 0;
        tsIapHandler.nStatus.u8Bits.u1FullyImageReceived = 1;
    }
    else
    {
    	tsIapHandler.nProgressFlag.u16Bits.u1DenyUpload = 0;
        tsIapHandler.nStatus.u8Bits.u1RecoverCorruptImage = 1;
    }   
}

/**
 *  @brief  Asking permission of switch mode to host
 *  @retval None
 */
static inline void IAP_AskingSwitchPermission(void)
{
	tsIapHandler.nProgressFlag.u16Bits.u1AskingPermission = 0;
	
    if (Main_IapRequest_Handler(eIAP_ASKING_PERMIT_TO_SWITCH_MODE) == TRUE)
    {
    	PeriDacB_SetValue(PERI_DAC_3V3);        
        tsIapHandler.nProgressFlag.u16Bits.u1SwitchMode = 1;
    }
}

/**
 *  @brief  Send switch mode request to host
 *  @retval None
 */
static inline void IAP_SwitchMode(void)
{
	CommonRam_PushData(COMMON_RAM_ADDRESS_ProgramBlocks, (u16_t)tsIapHandler.u32TotalProgramBlocks);
    CommonRam_PushData(COMMON_RAM_ADDRESS_STARTUP_TYPE, DEVICE_WARM_STARTUP);
    Main_IapRequest_Handler(eIAP_REQUEST_ENTER_BOOT_MODE);
}

/**
 *  @brief  IAP background Process
 *  @retval None
 */
void IAP_Background_Process(void)
{
    switch (tsIapHandler.nProgressFlag.u16All & 0x00FF)
    {
        case IAP_FLAG_BIT_ERASE_BACKUP_IMAGE:
            IAP_EraseBackupImage();
            break;
            
        case IAP_FLAG_BIT_VERIFY_IMAGE_CHECKSUM:
            IAP_VerifyImageChecksum();
            break;
            
        case IAP_FLAG_BIT_INSPECT_BACKUP_IMAGE:
            IAP_InspectBackupImage();
            break;

		case IAP_FLAG_BIT_ASKING_PERMISSION:
            IAP_AskingSwitchPermission();
            break;
        
        case IAP_FLAG_BIT_SWITCH_MODE:
            IAP_SwitchMode();
            break;
      
        default:
            break;
    }
}

/**
 *  @brief  Reset IAP upload progress
 *  @retval None
 */
static inline void IAP_Reset(void)
{
    tsIapHandler.u32TotalProgramBlocks = 0;
    tsIapHandler.nProgressFlag.u16All = 0;
	tsIapHandler.nStatus.u8All = 0;
    tsIapHandler.u16FileCrc = 0x0000;
	memset(tsIapHandler.pu16ProgramData, 0, sizeof(tsIapHandler.pu16ProgramData));
}

/**
 *  @brief  Reset IAP Receive buff data
 *  @retval None
 */
static void IAP_ReceiveBuff_Reset(void)
{
	tsIapHandler.u8ReceiveIndex = 0;
	tsIapHandler.u8FileCrc8 = 0x00;
	memset(tsIapHandler.pu8UploadData, 0, sizeof(tsIapHandler.pu8UploadData));
	memset(tsIapHandler.pu8ReceiveData, 0, sizeof(tsIapHandler.pu8ReceiveData));
}

/**
 *  @brief  IAP Programming - Start
 *  @Note	Call back from CANbus
 */
void IAP_Program_START(void)
{
    tsIapHandler.u8FWUpdateACK = 0;
	tsIapHandler.u16LED_Indicator_CNT = 1;
}

/**
 *  @brief  IAP Programming - header start
 *  @Note	Call back from CANbus
 */
void IAP_HEADER_START(void)
{
	PeriDacB_SetValue(PERI_DAC_0V0);
	IAP_Reset();
	IAP_ReceiveBuff_Reset();
	tsIapHandler.u8FWUpdateACK = 0;
	tsIapHandler.u8ProgramStage = eProgram_HEADER;
}

/**
 *  @brief  IAP Programming - header Data
 *  @Note	Call back from CANbus
 */
void IAP_HEADER_DTAT(void)
{
	if ((tsIapHandler.u8ProgramStage == eProgram_HEADER) && 
		(tsIapHandler.u8ReceiveIndex < 4))
	{
	    u16_t i;
    
    	for (i=0; i<CAN_BUFF_SIZE; i++)
    	{
        	CalCRC8(&tsIapHandler.u8FileCrc8, tsIapHandler.pu8ReceiveData[i]);
    	}
		
		memcpy(tsIapHandler.pu8UploadData + (tsIapHandler.u8ReceiveIndex << 3), tsIapHandler.pu8ReceiveData, CAN_BUFF_SIZE);
		memset(tsIapHandler.pu8ReceiveData, 0, sizeof(tsIapHandler.pu8ReceiveData));
		tsIapHandler.u8ReceiveIndex ++;
	}
}

/**
 *  @brief  IAP Programming - header stop
 *  @Note	Call back from CANbus
 */
void IAP_HEADER_STOP(void)
{
	if ((tsIapHandler.u8ProgramStage == eProgram_HEADER) &&
		(tsIapHandler.u8FileCrc8 == tsIapHandler.u8FileCrc8_PSC) &&
		(tsIapHandler.nProgressFlag.u16Bits.u1DenyUpload == 0))
    {
    	if (IAP_IsImageHeaderAcceptable() == TRUE)
    	{
    		PeriDacB_SetValue(PERI_DAC_1V0);
			tsIapHandler.u8FWUpdateACK = 0;
			tsIapHandler.u8ProgramStage = eProgram_ING;
        	tsIapHandler.nProgressFlag.u16Bits.u1Erasebackupimage = 1;
    	}
		else
		{
			tsIapHandler.u8FWUpdateACK = 2;
			tsIapHandler.u8ProgramStage = eProgram_IDLE;
		}
    }
	else
	{	
		tsIapHandler.u8FWUpdateACK = 1;
		tsIapHandler.u8ProgramStage = eProgram_IDLE;
	}
}

/**
 *  @brief  IAP Programming - header start
 *  @Note	Call back from CANbus
 */
void IAP_BLOCK_START(void)
{
	if (tsIapHandler.nStatus.u8Bits.u1UnsupportedImage == 1)
	{
		tsIapHandler.u8FWUpdateACK = 2;
	}
	else if ((tsIapHandler.nStatus.u8Bits.u1ImageReceiving == 1) &&
			 (tsIapHandler.nStatus.u8Bits.u1UnsupportedImage == 0) &&
			 (tsIapHandler.nStatus.u8Bits.u1RecoverCorruptImage == 0) &&
			 (tsIapHandler.nProgressFlag.u16Bits.u1Erasebackupimage == 0) &&
			 (tsIapHandler.u8ProgramStage == eProgram_ING))
	{		
		IAP_ReceiveBuff_Reset();
		tsIapHandler.u8FWUpdateACK = 0;
		tsIapHandler.u8ProgramStage = eProgram_BLOCK;
	}
	else
	{
		tsIapHandler.u8FWUpdateACK = 1;
	}
}

/**
 *  @brief  IAP Programming - header Data
 *  @Note	Call back from CANbus
 */
void IAP_BLOCK_DTAT(void)
{
	if ((tsIapHandler.u8ProgramStage == eProgram_BLOCK) &&
		(tsIapHandler.u8ReceiveIndex < 8))
	{
		u16_t i;
    
    	for (i=0; i<CAN_BUFF_SIZE; i++)
    	{
        	CalCRC8(&tsIapHandler.u8FileCrc8, tsIapHandler.pu8ReceiveData[i]);
    	}
		
		memcpy(tsIapHandler.pu8UploadData + (tsIapHandler.u8ReceiveIndex << 3), tsIapHandler.pu8ReceiveData, CAN_BUFF_SIZE);
		memset(tsIapHandler.pu8ReceiveData, 0, sizeof(tsIapHandler.pu8ReceiveData));
		tsIapHandler.u8ReceiveIndex ++;
	}
}

/**
 *  @brief  IAP Programming - header stop
 *  @Note	Call back from CANbus
 */
void IAP_BLOCK_STOP(void)
{
	if (tsIapHandler.nStatus.u8Bits.u1UnsupportedImage == 1)
	{
		tsIapHandler.u8FWUpdateACK = 2;
	}
	else if ((tsIapHandler.u8ProgramStage == eProgram_BLOCK) &&
			 (tsIapHandler.u8FileCrc8 == tsIapHandler.u8FileCrc8_PSC) &&
			 (tsIapHandler.nProgressFlag.u16Bits.u1DenyUpload == 0))
	{
		if ((tsIapHandler.u32TotalProgramBlocks == tsIapHandler.u32CurrentProgramBlocks) &&
			(tsIapHandler.u32TotalProgramBlocks <= tsIapHandler.u32MaxProgramBlocks_image))
		{
			u16_t i;
		
			///< receive first ProgramData to last ProgramData
        	/* Calculate CRC since from application image */
        	tsIapHandler.u16FileCrc = CalCRC16(tsIapHandler.u16FileCrc, tsIapHandler.pu8UploadData, IMAGE_BLOCK_SIZE, 0);
        
        	/* Integrate upload data to pu16ProgramData for programming */
        	for (i=0; i<(IMAGE_BLOCK_SIZE>>1); i++)
        	{
            	tsIapHandler.pu16ProgramData[i] = __MByteToWord((tsIapHandler.pu8UploadData+(i<<1)));
        	}

        	/* Mask UAP Image Stamp section */
        	if (tsIapHandler.u32TotalProgramBlocks == 0)
        	{
        		///< Mask first ProgramData, because this is key
        		PeriDacB_SetValue(PERI_DAC_2V0);
        		memcpy(tsIapHandler.u16StoreImageStamp, tsIapHandler.pu16ProgramData, 8); // Store image stamp
            	if (PeriFlash_Program(BACKUP_IMAGE_START_ADDRESS+8, &tsIapHandler.pu16ProgramData[8], (IMAGE_BLOCK_SIZE >> 1) - 8) == FALSE)
            	{
                	tsIapHandler.nStatus.u8Bits.u1RecoverCorruptImage = 1;
            	}
        	}
        	else
        	{
        		///< receive Second ProgramData to last ProgramData
            	/* Program to backup flash sector */
				if (PeriFlash_Program(BACKUP_IMAGE_START_ADDRESS + (tsIapHandler.u32TotalProgramBlocks * (IMAGE_BLOCK_SIZE >> 1)), tsIapHandler.pu16ProgramData,  (IMAGE_BLOCK_SIZE >> 1)) == FALSE)
            	{
            		tsIapHandler.nStatus.u8Bits.u1RecoverCorruptImage = 1;
            	}
        	}

        	tsIapHandler.u32TotalProgramBlocks += 1;
		}
		
		tsIapHandler.u8FWUpdateACK = 0;
		tsIapHandler.u8ProgramStage = eProgram_ING;
	}
	else
	{
		tsIapHandler.u8FWUpdateACK = 1;
		
		if (tsIapHandler.u8ProgramStage == eProgram_BLOCK)
		{
			tsIapHandler.u8ProgramStage = eProgram_ING;
		}		
	}
}

/**
 *  @brief  IAP Programming - STOP
 *  @Note	Call back from CANbus
 */
void IAP_Program_STOP(void)
{
	if (tsIapHandler.nStatus.u8Bits.u1UnsupportedImage == 1)
	{
		tsIapHandler.u8FWUpdateACK = 2;
		tsIapHandler.u16LED_Indicator_CNT = 0;
	}
	else if ((tsIapHandler.nStatus.u8Bits.u1ImageReceiving == 1) &&
			 (tsIapHandler.nStatus.u8Bits.u1UnsupportedImage == 0) &&
			 ((tsIapHandler.u32TotalProgramBlocks - 1) == tsIapHandler.u32MaxProgramBlocks_image) &&
        	 (tsIapHandler.nStatus.u8Bits.u1RecoverCorruptImage == 0) &&
        	 (tsIapHandler.nProgressFlag.u16Bits.u1DenyUpload == 0) &&
        	 (tsIapHandler.u16FileCrc == tsIapHandler.u16FileCrc_PSC))
	{
		///< receive last ProgramData
		PeriDacB_SetValue(PERI_DAC_2V5);
		tsIapHandler.u8FWUpdateACK = 0;
		
		if (tsIapHandler.u8FWAction == 0)
		{
			// Accept FW update
			tsIapHandler.nProgressFlag.u16Bits.u1VerifyImageChecksum = 1;
		}
		else
		{
			// Abort FW update
			tsIapHandler.u8ProgramStage = eProgram_IDLE;
			tsIapHandler.u16LED_Indicator_CNT = 0;
		}
	}
	else
	{
		tsIapHandler.u8ProgramStage = eProgram_IDLE;
		tsIapHandler.u8FWUpdateACK = 1;
		tsIapHandler.u16LED_Indicator_CNT = 0;
	}
}

/**
 *  @brief  Initial IAP Handler
 *  @retval None
 */
void IAP_Initialize(void)
{
    memset(&tsIapHandler, 0, sizeof(tsIapHandler));
    
    tsIapHandler.psImageLocator[eIMAGE_TAG_ACTIVE].u32Address_Stamp = ACTIVE_IMAGE_STAMP_ADDRESS;
    tsIapHandler.psImageLocator[eIMAGE_TAG_ACTIVE].u32Address_PIB = ACTIVE_IMAGE_PIB_ADDRESS;
    tsIapHandler.psImageLocator[eIMAGE_TAG_ACTIVE].u32Address_RCB = ACTIVE_IMAGE_RCB_ADDRESS;
    tsIapHandler.psImageLocator[eIMAGE_TAG_ACTIVE].u32Address_UAP = ACTIVE_IMAGE_UAP_ADDRESS;

    tsIapHandler.psImageLocator[eIMAGE_TAG_BACKUP].u32Address_Stamp = BACKUP_IMAGE_STAMP_ADDRESS;
    tsIapHandler.psImageLocator[eIMAGE_TAG_BACKUP].u32Address_PIB = BACKUP_IMAGE_PIB_ADDRESS;
    tsIapHandler.psImageLocator[eIMAGE_TAG_BACKUP].u32Address_RCB = BACKUP_IMAGE_RCB_ADDRESS;
    tsIapHandler.psImageLocator[eIMAGE_TAG_BACKUP].u32Address_UAP = BACKUP_IMAGE_UAP_ADDRESS;

    tsIapHandler.nStatus.u8All = 0;
	tsIapHandler.u32FW_Release_Date = FIRMWARE_RELEASE_DATE;
	tsIapHandler.u8FWUpdateACK = 0;
	tsIapHandler.u8ProgramStage = eProgram_IDLE;

	memcpy(tsIapHandler.sCompatibility.pu8HardwareCompatibleCode, HARDWARE_COMPATIBLE_REVISION, DEVICE_FWCR_LEN);

	tsIapHandler.sImageRevision.u8MajorRevision = (u8_t)FIRMWARE_MAJOR_REVISION;
    tsIapHandler.sImageRevision.u8MiniorRevision = (u8_t)FIRMWARE_MINOR_REVISION;

	tsIapHandler.u32InternalRevision = (u32_t)FIRMWARE_MAJOR_REVISION + (((u32_t)FIRMWARE_MINOR_REVISION) << 8) + (((u32_t)FW_INTERNAL_REVISION) << 16) + (((u32_t)HARDWARE_COMPATIBLE_REVISION_) << 24);

	/* Initial Device startup type on Common RAM*/
	CommonRam_PushData(COMMON_RAM_ADDRESS_STARTUP_TYPE, DEVICE_COLD_STARTUP);


}
