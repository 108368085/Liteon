/****************************************************************************
 *	File	Monitor_AC.c
 * 	Brief	AC input signals handler
 * 			- Vac1
 * 			- Vac2
 * 			- Vac (PFC input Voltage)
 * 			- Iac (PFC input Current)
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/25 - 1st release
 ****************************************************************************/
#include <string.h>
#include <math.h>
#include "F28x_Project.h"
#include "Monitor_AC.h"
#include "SERV_ADCFilter.h"
#include "CONFIG_RisingPower.h"
#include "Peripheral.h"
#include "SERV_LOG.h"
#include "SERV_FFT.h"
#include "Handler_ATS.h"
#include "Monitor_TP.h"




/****************************************************************************
*	Private parameter definition 
****************************************************************************/
/* AC Monitor Configuration */

#define MOMIAC_Bits_Dropout						0x0004
#define MOMIAC_Bits_UVW							0x0008
#define MOMIAC_Bits_UVP							0x0010
#define MOMIAC_Bits_OVW							0x0020
#define MOMIAC_Bits_OVP							0x0040
#define MOMIAC_Bits_OCW							0x0080
#define MOMIAC_Bits_OCP							0x0100
#define MOMIAC_Bits_OPW							0x0800
#define MOMIAC_Bits_OPP							0x1000
#define MOMIAC_Bits_OHW							0x2000
#define MOMIAC_Bits_OHP							0x4000
#define MOMIAC_Bits_OVPH						0x8000

#define ISO_Sensor_Delay						500			// unit is ms
#define ReportRMS_Delay                         16          // unit is ms



#define Dropout_SetThreshold					970		    // unit is 0.1V
#define Dropout_ClearThreshold					1160		// unit is 0.1V
#define Dropout_SetThreshold_DC					1300		// unit is 0.1V
#define Dropout_ClearThreshold_DC				1500		// unit is 0.1V
#define Dropout_SetDelay						0			// unit is ms
#define Dropout_ClearDelay						ISO_Sensor_Delay			// unit is ms, delay for ISO voltage sensor issue

#define UVP_SetThreshold						1650		// unit is 0.1V
#define UVP_ClearThreshold						1700		// unit is 0.1V
#define UVP_SetThreshold_DC						2200		// unit is 0.1V
#define UVP_ClearThreshold_DC					2250		// unit is 0.1V
#define UVP_SetDelay							0			// unit is ms
#define UVP_ClearDelay							ISO_Sensor_Delay			// unit is ms, delay for ISO voltage sensor issue

#define UVW_SetThreshold						1720		// unit is 0.1V
#define UVW_ClearThreshold						1770		// unit is 0.1V
#define UVW_SetThreshold_DC						2300		// unit is 0.1V
#define UVW_ClearThreshold_DC					2350		// unit is 0.1V
#define UVW_SetDelay							0			// unit is ms
#define UVW_ClearDelay							200			// unit is ms

#define OVW_SetThreshold						3050		// unit is 0.1V
#define OVW_ClearThreshold						3000		// unit is 0.1V
#define OVW_SetThreshold_DC						4350		// unit is 0.1V
#define OVW_ClearThreshold_DC					4300		// unit is 0.1V
#define OVW_SetDelay							100			// unit is ms
#define OVW_ClearDelay							200			// unit is ms

#define OVP_SetThreshold						3150		// unit is 0.1V
#define OVP_ClearThreshold						3100		// unit is 0.1V
#define OVP_SetThreshold_DC						4400		// unit is 0.1V
#define OVP_ClearThreshold_DC					4350		// unit is 0.1V
#define OVP_SetDelay							100			// unit is ms
#define OVP_ClearDelay							200			// unit is ms

#define OVPH_SetThreshold						3200		// unit is 0.1V
#define OVPH_ClearThreshold						3070		// unit is 0.1V
#define OVPH_SetThreshold_DC					4800		// unit is 0.1V
#define OVPH_ClearThreshold_DC					4350		// unit is 0.1V
#define OVPH_SetDelay							0			// unit is ms
#define OVPH_ClearDelay							200			// unit is ms


#define SourcePresent_ClearThresholdHigh		OVPH_SetThreshold
#define SourcePresent_SetThresholdHigh			OVP_SetThreshold		// align with OVP for inrush R thermal issue
#define SourcePresent_SetThresholdLow			1600        //
#define SourcePresent_ClearThresholdLow			1550        //
#define SourcePresent_ClearThresholdHigh_DC		OVP_SetThreshold_DC
#define SourcePresent_SetThresholdHigh_DC		4350
#define SourcePresent_SetThresholdLow_DC		2000
#define SourcePresent_ClearThresholdLow_DC		1700
#define SourcePresent_SetDelay					ISO_Sensor_Delay			// unit is ms, delay for ISO voltage sensor issue
#define SourcePresent_ClearDelay				0			// unit is ms

#define SourceGood_ClearThresholdHigh			OVPH_SetThreshold
#define SourceGood_SetThresholdHigh				OVP_SetThreshold		// align with OVP for inrush R thermal issue
#define SourceGood_SetThresholdLow				1760		// unit is 0.1V
#define SourceGood_ClearThresholdLow			UVP_SetThreshold
#define SourceGood_ClearThresholdHigh_DC		OVP_SetThreshold_DC
#define SourceGood_SetThresholdHigh_DC			4350
#define SourceGood_SetThresholdLow_DC			UVW_ClearThreshold_DC
#define SourceGood_ClearThresholdLow_DC			UVP_SetThreshold_DC
#define SourceGood_SetDelay						50			// unit is ms, change to Observed window
#define SourceGood_ClearDelay					0			// unit is ms

#define OCP_SetThreshold						28800		// unit is 0.001A (4300W/180Vac)x1.2
#define OCP_ClearThreshold						26800		// unit is 0.001A
#define OCP_SetDelay							2000		// unit is ms
#define OCP_ClearDelay							2000		// unit is ms

#define OCW_SetThreshold						18000		// unit is 0.001A
#define OCW_ClearThreshold						16000		// unit is 0.001A
#define OCW_SetDelay							2000		// unit is ms
#define OCW_ClearDelay							2000		// unit is ms

#define OPP_SetThreshold						6000		// unit is 1W,	4.2KW*1.1/0.945
#define OPP_ClearThreshold						5700		// unit is 1W
#define OPP_SetDelay							100			// unit is ms
#define OPP_ClearDelay							100			// unit is ms

#define OPW_SetThreshold						5200		// unit is 1W	4.2KW*1.05/0.945
#define OPW_ClearThreshold						4940		// unit is 1W
#define OPW_SetDelay							100			// unit is ms
#define OPW_ClearDelay							100			// unit is ms

#define OHP_SetThreshold						1400		// unit is 0.01%
#define OHP_ClearThreshold						1200		// unit is 0.01%
#define OHP_SetDelay							30000		// unit is ms
#define OHP_ClearDelay							15000		// unit is ms

#define OHW_SetThreshold						1400		// unit is 0.01%
#define OHW_ClearThreshold						1200		// unit is 0.01%
#define OHW_SetDelay							100 		// unit is ms
#define OHW_ClearDelay							100 		// unit is ms

#define FreqWarning_SetThresholdHigh			6300		// unit is 0.01Hz
#define FreqWarning_ClearThresholdHigh			6100		// unit is 0.01Hz
#define FreqWarning_ClearThresholdLow			4900		// unit is 0.01Hz
#define FreqWarning_SetThresholdLow				4700		// unit is 0.01Hz
#define FreqWarning_SetDelay					2000		// unit is ms
#define FreqWarning_ClearDelay					2000		// unit is ms

#define FreqError_SetThresholdHigh				7300		// unit is 0.01Hz
#define FreqError_ClearThresholdHigh			7100		// unit is 0.01Hz
#define FreqError_ClearThresholdLow				4300		// unit is 0.01Hz
#define FreqError_SetThresholdLow				4100		// unit is 0.01Hz
#define FreqError_SetDelay						2000		// unit is ms
#define FreqError_ClearDelay					2000		// unit is ms


/* ATS Relay switch angle */
#define ATSSwitchAngle	 						30			// unit is degree
#define ATSSwitchAngle_scale	 				((f32_t)ATSSwitchAngle/180)


/* Zero cross detect and frequency limit */
// If AC Present, the polarity should be change in Phase_lock_min_Freq
#define Phase_lock_min_Freq						30 			// unit is Hz
#define Phase_lock_min_falf_CNT					(u16_t)(((f32_t)CPU_TIMER_10KHz_FREQUENCY/Phase_lock_min_Freq/2)+0.5) // 166 count
#define Phase_lock_max_Freq						120 			// unit is Hz
#define Phase_lock_max_falf_CNT					(u16_t)(((f32_t)CPU_TIMER_10KHz_FREQUENCY/Phase_lock_max_Freq/2)+0.5) // 41 count
#define Phase_lock_Compare_CNT					10 			// 1ms, unit is 0.1ms
#define Zero_phase_noise_filter					27			// 2.7ms, unit is 0.1ms, for CF1.6 180Vac condition

/* Blackout config */
// Meet black out When AC below 90Vac/40Hz
#define ITIC_200Persent_VPeak                   470000      // 470V, unit is 1mV
#define Blackout_Real_HVoltage					100000     	// 100V, unit is 1mV
#define Blackout_Real_LVoltage          		30000     	// 30V, unit is 1mV
//#define Blackout_Qtype_HVoltage_ATS				(u16_t)(((f32_t)Blackout_Real_HVoltage/V_ACATS_FS)*Q12_)
//#define Blackout_Qtype_LVoltage_ATS				(u16_t)(((f32_t)Blackout_Real_LVoltage/V_ACATS_FS)*Q12_)
//#define Blackout_Qtype_HVoltage_PFC				(u16_t)(((f32_t)Blackout_Real_HVoltage/V_ACPFC_FS)*Q12_)
//#define Blackout_Qtype_LVoltage_PFC				(u16_t)(((f32_t)Blackout_Real_LVoltage/V_ACPFC_FS)*Q12_)
#define Default_BlackoutCNT						32			// 3.2ms, unit is 0.1ms, for CF1.6 180Vac condition

/* DC Average fileter */
// DC_Filter_A + DC_Filter_B = 1
#define DC_Filter_A								(f32_t)0.1
#define DC_Filter_B								(f32_t)0.9

#define IDC_Filter_A							(f32_t)0.01
#define IDC_Filter_B							(f32_t)0.99


/* AC Average filter */
// AC_Filter_A + AC_Filter_B = 1
// 340ms Integral time
#define AC_Filter_A								(f32_t)0.1
#define AC_Filter_B								(f32_t)0.9

#define IAC_Filter_A							(f32_t)0.01
#define IAC_Filter_B							(f32_t)0.99


/****************************************************************************
*	Private macro definition
****************************************************************************/ 

/****************************************************************************
*	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
*	Private structure definition 
****************************************************************************/

/****************************************************************************
*	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 1165
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Delay, ".TI.ramfunc");
#pragma CODE_SECTION(MoniAC_UpdateFlag, ".TI.ramfunc");
#pragma CODE_SECTION(MoniAC_10k_Instant_Process, ".TI.ramfunc");
#pragma CODE_SECTION(Cal_AC_Square_Root, ".TI.ramfunc");
#pragma CODE_SECTION(MoniAC_1ms_Periodically_Process, ".TI.ramfunc");
#pragma CODE_SECTION(SwitchTiming, ".TI.ramfunc");
#endif


/****************************************************************************
*	Private variable declaration
****************************************************************************/
sMoniAC_t tsMoniAC[MoniAC_Tag_Num];


/***************************************************************************
*   brief  Delay method
*   note   
****************************************************************************/
static u16_t Delay(u16_t* u16Delay)
{
	if (*u16Delay == 0)
	{
		return 1;
	}
	else
	{
		*u16Delay -= 1;
		return 0;
	}
}

/***************************************************************************
*   brief  Real Value Calibrated Compensation
*   note   1. retrun unit is 0.1V or 0.01A
*          2. at 10kHz Timer0 interrupt
****************************************************************************/
static inline void MoniAC_RealValue_Cal(sMoniAC_t *psMoni)
{
    f32_t f32Value, f32Out;
	u16_t u16Temp;

	// select input source
	if (psMoni->eType == MoniAC_Type_Volt)
	{
		u16Temp = *psMoni->pu16ADCVnnn_Q12;
	}
	else
	{
		u16Temp = *psMoni->pu16ADCInnn_Q12;
	}

	/* Calculate real value by HardWare gain */
	f32Value = (f32_t)u16Temp / Q12_;
	f32Out = f32Value * psMoni->f32Cali_Gain + psMoni->f32Cali_Offset + 0.5;	//rounding
	
	// Absolute value
	if (f32Out < 0)
	{
		psMoni->u16RealInstant = (u16_t)(-f32Out);
	}
	else
	{
		psMoni->u16RealInstant = (u16_t)f32Out;
	}
}

/***************************************************************************
*   brief  Input Phase Detect Task at 10kHz Timer0 interrupt
*   note   1. Record multiple AC cycle
****************************************************************************/
static inline void MoniAC_Multiple_CycleRecord(sMoniAC_t *psMoni) //dbg
{
    psMoni->u16Period_5Cycle += 1;
    psMoni->u16Period_5Cycle_CNT = psMoni->u16Period_5Cycle_CNT + psMoni->u16Period;

    if (psMoni->u16Period_5Cycle >= 20)
    {
        psMoni->u16Period_5Cycle = 1;
        psMoni->u16Period_5Cycle_Period = psMoni->u16Period_5Cycle_CNT;
        psMoni->u16Period_5Cycle_CNT = psMoni->u16Period;
    }
}

/***************************************************************************
*   brief  Input Phase Detect Task at 10kHz Timer0 interrupt
*   note   1. Analysis AC is blackout or not, per half cycle update period and AC peak Value
*          2. at 10kHz Timer0 interrupt
****************************************************************************/
static inline void MoniAC_Phase_Detect(sMoniAC_t *psMoni)
{
	/* Zero cross noise filter */
	if (psMoni->u16Filter_CNT > 0)
	{
		psMoni->u16Filter_CNT -- ;
	}
		
	/* Zero cross detect, record period and peak value */
	if ((*psMoni->pi16ADCVSin_Q12 >= 0) &&
		(psMoni->u16Filter_CNT == 0) &&
		(psMoni->nStatus.u16Bits.u1Polarity == 0))
	{
		// Positive
		psMoni->u16Filter_CNT = Zero_phase_noise_filter;
		psMoni->u16Period = psMoni->u16Period_CNT;
		psMoni->u16Period_CNT = 1;
		psMoni->f32RealPeak = (f32_t)psMoni->u16Real_Peak_BUF;
		psMoni->u16Real_Peak_BUF = 0;
		psMoni->nStatus.u16Bits.u1Polarity = 1;

		MoniAC_Multiple_CycleRecord(psMoni);
	}
	else if ((*psMoni->pi16ADCVSin_Q12 < 0) &&
			 (psMoni->u16Filter_CNT == 0) &&
			 (psMoni->nStatus.u16Bits.u1Polarity == 1))
	{
		// Negative
		psMoni->u16Filter_CNT = Zero_phase_noise_filter;
		psMoni->u16Period = psMoni->u16Period_CNT;
		psMoni->u16Period_CNT = 1;
		psMoni->f32RealPeak = (f32_t)psMoni->u16Real_Peak_BUF;
		psMoni->u16Real_Peak_BUF = 0;
		psMoni->nStatus.u16Bits.u1Polarity = 0;

        MoniAC_Multiple_CycleRecord(psMoni);
	}
	else
	{
		// Limit period CNT
		if (psMoni->u16Period_CNT < psMoni->u16FreqMinlimit)
		{
			psMoni->u16Period_CNT++;
		}

		// update peak value
		if (psMoni->u16Real_Peak_BUF < psMoni->u16RealInstant)
		{
			psMoni->u16Real_Peak_BUF = psMoni->u16RealInstant;
		}
	}

    // monitor 140% and 200% ITIC
    if (*psMoni->pu16ADCVnnn_Q12 > psMoni->u16ITIC_Vpeak_SetPoint)
    {
        psMoni->nStatus.u16Bits.u16ITIC = TRUE;
    }
    else
    {
        psMoni->nStatus.u16Bits.u16ITIC = FALSE;
    }

	/* Blackout Detect */
	if (*psMoni->pu16ADCVnnn_Q12 < psMoni->u16Blackout_LV)
	{
		if (psMoni->u16BlackoutCNT < Default_BlackoutCNT)
		{
			psMoni->u16BlackoutCNT ++;
		}	
	}
	else if (*psMoni->pu16ADCVnnn_Q12 > psMoni->u16Blackout_HV)
	{
		if (psMoni->u16BlackoutCNT > 0)
		{
			psMoni->u16BlackoutCNT --;
		}
	}

	/* Detect AC input or DC input or input Loss */
	if (psMoni->u16BlackoutCNT == Default_BlackoutCNT)
	{
		psMoni->nStatus.u16Bits.u2InputStatus = MoniAC_InputStatus_Loss;
	}
	else if (psMoni->u16Period_CNT == psMoni->u16FreqMinlimit)
	{
	
#ifdef EnableDCInput
		psMoni->nStatus.u16Bits.u2InputStatus = MoniAC_InputStatus_DC;
#else
		psMoni->nStatus.u16Bits.u2InputStatus = MoniAC_InputStatus_Loss;
#endif

	}
	else if (psMoni->u16BlackoutCNT == 0)
	{
		psMoni->nStatus.u16Bits.u2InputStatus = MoniAC_InputStatus_AC;
	}
}

/***************************************************************************
*   brief  Update Ac Source Flag - Source Present
*   note   1. Source Present : 160V ~ 307V delay 500ms
*          2. Clear Source Present : Vac>312 , Vac<155  delay 0ms
****************************************************************************/
static inline void MoniAC_UpdateFlag_SourcePresent(sMoniAC_t *psMoni)
{
	sBetweenThreshold_t* psConfig = &psMoni->sConfig.sSourcePresent;

	if (psConfig->eTriggerType == TriggerDisable)
	{
		psMoni->nFlag.u16Bits.u1SourcePresent = FALSE;
		psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
	}
	else
	{
		if ((psMoni->u16RealRMS > psConfig->i16SetThresholdLow) &&
			(psMoni->u16RealRMS < psConfig->i16SetThresholdHigh))
		{
			if ((Delay(&psConfig->sVar.u16SetDelay)) &&
				(psMoni->nFlag.u16Bits.u1SourcePresent == FALSE))
			{
				psMoni->nFlag.u16Bits.u1SourcePresent = TRUE; 
			}

			psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
		}
		else if ((psMoni->u16RealRMS < psConfig->i16ClearThresholdLow) ||
				 (psMoni->u16RealRMS > psConfig->i16ClearThresholdHigh))
		{
			if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
				(psMoni->nFlag.u16Bits.u1SourcePresent == TRUE) &&
				(psConfig->eTriggerType == TriggerAutoRecover))		
			{
				psMoni->nFlag.u16Bits.u1SourcePresent = FALSE;
			}

			psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		}
	}
}

/***************************************************************************
*   brief  Update Ac Source Status - Freq warning
*   note   at 1ms Instant Process
****************************************************************************/
static inline void MoniAC_UpdateFlag_FreqWarning(sMoniAC_t *psMoni)
{
	sBetweenThreshold_t* psConfig = &psMoni->sConfig.sFreqWarning;
	
	if (psConfig->eTriggerType == TriggerDisable)
	{
		psMoni->nFlag.u16Bits.u1FreqWarning = FALSE;
		psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
	}
	else
	{
		// Frequency Error
		if ((psMoni->u16Freq_WF > psConfig->i16SetThresholdHigh) || 
			(psMoni->u16Freq_WF < psConfig->i16SetThresholdLow))
		{
			if ((Delay(&psConfig->sVar.u16SetDelay)) &&
				(psMoni->nFlag.u16Bits.u1FreqWarning == FALSE))
			{
				psMoni->nFlag.u16Bits.u1FreqWarning = TRUE;
			}

			psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
		}
		// Frequency Normal
		else if ((psMoni->u16Freq_WF < psConfig->i16ClearThresholdHigh) &&
				 (psMoni->u16Freq_WF > psConfig->i16ClearThresholdLow))
		{
			if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
				(psMoni->nFlag.u16Bits.u1FreqWarning == TRUE) &&
				(psConfig->eTriggerType == TriggerAutoRecover))
			{
				psMoni->nFlag.u16Bits.u1FreqWarning = FALSE;
			}

			psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		}
	}
}


/***************************************************************************
*   brief  Update Ac Source Status - FreqError
*   note   at 1ms Instant Process
****************************************************************************/
static inline void MoniAC_UpdateFlag_FreqError(sMoniAC_t *psMoni)
{
	sBetweenThreshold_t* psConfig = &psMoni->sConfig.sFreqError;
	
	if (psConfig->eTriggerType == TriggerDisable)
	{
		psMoni->nFlag.u16Bits.u1FreqError = FALSE;
		psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
	}
	else
	{
		// Frequency Error
		if ((psMoni->u16Freq_WF > psConfig->i16SetThresholdHigh) || 
			(psMoni->u16Freq_WF < psConfig->i16SetThresholdLow))
		{
			if ((Delay(&psConfig->sVar.u16SetDelay)) &&
				(psMoni->nFlag.u16Bits.u1FreqError == FALSE))
			{
				psMoni->nFlag.u16Bits.u1FreqError = TRUE;
			}

			psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
		}
		// Frequency Normal
		else if ((psMoni->u16Freq_WF < psConfig->i16ClearThresholdHigh) &&
				 (psMoni->u16Freq_WF > psConfig->i16ClearThresholdLow))
		{
			if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
				(psMoni->nFlag.u16Bits.u1FreqError == TRUE) &&
				(psConfig->eTriggerType == TriggerAutoRecover))
			{
				psMoni->nFlag.u16Bits.u1FreqError = FALSE;
			}

			psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		}
	}
}

/***************************************************************************
*   brief : Update Ac Source Flag - Source Good
*   Source Good condition : 1. Vac range is 176~307
*                           2. Not UVP, UVW, OVP, OVW
*                           3. Not frequency error
*
*    note : at 1ms Instant Process
****************************************************************************/
static inline void MoniAC_UpdateFlag_SourceGood(sMoniAC_t *psMoni)
{
	sBetweenThreshold_t* psConfig = &psMoni->sConfig.sSourceGood;
	
	if (psConfig->eTriggerType == TriggerDisable)
	{
		psMoni->nFlag.u16Bits.u1SourceGood = FALSE;
		psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
	}
	else
	{
		// Input Source Good
		if ((psMoni->u16RealRMS < psConfig->i16SetThresholdHigh) &&
			(psMoni->u16RealRMS > psConfig->i16SetThresholdLow) &&
            (psMoni->nFlag.u16Bits.u1BrownoutProtect == FALSE) &&
            (psMoni->nFlag.u16Bits.u1BrownoutWarning == FALSE) &&
			(psMoni->nFlag.u16Bits.u1OverVoltageProtect == FALSE) &&
			(psMoni->nFlag.u16Bits.u1FreqError == FALSE))
		{
			if ((Delay(&psConfig->sVar.u16SetDelay)) &&
				(psMoni->nFlag.u16Bits.u1SourceGood == FALSE))
			{
				psMoni->nFlag.u16Bits.u1SourceGood = TRUE;
            }

			psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
		}
		// Input Source Not Good
        else if ((psMoni->nFlag.u16Bits.u1BrownoutProtect == TRUE) ||
				 (psMoni->nFlag.u16Bits.u1BrownoutWarning == TRUE) ||
        		 (psMoni->nFlag.u16Bits.u1OverVoltageProtect == TRUE) ||
        		 (psMoni->nFlag.u16Bits.u1FreqError == TRUE))
		{
			if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
				(psMoni->nFlag.u16Bits.u1SourceGood == TRUE) &&
				(psConfig->eTriggerType == TriggerAutoRecover))
			{
				psMoni->nFlag.u16Bits.u1SourceGood = FALSE;
			}

			psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
		}
	}
}

/***************************************************************************
*   brief  Update AC flag
*   note   at 1ms Instant Process
****************************************************************************/
static void MoniAC_UpdateFlag(sMoniAC_t *psMoni)
{
    if (psMoni->eType == MoniAC_Type_Volt)
    {
        // Update VAC1, VAC2, VPFC
        MoniAC_UpdateFlag_SourcePresent(psMoni);

        // Update VAC1, VAC2, VPFC
        Single_Threshold(&psMoni->sConfig.sUVP, psMoni->u16RealRMS, &psMoni->nFlag.u16All);
        Single_Threshold(&psMoni->sConfig.sUVW, psMoni->u16RealRMS, &psMoni->nFlag.u16All);
        Single_Threshold(&psMoni->sConfig.sOVP, psMoni->u16RealRMS, &psMoni->nFlag.u16All);
        Single_Threshold(&psMoni->sConfig.sOVW, psMoni->u16RealRMS, &psMoni->nFlag.u16All);
        Single_Threshold(&psMoni->sConfig.sOVPH, psMoni->u16RealRMS, &psMoni->nFlag.u16All);

        /* These flags will trigger BlackBox , update RMS immediately */
        if ((psMoni->nFlag.u16Bits.u1BrownoutProtect)    ||
            (psMoni->nFlag.u16Bits.u1OverVoltageWarning) ||
            (psMoni->nFlag.u16Bits.u1OverVoltageProtect))
        {
            psMoni->u16RealRMS_WF = psMoni->u16RealRMS;
        }

        // Update VAC1, VAC2
        if ((psMoni->eTag == MoniAC_Tag_VAC1) ||
            (psMoni->eTag == MoniAC_Tag_VAC2))
        {
            // Update VAC1, VAC2
            Single_Threshold(&psMoni->sConfig.sOHP, psMoni->u16Harmonic_WF, &psMoni->nFlag.u16All);
            Single_Threshold(&psMoni->sConfig.sOHW, psMoni->u16Harmonic_WF, &psMoni->nFlag.u16All);
            Single_Threshold(&psMoni->sConfig.sDropout, psMoni->u16RealRMS, &psMoni->nFlag.u16All);

            // Frequency handler
            if ((psMoni->nFlag.u16Bits.u1Dropout)||
                (psMoni->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_DC))
            {
                // For fault injection
                if (psMoni->sConfig.sFreqWarning.eTriggerType != TriggerLatch)
                {
                    psMoni->sConfig.sFreqWarning.eTriggerType = TriggerDisable;
                }

                if (psMoni->sConfig.sFreqError.eTriggerType != TriggerLatch)
                {
                    psMoni->sConfig.sFreqError.eTriggerType = TriggerDisable;
                }
            }
            else
            {
                if (psMoni->sConfig.sFreqWarning.eTriggerType != TriggerLatch)
                {
                    psMoni->sConfig.sFreqWarning.eTriggerType = TriggerAutoRecover;
                }

                if (psMoni->sConfig.sFreqError.eTriggerType != TriggerLatch)
                {
                    psMoni->sConfig.sFreqError.eTriggerType = TriggerAutoRecover;
                }
            }

            MoniAC_UpdateFlag_FreqWarning(psMoni);
            MoniAC_UpdateFlag_FreqError(psMoni);
            MoniAC_UpdateFlag_SourceGood(psMoni);
        }
    }
    else
    {
        // Update IPFC
        // IPFC only update overcurrent flag, because u16RealRMS is current
        Single_Threshold(&psMoni->sConfig.sOCP, psMoni->u16RealRMS_WF, &psMoni->nFlag.u16All);
        Single_Threshold(&psMoni->sConfig.sOCW, psMoni->u16RealRMS_WF, &psMoni->nFlag.u16All);
        Single_Threshold(&psMoni->sConfig.sOPP, psMoni->u16Power_WF, &psMoni->nFlag.u16All);
        Single_Threshold(&psMoni->sConfig.sOPW, psMoni->u16Power_WF, &psMoni->nFlag.u16All);
    }
}

/***************************************************************************
*   brief  Update flag and Real value content while input loss
*   note   at 10kHz Timer0 interrupt
****************************************************************************/
static inline void MoniAC_UpdateContent_Fast(sMoniAC_t *psMoni)
{
	// Status into Loss
	if ((psMoni->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_Loss) &&
		(psMoni->nStatus.u16Bits.u2InputStatusPre != psMoni->nStatus.u16Bits.u2InputStatus))
	{
		psMoni->nStatus.u16Bits.u2InputStatusPre = psMoni->nStatus.u16Bits.u2InputStatus;
		psMoni->nStatus.u16Bits.u16ITIC = FALSE;
		psMoni->nStatus.u16Bits.u1Phaselock = FALSE;
        psMoni->nStatus.u16Bits.u1CalRMS = FALSE;
        psMoni->nStatus.u16Bits.u16ReportVrms = FALSE;
        psMoni->u16ReportRMS_Delay = ReportRMS_Delay;
		psMoni->u32Square_Sum_Q12 = 0;
		psMoni->u32Square_Sum_Buff_Q12 = 0;
		psMoni->u16RealRMS_Buff1 = 0;
		psMoni->u16RealRMS_Buff2 = 0;
		psMoni->u16RealRMS = 0;
		psMoni->u16RealRMS_WF = 0;
		psMoni->u16RealInstant = 0;
		psMoni->u16Period = 0;	
		psMoni->u16Period_Pre = 0;
		psMoni->u16Period_Cycle = 0;
		psMoni->u16Freq = 0;
		psMoni->u16Freq_WF = 0;
		psMoni->u16Power_WF = 0;
		psMoni->u16Harmonic_WF = 0;
		MoniAC_UpdateFlag(psMoni);
	}
	// Status into DC
	else if ((psMoni->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_DC) &&
			 (psMoni->nStatus.u16Bits.u2InputStatusPre != psMoni->nStatus.u16Bits.u2InputStatus))
	{
		psMoni->nStatus.u16Bits.u2InputStatusPre = psMoni->nStatus.u16Bits.u2InputStatus;
		psMoni->nStatus.u16Bits.u1Phaselock = FALSE;
        psMoni->nStatus.u16Bits.u1CalRMS = FALSE;
		psMoni->u32Square_Sum_Q12 = 0;
		psMoni->u32Square_Sum_Buff_Q12 = 0;
		psMoni->u16Period = 0;	
		psMoni->u16Period_Pre = 0;
		psMoni->u16Period_Cycle = 0;
		psMoni->u16Freq = 0;
		psMoni->u16Freq_WF = 0;
		psMoni->u16Harmonic_WF = 0;

		psMoni->sConfig.sSourcePresent.i16SetThresholdHigh = SourcePresent_SetThresholdHigh_DC;
		psMoni->sConfig.sSourcePresent.i16SetThresholdLow = SourcePresent_SetThresholdLow_DC;
		psMoni->sConfig.sSourcePresent.i16ClearThresholdHigh = SourcePresent_ClearThresholdHigh_DC;
		psMoni->sConfig.sSourcePresent.i16ClearThresholdLow = SourcePresent_ClearThresholdLow_DC;

		psMoni->sConfig.sSourceGood.i16SetThresholdHigh = SourceGood_SetThresholdHigh_DC;
		psMoni->sConfig.sSourceGood.i16SetThresholdLow = SourceGood_SetThresholdLow_DC;
		psMoni->sConfig.sSourceGood.i16ClearThresholdHigh = SourceGood_ClearThresholdHigh_DC;
		psMoni->sConfig.sSourceGood.i16ClearThresholdLow = SourceGood_ClearThresholdLow_DC;

		psMoni->sConfig.sDropout.i16SetThreshold = Dropout_SetThreshold_DC;
		psMoni->sConfig.sDropout.i16ClearThreshold = Dropout_ClearThreshold_DC;

		psMoni->sConfig.sUVP.i16SetThreshold = UVP_SetThreshold_DC;
		psMoni->sConfig.sUVP.i16ClearThreshold = UVP_ClearThreshold_DC;

		psMoni->sConfig.sUVW.i16SetThreshold = UVW_SetThreshold_DC;
		psMoni->sConfig.sUVW.i16ClearThreshold = UVW_ClearThreshold_DC;

		psMoni->sConfig.sOVP.i16SetThreshold = OVP_SetThreshold_DC;
		psMoni->sConfig.sOVP.i16ClearThreshold = OVP_ClearThreshold_DC;

		psMoni->sConfig.sOVPH.i16SetThreshold = OVPH_SetThreshold_DC;
		psMoni->sConfig.sOVPH.i16ClearThreshold = OVPH_ClearThreshold_DC;

		psMoni->sConfig.sOVW.i16SetThreshold = OVW_SetThreshold_DC;
		psMoni->sConfig.sOVW.i16ClearThreshold = OVW_ClearThreshold_DC;

	}
	// Status into AC
	else if ((psMoni->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC) &&
			 (psMoni->nStatus.u16Bits.u2InputStatusPre != psMoni->nStatus.u16Bits.u2InputStatus))
	{
		psMoni->nStatus.u16Bits.u2InputStatusPre = psMoni->nStatus.u16Bits.u2InputStatus;
	
		psMoni->sConfig.sSourcePresent.i16SetThresholdHigh = SourcePresent_SetThresholdHigh;
		psMoni->sConfig.sSourcePresent.i16SetThresholdLow = SourcePresent_SetThresholdLow;
		psMoni->sConfig.sSourcePresent.i16ClearThresholdHigh = SourcePresent_ClearThresholdHigh;
		psMoni->sConfig.sSourcePresent.i16ClearThresholdLow = SourcePresent_ClearThresholdLow;

		psMoni->sConfig.sSourceGood.i16SetThresholdHigh = SourceGood_SetThresholdHigh;
		psMoni->sConfig.sSourceGood.i16SetThresholdLow = SourceGood_SetThresholdLow;
		psMoni->sConfig.sSourceGood.i16ClearThresholdHigh = SourceGood_ClearThresholdHigh;
		psMoni->sConfig.sSourceGood.i16ClearThresholdLow = SourceGood_ClearThresholdLow;

		psMoni->sConfig.sDropout.i16SetThreshold = Dropout_SetThreshold;
		psMoni->sConfig.sDropout.i16ClearThreshold = Dropout_ClearThreshold;

		psMoni->sConfig.sUVP.i16SetThreshold = UVP_SetThreshold;
		psMoni->sConfig.sUVP.i16ClearThreshold = UVP_ClearThreshold;

		psMoni->sConfig.sUVW.i16SetThreshold = UVW_SetThreshold;
		psMoni->sConfig.sUVW.i16ClearThreshold = UVW_ClearThreshold;

		psMoni->sConfig.sOVP.i16SetThreshold = OVP_SetThreshold;
		psMoni->sConfig.sOVP.i16ClearThreshold = OVP_ClearThreshold;

		psMoni->sConfig.sOVPH.i16SetThreshold = OVPH_SetThreshold;
		psMoni->sConfig.sOVPH.i16ClearThreshold = OVPH_ClearThreshold;

		psMoni->sConfig.sOVW.i16SetThreshold = OVW_SetThreshold;
		psMoni->sConfig.sOVW.i16ClearThreshold = OVW_ClearThreshold;
	}
}

/***************************************************************************
*   brief  Calculation square summary
*   note   at 10kHz Timer0 interrupt
****************************************************************************/
static inline void Cal_AC_Square_Sum(sMoniAC_t *psMoni)
{
	i16_t i16Temp;

	if (psMoni->nStatus.u16Bits.u1PolarityPreRMS != psMoni->nStatus.u16Bits.u1Polarity)
	{
		// phase unlock
		if ((psMoni->nStatus.u16Bits.u1Phaselock == FALSE) &&
			(psMoni->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC) &&
			(psMoni->u16Period < psMoni->u16FreqMinlimit) &&
			(psMoni->u16Period > psMoni->u16FreqMaxlimit))
		{
			// check phase lock
			i16Temp = (i16_t)psMoni->u16Period - (i16_t)psMoni->u16Period_Pre;

			if ((i16Temp > -Phase_lock_Compare_CNT) && (i16Temp < Phase_lock_Compare_CNT))
			{
				// Frequency variance within +- 1ms
				psMoni->nStatus.u16Bits.u1Phaselock = TRUE;
			}
		}
		// phase lock
		else if ((psMoni->nStatus.u16Bits.u1Phaselock == TRUE) && 
				 (psMoni->nStatus.u16Bits.u1NeedtodoRMS == TRUE))
		{
			// Record total Square sum
			psMoni->u32Square_Sum_Q12 = psMoni->u32Square_Sum_Buff_Q12;
			psMoni->u32Square_Sum_Buff_Q12 = (u32_t)psMoni->u16RealInstant * (u32_t)psMoni->u16RealInstant;
			psMoni->nStatus.u16Bits.u1CalRMS = TRUE;	


	        if ((psMoni->eTag == MoniAC_Tag_VAC1 || psMoni->eTag == MoniAC_Tag_VAC2) && psMoni->u16Period_5Cycle == 1) //dbg
	        {
	            psMoni->u16CalRealPower = TRUE;
	            psMoni->u32sum = psMoni->u32sum_Buff;
	            psMoni->u32sum_Buff = (u32_t)psMoni->u16RealInstant * (u32_t)tsMoniAC[MoniAC_Tag_IPFC].u16RealInstant;
	        }
	        else
	        {
	            psMoni->u32sum_Buff = psMoni->u32sum_Buff + (u32_t)psMoni->u16RealInstant * (u32_t)tsMoniAC[MoniAC_Tag_IPFC].u16RealInstant;//dbg
	        }
		}

		psMoni->u16Period_Cycle = psMoni->u16Period + psMoni->u16Period_Pre;
		psMoni->u16Period_Pre = psMoni->u16Period;
		psMoni->nStatus.u16Bits.u1PolarityPreRMS = psMoni->nStatus.u16Bits.u1Polarity;
				 
	}
	else if ((psMoni->nStatus.u16Bits.u1Phaselock == TRUE) && 
			 (psMoni->nStatus.u16Bits.u1NeedtodoRMS == TRUE))
	{
	    // Summation Apparent Power
		psMoni->u32Square_Sum_Buff_Q12 = psMoni->u32Square_Sum_Buff_Q12 + ((u32_t)psMoni->u16RealInstant * (u32_t)psMoni->u16RealInstant);

		// Summation Real Power
		if (psMoni->eTag == MoniAC_Tag_VAC1 || psMoni->eTag == MoniAC_Tag_VAC2) //dbg
		{
		    psMoni->u32sum_Buff = psMoni->u32sum_Buff + (u32_t)psMoni->u16RealInstant * (u32_t)tsMoniAC[MoniAC_Tag_IPFC].u16RealInstant;
		}
	}
}

/***************************************************************************
*   brief  AcSource Instant Process at 10kHz Timer0 interrupt
*   note   
****************************************************************************/
void MoniAC_10k_Instant_Process(void)
{
	u16_t i;
	
	for (i=0; i<MoniAC_Tag_Num; i++)
	{
		MoniAC_RealValue_Cal(&tsMoniAC[i]);
		MoniAC_Phase_Detect(&tsMoniAC[i]);
		MoniAC_UpdateContent_Fast(&tsMoniAC[i]);
		Cal_AC_Square_Sum(&tsMoniAC[i]);
	}
}

/***************************************************************************
*   brief  Calculation square root to got RMS value
*   note   
****************************************************************************/
static u16_t Cal_AC_Square_Root(u32_t u32Square_Sum, u16_t u16Period)
{
	f32_t f32Temp1;
	u16_t u16Temp2;
	f32Temp1 = (f32_t)u32Square_Sum / (f32_t)u16Period;
	u16Temp2 = (u16_t)__sqrt(f32Temp1);
	return u16Temp2;
}

/***************************************************************************
*   brief  Update RMS value and Frequency
*   note   1. Return RMS unit is 0.1V or 0.001A
*          2. at 1ms Instant Process while got the calRMS flag
****************************************************************************/
static inline void Update_RMS(sMoniAC_t *psMoni)
{
	if (psMoni->nStatus.u16Bits.u1CalRMS == TRUE)
	{
		psMoni->nStatus.u16Bits.u1CalRMS = FALSE;
		psMoni->u16RealRMS_Buff2 = Cal_AC_Square_Root(psMoni->u32Square_Sum_Q12, psMoni->u16Period);

        if ((psMoni->eTag == MoniAC_Tag_VAC1 || psMoni->eTag == MoniAC_Tag_VAC2) && psMoni->u16CalRealPower == TRUE) //dbg
        {
            psMoni->u16CalRealPower = FALSE;
            psMoni->u16RealPower = (u32_t)((f32_t)psMoni->u32sum / (f32_t)psMoni->u16Period_5Cycle_Period / 1000 + 0.5); // 0.1V * 0.01A = 1000
        }

		if (psMoni->eTag == MoniAC_Tag_IPFC)
		{
			// unit is 0.001A
			psMoni->u16RealRMS = (psMoni->u16RealRMS_Buff1 + psMoni->u16RealRMS_Buff2) * 5; // *10/2==5 , base on "f32Cali_Gain" , EX : 50A=5000 => *10 => 50A=50000
			psMoni->u16RealRMS_WF = (u16_t)(((f32_t)psMoni->u16RealRMS * IAC_Filter_A) + ((f32_t)psMoni->u16RealRMS_WF * IAC_Filter_B) + 0.5);
		}
		else
		{
            // unit is 0.1V
            psMoni->u16RealRMS = (psMoni->u16RealRMS_Buff1 + psMoni->u16RealRMS_Buff2) / 2;

            // CanBus only report RMS_WF
            if (psMoni->nStatus.u16Bits.u16ReportVrms)
            {
                /* These flags will trigger BlackBox , update RMS immediately to record BlackBox */
                if (((psMoni->nFlag.u16Bits.u1BrownoutProtect)    ||
                    (psMoni->nFlag.u16Bits.u1OverVoltageWarning)  ||
                    (psMoni->nFlag.u16Bits.u1OverVoltageProtect)) &&
                    (SET_CALI_KEY_OK == FALSE)) // avoid cannot calibration
                {
                    // unit is 0.1V
                    psMoni->u16RealRMS_WF = psMoni->u16RealRMS;
                }
                else
                {
                    psMoni->u16RealRMS_WF = (u16_t)(((f32_t)psMoni->u16RealRMS * AC_Filter_A) + ((f32_t)psMoni->u16RealRMS_WF * AC_Filter_B) + 0.5);
                }
            }
		}
		
		psMoni->u16RealRMS_Buff1 = psMoni->u16RealRMS_Buff2;
		psMoni->u16Freq = (u16_t)(((f32_t)CPU_TIMER_10KHz_FREQUENCY / (f32_t)psMoni->u16Period_Cycle) * 100 + 6.5);	// Add 0.45Hz for Calibration
		psMoni->u16AngleofCNT = (u16_t)(ATSSwitchAngle_scale * (f32_t)psMoni->u16Period);
		psMoni->u16Freq_WF = (u16_t)((f32_t)psMoni->u16Freq * AC_Filter_A + (f32_t)psMoni->u16Freq_WF * AC_Filter_B);
	}
}

/***************************************************************************
*   brief  Update Average value for DC input source
*   note   at 1ms Instant Process
****************************************************************************/
static inline void Update_AVG(sMoniAC_t *psMoni)
{
    if (psMoni->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_DC)
    {
        // Average filter
        if (psMoni->eTag == MoniAC_Tag_IPFC)
        {
            psMoni->u16RealRMS = (u16_t)((f32_t)psMoni->u16RealInstant * IDC_Filter_A * 10 + (f32_t)psMoni->u16RealRMS * IDC_Filter_B);
        }
        else
        {
            psMoni->u16RealRMS = (u16_t)((f32_t)psMoni->u16RealInstant * DC_Filter_A + (f32_t)psMoni->u16RealRMS * DC_Filter_B);
            psMoni->u16RealRMS_WF = psMoni->u16RealRMS;

            if (psMoni->u16RealInstant <= 1600)
            {
                // Avoid AMC-IC issue , if RealInstant below 160V then Forced RMS value to zero
                psMoni->u16RealRMS    = 0;
                psMoni->u16RealRMS_WF = 0;
            }
        }
    }
}

/***************************************************************************
*   brief  AcSource periodically Process at 1ms system time
*   note   
****************************************************************************/
void MoniAC_1ms_Periodically_Process(void)
{
	u16_t i;
	
	for (i=0; i<MoniAC_Tag_Num; i++)
	{
		Update_RMS(&tsMoniAC[i]);
		Update_AVG(&tsMoniAC[i]);
		MoniAC_UpdateFlag(&tsMoniAC[i]);

		// Fixed AMC issue, this function avoid report RMS when AC turn off
		if (i == MoniAC_Tag_VAC1 || i == MoniAC_Tag_VAC2 || i == MoniAC_Tag_VPFC)
		{
		    if ((tsMoniAC[i].nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC) &&
		             (Delay(&tsMoniAC[i].u16ReportRMS_Delay)))
		    {
		        tsMoniAC[i].nStatus.u16Bits.u16ReportVrms = TRUE;
		    }
		}
	}
}

/***************************************************************************
*   brief  AcSource periodically Process at 10ms system time
*   note   1. Update input power
****************************************************************************/
void MoniAC_10ms_Periodically_Process(void)
{
	tsMoniAC[MoniAC_Tag_IPFC].u16Power_WF = GET_LOG_AVGPOWER;

	// For DC input, IAC has 10Hz ripple need to filter, 6s stabilize delay
	if (tsMoniAC[MoniAC_Tag_IPFC].nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_DC)
	{
		tsMoniAC[MoniAC_Tag_IPFC].u16RealRMS_WF = (u16_t)((f32_t)tsMoniAC[MoniAC_Tag_IPFC].u16RealRMS * IDC_Filter_A + (f32_t)tsMoniAC[MoniAC_Tag_IPFC].u16RealRMS_WF * IDC_Filter_B);
	}
}

/***************************************************************************
*   brief  AcSource periodically Process at 1s system time
*   note   Update FFT
****************************************************************************/
void MoniAC_1s_Periodically_Process(void)
{
	tsMoniAC[MoniAC_Tag_VAC1].u16Harmonic_WF = GET_FFT_VAC1;
	tsMoniAC[MoniAC_Tag_VAC2].u16Harmonic_WF = GET_FFT_VAC2;
}

/***************************************************************************
*   brief  Update Observation window
*   note   Update Source Good of set delay time when observation Window change the value
****************************************************************************/
void Update_ObservationWindow(u16_t u16Value)
{
	u16_t i = 0;

	if (tsMoniAC[i].sConfig.sSourceGood.sConst.u16SetDelay != (u16Value * 1000))
	{		
    	for (i=0; i<MoniAC_Tag_Num; i++)
    	{
        	tsMoniAC[i].sConfig.sSourceGood.sConst.u16SetDelay = u16Value * 1000;
			// If system continuous update the observation window, the souce good will never assert.
			tsMoniAC[i].sConfig.sSourceGood.sVar.u16SetDelay = tsMoniAC[i].sConfig.sSourceGood.sConst.u16SetDelay;
    	}
	}
}

/***************************************************************************
*   brief  Update AC Calibration gain and offset value
*   note   pre calculation HWGain and offset, transfer Q type to real value 
****************************************************************************/
void UpdateMoniACCalibration(eMoniACTag_t eTag)
{
	if (eTag == MoniAC_Tag_IPFC)
	{
		// unit is 0.01
		tsMoniAC[eTag].f32Cali_Gain = tsMoniAC[eTag].psCali->f32CaliGain / 10;  //unit is 0.01A, 10 : from 0.001A to 0.01A , EX : 50A:50000 => /10 = 5000 => unit is 0.01A
		tsMoniAC[eTag].f32Cali_Offset = ((f32_t)tsMoniAC[eTag].psCali->i16Offset * 100) / CALI_OFFSET_GAIN;	// unit is 0.01A, 100 : from 1A(offset) to 0.01A
	}
	else
	{
		// unit is 0.1
		tsMoniAC[eTag].f32Cali_Gain = tsMoniAC[eTag].psCali->f32CaliGain / 100;	 //unit is 0.1V, 100 : from 0.001V to 0.1V , EX : 507V:507000 => /100 = 5070 => unit is 0.1V
		tsMoniAC[eTag].f32Cali_Offset = ((f32_t)tsMoniAC[eTag].psCali->i16Offset * 10) / CALI_OFFSET_GAIN;	// unit is 0.1V, 10 : from 1V(offset) to 0.1V
	}
}

/***************************************************************************
*   brief  Switch Device turn on / off timing
*   note   
****************************************************************************/
u16_t SwitchTiming(eMoniSwitchTiming_t eTiming, eMoniACTag_t eTag)
{
	sMoniAC_t* psMoniAC = &tsMoniAC[eTag];

	switch (eTiming)
	{
		case MoniAC_RelayONZC:

			if (psMoniAC->u16Period < RelayTurnOnDelayTime)	// FreError
			{
				return 0;
			}
			else if (psMoniAC->u16Period_CNT == (psMoniAC->u16Period - RelayTurnOnDelayTime))
			{
				return 1;
			}       
            else
            {
            	return 0;
            }

		case MoniAC_RelayONAngle:

			if (psMoniAC->u16Period < RelayTurnOnDelayTime)	// FreError
			{
				return 0;
			}		
			else if ((psMoniAC->u16AngleofCNT + RelayTurnOnDelayTime) > psMoniAC->u16Period)	// FreError_High
			{
				// Switch at ZCD
				if (psMoniAC->u16Period_CNT == (psMoniAC->u16Period - RelayTurnOnDelayTime))
				{
					return 1;
				}		
				else
				{
					return 0;
				}
			}
			else
			{
				// Switch at +-Angle timing
				if ((psMoniAC->u16Period_CNT > ((psMoniAC->u16Period - psMoniAC->u16AngleofCNT) - RelayTurnOnDelayTime)) &&
					 (psMoniAC->u16Period_CNT < ((psMoniAC->u16Period + psMoniAC->u16AngleofCNT) - RelayTurnOnDelayTime)))
				{
					return 1;
				}		
				else
				{
					return 0;
				}
			}
		
		case MoniAC_RelayOFFZC:

			if (psMoniAC->u16Period < RelayTurnOnDelayTime)	// FreError
			{
				return 1;	// if AC loss, Relay will turn off immediately
			}		
			else if (psMoniAC->u16Period_CNT == (psMoniAC->u16Period - RelayTurnOffDelayTime))
			{
				return 1;
			}
            else
            {
            	return 0;
            }

		case MoniAC_SwitchZC:
			
			if (psMoniAC->u16Period_CNT == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}			

        case MoniAC_SwitchAngle:
			
			if ((psMoniAC->u16Period_CNT < psMoniAC->u16AngleofCNT) ||
                (psMoniAC->u16Period_CNT > (psMoniAC->u16Period - psMoniAC->u16AngleofCNT)))
			{
				return 1;
			}       
            else
            {
            	return 0;
            }
			
		default:
			return 0;
	}
}

/***************************************************************************
*   brief  Return AC source address
*   note   
****************************************************************************/
sMoniAC_t* GetMoniACRef(eMoniACTag_t eTag)
{
	return &tsMoniAC[eTag];
}

/****************************************************************************
*	Brief	Monitor AC initialize
*	Note	
****************************************************************************/
void MoniAC_Initialize(void)
{
    u16_t i;
	
    for (i=0; i<MoniAC_Tag_Num; i++)
    {
        memset(&tsMoniAC[i], 0, sizeof(tsMoniAC[i]));
		
		tsMoniAC[i].eTag = (eMoniACTag_t)i;

		// default is AC input
		
		/* For StanyBy mode */
		tsMoniAC[i].sConfig.sDropout.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sDropout.eLimitType = Limit_Lower;
		tsMoniAC[i].sConfig.sDropout.u16SetBits = MOMIAC_Bits_Dropout;
		tsMoniAC[i].sConfig.sDropout.i16SetThreshold = Dropout_SetThreshold;
		tsMoniAC[i].sConfig.sDropout.i16ClearThreshold = Dropout_ClearThreshold;
		tsMoniAC[i].sConfig.sDropout.sConst.u16SetDelay = Dropout_SetDelay;
		tsMoniAC[i].sConfig.sDropout.sConst.u16ClearDelay = Dropout_ClearDelay;
		tsMoniAC[i].sConfig.sDropout.sVar.u16SetDelay = tsMoniAC[i].sConfig.sDropout.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sDropout.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sDropout.sConst.u16ClearDelay;

		/* For Brown Out Protect */
		tsMoniAC[i].sConfig.sUVP.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sUVP.eLimitType = Limit_Lower;
		tsMoniAC[i].sConfig.sUVP.u16SetBits = MOMIAC_Bits_UVP;
		tsMoniAC[i].sConfig.sUVP.i16SetThreshold = UVP_SetThreshold;
		tsMoniAC[i].sConfig.sUVP.i16ClearThreshold = UVP_ClearThreshold;
		tsMoniAC[i].sConfig.sUVP.sConst.u16SetDelay = UVP_SetDelay;
		tsMoniAC[i].sConfig.sUVP.sConst.u16ClearDelay = UVP_ClearDelay;
		tsMoniAC[i].sConfig.sUVP.sVar.u16SetDelay = tsMoniAC[i].sConfig.sUVP.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sUVP.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sUVP.sConst.u16ClearDelay;

		/* For Brown Out Warning */
		tsMoniAC[i].sConfig.sUVW.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sUVW.eLimitType = Limit_Lower;
		tsMoniAC[i].sConfig.sUVW.u16SetBits = MOMIAC_Bits_UVW;
		tsMoniAC[i].sConfig.sUVW.i16SetThreshold = UVW_SetThreshold;
		tsMoniAC[i].sConfig.sUVW.i16ClearThreshold = UVW_ClearThreshold;
		tsMoniAC[i].sConfig.sUVW.sConst.u16SetDelay = UVW_SetDelay;
		tsMoniAC[i].sConfig.sUVW.sConst.u16ClearDelay = UVW_ClearDelay;		
		tsMoniAC[i].sConfig.sUVW.sVar.u16SetDelay = tsMoniAC[i].sConfig.sUVW.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sUVW.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sUVW.sConst.u16ClearDelay;

		/* For Over Voltage Protect */
		tsMoniAC[i].sConfig.sOVP.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOVP.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOVP.u16SetBits = MOMIAC_Bits_OVP;
		tsMoniAC[i].sConfig.sOVP.i16SetThreshold = OVP_SetThreshold;
		tsMoniAC[i].sConfig.sOVP.i16ClearThreshold = OVP_ClearThreshold;
		tsMoniAC[i].sConfig.sOVP.sConst.u16SetDelay = OVP_SetDelay;
		tsMoniAC[i].sConfig.sOVP.sConst.u16ClearDelay = OVP_ClearDelay;	
		tsMoniAC[i].sConfig.sOVP.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOVP.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOVP.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOVP.sConst.u16ClearDelay;

		/* For Fast Over Voltage Protect */
		tsMoniAC[i].sConfig.sOVPH.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOVPH.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOVPH.u16SetBits = MOMIAC_Bits_OVPH;
		tsMoniAC[i].sConfig.sOVPH.i16SetThreshold = OVPH_SetThreshold;
		tsMoniAC[i].sConfig.sOVPH.i16ClearThreshold = OVPH_ClearThreshold;
		tsMoniAC[i].sConfig.sOVPH.sConst.u16SetDelay = OVPH_SetDelay;
		tsMoniAC[i].sConfig.sOVPH.sConst.u16ClearDelay = OVPH_ClearDelay;	
		tsMoniAC[i].sConfig.sOVPH.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOVPH.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOVPH.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOVPH.sConst.u16ClearDelay;

		/* For Over Voltage Warning */
		tsMoniAC[i].sConfig.sOVW.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOVW.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOVW.u16SetBits = MOMIAC_Bits_OVW;
		tsMoniAC[i].sConfig.sOVW.i16SetThreshold = OVW_SetThreshold;
		tsMoniAC[i].sConfig.sOVW.i16ClearThreshold = OVW_ClearThreshold;
		tsMoniAC[i].sConfig.sOVW.sConst.u16SetDelay = OVW_SetDelay;
		tsMoniAC[i].sConfig.sOVW.sConst.u16ClearDelay = OVW_ClearDelay;		
		tsMoniAC[i].sConfig.sOVW.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOVW.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOVW.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOVW.sConst.u16ClearDelay;

		/* For Over Current Protect*/
		tsMoniAC[i].sConfig.sOCP.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOCP.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOCP.u16SetBits = MOMIAC_Bits_OCP;
		tsMoniAC[i].sConfig.sOCP.i16SetThreshold = OCP_SetThreshold;
		tsMoniAC[i].sConfig.sOCP.i16ClearThreshold = OCP_ClearThreshold;
		tsMoniAC[i].sConfig.sOCP.sConst.u16SetDelay = OCP_SetDelay;
		tsMoniAC[i].sConfig.sOCP.sConst.u16ClearDelay = OCP_ClearDelay;	
		tsMoniAC[i].sConfig.sOCP.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOCP.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOCP.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOCP.sConst.u16ClearDelay;

		/* For Over Current Warning */
		tsMoniAC[i].sConfig.sOCW.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOCW.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOCW.u16SetBits = MOMIAC_Bits_OCW;
		tsMoniAC[i].sConfig.sOCW.i16SetThreshold = OCW_SetThreshold;
		tsMoniAC[i].sConfig.sOCW.i16ClearThreshold = OCW_ClearThreshold;
		tsMoniAC[i].sConfig.sOCW.sConst.u16SetDelay = OCW_SetDelay;
		tsMoniAC[i].sConfig.sOCW.sConst.u16ClearDelay = OCW_ClearDelay;	
		tsMoniAC[i].sConfig.sOCW.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOCW.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOCW.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOCW.sConst.u16ClearDelay;

		/* For Over Power Protect */
		tsMoniAC[i].sConfig.sOPP.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOPP.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOPP.u16SetBits = MOMIAC_Bits_OPP;
		tsMoniAC[i].sConfig.sOPP.i16SetThreshold = OPP_SetThreshold;
		tsMoniAC[i].sConfig.sOPP.i16ClearThreshold = OPP_ClearThreshold;
		tsMoniAC[i].sConfig.sOPP.sConst.u16SetDelay = OPP_SetDelay;
		tsMoniAC[i].sConfig.sOPP.sConst.u16ClearDelay = OPP_ClearDelay;	
		tsMoniAC[i].sConfig.sOPP.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOPP.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOPP.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOPP.sConst.u16ClearDelay;

		/* For Over Power Warning */
		tsMoniAC[i].sConfig.sOPW.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOPW.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOPW.u16SetBits = MOMIAC_Bits_OPW;
		tsMoniAC[i].sConfig.sOPW.i16SetThreshold = OPW_SetThreshold;
		tsMoniAC[i].sConfig.sOPW.i16ClearThreshold = OPW_ClearThreshold;
		tsMoniAC[i].sConfig.sOPW.sConst.u16SetDelay = OPW_SetDelay;
		tsMoniAC[i].sConfig.sOPW.sConst.u16ClearDelay = OPW_ClearDelay;	
		tsMoniAC[i].sConfig.sOPW.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOPW.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOPW.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOPW.sConst.u16ClearDelay;

		/* For Over Harmonic Protect */
		tsMoniAC[i].sConfig.sOHP.eTriggerType = TriggerDisable;
		tsMoniAC[i].sConfig.sOHP.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOHP.u16SetBits = MOMIAC_Bits_OHP;
		tsMoniAC[i].sConfig.sOHP.i16SetThreshold = OHP_SetThreshold;
		tsMoniAC[i].sConfig.sOHP.i16ClearThreshold = OHP_ClearThreshold;
		tsMoniAC[i].sConfig.sOHP.sConst.u16SetDelay = OHP_SetDelay;
		tsMoniAC[i].sConfig.sOHP.sConst.u16ClearDelay = OHP_ClearDelay;	
		tsMoniAC[i].sConfig.sOHP.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOHP.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOHP.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOHP.sConst.u16ClearDelay;

		/* For Over Harmonic Warning */
		tsMoniAC[i].sConfig.sOHW.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sOHW.eLimitType = Limit_Upper;
		tsMoniAC[i].sConfig.sOHW.u16SetBits = MOMIAC_Bits_OHW;
		tsMoniAC[i].sConfig.sOHW.i16SetThreshold = OHW_SetThreshold;
		tsMoniAC[i].sConfig.sOHW.i16ClearThreshold = OHW_ClearThreshold;
		tsMoniAC[i].sConfig.sOHW.sConst.u16SetDelay = OHW_SetDelay;
		tsMoniAC[i].sConfig.sOHW.sConst.u16ClearDelay = OHW_ClearDelay;	
		tsMoniAC[i].sConfig.sOHW.sVar.u16SetDelay = tsMoniAC[i].sConfig.sOHW.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sOHW.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sOHW.sConst.u16ClearDelay;

		/* Source Present */
		tsMoniAC[i].sConfig.sSourcePresent.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sSourcePresent.i16SetThresholdHigh = SourcePresent_SetThresholdHigh;
		tsMoniAC[i].sConfig.sSourcePresent.i16SetThresholdLow = SourcePresent_SetThresholdLow;
		tsMoniAC[i].sConfig.sSourcePresent.i16ClearThresholdHigh = SourcePresent_ClearThresholdHigh;
		tsMoniAC[i].sConfig.sSourcePresent.i16ClearThresholdLow = SourcePresent_ClearThresholdLow;
		tsMoniAC[i].sConfig.sSourcePresent.sConst.u16SetDelay = SourcePresent_SetDelay;
		tsMoniAC[i].sConfig.sSourcePresent.sConst.u16ClearDelay = SourcePresent_ClearDelay;	
		tsMoniAC[i].sConfig.sSourcePresent.sVar.u16SetDelay = tsMoniAC[i].sConfig.sSourcePresent.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sSourcePresent.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sSourcePresent.sConst.u16ClearDelay;

		/* Source Good */
		tsMoniAC[i].sConfig.sSourceGood.eTriggerType = TriggerAutoRecover;
		tsMoniAC[i].sConfig.sSourceGood.i16SetThresholdHigh = SourceGood_SetThresholdHigh;
		tsMoniAC[i].sConfig.sSourceGood.i16SetThresholdLow = SourceGood_SetThresholdLow;
		tsMoniAC[i].sConfig.sSourceGood.i16ClearThresholdHigh = SourceGood_ClearThresholdHigh;
		tsMoniAC[i].sConfig.sSourceGood.i16ClearThresholdLow = SourceGood_ClearThresholdLow;
		tsMoniAC[i].sConfig.sSourceGood.sConst.u16SetDelay = DEFAULT_OBSERVE_DELAY_TIME * 1000;
		tsMoniAC[i].sConfig.sSourceGood.sConst.u16ClearDelay = SourceGood_ClearDelay;
		tsMoniAC[i].sConfig.sSourceGood.sVar.u16SetDelay = tsMoniAC[i].sConfig.sSourceGood.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sSourceGood.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sSourceGood.sConst.u16ClearDelay;

		/* For Over Frequency Warning */
		tsMoniAC[i].sConfig.sFreqWarning.eTriggerType = TriggerDisable;
		tsMoniAC[i].sConfig.sFreqWarning.i16SetThresholdHigh = FreqWarning_SetThresholdHigh;
		tsMoniAC[i].sConfig.sFreqWarning.i16SetThresholdLow = FreqWarning_SetThresholdLow;
		tsMoniAC[i].sConfig.sFreqWarning.i16ClearThresholdHigh = FreqWarning_ClearThresholdHigh;
		tsMoniAC[i].sConfig.sFreqWarning.i16ClearThresholdLow = FreqWarning_ClearThresholdLow;
		tsMoniAC[i].sConfig.sFreqWarning.sConst.u16SetDelay = FreqWarning_SetDelay;
		tsMoniAC[i].sConfig.sFreqWarning.sConst.u16ClearDelay = FreqWarning_ClearDelay;
		tsMoniAC[i].sConfig.sFreqWarning.sVar.u16SetDelay = tsMoniAC[i].sConfig.sFreqWarning.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sFreqWarning.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sFreqWarning.sConst.u16ClearDelay;

		/* For Over Frequency Protect */
		tsMoniAC[i].sConfig.sFreqError.eTriggerType = TriggerDisable;
		tsMoniAC[i].sConfig.sFreqError.i16SetThresholdHigh = FreqError_SetThresholdHigh;
		tsMoniAC[i].sConfig.sFreqError.i16SetThresholdLow = FreqError_SetThresholdLow;
		tsMoniAC[i].sConfig.sFreqError.i16ClearThresholdHigh = FreqError_ClearThresholdHigh;
		tsMoniAC[i].sConfig.sFreqError.i16ClearThresholdLow = FreqError_ClearThresholdLow;
		tsMoniAC[i].sConfig.sFreqError.sConst.u16SetDelay = FreqError_SetDelay;
		tsMoniAC[i].sConfig.sFreqError.sConst.u16ClearDelay = FreqError_ClearDelay;		
		tsMoniAC[i].sConfig.sFreqError.sVar.u16SetDelay = tsMoniAC[i].sConfig.sFreqError.sConst.u16SetDelay;
		tsMoniAC[i].sConfig.sFreqError.sVar.u16ClearDelay = tsMoniAC[i].sConfig.sFreqError.sConst.u16ClearDelay;

		tsMoniAC[i].u16FreqMinlimit = Phase_lock_min_falf_CNT;
		tsMoniAC[i].u16FreqMaxlimit = Phase_lock_max_falf_CNT;
		tsMoniAC[i].nStatus.u16Bits.u1NeedtodoRMS = TRUE;
    }

    tsMoniAC[MoniAC_Tag_VPFC].nStatus.u16Bits.u16ReportVrms = TRUE;

	tsMoniAC[MoniAC_Tag_VAC1].eType = MoniAC_Type_Volt;
	tsMoniAC[MoniAC_Tag_VAC2].eType = MoniAC_Type_Volt;
	tsMoniAC[MoniAC_Tag_VPFC].eType = MoniAC_Type_Volt;
	tsMoniAC[MoniAC_Tag_IPFC].eType = MoniAC_Type_Curr;

	/* Get calibration pointer */
	tsMoniAC[MoniAC_Tag_VAC1].psCali = Calibration_GetCoefficient(eCalibration_Tag_VS1);
	tsMoniAC[MoniAC_Tag_VAC2].psCali = Calibration_GetCoefficient(eCalibration_Tag_VS2);
	tsMoniAC[MoniAC_Tag_VPFC].psCali = Calibration_GetCoefficient(eCalibration_Tag_VPFC);
	tsMoniAC[MoniAC_Tag_IPFC].psCali = Calibration_GetCoefficient(eCalibration_Tag_Current);

	/* Set BlackOut High Voltage */
	tsMoniAC[MoniAC_Tag_VAC1].u16Blackout_HV = (u16_t)(((f32_t)Blackout_Real_HVoltage / tsMoniAC[MoniAC_Tag_VAC1].psCali->f32CaliGain) * Q12_);
	tsMoniAC[MoniAC_Tag_VAC2].u16Blackout_HV = (u16_t)(((f32_t)Blackout_Real_HVoltage / tsMoniAC[MoniAC_Tag_VAC2].psCali->f32CaliGain) * Q12_);
	tsMoniAC[MoniAC_Tag_VPFC].u16Blackout_HV = (u16_t)(((f32_t)Blackout_Real_HVoltage / tsMoniAC[MoniAC_Tag_VPFC].psCali->f32CaliGain) * Q12_);
	tsMoniAC[MoniAC_Tag_IPFC].u16Blackout_HV = (u16_t)(((f32_t)Blackout_Real_HVoltage / tsMoniAC[MoniAC_Tag_VPFC].psCali->f32CaliGain) * Q12_);
	
	/* Set BlackOut Low Voltage */
	tsMoniAC[MoniAC_Tag_VAC1].u16Blackout_LV = (u16_t)(((f32_t)Blackout_Real_LVoltage / tsMoniAC[MoniAC_Tag_VAC1].psCali->f32CaliGain) * Q12_);
	tsMoniAC[MoniAC_Tag_VAC2].u16Blackout_LV = (u16_t)(((f32_t)Blackout_Real_LVoltage / tsMoniAC[MoniAC_Tag_VAC2].psCali->f32CaliGain) * Q12_);
	tsMoniAC[MoniAC_Tag_VPFC].u16Blackout_LV = (u16_t)(((f32_t)Blackout_Real_LVoltage / tsMoniAC[MoniAC_Tag_VPFC].psCali->f32CaliGain) * Q12_);
	tsMoniAC[MoniAC_Tag_IPFC].u16Blackout_LV = (u16_t)(((f32_t)Blackout_Real_LVoltage / tsMoniAC[MoniAC_Tag_VPFC].psCali->f32CaliGain) * Q12_);

    /* Set ITIC 200% Vpeak detect point */
	tsMoniAC[MoniAC_Tag_VAC1].u16ITIC_Vpeak_SetPoint = (u16_t)(((f32_t)ITIC_200Persent_VPeak / tsMoniAC[MoniAC_Tag_VAC1].psCali->f32CaliGain) * Q12_);
    tsMoniAC[MoniAC_Tag_VAC2].u16ITIC_Vpeak_SetPoint = (u16_t)(((f32_t)ITIC_200Persent_VPeak / tsMoniAC[MoniAC_Tag_VAC2].psCali->f32CaliGain) * Q12_);
    tsMoniAC[MoniAC_Tag_VPFC].u16ITIC_Vpeak_SetPoint = (u16_t)(((f32_t)ITIC_200Persent_VPeak / tsMoniAC[MoniAC_Tag_VAC1].psCali->f32CaliGain) * Q12_);
    tsMoniAC[MoniAC_Tag_IPFC].u16ITIC_Vpeak_SetPoint = (u16_t)(((f32_t)ITIC_200Persent_VPeak / tsMoniAC[MoniAC_Tag_VAC2].psCali->f32CaliGain) * Q12_);

	/* Pre update calibration value */
	for (i=0; i<MoniAC_Tag_Num; i++)
	{
		UpdateMoniACCalibration((eMoniACTag_t)i);
	}

	tsMoniAC[MoniAC_Tag_VAC1].pi16ADCVSin_Q12 = &GET_ADCFilter_ATS_VAC1_Sin;
	tsMoniAC[MoniAC_Tag_VAC1].pu16ADCVnnn_Q12 = &GET_ADCFilter_ATS_VAC1_nnn;
	tsMoniAC[MoniAC_Tag_VAC1].pu16ADCInnn_Q12 = &GET_ADCFilter_PFC_IAC_nnn;		//no used
	
	tsMoniAC[MoniAC_Tag_VAC2].pi16ADCVSin_Q12 = &GET_ADCFilter_ATS_VAC2_Sin;
	tsMoniAC[MoniAC_Tag_VAC2].pu16ADCVnnn_Q12 = &GET_ADCFilter_ATS_VAC2_nnn;
	tsMoniAC[MoniAC_Tag_VAC2].pu16ADCInnn_Q12 = &GET_ADCFilter_PFC_IAC_nnn;		//no used
	
	tsMoniAC[MoniAC_Tag_VPFC].pi16ADCVSin_Q12 = &GET_ADCFilter_PFC_VAC_Sin;
	tsMoniAC[MoniAC_Tag_VPFC].pu16ADCVnnn_Q12 = &GET_ADCFilter_PFC_VAC_nnn;
	tsMoniAC[MoniAC_Tag_VPFC].pu16ADCInnn_Q12 = &GET_ADCFilter_PFC_IAC_nnn;		//no used
	
	tsMoniAC[MoniAC_Tag_IPFC].pi16ADCVSin_Q12 = &GET_ADCFilter_PFC_VAC_Sin;		//phase detect used
	tsMoniAC[MoniAC_Tag_IPFC].pu16ADCVnnn_Q12 = &GET_ADCFilter_PFC_VAC_nnn;		//phase detect used
	tsMoniAC[MoniAC_Tag_IPFC].pu16ADCInnn_Q12 = &GET_ADCFilter_PFC_IAC_nnn;
		
}

