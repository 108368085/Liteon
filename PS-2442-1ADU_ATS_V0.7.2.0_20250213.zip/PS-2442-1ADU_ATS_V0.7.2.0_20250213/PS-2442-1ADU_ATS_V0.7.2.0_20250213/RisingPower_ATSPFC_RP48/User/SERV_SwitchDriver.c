/****************************************************************************
 *	File	SERV_SwitchDriver.c
 * 	Brief	ATS Switch
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/10/19 - 1st release
 ****************************************************************************/

#include "F28x_Project.h"
#include "SERV_SwitchDriver.h"
#include "Peripheral.h"
#include <string.h>



/****************************************************************************
*	Private parameter definition 
****************************************************************************/

#define Duty_OFF    	0       // 0% 	Duty Off
#define Duty_TurnON     Q16_    // 100% Full Duty for turn on
#define Duty_ON    		52428   // 80% 	Duty for power saving
#define Duty_75P        49151   // 75%  Duty


/****************************************************************************
*	Private macro definition
****************************************************************************/ 

/****************************************************************************
*	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
*	Private structure definition 
****************************************************************************/

/****************************************************************************
*	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 96
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(SetSwitchState, ".TI.ramfunc");
#endif

/****************************************************************************
*	Private variable declaration
****************************************************************************/

sSwitchDriver_t ptSwitch[SwitchDriver_Tag_Num];

/***************************************************************************
*   brief  	Switch PWM Duty or GPIO
*   note    Add by AD
****************************************************************************/
static inline void SetSwitch(eSwitchTag_t eTag, eSwitchState_t eNewState)
{
	switch (eTag)
	{
		case SwitchDriver_Tag_ATS_Relay1:

			if (eNewState == SwitchDriver_State_OFF)
			{
				SET_GPIO_AC1_RELAY_DIS;
				SET_GPIO_AC1_24V_DIS;				
			}
			else if (eNewState == SwitchDriver_State_TurnOn)
			{
				SET_GPIO_AC1_RELAY_EN;
				SET_GPIO_AC1_24V_EN;
			}
			else
			{
				SET_GPIO_AC1_RELAY_EN;
				SET_GPIO_AC1_24V_DIS;
			}
			
			break;

		case SwitchDriver_Tag_ATS_Relay2:

			if (eNewState == SwitchDriver_State_OFF)
			{
				SET_GPIO_AC2_RELAY_DIS;
				SET_GPIO_AC2_24V_DIS;				
			}
			else if (eNewState == SwitchDriver_State_TurnOn)
			{
				SET_GPIO_AC2_RELAY_EN;
				SET_GPIO_AC2_24V_EN;
			}
			else
			{
				SET_GPIO_AC2_RELAY_EN;
				SET_GPIO_AC2_24V_DIS;
			}
			
			break;


		case SwitchDriver_Tag_PFC_Relay:

			if (eNewState == SwitchDriver_State_OFF)
			{
				PeriEPwm_SetDuty(ePeriEPwm_Tag_PFCRELAY, Duty_OFF);			
			}
			else if (eNewState == SwitchDriver_State_TurnOn)
			{
				PeriEPwm_SetDuty(ePeriEPwm_Tag_PFCRELAY, Duty_TurnON);	
			}
			else
			{
				PeriEPwm_SetDuty(ePeriEPwm_Tag_PFCRELAY, Duty_ON);
			}
			
			break;


		case SwitchDriver_Tag_PFC_IGBT:

			if (eNewState == SwitchDriver_State_OFF)
			{
				PeriEPwm_SetDuty(ePeriEPwm_Tag_PFCIGBT, Duty_OFF);	
			}
			else
			{
				PeriEPwm_SetDuty(ePeriEPwm_Tag_PFCIGBT, Duty_TurnON);
			}
			
			break;

		default:
			break;
	}
}

/***************************************************************************
*   brief  	Assign target switch driver new state
*   note   	eTag : target switch driver tag
*			eNewState : target switch driver new state
*	return	NULL
****************************************************************************/
void SetSwitchState(sSwitchDriver_t *psSwitch, eSwitchState_t eNewState)
{
	if (psSwitch->eState == eNewState)
	{
		psSwitch->u16ElapsedTime = 0;
		return;
	}
	
	SetSwitch(psSwitch->eTag, eNewState);	
	psSwitch->eState = eNewState;
	psSwitch->u16ElapsedTime = 0;
}

/***************************************************************************
*   brief  	Return target switch driver address
*   note   
*	para	eTag : target switch driver tag
*	return	target switch driver address
****************************************************************************/
sSwitchDriver_t* GetSwitchDriverRef(eSwitchTag_t eTag)
{
	return &ptSwitch[eTag];
}

/***************************************************************************
*   brief  	Switch driver module initialize
*   note   
****************************************************************************/
void SwitchDriver_Initialize(void)
{
	u16_t i;
	
	for (i=0; i<SwitchDriver_Tag_Num; i++)
	{
		memset(&ptSwitch[i], 0, sizeof(ptSwitch[i]));		
		ptSwitch[i].eTag = (eSwitchTag_t)i;		
	}
}

