/****************************************************************************
 *	File	SysTime.c
 * 	Brief	Used to get the system time
 * 	Note	Instant_Process	-> interrupt time
 * 			Periodically_Process -> Systime
 * 			Background_Process -> Main while loop
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/08/17 - 2nd release
 *		-	2014/04/09: initial version by allen lee
 ****************************************************************************/

#include "SysTime.h"
#include "F28x_Project.h"
#include "Peripheral.h"
#include "CONFIG_RisingPower.h"
#include <string.h>

/* include service */
#include "SERV_ADCFilter.h"
#include "SERV_Calibration.h"
#include "SERV_LED.h"
#include "SERV_LOG.h"
#include "SERV_FFT.h"
#include "SERV_SwitchDriver.h"
#include "Monitor_AC.h"
#include "Monitor_DC.h"
#include "Monitor_TP.h"
#include "Handler_ATS.h"
#include "Handler_PFC.h"
#include "E2P_Driver.h"
#include "E2P_Data.h"
#include "E2P_BlackBox.h"
#include "E2P_Waveform.h"
#include "FLASH_IAP.h"
#include "ModBus_Data.h"
#include "ModBus_Server.h"
#include "CANBus_Data.h"
#include "CANBus_Server.h"


/****************************************************************************
*	Private parameter definition 
****************************************************************************/

/****************************************************************************
*	Private macro definition
****************************************************************************/ 

/****************************************************************************
*	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
*	Private structure definition 
****************************************************************************/

/****************************************************************************
*	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 142
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(INTERRUPT_ADC, ".TI.ramfunc");
#pragma CODE_SECTION(INTERRUPT_10kHz, ".TI.ramfunc");
#pragma CODE_SECTION(SysTime, ".TI.ramfunc");
#endif


/****************************************************************************
*	Private variable declaration
****************************************************************************/

sSysTimer_t  tsSysTimer;

/****************************************************************************
*	Brief	PWM Period time in ADC interrupt
*	Note	
****************************************************************************/
void INTERRUPT_ADC(void)
{
	ADCFilter_PWM_Instant_Process();
	PFC_Current_Loop_Handler();
}

/****************************************************************************
*	Brief	Timer0 interrupt
*	Note	10kHz
****************************************************************************/
void INTERRUPT_10kHz(void)
{
	if (GET_LOG_MAIN_ISR_TOGGLE)
	{
		SET_GPIO_DEBUG1_H;
	}

	ADCFilter_10k_Instant_Process();
	MoniAC_10k_Instant_Process();
	ATS_Handler();
	PFC_Handler();
	PFC_Voltage_Loop_Handler();
	Log_10k_Instant_Process();
	Waveform_10k_Instant_Process();

	if (GET_LOG_MAIN_ISR_TOGGLE)
	{
		SET_GPIO_DEBUG1_L;
	}
}

/****************************************************************************
*	Brief	1ms system time in while loop
*	Note	
****************************************************************************/
static inline void SysTime_1ms(void)
{
	ADCFilter_1ms_Periodically_Process();
	MoniAC_1ms_Periodically_Process();
	MoniDC_1ms_Periodically_Process();
	ATS_1ms_Periodically_Process();
	PFC_1ms_Periodically_Process();
	PeriSPI_1ms_Periodically_Process();
	PeriSCI_1ms_Periodically_Process();
	Log_1ms_Periodically_Process();
	PeriCAN_1ms_Periodically_Process();
	CANBusServer_1ms_Periodically_Process();
}

/****************************************************************************
*	Brief	10ms system time in while loop
*	Note	
****************************************************************************/
static inline void SysTime_10ms(void)
{
	ADCFilter_10ms_Periodically_Process();
	MoniDC_10ms_Periodically_Process();
	MBusServer_10ms_Periodically_Process();
	CANBusData_10ms_Periodically_Process();
	MoniAC_10ms_Periodically_Process();
	Log_10ms_Periodically_Process();
    PFC_10ms_Periodically_Process();
}

/****************************************************************************
*	Brief	100ms system time in while loop
*	Note	
****************************************************************************/
static inline void SysTime_100ms(void)
{
	ADCFilter_100ms_Periodically_Process();
	ATS_100ms_Periodically_Process();
}

/****************************************************************************
*	Brief	1sec system time in while loop
*	Note	
****************************************************************************/
static inline void SysTime_1sec(void)
{
	MoniTP_1s_Periodically_Process();
	ATS_1s_Periodically_Process();
	PFC_1s_Periodically_Process();
	Log_1s_Periodically_Process();
	CANBusServer_1s_Periodically_Process();
	FFT_1s_Periodically_Process();
	MoniAC_1s_Periodically_Process();
}

/****************************************************************************
*	Brief	1min system time in while loop
*	Note	
****************************************************************************/
static inline void SysTime_1min(void)
{
	BlackBox_1min_Periodically_Process();
}

/****************************************************************************
*	Brief	1hour system time in while loop
*	Note	
****************************************************************************/
static inline void SysTime_1hour(void)
{
	Log_1hr_Periodically_Process();
}

/****************************************************************************
*	Brief	System time state machine handler
*	Note	system time base is 1ms (1kHz)
****************************************************************************/
static inline void SysTime_Background_Process(void)
{
    if (tsSysTimer.u16SysTimeBase == 1)
    {
        tsSysTimer.u16SysTimeBase = 0;
        tsSysTimer.u16Sys_1ms++;
        SysTime_1ms();
        
        if (tsSysTimer.u16Sys_1ms >= 10)
        {
        	tsSysTimer.u16Sys_1ms -= 10;
        	tsSysTimer.u16Sys_10ms++;
			SysTime_10ms();
        	
        	if (tsSysTimer.u16Sys_10ms >= 10)
        	{
        		tsSysTimer.u16Sys_10ms -= 10;
        		tsSysTimer.u16Sys_100ms++;				
				SysTime_100ms();
       	 		    		
        		if (tsSysTimer.u16Sys_100ms >= 10)
        		{
        			tsSysTimer.u16Sys_100ms -= 10;
        			tsSysTimer.u16Sys_1sec ++;
					SysTime_1sec();
        			
        			if (tsSysTimer.u16Sys_1sec >= 60)
        			{
        				tsSysTimer.u16Sys_1sec -= 60;
        				tsSysTimer.u16Sys_1min++;
						SysTime_1min();
        				
        				if (tsSysTimer.u16Sys_1min >= 60)
        				{
        					tsSysTimer.u16Sys_1min -= 60;
        					tsSysTimer.u16Sys_1hour++;
							SysTime_1hour();
        					
        					if (tsSysTimer.u16Sys_1hour >= 24)
        					{
        						tsSysTimer.u16Sys_1hour -= 24;
        					}
        				}	
        			}
        		}
        	}
        }
    }

}


/****************************************************************************
*	Brief	System time
*	Note	In while loop
****************************************************************************/
void SysTime(void)
{
	CANBusServer_Background_Process();
	Peripheral_Background_Process();
	E2pData_Background_Process();
	SysTime_Background_Process();
	IAP_Background_Process();
	MBusServer_Background_Process();
    BlackBox_Background_Process();
	FFT_Background_Process();
}

/****************************************************************************
*	Brief	Initialize systime variable
*	Note	
****************************************************************************/
static void SysTime_Initialize(void)
{
	memset(&tsSysTimer, 0, sizeof(tsSysTimer));
}

/***************************************************************************
*   brief  Service Initialize
*   note   
****************************************************************************/
void Service_Initialize(void)
{
	/* Initialize Service Function */
	SysTime_Initialize();	
	E2pDrv_Initialize();
	E2pData_Initialize();
	BlackBox_Initialize();
	SwitchDriver_Initialize();
	LED_Initialize();
    Calibration_Initialize();
	ADCFilter_Initialize();
	MoniAC_Initialize();
	MoniDC_Initialize();
	MoniTP_Initialize();
	Log_Initialize();
	ATS_Initialize();
	PFC_Initialize();
	IAP_Initialize();
	FFT_Initialize();
	MBusData_Initialize();
	MBusServer_Initialize();
	CANBusData_Initialize();
	CANBusServer_Initialize();

}


