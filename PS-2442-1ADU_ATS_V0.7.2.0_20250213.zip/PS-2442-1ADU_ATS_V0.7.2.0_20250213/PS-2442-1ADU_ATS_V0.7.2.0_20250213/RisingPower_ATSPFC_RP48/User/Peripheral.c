/****************************************************************************
 *	File	Peripheral.c
 *	Brief	Configure and control peripheral modules on TI 28004x platform
 *	Note
 *	Author	Adonis Wang
 *	Ver 	01
 *	History 2020/08/17 - 1st release
 ****************************************************************************/

/****************************************************************************
*	Included Files
****************************************************************************/

#include "Peripheral.h"
#include "CONFIG_RisingPower.h"

/****************************************************************************
    Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 8
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Peripheral_Background_Process, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/

/**
 *  @brief  Initial all used peripheral
 *  @retval None
 */
void Peripheral_Initialize(void)
{	
	/* Initial Peripheral - GPIO */
    PeriGPIO_Initialize();

    /* Initial Peripheral - ADC */
    PeriAdc_Initialize();

    /* Initial Peripheral - DAC */
    PeriDac_Initialize();

    /* Initial Peripheral - CMPSS */
    PeriCmpss_Initialize();

	/* Initial Peripheral - EPWM */
	PeriEPwm_Initialize();
    
    /* Initial Peripheral - CPU Timer */
    PeriCpuTimer_Initialize();

    /* Initial Peripheral - SCI */
     PeriSCI_Initialize();

    /* Initial Peripheral - I2C */
    // PeriI2C_Initialize();

	/* Initial Peripheral - SPI */
	PeriSPI_Initialize();

	/* Initial Peripheral - CAN */
	PeriCAN_Initialize();

	/* Initial Peripheral - Flash */
	PeriFlash_Initialize();

}


/**
 *  @brief Start necessary peripheral
 *  @retval None
 */
void Peripheral_Start(void)
{
    PeriAdc_Start();
    PeriCmpss_Start();
    PeriDac_Start();
	PeriCpuTimer_Start();
	PeriPWM_Start();
	PeriSPI_Start();
    PeriSCI_Start();
	PeriCAN_Start();
    //PeriI2C_Start();
}

/**
 *  @brief  Stop necessary peripheral
 *  @retval None
 */
void Peripheral_Stop(void)
{
	PeriPWM_Stop();
	PeriCpuTimer_Stop();
    PeriAdc_Stop();
    PeriCmpss_Stop();
    PeriDac_Stop();
	PeriSPI_Stop();
	PeriSCI_Stop();
	PeriCAN_Stop();
    //PeriI2C_Stop();
    SET_GPIO_D2D_DIS; // Turn off D2D after disable modbus for D2D UVP issue when ATS bootloader
}

/**
 *  @brief  Peripheral background process
 *  @retval None
 */
void Peripheral_Background_Process(void)
{
	PeriSPI_Background_Process();
    PeriSCI_Background_Process();
	PeriCAN_Background_Process();
	//PeriI2C_Background_Process();
}


