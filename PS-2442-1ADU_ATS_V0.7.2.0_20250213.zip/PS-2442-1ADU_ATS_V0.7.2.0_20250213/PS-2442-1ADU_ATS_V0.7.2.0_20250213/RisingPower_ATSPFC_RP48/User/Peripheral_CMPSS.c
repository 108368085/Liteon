/****************************************************************************
 *	File	Peripheral_CMPSS.c
 * 	Brief	Configure Comparator SubSystem module on TI 28004x platform
 *  Note    See TI SPEC "Analog Pins and Internal Connections"
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/
 
#include "F28x_Project.h"
#include "Peripheral_CMPSS.h"
#include "Handler_PFC.h"

/****************************************************************************
    Private parameter definition
****************************************************************************/

/* Configure Digital Filter 
 * Maximum SAMPWIN value provides largest number of samples
 * 3+1 sample counts,  1us*4 = 4us
 */

#define CMPSS_SAMPWIN			0x03


/* Maximum THRESH value requires static value for entire window 
 * SAMPWIN/2 < THRESH <= SAMPWIN
 * Output would be changed if condition is matched during THRESH duration
 * 2+1 sample counts,  1us*3 = 3us
 */

#define CMPSS_THRESH			0x02

/* Configure Digital Filter 
 * Maximum CLKPRESCALE value provides the most time between samples
 * 99+1, 100MHz/100 = 1MHz
 */

#define CMPSS_CLKPRESCALE		0x63


/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

/****************************************************************************
	Private variable declaration
****************************************************************************/

/**
 *  @brief  Initial CMPSS 2H module
 *  @Note 	For Interleaved PFC phase A current positive protect
 *			Using CMPSS-2 High Comparator Positive Input 0 (CMPSS2.CTRIPH) for trip 7
 */
static inline void PeriCmpss_Init_CMPSS2HP(void)
{
    EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPHPMXSEL.bit.CMP2HPMXSEL = 0;// Select Pin36 for CMPSS2 High Positive input source (49 Please refer to P.1415)
                                                    //                                                     39 Please refer to P.1758  Alden

	/* CMPSSx Comparator Config */
	Cmpss2Regs.COMPCTL.bit.COMPDACE = 1;            // Enable Comparator/DAC
    Cmpss2Regs.COMPCTL.bit.COMPHSOURCE = 0;         // Inverting input of comparator driven by internal DAC
    Cmpss2Regs.COMPCTL.bit.COMPHINV = 0;            // Output of comparator is not inverted
    Cmpss2Regs.COMPCTL.bit.ASYNCHEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

    Cmpss2Regs.COMPDACCTL.bit.DACSOURCE = 0;        // DACHVALA is updated from DACHVALS
    Cmpss2Regs.COMPDACCTL.bit.SELREF = 0;           // VDDA is the voltage reference for the DAC
    Cmpss2Regs.COMPDACCTL.bit.SWLOADSEL = 0;        // DACxVALA is updated from DACxVALS on SYSCLK
    
    Cmpss2Regs.DACHVALS.bit.DACVAL = 0xFFF;         // Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss2Regs.CTRIPHFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss2Regs.CTRIPHFILCTL.bit.THRESH = CMPSS_THRESH;
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
    Cmpss2Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = CMPSS_CLKPRESCALE;
  
    /* Reset filter logic and start filtering */
    Cmpss2Regs.CTRIPHFILCTL.bit.FILINIT = 1;

	Cmpss2Regs.COMPCTL.bit.CTRIPHSEL = 2;           // Output of digital filter drives CTRIPH
	
	EDIS;
}


/**
 *  @brief  Initial CMPSS 2L module
 *  @Note 	For Interleaved PFC phase A current negative protect
 *			Using CMPSS-2 Low Comparator Positive Input 0 (CMPSS2.CTRIPL) for trip 7
 */
static inline void PeriCmpss_Init_CMPSS2LP(void)
{
	EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPLPMXSEL.bit.CMP2LPMXSEL = 0;// Select Pin36 for CMPSS2 Low Positive input source

	/* CMPSSx Comparator Config */
    Cmpss2Regs.COMPCTL.bit.COMPLSOURCE = 0;         // Inverting input of comparator driven by internal DAC
    Cmpss2Regs.COMPCTL.bit.COMPLINV = 1;            // Output of comparator is inverted  
    Cmpss2Regs.COMPCTL.bit.ASYNCLEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

    Cmpss2Regs.DACLVALS.bit.DACVAL = 0;         	// Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss2Regs.CTRIPLFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss2Regs.CTRIPLFILCTL.bit.THRESH = CMPSS_THRESH;
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
    Cmpss2Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = CMPSS_CLKPRESCALE;
  
    /* Reset filter logic and start filtering */
    Cmpss2Regs.CTRIPLFILCTL.bit.FILINIT = 1;

	Cmpss2Regs.COMPCTL.bit.CTRIPLSEL = 2;			// Output of digital filter drives CTRIPH

    EDIS;
}


/**
 *  @brief  Initial CMPSS 6H module
 *  @Note 	For Interleaved PFC phase B current positive protect
 *			Using CMPSS-6 High Comparator Positive Input 3 (CMPSS6.CTRIPH) for trip 8
 */
static inline void PeriCmpss_Init_CMPSS6HP(void)
{
    EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPHPMXSEL.bit.CMP6HPMXSEL = 3;// Select Pin38 for CMPSS6 High Positive input source (49 Please refer to P.1415)
                                                    //                                                     39 Please refer to P.1758  Alden

	/* CMPSSx Comparator Config */
	Cmpss6Regs.COMPCTL.bit.COMPDACE = 1;            // Enable Comparator/DAC
    Cmpss6Regs.COMPCTL.bit.COMPHSOURCE = 0;         // COMPH, Inverting input of comparator driven by internal DAC
    Cmpss6Regs.COMPCTL.bit.COMPHINV = 0;            // Output of comparator is not inverted 
    Cmpss6Regs.COMPCTL.bit.ASYNCHEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

    Cmpss6Regs.COMPDACCTL.bit.DACSOURCE = 0;        // DACHVALA is updated from DACHVALS
    Cmpss6Regs.COMPDACCTL.bit.SELREF = 0;           // VDDA is the voltage reference for the DAC
    Cmpss6Regs.COMPDACCTL.bit.SWLOADSEL = 0;        // DACxVALA is updated from DACxVALS on SYSCLK
    
    Cmpss6Regs.DACHVALS.bit.DACVAL = 0xFFF;         // Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss6Regs.CTRIPHFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss6Regs.CTRIPHFILCTL.bit.THRESH = CMPSS_THRESH;
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
    Cmpss6Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = CMPSS_CLKPRESCALE;
  
    /* Reset filter logic and start filtering */
    Cmpss6Regs.CTRIPHFILCTL.bit.FILINIT = 1;

	Cmpss6Regs.COMPCTL.bit.CTRIPHSEL = 2;			// Output of digital filter drives CTRIPH

	EDIS;
}


/**
 *  @brief  Initial CMPSS 6L module
 *  @Note 	For Interleaved PFC phase B current negative protect
 *			Using CMPSS-6 Low Comparator Positive Input 3 (CMPSS6.CTRIPL) for trip 8
 */
static inline void PeriCmpss_Init_CMPSS6LP(void)
{
	EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPLPMXSEL.bit.CMP6LPMXSEL = 3;// Select Pin38 for CMPSS6 Low Positive input source

	/* CMPSSx Comparator Config */
    Cmpss6Regs.COMPCTL.bit.COMPLSOURCE = 0;         // COMPH, Inverting input of comparator driven by internal DAC
    Cmpss6Regs.COMPCTL.bit.COMPLINV = 1;            // Output of comparator is inverted
    Cmpss6Regs.COMPCTL.bit.ASYNCLEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output
	
    Cmpss6Regs.DACLVALS.bit.DACVAL = 0;         	// Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss6Regs.CTRIPLFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss6Regs.CTRIPLFILCTL.bit.THRESH = CMPSS_THRESH;
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
    Cmpss6Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = CMPSS_CLKPRESCALE;
  
    /* Reset filter logic and start filtering */
    Cmpss6Regs.CTRIPLFILCTL.bit.FILINIT = 1;

	Cmpss6Regs.COMPCTL.bit.CTRIPLSEL = 2;			// Output of digital filter drives CTRIPH

    EDIS;
}

/**
 *  @brief  Initial CMPSS module
 *  @retval None
 */
void PeriCmpss_Initialize(void)
{
	PeriCmpss_Init_CMPSS2HP();
	PeriCmpss_Init_CMPSS2LP();
	PeriCmpss_Init_CMPSS6HP();
	PeriCmpss_Init_CMPSS6LP();
}

/** 
 *  @brief  Set internal DAC value
 *  @param  u16Value: DAC value of comparator 
 *  @retval None
 */
static void PeriCmpss_SetCMPSSHPValue(u16_t u16Value)
{
    EALLOW;
    Cmpss2Regs.DACHVALS.bit.DACVAL = u16Value;
	Cmpss6Regs.DACHVALS.bit.DACVAL = u16Value;
    EDIS;
}

/** 
 *  @brief  Set internal DAC value
 *  @param  u16Value: DAC value of comparator 
 *  @retval None
 */
static void PeriCmpss_SetCMPSSLPValue(u16_t u16Value)
{
    EALLOW;
    Cmpss2Regs.DACLVALS.bit.DACVAL = u16Value;
	Cmpss6Regs.DACLVALS.bit.DACVAL = u16Value;
    EDIS;
}

/**
 *  @brief  Start peripheral - CMPSS
 *  @retval None
 */
void PeriCmpss_Start(void)
{
	PeriCmpss_SetCMPSSHPValue(PFC_CBC_HIGH);
	PeriCmpss_SetCMPSSLPValue(PFC_CBC_Low);
}

/**
 *  @brief  Stop peripheral - CMPSS
 *  @retval None
 */
void PeriCmpss_Stop(void)
{
	PeriCmpss_SetCMPSSHPValue(0xFFF);
	PeriCmpss_SetCMPSSLPValue(0);
    EALLOW;
    Cmpss2Regs.COMPCTL.bit.COMPDACE = 0;            // Disable Comparator/DAC
    Cmpss6Regs.COMPCTL.bit.COMPDACE = 0;            // Disable Comparator/DAC
    EDIS;
}

