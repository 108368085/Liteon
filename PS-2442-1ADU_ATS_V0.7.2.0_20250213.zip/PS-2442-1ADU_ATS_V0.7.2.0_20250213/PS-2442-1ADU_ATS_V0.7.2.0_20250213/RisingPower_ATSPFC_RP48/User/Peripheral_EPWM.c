/****************************************************************************
 *	File	Peripheral_EPWM.c
 * 	Brief	Configure and control ePWM module on TI 28004x platform
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 *
 *			EPWM1A: 100kHz	BIAS_A
 *			EPWM1B: 100kHz	BIAS_B
 *			EPWM3A: 20kHz	PFC inrush limit relay
 *			EPWM3B: 20kHz	PFC inrush limit IGBT
 *			EPWM4B: 200KHz  Pass Vbulk level to D2D
 *          EPWM7A: 40kHz	Interleaved Totlem Pole PFC phase A H side
 *          EPWM7B: 40kHz	Interleaved Totlem Pole PFC phase A L side
 *          EPWM8A: 40kHz	Interleaved Totlem Pole PFC phase B H side
 *          EPWM8B: 40kHz	Interleaved Totlem Pole PFC phase B L side
 *
 *          1. EPWM7 trigger ADCSOC in up-down-count at Zero
 *          2. EPWM8 trigger ADCSOC in up-down-count at Period
 *          3. When EPWM8 trigger EOC5 over, will enter ADC 40KHz interrupt
 *
 *          \ GATE_A(PWM7A)     \ GATE_C(PWM8A)
 *          |-------------------|
 *          \ GATE_B(PWM7B)     \ GATE_D(PWM8B)
 ****************************************************************************/

#include "F28x_Project.h"
#include "sw_prioritized_isr_levels.h"
#include "Peripheral.h"
#include "Peripheral_EPWM.h"
#include "Handler_PFC.h"
#include <string.h>


/****************************************************************************
    Private parameter definition
****************************************************************************/

   
/****************************************************************************
	Private macro definition
****************************************************************************/

#define STOP_ALL_PWM_CLOCK()                            \
        do                                              \
        {                                               \
            EALLOW;                                     \
            CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;       \
            EDIS;                                       \
        }while(0)

#define START_ALL_PWM_CLOCK()                           \
        do                                              \
        {                                               \
            EALLOW;                                     \
            CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;       \
            EDIS;                                       \
        }while(0)        
/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 237
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(PeriPWM_PFC_Pos_Polarity, ".TI.ramfunc");
#pragma CODE_SECTION(PeriPWM_PFC_Neg_Polarity, ".TI.ramfunc");
#pragma CODE_SECTION(PeriPWM_PFC_DB_Enable, ".TI.ramfunc");
#pragma CODE_SECTION(PeriEPwm_PFC_Enable, ".TI.ramfunc");
#pragma CODE_SECTION(PeriEPwm_PFC_Disable, ".TI.ramfunc");
#pragma CODE_SECTION(PeriEPwm_SetDuty, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declaration
****************************************************************************/
u16_t PWM_Period[ePeriEPwm_Tag_Num];


/**
 *  @brief  Initial and configure EPwm-XBar
 *  @retval None : Keyword search TI specification "ePWM X-BAR Mux Configuration Table"
 */
static inline void PeriEPwm_Init_EPwmXBar(void)
{
	/* Setting X-Bar */
    EALLOW;

	// PFC IpfcA Positive and Negatice current limit Select ePWMXbar Trip7 for MUX=2.1(CMPSS2.CTRIPH_OR_CTRIPL)
	EPwmXbarRegs.TRIP7MUX0TO15CFG.bit.MUX2 = 1;		//Select input for Mux2.1
	EPwmXbarRegs.TRIP7MUXENABLE.bit.MUX2 = 1;		//enabled to drive the TRIP7 of EPWM-XBAR

	// PFC IpfcB Positive and Negatice current limit Select ePWMXbar Trip8 for MUX=10.1(CMPSS6.CTRIPH_OR_CTRIPL)
	EPwmXbarRegs.TRIP8MUX0TO15CFG.bit.MUX10 = 1;	//Select input for Mux10.1
	EPwmXbarRegs.TRIP8MUXENABLE.bit.MUX10 = 1;		//enabled to drive the TRIP8 of EPWM-XBAR
    
    EDIS;
}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM1
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM1_IO_Multiplexer(void)
{
    EALLOW;

    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO0 = 1;     // Disable pull-up on GPIO0 (EPWM1A)
    GpioCtrlRegs.GPAPUD.bit.GPIO1 = 1;     // Disable pull-up on GPIO1 (EPWM1B)
    
    /* Configure EPWM1 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM1 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0;
	GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;    // Configure GPIO0 as EPWM1A
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;    // Configure GPIO1 as EPWM1B

    EDIS;
}

/**
 *  @brief  Initial and configure EPWM1 for BIAS_A and BIAS_B
 *  @retval None
 */ 
static inline void PeriEPwm_Init_EPWM1(void)
{
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM1_IO_Multiplexer();
    
    /* Configure Time-Base(TB) Submodule */
    EPwm1Regs.TBPRD = EPWM1_PERIOD;							// Setting the period of the time-base counter
    EPwm1Regs.TBPHS.bit.TBPHS = 0;							// These bits set time-base counter phas
    EPwm1Regs.TBCTR = 0x0000;                               // Clear Time Base Counter
    EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;          // Up-down count mode
    EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;					// TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;				// TBCLK = EPWMCLK / 1*1
    EPwm1Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    
    /* Configure Counter-Compare(CC) Submodule */
    EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
	EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm1Regs.CMPA.bit.CMPA = EPWM1_PERIOD/2;				// 50% Duty
   
    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;                    // Set   when TBCTR = CMPA on Up Count
	EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;                    	// Clear when TBCTR = CMPA on Down Count
	EPwm1Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately
    
    /* Configure Dead-Band(DB) Submodule - Active High Complementary */
	EPwm1Regs.DBCTL.bit.IN_MODE = DBA_ALL;					// EPWMxA is the source for both OutA and OutB
	EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;				// EPWMxB is inverted.
	EPwm1Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;			// DBM is fully enabled
	EPwm1Regs.DBRED.bit.DBRED = 50; 						// 500ns = 50*0.01us, RED = DBRED*TBCLK
	EPwm1Regs.DBFED.bit.DBFED = 50;							// 500ns = 50*0.01us, FED = DBFED*TBCLK
    
    /* Configure Trip-Zone(TZ) Submodule */
    
    /* Configure Digital-Compare(DC) Submodule */
    
    /* Configure Event-Trigger(ET) Submodule */

}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM3
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM3_IO_Multiplexer(void)
{
    EALLOW;

    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO4 = 1;     // Disable pull-up on GPIO4 (EPWM3A)
    GpioCtrlRegs.GPAPUD.bit.GPIO5 = 1;     // Disable pull-up on GPIO5 (EPWM3B)
    
    /* Configure EPWM3 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM3 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO4 = 0;
	GpioCtrlRegs.GPAGMUX1.bit.GPIO5 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;    // Configure GPIO4 as EPWM3A
    GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1;    // Configure GPIO5 as EPWM3A

    EDIS;
}

/**
 *  @brief  Initial and configure EPWM3 for inrush Relay and inrush IGBT
 *  @retval None
 */ 
static inline void PeriEPwm_Init_EPWM3(void)
{
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM3_IO_Multiplexer();
    
    /* Configure Time-Base(TB) Submodule */
    EPwm3Regs.TBPRD = EPWM3_PERIOD;
    EPwm3Regs.TBPHS.bit.TBPHS = 0;
    EPwm3Regs.TBCTR = 0x0000;                               // Clear TB counter
    EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;              // Up count mode
    EPwm3Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;					// TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;				// TBCLK = EPWMCLK / 1*1
    EPwm3Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    
    /* Configure Counter-Compare(CC) Submodule */
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
	EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
    EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm3Regs.CMPA.bit.CMPA = 0;
	EPwm3Regs.CMPB.bit.CMPB = 0;
    
    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm3Regs.AQCTLA.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
	EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPA
    EPwm3Regs.AQCTLB.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
	EPwm3Regs.AQCTLB.bit.CBU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPB
	EPwm3Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately
    
    /* Configure Dead-Band(DB) Submodule */
    EPwm3Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;
    
    /* Configure Trip-Zone(TZ) Submodule */
    
    /* Configure Digital-Compare(DC) Submodule */
    
    /* Configure Event-Trigger(ET) Submodule */

}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM4
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM4_IO_Multiplexer(void)
{
    EALLOW;

    /* Disable internal pull-up for the selected output pins for reduced power consumption */
//    GpioCtrlRegs.GPAPUD.bit.GPIO6 = 1;     // Disable pull-up on GPIO4 (EPWM4A)
    GpioCtrlRegs.GPAPUD.bit.GPIO7 = 1;     // Disable pull-up on GPIO5 (EPWM4B)

    /* Configure EPWM3 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM3 functional pins */
//    GpioCtrlRegs.GPAGMUX1.bit.GPIO6 = 0;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO7 = 0;
//    GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 1;    // Configure GPIO6 as EPWM4A
    GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 1;    // Configure GPIO7 as EPWM4B

    EDIS;
}

/**
 *  @brief  Initial and configure EPWM4 for pass VBulk level to D2D
 *  @retval None
 */
static inline void PeriEPwm_Init_EPWM4(void)
{
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM4_IO_Multiplexer();

    /* Configure Time-Base(TB) Submodule */
    EPwm4Regs.TBPRD = EPWM4_VbulkToD2D_PERIOD;
    EPwm4Regs.TBPHS.bit.TBPHS = 0;
    EPwm4Regs.TBCTR = 0x0000;                               // Clear TB counter
    EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;              // Up count mode
    EPwm4Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm4Regs.TBCTL.bit.CLKDIV = TB_DIV1;                   // TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm4Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;                // TBCLK = EPWMCLK / 1*1
    EPwm4Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events

    /* Configure Counter-Compare(CC) Submodule */
    EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
    EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm4Regs.CMPA.bit.CMPA = 0;
    EPwm4Regs.CMPB.bit.CMPB = 0;

    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm4Regs.AQCTLA.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
    EPwm4Regs.AQCTLA.bit.CAU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPA
    EPwm4Regs.AQCTLB.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
    EPwm4Regs.AQCTLB.bit.CBU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPB
    EPwm4Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately

    /* Configure Dead-Band(DB) Submodule */
    EPwm4Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;

    /* Configure Trip-Zone(TZ) Submodule */

    /* Configure Digital-Compare(DC) Submodule */

    /* Configure Event-Trigger(ET) Submodule */

}

/**
 *  @brief  Interrupt for EPWM7 TZ
 *  @retval None
 */ 
__interrupt void PeriEPwm_EPWM7_TZ_Handler(void)
{
    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER2.all;   // Store IER
    IER |= M_INT2;
    IER &= MINT2;                                           // Set "global" priority
    PieCtrlRegs.PIEIER2.all &= MG2_7;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");

    EINT;

    /* User code Start */
    if (EPwm7Regs.TZFLG.bit.CBC == 1)
    {
    	SET_PFC_A_CBC;
    }

    /* User code End */
    
    DINT;
    PieCtrlRegs.PIEIER2.all = TempPIEIER;                   // Restore IER
    /* Branch mechanism code End */
}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM7
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM7_IO_Multiplexer(void)
{
    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO12 = 1;     // Disable pull-up on GPIO12 (EPWM7A)
    GpioCtrlRegs.GPAPUD.bit.GPIO13 = 1;     // Disable pull-up on GPIO13 (EPWM7B)
    
    /* Configure EPWM7 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM7 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO12 = 0;	// Configure Peripheral Group section 0
    GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 1;    // Configure GPIO12 as EPWM7A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO13 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1;    // Configure GPIO13 as EPWM7B
}

/**
 *  @brief  Initial and configure EPWM7 for Interleaved totem pole PFC phase A
 *  @retval None
 *  @Note	ePWM7A is phase A High side
 *  @Note	ePWM7B is phase A Low side
 */ 
static inline void PeriEPwm_Init_EPWM7(void)
{
    EALLOW;
    
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM7_IO_Multiplexer();
    
    /* Configure Time-Base(TB) Submodule */
    EPwm7Regs.TBPRD = EPWM7_PERIOD;
    EPwm7Regs.TBPHS.bit.TBPHS = 0;
    EPwm7Regs.TBCTR = 0x0000;                               // Clear TB counter
    EPwm7Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;          // Up-Down count mode
    EPwm7Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm7Regs.TBCTL.bit.CLKDIV = TB_DIV1;					// TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm7Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;				// TBCLK = EPWMCLK / 1*1
    EPwm7Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    
    /* Configure Counter-Compare(CC) Submodule */
    EPwm7Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;			// Load on CTR = ZERO
    EPwm7Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;			// Load on CTR = ZERO
    EPwm7Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm7Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm7Regs.CMPA.bit.CMPA = 0;
	EPwm7Regs.CMPB.bit.CMPB = 0;
	   
    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm7Regs.AQCTLA.bit.CAU = AQ_CLEAR;					// EPWMxA output low when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLA.bit.CAD = AQ_CLEAR;					// EPWMxA output high when TBCTR = CMPA on Down Count
	EPwm7Regs.AQCTLB.bit.CAU = AQ_CLEAR;					// EPWMxB output low when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLB.bit.CAD = AQ_CLEAR;					// EPWMxB output high when TBCTR = CMPA on Down Count
    EPwm7Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately
    
	/* Configure Dead-Band(DB) Submodule - Active High Complementary */
	EPwm7Regs.DBCTL2.bit.SHDWDBCTLMODE = 1;					// DBCTL Load is Shadow mode
	EPwm7Regs.DBCTL2.bit.LOADDBCTLMODE = 0;					// Active DBCTL Load from Shadow Select Mode when Counter = 0
	EPwm7Regs.DBCTL.bit.IN_MODE = DBA_ALL;					// EPWMxA is the source for both OutA and OutB
	EPwm7Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;				// EPWMxB is inverted.
	EPwm7Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;			// DBM is fully enabled
	EPwm7Regs.DBRED.bit.DBRED = PWM_DeadBand_300; 				// 300ns = 30*0.01us, RED = DBRED*TBCLK
	EPwm7Regs.DBFED.bit.DBFED = PWM_DeadBand_300;				// 300ns = 30*0.01us, FED = DBFED*TBCLK

    /* Configure Trip-Zone(TZ) Submodule
     * CBC events of EPwm7 comes from IPFC_A:
     * CMPSS2_CTRIPH or CMPSS2_CTRIPL -> EPwmXBar_TRIP7 -> DCAH/DCBH -> DCAEVT2/DCBEVT2 -> TZ  (49 p.1839)
     * Enable:CBC per one cycle , Disable:CBC per level trigger
     */
	EPwm7Regs.TZSEL.bit.DCAEVT2 = TZ_ENABLE;             	// Enable DCAEVT2 as a CBC trip source for this ePWM module
	EPwm7Regs.TZSEL.bit.DCBEVT2 = TZ_ENABLE;             	// Enable DCBEVT2 as a CBC trip source for this ePWM module	
	EPwm7Regs.TZDCSEL.bit.DCAEVT2 = TZ_DCAH_HI;             // DCAEVT2 is trigger when DCAH set to high, DCAL is don't care
	EPwm7Regs.TZDCSEL.bit.DCBEVT2 = TZ_DCBH_HI;             // DCBEVT2 is trigger when DCBH set to high, DCBL is don't care	

	// level trigger
	//EPwm7Regs.TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;              // EPWMxA action on DCAEVT2, Force EPWMxA to a low state.
    //EPwm7Regs.TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;              // EPWMxB action on DCBEVT2, Force EPWMxB to a low state.

	// CBC
	EPwm7Regs.TZCTL.bit.TZA = TZ_FORCE_LO;              	// TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxA, Force EPWMxA to a low state.
    EPwm7Regs.TZCTL.bit.TZB = TZ_FORCE_LO;              	// TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxB, Force EPWMxB to a low state.

	EPwm7Regs.TZCTL2.bit.ETZE = 0;              			// Use trip action from TZCTL (legacy EPWM compatibility)
	EPwm7Regs.TZFRC.bit.OST = 1;							// Force Trip Zones One Shot Event (Disable PWM)

    /* Configure Digital-Compare(DC) Submodule */
	EPwm7Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_TRIPIN7;		// Digital Compare A High COMP Input Select is TRIPIN7
	EPwm7Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_TRIPIN7;		// Digital Compare B High COMP Input Select is TRIPIN7
    EPwm7Regs.DCACTL.bit.EVT2SRCSEL = DC_EVT2;              // DCAEVT2 is source by DCAEVT2 signal, not filtered
    EPwm7Regs.DCACTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;     // DCAEVT2 is passed through asynchronously
	EPwm7Regs.DCBCTL.bit.EVT2SRCSEL = DC_EVT2;              // DCBEVT2 is source by DCBEVT2 signal, not filtered
	EPwm7Regs.DCBCTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;     // DCBEVT2 is passed through asynchronously

    /* Configure Event-Trigger(ET) Submodule */
    EPwm7Regs.ETSEL.bit.SOCAEN = 0;                         // Disable SOC on A group
    EPwm7Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;              // Select SOC from Enable event time-base counter equal to zero for phase A average current control
    EPwm7Regs.ETPS.bit.SOCAPRD = ET_1ST;		            // Generate pulse on 1st event

	/* Re-mapped interrupt */
    PieVectTable.EPWM7_TZ_INT = &PeriEPwm_EPWM7_TZ_Handler;

#ifdef EnableCBCISR

	EPwm7Regs.TZEINT.bit.CBC = 1;							// Trip-zone Cycle-by-Cycle Interrupt Enable

	/* Enable CPU INT2 which is connected to EPWM7 TZ INT */
	IER |= M_INT2;

	/* Enable ePWM7 INTn in the PIE */
	PieCtrlRegs.PIEIER2.bit.INTx7 = 1;						// Enable EWM7 TZ INT
	
#else

	EPwm7Regs.TZEINT.bit.CBC = 0;							// Trip-zone Cycle-by-Cycle Interrupt Disable
	PieCtrlRegs.PIEIER2.bit.INTx7 = 0;						// Disable EWM7 TZ INT
	
#endif

    EDIS;
}

/**
 *  @brief  Interrupt for EPWM8 TZ
 *  @retval None
 */ 
__interrupt void PeriEPwm_EPWM8_TZ_Handler(void)
{
    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER2.all;   // Store IER
    IER |= M_INT2;
    IER &= MINT2;                                           // Set "global" priority
    PieCtrlRegs.PIEIER2.all &= MG2_8;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");

    EINT;

    /* User code Start */
    if (EPwm8Regs.TZFLG.bit.CBC == 1)
    {
    	SET_PFC_B_CBC;
    }

    /* User code End */
    
    DINT;
    PieCtrlRegs.PIEIER2.all = TempPIEIER;                   // Restore IER
    /* Branch mechanism code End */
}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM8
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM8_IO_Multiplexer(void)
{
    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO14 = 1;     // Disable pull-up on GPIO14 (EPWM8A)
    GpioCtrlRegs.GPAPUD.bit.GPIO15 = 1;     // Disable pull-up on GPIO15 (EPWM8B)
    
    /* Configure EPWM8 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM8 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO14 = 0;	// Configure Peripheral Group section 0
    GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 1;    // Configure GPIO14 as EPWM8A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO15 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 1;    // Configure GPIO15 as EPWM8B
}

/**
 *  @brief  Initial and configure EPWM8 for Interleaved totem pole PFC phase B
 *  @retval None
 */ 
static inline void PeriEPwm_Init_EPWM8(void)
{
    EALLOW;
    
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM8_IO_Multiplexer();
    
    /* Configure Time-Base(TB) Submodule */
    EPwm8Regs.TBPRD = EPWM8_PERIOD;
    EPwm8Regs.TBPHS.bit.TBPHS = 0;
    EPwm8Regs.TBCTR = 0x0000;                               // Clear TB counter
    EPwm8Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;          // Up-Down count mode
    EPwm8Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm8Regs.TBCTL.bit.CLKDIV = TB_DIV1;					// TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm8Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;				// TBCLK = EPWMCLK / 1*1
    EPwm8Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    
    /* Configure Counter-Compare(CC) Submodule */
    EPwm8Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;			// Load on CTR = ZERO
    EPwm8Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;			// Load on CTR = ZERO
    EPwm8Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm8Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm8Regs.CMPA.bit.CMPA = 0;
	EPwm8Regs.CMPB.bit.CMPB = 0;
	   
    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm8Regs.AQCTLA.bit.CAU = AQ_CLEAR;					// EPWMxA output high when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLA.bit.CAD = AQ_CLEAR;					// EPWMxA output low when TBCTR = CMPA on Down Count
	EPwm8Regs.AQCTLB.bit.CAU = AQ_CLEAR;					// EPWMxB output high when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLB.bit.CAD = AQ_CLEAR;					// EPWMxB output low when TBCTR = CMPA on Down Count
	EPwm8Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately

	/* Configure Dead-Band(DB) Submodule - Active High Complementary */
	EPwm8Regs.DBCTL2.bit.SHDWDBCTLMODE = 1;					// DBCTL Load is Shadow mode
	EPwm8Regs.DBCTL2.bit.LOADDBCTLMODE = 1;					// Active DBCTL Load from Shadow Select Mode when Counter = Period
	EPwm8Regs.DBCTL.bit.IN_MODE = DBA_ALL;					// EPWMxA is the source for both OutA and OutB
	EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;				// EPWMxB is inverted.
	EPwm8Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;			// DBM is fully enabled
	EPwm8Regs.DBRED.bit.DBRED = PWM_DeadBand_300; 				// 300ns = 30*0.01us, RED = DBRED*TBCLK
	EPwm8Regs.DBFED.bit.DBFED = PWM_DeadBand_300;				// 300ns = 30*0.01us, FED = DBFED*TBCLK

    /* Configure Trip-Zone(TZ) Submodule
     * CBC events of EPwm8 comes from IPFC_B:
     * CMPSS6_CTRIPH or CMPSS6_CTRIPL -> EPwmXBar_TRIP8 -> DCAH/DCBH -> DCAEVT2/DCBEVT2 -> TZ   (49 p.1839)
     * Enable:CBC per one cycle , Disable:CBC per level trigger
     */

	EPwm8Regs.TZSEL.bit.DCAEVT2 = TZ_ENABLE;             	// Enable DCAEVT2 as a CBC trip source for this ePWM module
	EPwm8Regs.TZSEL.bit.DCBEVT2 = TZ_ENABLE;             	// Enable DCBEVT2 as a CBC trip source for this ePWM module	
	EPwm8Regs.TZDCSEL.bit.DCAEVT2 = TZ_DCAH_HI;             // DCAEVT2 is trigger when DCAH set to high, DCAL is don't care
	EPwm8Regs.TZDCSEL.bit.DCBEVT2 = TZ_DCBH_HI;             // DCBEVT2 is trigger when DCBH set to high, DCBL is don't care	

	// level trigger
	//EPwm8Regs.TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;              // EPWMxA action on DCAEVT2, Force EPWMxA to a low state.
    //EPwm8Regs.TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;              // EPWMxB action on DCBEVT2, Force EPWMxB to a low state.

	// CBC
	EPwm8Regs.TZCTL.bit.TZA = TZ_FORCE_LO;              	// TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxA, Force EPWMxA to a low state.
    EPwm8Regs.TZCTL.bit.TZB = TZ_FORCE_LO;              	// TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxB, Force EPWMxB to a low state.
	EPwm8Regs.TZCTL2.bit.ETZE = 0;              			// Use trip action from TZCTL (legacy EPWM compatibility)
	EPwm8Regs.TZFRC.bit.OST = 1;							// Force Trip Zones One Shot Event (Disable PWM)

    /* Configure Digital-Compare(DC) Submodule */
	EPwm8Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_TRIPIN8;		// Digital Compare A High COMP Input Select is TRIPIN8
	EPwm8Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_TRIPIN8;		// Digital Compare B High COMP Input Select is TRIPIN8
    EPwm8Regs.DCACTL.bit.EVT2SRCSEL = DC_EVT2;              // DCAEVT2 is source by DCAEVT2 signal, not filtered
	EPwm8Regs.DCACTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;     // DCAEVT2 is passed through asynchronously
	EPwm8Regs.DCBCTL.bit.EVT2SRCSEL = DC_EVT2;              // DCBEVT2 is source by DCBEVT2 signal, not filtered
	EPwm8Regs.DCBCTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;     // DCBEVT2 is passed through asynchronously
    
    /* Configure Event-Trigger(ET) Submodule */
    EPwm8Regs.ETSEL.bit.SOCAEN = 0;                         // Disable SOC on A group
    EPwm8Regs.ETSEL.bit.SOCASEL = ET_CTR_PRD;              	// Select SOC from Enable event time-base counter equal to period for phase B average current control
    EPwm8Regs.ETPS.bit.SOCAPRD = ET_1ST;		            // Generate pulse on 1st event

	/* Re-mapped interrupt */
    PieVectTable.EPWM8_TZ_INT = &PeriEPwm_EPWM8_TZ_Handler;

#ifdef EnableCBCISR

	EPwm8Regs.TZEINT.bit.CBC = 1;							// Trip-zone Cycle-by-Cycle Interrupt Enable

	/* Enable CPU INT2 which is connected to EPWM8 TZ INT */
    IER |= M_INT2;
    
    /* Enable ePWM8 INTn in the PIE */
    PieCtrlRegs.PIEIER2.bit.INTx8 = 1;                      // Enable EWM8 TZ INT
    
#else

	EPwm8Regs.TZEINT.bit.CBC = 0;							// Trip-zone Cycle-by-Cycle Interrupt Disable
	PieCtrlRegs.PIEIER2.bit.INTx8 = 0;                      // Disable EWM8 TZ INT
	
#endif

    EDIS;
}

/**
 *  @brief  Initial and configure used EPwm module
 *  @retval None
 */ 
void PeriEPwm_Initialize(void)
{
	// initial PWM period
	PWM_Period[ePeriEPwm_Tag_PFCRELAY] = EPWM3_PERIOD;
	PWM_Period[ePeriEPwm_Tag_PFCIGBT] = EPWM3_PERIOD;
	PWM_Period[ePeriEPwm_Tag_PFC_A] = EPWM7_PERIOD;
	PWM_Period[ePeriEPwm_Tag_PFC_B] = EPWM8_PERIOD;
    PWM_Period[ePeriEPwm_Tag_VBulkToD2D] = EPWM4_VbulkToD2D_PERIOD;
	
    STOP_ALL_PWM_CLOCK();

    PeriEPwm_Init_EPwmXBar();
	PeriEPwm_Init_EPWM1();
	PeriEPwm_Init_EPWM3();
    PeriEPwm_Init_EPWM4();
	PeriEPwm_Init_EPWM7();
	PeriEPwm_Init_EPWM8();

    START_ALL_PWM_CLOCK();
}

/**
 *  @brief  Setting PWM for PFC postive polarity
 *  @retval None
 */
void PeriPWM_PFC_Pos_Polarity(void)
{
	/* Configure Action-Qualifier(AQ) Submodule */
	EPwm7Regs.AQCTLA.bit.CAU = AQ_SET;		// EPWMxA output high when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLA.bit.CAD = AQ_CLEAR;	// EPWMxA output low when TBCTR = CMPA on Down Count
	EPwm7Regs.AQCTLB.bit.CAU = AQ_SET;		// EPWMxB output high when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLB.bit.CAD = AQ_CLEAR;	// EPWMxB output low when TBCTR = CMPA on Down Count

	EPwm8Regs.AQCTLA.bit.CAU = AQ_CLEAR;	// EPWMxA output low when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLA.bit.CAD = AQ_SET;		// EPWMxA output high when TBCTR = CMPA on Down Count
	EPwm8Regs.AQCTLB.bit.CAU = AQ_CLEAR;	// EPWMxB output low when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLB.bit.CAD = AQ_SET;		// EPWMxB output high when TBCTR = CMPA on Down Count

	EPwm7Regs.AQCSFRC.bit.CSFA = 1;			// Forces a continuous low on output A
	EPwm7Regs.AQCSFRC.bit.CSFB = 0;			// Software forcing is disabled and has no effect
	EPwm7Regs.DBCTL.bit.IN_MODE = DBB_ALL;			// EPWMxB is the source for both OutA and OutB
	EPwm7Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled

	EPwm8Regs.AQCSFRC.bit.CSFA = 1;			// Forces a continuous low on output A
	EPwm8Regs.AQCSFRC.bit.CSFB = 0;			// Software forcing is disabled and has no effect
	EPwm8Regs.DBCTL.bit.IN_MODE = DBB_ALL;			// EPWMxB is the source for both OutA and OutB
	EPwm8Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled
}

/**
 *  @brief  Setting PWM for PFC negative polarity
 *  @retval None
 */
void PeriPWM_PFC_Neg_Polarity(void)
{
	/* Configure Action-Qualifier(AQ) Submodule */
	EPwm7Regs.AQCTLA.bit.CAU = AQ_CLEAR;	// EPWMxA output low when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLA.bit.CAD = AQ_SET;		// EPWMxA output high when TBCTR = CMPA on Down Count
	EPwm7Regs.AQCTLB.bit.CAU = AQ_CLEAR;	// EPWMxB output low when TBCTR = CMPB on Up Count
	EPwm7Regs.AQCTLB.bit.CAD = AQ_SET;		// EPWMxB output high when TBCTR = CMPB on Down Count

	EPwm8Regs.AQCTLA.bit.CAU = AQ_SET;		// EPWMxA output high when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLA.bit.CAD = AQ_CLEAR;	// EPWMxA output low when TBCTR = CMPA on Down Count
	EPwm8Regs.AQCTLB.bit.CAU = AQ_SET;		// EPWMxB output high when TBCTR = CMPB on Up Count
	EPwm8Regs.AQCTLB.bit.CAD = AQ_CLEAR;	// EPWMxB output low when TBCTR = CMPB on Down Count

	EPwm7Regs.AQCSFRC.bit.CSFB = 1;			// Forces a continuous low on output B
	EPwm7Regs.AQCSFRC.bit.CSFA = 0;			// Software forcing is disabled and has no effect
	EPwm7Regs.DBCTL.bit.IN_MODE = DBA_ALL;			// EPWMxA is the source for both OutA and OutB
	EPwm7Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled

	EPwm8Regs.AQCSFRC.bit.CSFB = 1;			// Forces a continuous low on output B
	EPwm8Regs.AQCSFRC.bit.CSFA = 0;			// Software forcing is disabled and has no effect
	EPwm8Regs.DBCTL.bit.IN_MODE = DBA_ALL;			// EPWMxA is the source for both OutA and OutB
	EPwm8Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled
}

/**
 *  @brief  Setting PWM for PFC postive polarity normal work
 *  @retval None
 */
void PeriPWM_PFC_DB_Enable(void)
{
	EPwm7Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;		// DBM is Full Enabled
	EPwm8Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;		// DBM is Full Enabled
}

/**
 *  @brief  Enable target ePWM
 *  @note   User "MUST" set duty before enable ePWM
 *  @param  eTag: Which ePWM is attempted to enable
 *  @retval None
 */
void PeriEPwm_PFC_Enable(void)
{
	EALLOW;
    EPwm7Regs.TZCLR.bit.OST = 1;
	EPwm8Regs.TZCLR.bit.OST = 1;
    EDIS;
}

/**
 *  @brief  Enable target ePWM
 *  @note   User "MUST" set duty before enable ePWM
 *  @param  eTag: Which ePWM is attempted to enable
 *  @retval None
 */
void PeriEPwm_PFC_PhaseA_Enable(void)
{
	EALLOW;
    EPwm7Regs.TZCLR.bit.OST = 1;
    EDIS;
}

/* Enable target PWM8 */
void PeriEPwm_PFC_PhaseB_Enable(void)
{
    EALLOW;
    EPwm8Regs.TZCLR.bit.OST = 1;
    EDIS;
}

/**
 *  @brief  Disable target ePWM
 *  @param  eTag: Which ePWM is attempted to disable
 *  @retval None
 */
void PeriEPwm_PFC_Disable(void)
{
	EALLOW;
	EPwm7Regs.TZFRC.bit.OST = 1;
	EPwm8Regs.TZFRC.bit.OST = 1;
	EDIS;
}

/**
 *  @brief  Clear PFC phase A CBC ISR flag
 *  @retval None
 */
void PeriPWM_PFC_A_CBC_Clear(void)
{
	EALLOW;
	EPwm7Regs.TZCLR.bit.CBC = 1;
	EPwm7Regs.TZCLR.bit.INT = 1;
	EDIS;
}

/**
 *  @brief  Clear PFC phase B CBC ISR flag
 *  @retval None
 */
void PeriPWM_PFC_B_CBC_Clear(void)
{
	EALLOW;
	EPwm8Regs.TZCLR.bit.CBC = 1;
	EPwm8Regs.TZCLR.bit.INT = 1;
	EDIS;
}

/**
 *  @brief  Set target ePWM Duty
 *  @param  eTag: Which ePWM is attempted to set its duty
 *  @param  u32Duty_Q16: duty in Q16 format
 *  @retval None
 */
void PeriEPwm_SetDuty(ePeriEPwmTag_t eTag, u32_t u32Duty_Q16)
{
    switch (eTag)
    {
        case ePeriEPwm_Tag_PFCRELAY:
         	EPwm3Regs.CMPA.bit.CMPA = (u32Duty_Q16 * PWM_Period[eTag] + 1) >> 16;
            break;
		
		case ePeriEPwm_Tag_PFCIGBT:
         	EPwm3Regs.CMPB.bit.CMPB = (u32Duty_Q16 * PWM_Period[eTag] + 1) >> 16;
            break;

        case ePeriEPwm_Tag_VBulkToD2D:
            EPwm4Regs.CMPB.bit.CMPB = (u32Duty_Q16 * PWM_Period[eTag] + 1) >> 16;
            break;

		case ePeriEPwm_Tag_PFC_A:
            EPwm7Regs.CMPA.bit.CMPA = (u32Duty_Q16 * PWM_Period[eTag]) >> 16;
            break;

		case ePeriEPwm_Tag_PFC_B:
            EPwm8Regs.CMPA.bit.CMPA = PWM_Period[eTag] - ((u32Duty_Q16 * PWM_Period[eTag]) >> 16);
            break;

        default:
            break;
    }
}


/**
 *  @brief  Start peripheral - Enable trigger ADC interrupt
 *  @retval None
 */
void PeriPWM_Start(void)
{
	/* Configure Event-Trigger(ET) Submodule */
    EPwm7Regs.ETSEL.bit.SOCAEN = 1;            // Enable SOC on A group
    EPwm8Regs.ETSEL.bit.SOCAEN = 1;            // Enable SOC on A group
}

/**
 *  @brief  Start peripheral - Disable trigger ADC interrupt
 *  @retval None
 */
void PeriPWM_Stop(void)
{
	/* Configure Event-Trigger(ET) Submodule */
    EPwm7Regs.ETSEL.bit.SOCAEN = 0;            // Disable SOC on A group
    EPwm8Regs.ETSEL.bit.SOCAEN = 0;            // Disable SOC on A group
}



