/** @file       Peripheral_Flash.h
 *  @brief      Header file for Peripheral Flash module
 *  @author     Adonis Wang
 *  @version    1.0
 *  @date       
 */
 
#ifndef _PERIPHERAL_FLASH_H_
#define _PERIPHERAL_FLASH_H_

#include "CONFIG_Define.h"

/****************************************************************************
    Public parameter definition
****************************************************************************/


// Boot, 16KWx16
#define FlashAddr_B0_S0_start	        0x80000
#define FlashAddr_B0_S0_End           	0x80FFF
#define FlashAddr_B0_S1_start	        0x81000
#define FlashAddr_B0_S1_End           	0x81FFF
#define FlashAddr_B0_S2_start	        0x82000
#define FlashAddr_B0_S2_End           	0x82FFF
#define FlashAddr_B0_S3_start	        0x83000
#define FlashAddr_B0_S3_End           	0x83FFF

// APP1, 48KWx16
#define FlashAddr_B0_S4_start	        0x84000
#define FlashAddr_B0_S4_End           	0x84FFF
#define FlashAddr_B0_S5_start	        0x85000
#define FlashAddr_B0_S5_End           	0x85FFF
#define FlashAddr_B0_S6_start	        0x86000
#define FlashAddr_B0_S6_End           	0x86FFF
#define FlashAddr_B0_S7_start	        0x87000
#define FlashAddr_B0_S7_End           	0x87FFF
#define FlashAddr_B0_S8_start	        0x88000
#define FlashAddr_B0_S8_End           	0x88FFF
#define FlashAddr_B0_S9_start	        0x89000
#define FlashAddr_B0_S9_End           	0x89FFF
#define FlashAddr_B0_S10_start	        0x8A000
#define FlashAddr_B0_S10_End           	0x8AFFF
#define FlashAddr_B0_S11_start	        0x8B000
#define FlashAddr_B0_S11_End           	0x8BFFF
#define FlashAddr_B0_S12_start	        0x8C000
#define FlashAddr_B0_S12_End           	0x8CFFF
#define FlashAddr_B0_S13_start	        0x8D000
#define FlashAddr_B0_S13_End           	0x8DFFF
#define FlashAddr_B0_S14_start	        0x8E000
#define FlashAddr_B0_S14_End           	0x8EFFF
#define FlashAddr_B0_S15_start	        0x8F000
#define FlashAddr_B0_S15_End           	0x8FFFF

// Reserve, 16KWx16
#define FlashAddr_B1_S0_start	        0x90000
#define FlashAddr_B1_S0_End           	0x90FFF
#define FlashAddr_B1_S1_start	        0x91000
#define FlashAddr_B1_S1_End           	0x91FFF
#define FlashAddr_B1_S2_start	        0x92000
#define FlashAddr_B1_S2_End           	0x92FFF
#define FlashAddr_B1_S3_start	        0x93000
#define FlashAddr_B1_S3_End           	0x93FFF

// APP2, 48KWx16
#define FlashAddr_B1_S4_start	        0x94000
#define FlashAddr_B1_S4_End           	0x94FFF
#define FlashAddr_B1_S5_start	        0x95000
#define FlashAddr_B1_S5_End           	0x95FFF
#define FlashAddr_B1_S6_start	        0x96000
#define FlashAddr_B1_S6_End           	0x96FFF
#define FlashAddr_B1_S7_start	        0x97000
#define FlashAddr_B1_S7_End           	0x97FFF
#define FlashAddr_B1_S8_start	        0x98000
#define FlashAddr_B1_S8_End           	0x98FFF
#define FlashAddr_B1_S9_start	        0x99000
#define FlashAddr_B1_S9_End           	0x99FFF
#define FlashAddr_B1_S10_start	        0x9A000
#define FlashAddr_B1_S10_End           	0x9AFFF
#define FlashAddr_B1_S11_start	        0x9B000
#define FlashAddr_B1_S11_End           	0x9BFFF
#define FlashAddr_B1_S12_start	        0x9C000
#define FlashAddr_B1_S12_End           	0x9CFFF
#define FlashAddr_B1_S13_start	        0x9D000
#define FlashAddr_B1_S13_End           	0x9DFFF
#define FlashAddr_B1_S14_start	        0x9E000
#define FlashAddr_B1_S14_End           	0x9EFFF
#define FlashAddr_B1_S15_start	        0x9F000
#define FlashAddr_B1_S15_End           	0x9FFFF


#define FLASH_B0_S0          			((u32_t)0x00000001)
#define FLASH_B0_S1          			((u32_t)0x00000002)
#define FLASH_B0_S2          			((u32_t)0x00000004)
#define FLASH_B0_S3          			((u32_t)0x00000008)
#define FLASH_B0_S4          			((u32_t)0x00000010)
#define FLASH_B0_S5          			((u32_t)0x00000020)
#define FLASH_B0_S6          			((u32_t)0x00000040)
#define FLASH_B0_S7          			((u32_t)0x00000080)
#define FLASH_B0_S8          			((u32_t)0x00000100)
#define FLASH_B0_S9          			((u32_t)0x00000200)
#define FLASH_B0_S10          			((u32_t)0x00000400)
#define FLASH_B0_S11          			((u32_t)0x00000800)
#define FLASH_B0_S12          			((u32_t)0x00001000)
#define FLASH_B0_S13          			((u32_t)0x00002000)
#define FLASH_B0_S14          			((u32_t)0x00004000)
#define FLASH_B0_S15          			((u32_t)0x00008000)

#define FLASH_B1_S0          			((u32_t)0x00010000)
#define FLASH_B1_S1          			((u32_t)0x00020000)
#define FLASH_B1_S2          			((u32_t)0x00040000)
#define FLASH_B1_S3          			((u32_t)0x00080000)
#define FLASH_B1_S4          			((u32_t)0x00100000)
#define FLASH_B1_S5          			((u32_t)0x00200000)
#define FLASH_B1_S6          			((u32_t)0x00400000)
#define FLASH_B1_S7          			((u32_t)0x00800000)
#define FLASH_B1_S8          			((u32_t)0x01000000)
#define FLASH_B1_S9          			((u32_t)0x02000000)
#define FLASH_B1_S10          			((u32_t)0x04000000)
#define FLASH_B1_S11          			((u32_t)0x08000000)
#define FLASH_B1_S12          			((u32_t)0x10000000)
#define FLASH_B1_S13          			((u32_t)0x20000000)
#define FLASH_B1_S14          			((u32_t)0x40000000)
#define FLASH_B1_S15          			((u32_t)0x80000000)


#define STAMP_LENGTH					((u32_t)0x10)
#define PIB_LENGTH						((u32_t)0x40)
#define RCB_LENGTH						((u32_t)0x60)

/* Bootloader Location */
#define BOOT_ENTRY_ADDRESS              (FlashAddr_B0_S0_start)

/* Active Image Location */
#define ACTIVE_IMAGE_START_ADDRESS      (FlashAddr_B0_S4_start)
#define ACTIVE_IMAGE_END_ADDRESS        (FlashAddr_B0_S15_End)
#define ACTIVE_IMAGE_SIZE               (ACTIVE_IMAGE_END_ADDRESS - ACTIVE_IMAGE_START_ADDRESS + 1)

#define ACTIVE_IMAGE_STAMP_ADDRESS      (ACTIVE_IMAGE_START_ADDRESS)
#define ACTIVE_IMAGE_PIB_ADDRESS        (ACTIVE_IMAGE_STAMP_ADDRESS + STAMP_LENGTH)
#define ACTIVE_IMAGE_RCB_ADDRESS        (ACTIVE_IMAGE_PIB_ADDRESS + PIB_LENGTH)
#define ACTIVE_IMAGE_UAP_ADDRESS        (ACTIVE_IMAGE_RCB_ADDRESS + RCB_LENGTH)

/* Backup Image Location */
#define BACKUP_IMAGE_START_ADDRESS      (FlashAddr_B1_S4_start)
#define BACKUP_IMAGE_END_ADDRESS        (FlashAddr_B1_S15_End)
#define BACKUP_IMAGE_SIZE               (BACKUP_IMAGE_END_ADDRESS - BACKUP_IMAGE_START_ADDRESS + 1)

#define BACKUP_IMAGE_STAMP_ADDRESS      (BACKUP_IMAGE_START_ADDRESS)
#define BACKUP_IMAGE_PIB_ADDRESS        (BACKUP_IMAGE_STAMP_ADDRESS + STAMP_LENGTH)
#define BACKUP_IMAGE_RCB_ADDRESS        (BACKUP_IMAGE_PIB_ADDRESS + PIB_LENGTH)
#define BACKUP_IMAGE_UAP_ADDRESS        (BACKUP_IMAGE_RCB_ADDRESS + RCB_LENGTH)




/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/

extern u16_t PeriFlash_Initialize(void);
extern u16_t PeriFlash_Erase(u32_t u32SectorMask);
extern u16_t PeriFlash_Program(u32_t u32FlashAddress, u16_t* pu16ProgramData, u32_t u32ProgramLength);
extern u16_t PeriFlash_Read(u32_t u32FlashAddress, u16_t* pu16ReadBuffer, u32_t u32ReadLength);
extern u16_t PeriFlash_Verify(u32_t u32FlashAddress, u16_t* pu16VerifyData, u32_t u32VerifyLength);
extern u16_t PeriFlash_Copy(u32_t u32DestinationAddress, u32_t u32SourceAddress, u32_t u32CopyLength);
#endif

