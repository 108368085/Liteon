/****************************************************************************
 *	File	CONFIG_RisingPower.h
 * 	Brief	Rising Power Configuration
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/29 - 1st release
 ****************************************************************************/

 
#ifndef _CONFIG_RISINGPOWER_H_
#define _CONFIG_RISINGPOWER_H_

#include "CONFIG_Define.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/


//
// Program Configuration
//
#define PFC_Frequency_Conversion    // if define = Enable PFC Frequency Conversion , For 277Vac at 10%load iTHD
#define WithD2D                     // if define = With D2D

//#define EnableXcapCompensate		// if define = Enable Xcap compensate function
//#define EnableDynamicVbulk		// if define = Enable dynamic Vbulk by Vin and Iin
#define EnableWatchDog				// if define = Enable watch dog
#define EnableDCInput				// if define = Support DC input
#define EnablePSKILL				// if define = Enable PSKill
#define EnableATSFunction			// if define = Enable ATS function
#define PFCEnable 			TRUE	// 0:PFC Disable, 1:PFC Enable
//#define EnableSinglePFC			// if define = Enable Single PFC when light load condition, unfinish
//#define EnableCBCISR				// if define = Enable CBC Interrupt for clear PI value
//#define Enable20AHallSensor		// if define = Enable 20A hall sensor, otherwise enable 40A
//#define DEMO_BOARD				// if define = HW using demo Board
//#define PPTSample					// if define = PPT sample, PFC Temp is 822148 and need to special calibration
//#define EnableTempFIJ				// if define = Enable Temp fault injection 0x41 command


//
// FW Configuration
// FW bootloader stress test version using minor 0xFX (X is current version)
//

/**
 *  @brief  MCU ID is used to identify location of MCU
 *          It could be one of following values:
 *          - @arg B: BMS
 *          - @arg C: DC/DC
 *          - @arg D: Display
 *          - @arg I: Inverter
 *          - @arg P: PFC
 *          - @arg O: Other
 *          - @arg S: System
 */
#define FIRMWARE_MCU_ID                 'P'

/**
 *  @brief  State is used to identify this image release at which stage
 *          It could be one of following values:
 *          - @arg R: official Release after mass production
 *          - @arg S: Sample to customer
 *          - @arg T: Testing
 *          - @arg D: Debug version for Verification Unit
 */
#define FIRMWARE_RELEASE_STAGE          'R'

/**
 *  @brief  Firmware Major Revision
 *  @note   This number should be accumulate after official release.
 *          This number is start from "00"
 */
#define FIRMWARE_MAJOR_REVISION         0

/**
 *  @brief  Firmware Minor Revision
 *  @note   This number should be clear to "00" when major revision accumulated <TBD>
 *          This number is start from "00"
 *			Any test or debug code for client verify, please | 0x80
 */
#define FIRMWARE_MINOR_REVISION         07

/**
 *  @brief  Firmware Compatible Revision -> Same as FIRMWARE_MAJOR_REVISION
 *  @note   This number is used identify firmware image is compatible with re-programming image through boot-loader
 *          Once if firmware compatible code is incompatible,
 *          boot-loader should override(cancel) startup type to make application restart with cold type
 */
#define FIRMWARE_COMPATIBLE_REVISION 	FIRMWARE_MAJOR_REVISION

/**
 *  @brief  Hardware Compatible Revision
 *  @note   This number is used identify hardware change is compatible with re-programming hardware version through boot-loader
 *          Once if hardware compatible code is incompatible,
 *          boot-loader should override(cancel) startup type to make application restart with cold type
 */
#define HARDWARE_COMPATIBLE_REVISION 	"00"
#define HARDWARE_COMPATIBLE_REVISION_ 	0

/**
 *  @brief  Firmware internal Revision
 *  @note   This number is used identify internal FW change
 *          This number should be clear to "00" when minor revision accumulated
 *          
 */
#define FW_INTERNAL_REVISION          	02


/* FIRMWARE_RELEASE_DATE */
#define FIRMWARE_RELEASE_DATE        	20250213UL


#define DEVICE_FWCR_LEN           		2               // Byte length of Device FirmWare Compatible Revision
#define DEVICE_ID              			"PS-2442-1ADU"
#define DEVICE_ID_LEN       			10				//"PS-2442-1AXX"
#define MCU_TYPE                   		(0x03)



//
// HW Configuration
//

/* Full scale of PFC Bus voltage, unit is 1mV */
#define V_BUS_FS                 		507570UL

/* Full scale of ATS AC voltage, unit is 1mV */
/* For implement 2nd ISO meter IC and change 1.05k to 825ohm, the HW gain already different
 * Therefore, for compatible previous version, we keep the HW gain.
 */
#define V_ACATS_FS               		1070159UL

/* Full scale of PFC AC voltage, unit is 1mV */
#define V_ACPFC_FS                 		521770UL

/* Full scale of Auxiliary Power voltage, unit is 1mV */
#define V_AUX_FS                    	14320

/* Full scale of PFC input current, unit is 1mA */

#ifdef Enable20AHallSensor
#define I_AC_FS                      	25000			//20A:25000
#else 
#define I_AC_FS                      	50000			//40A:50000 1.65/0.033=50A , For 7KW:1.65/0.02=82.5A
#endif

/* Full scale of Qtype ATS  AC voltage trasfer to Qtype PFC Bus voltage*/
#define Gain_ACATS_to_BUS          		((f32_t)V_ACATS_FS/(f32_t)V_BUS_FS)	// V_ACATS_FS/V_BUS_FS

/* Full scale of Qtype PFC  AC voltage trasfer to Qtype PFC Bus voltage*/
#define Gain_ACPFC_to_BUS	         	((f32_t)1.028)	// V_ACPFC_FS/V_BUS_FS

/* Full scale of Qtype PFC Bus voltage trasfer to Qtype PFC  AC voltage*/
#define Gain_BUS_to_ACPFC           	((f32_t)0.9728)	// V_BUS_FS/V_ACPFC_FS

/* Full scale of Qtype PFC Bus voltage trasfer to Qtype ATS  AC voltage*/
#define Gain_BUS_to_ACATS           	((f32_t)V_BUS_FS/(f32_t)V_ACATS_FS)	// V_BUS_FS/V_ACATS_FS

/* Full scale of Qtype ATS  AC voltage trasfer to Qtype PFC  AC voltage*/
#define Gain_ACATS_to_ACPFC           	((f32_t)V_ACATS_FS/(f32_t)V_ACPFC_FS)	// V_ACATS_FS/V_ACPFC_FS

/* Full scale of Qtype PFC  AC voltage trasfer to Qtype ATS  AC voltage*/
#define Gain_ACPFC_to_ACATS           	((f32_t)V_ACPFC_FS/(f32_t)V_ACATS_FS)	// V_ACPFC_FS/V_ACATS_FS

/* Full scale of Qtype PFC  AC voltage trasfer to Qtype Iac for Xcao compensation*/
#define Gain_ACPFC_to_I_AC          	((f32_t)V_ACPFC_FS/(f32_t)I_AC_FS)

/* Relay turn on delay time*/
#define InrushRelayTurnOnDelayTime      80  // 8ms, unit is 0.1ms
#define RelayTurnOnDelayTime          	50  // 5ms, unit is 0.1ms
#define RelayTurnOffDelayTime          	20  // 2ms, unit is 0.1ms


/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/

#endif
