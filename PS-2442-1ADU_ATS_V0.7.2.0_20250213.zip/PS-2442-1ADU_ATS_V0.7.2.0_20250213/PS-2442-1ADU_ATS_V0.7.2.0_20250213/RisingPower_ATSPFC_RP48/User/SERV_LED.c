/****************************************************************************
 *	File	SERV_LED.c
 * 	Brief	LED status update
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2021/02/17 - 1st release
 ****************************************************************************/

#include "SERV_LED.h"
#include <string.h>


/****************************************************************************
    Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 26
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(LED_SetState, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/

sLED_t ptLED[LED_Tag_Num];
nLedStatus_t nLEDstatus;

/***************************************************************************
*   brief  Return LED address
*   note   
****************************************************************************/
sLED_t* GetLedRef(eLedTag_t eTag)
{
	return &ptLED[eTag];
}

/***************************************************************************
*   brief  Update LED state
*   note   
****************************************************************************/
void LED_SetState(sLED_t* psLED, u8_t u8NewState)
{
	if (psLED->u8State == u8NewState)
	{
		return;
	}

    psLED->u8State = u8NewState;

	switch (psLED->eTag)
	{
		case LED_Tag_AC1:
			nLEDstatus.u8Bits.u4AC1 = u8NewState;
			break;
			
		case LED_Tag_AC2:
			nLEDstatus.u8Bits.u4AC2 = u8NewState;
			break;
			         
       default:
			break;
	}
}

/***************************************************************************
*   brief  LED initialize
*   note   
****************************************************************************/
void LED_Initialize(void)
{
	u16_t i;
	
    nLEDstatus.u8All = 0;
	
	for (i=0; i<LED_Tag_Num; i++)
	{
		memset(&ptLED[i], 0, sizeof(ptLED[i]));
		ptLED[i].eTag = (eLedTag_t)i;
		ptLED[i].u8State = LED_STATIC_OFF;
	}
}
