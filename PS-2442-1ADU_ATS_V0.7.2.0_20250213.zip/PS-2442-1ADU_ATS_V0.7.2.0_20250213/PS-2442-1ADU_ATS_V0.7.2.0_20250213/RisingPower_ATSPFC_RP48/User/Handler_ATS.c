/****************************************************************************
 *	File	Handler_ATS.c
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/11/01 - 1st release
 ****************************************************************************/

#include <string.h>
#include "stdlib.h"
#include "Handler_ATS.h"
#include "Handler_PFC.h"
#include "CONFIG_RisingPower.h"
#include "Peripheral.h"
#include "SERV_LOG.h"
#include "FLASH_CommonRam.h"
#include "CANBus_Server.h"
#include "SERV_Calibration.h"


/****************************************************************************
*	Private parameter definition 
****************************************************************************/

#define NoInput							0x00
#define PrimaryInput					0x01
#define	SecondaryInput					0x02
#define	BBUInput						0x03


#define	HealthInValid					0x00	// ATS off
#define HealthStandBy                   0x01	// ATS on, PFC off
#define	HealthUsefull					0x02	
#define	HealthValid						0x03	// ATS Valid

#define Default_RideThroughTimeOut      350      // 35ms,unit is 0.1ms
#define Default_RideThroughTimeOut_2    120000   // 12s,unit is 0.1ms, 1.2s to 12s
#define Default_RideThroughACBack       120000   // 12s,unit is 0.1ms, 0.6s->1s->20s

#define T_100usToSec            	 	(u32_t)10000   	// Transfer 0.1ms to 1s

#define ATS_Switch_Dead_time       		40   	// 4ms, unit is 0.1ms
#define IGBT_TurnOn_delay          		10   	// 1ms, unit is 0.1ms
#define InrushRelay_TurnOn_delay        2000   	// 200ms, unit is 0.1ms
#define Relay_Short_delay          		1000   	// 100ms, unit is 0.1ms
#define Relay_Open_delay          		3000    // 300ms, unit is 0.1ms, consider bulkcap voltage and AC present delay
#define Relay_Short_VDiff				100		// 10V, unit is 0.1V
#define ATS_SeletS1_delay               1000    // 100ms, unit is 0.1ms

#define ATS_Start_up_delay	            300  	// 300ms,unit is 1ms, Waiting for VrefCali_count and input status update(UVP)

#define PFCDisable	            		FALSE

#define Input_Drop_delay          		20   	// 2ms, unit is 0.1ms, avoid AC1 and AC2 drop at the same time and switch to another source
#define WalkTimeOut_Default             (0xFFFF)
#define WalkTimeOut_Delay_CNT           5       // 500ms, unit is 100ms ; keep "WalkTimeOut" pass to D2D
#define WalkTimeOut                     15      // Force D2D enable when "WalkTimeOut" is reach

/****************************************************************************
*	Private macro definition
****************************************************************************/ 

/****************************************************************************
*	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
*	Private structure definition 
****************************************************************************/

/****************************************************************************
*	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 1008
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Delay, ".TI.ramfunc");
#pragma CODE_SECTION(TurnOffAllSwitch, ".TI.ramfunc");
#pragma CODE_SECTION(Reset_Timer, ".TI.ramfunc");
#pragma CODE_SECTION(IS_InrushRelay_On, ".TI.ramfunc");
#pragma CODE_SECTION(CheckApplyInput, ".TI.ramfunc");
#pragma CODE_SECTION(GetApplyInputRef, ".TI.ramfunc");
#pragma CODE_SECTION(GetWalkInTime, ".TI.ramfunc");
#pragma CODE_SECTION(ATS_Manager, ".TI.ramfunc");
#pragma CODE_SECTION(ATS_Operating, ".TI.ramfunc");
#pragma CODE_SECTION(ATS_Handler, ".TI.ramfunc");
#pragma CODE_SECTION(ATS_LED_Handler, ".TI.ramfunc");
#pragma CODE_SECTION(ATS_1ms_Periodically_Process, ".TI.ramfunc");
#pragma CODE_SECTION(Transmit_AC_Recovery, ".TI.ramfunc");
#pragma CODE_SECTION(Transmit_AC_Loss, ".TI.ramfunc");
#endif


/****************************************************************************
*	Private variable declaration
****************************************************************************/
sATS_t tsATS;
sATSManager_t *psNextSource;


/***************************************************************************
*   brief  Delay method
*   note   
****************************************************************************/
static u16_t Delay(u32_t* u32Delay)
{
	if (*u32Delay == 0)
	{
		return 1;
	}
	else
	{
		*u32Delay -= 1;
		return 0;
	}
}

/***************************************************************************
*   brief  PFC Enable and Disable function
*   note   
****************************************************************************/
static inline void SET_PFC(u16_t Value)
{
	tsATS.nFlag.u16Bits.u1PFCEnable = Value;
}

/***************************************************************************
*   brief  Turn off all switch to off due to dropout or power path failure
*   note   
****************************************************************************/
static void TurnOffAllSwitch(sATSManager_t *psInput)
{
    SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_ATSRelay], SwitchDriver_State_OFF);
	SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_InrushRelay], SwitchDriver_State_OFF);
	SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_InrushIGBT], SwitchDriver_State_OFF);
}

/***************************************************************************
*   brief  Reset ATS switching Timer
*   note   
****************************************************************************/
static void Reset_Timer(void)
{
	if (tsATS.nFlag.u16Bits.u1TimeStartCNT)
	{
		tsATS.nFlag.u16Bits.u1TimeStartCNT = FALSE;
		tsATS.nFlag.u16Bits.u1ReturnStartCNT = FALSE;
		tsATS.nFlag.u16Bits.u1OutageStartCNT = FALSE;
		tsATS.nFlag.u16Bits.u1WalkInRandomTime = FALSE;
		tsATS.sTimer.sVar.u32StabilizationDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u16StabilizationDelay;
		tsATS.sTimer.sVar.u32ObserveWindow = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8ObserveWindow;
		tsATS.sTimer.sVar.u32OutageDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8OutageDelay;
		tsATS.sTimer.sVar.u32ReturnDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8ReturnDelay;
	}
}

/***************************************************************************
*   brief  Check AC Recovery message is transmit or not
*   note   
****************************************************************************/
static void Transmit_AC_Recovery(void)
{
	if (tsATS.nFlag.u16Bits.u1AC_Recovery_Log == FALSE)
	{
		SET_CANBUS_SERVER_BC_AC_RECOVER;
		tsATS.nFlag.u16Bits.u1AC_Recovery_Log = TRUE;
		tsATS.nFlag.u16Bits.u1AC_Loss_Log = FALSE;
	}
}

/***************************************************************************
*   brief  Check AC Loss message is transmit or not
*   note   
****************************************************************************/
static void Transmit_AC_Loss(void)
{
	if (tsATS.nFlag.u16Bits.u1AC_Loss_Log == FALSE)
	{
		SET_CANBUS_SERVER_BC_AC_LOSS;
		tsATS.nFlag.u16Bits.u1AC_Recovery_Log = FALSE;
		tsATS.nFlag.u16Bits.u1AC_Loss_Log = TRUE;
	}
}

/***************************************************************************
*   brief  Check Inrush Relay turn on condition
*   note   Inrush relay turn on when Vbulk higher than ATS input RMS*1.4
****************************************************************************/
u16_t IS_InrushRelay_On(void)
{
	u16_t u16Vacpeak;
	u16_t u16ReturnVaule = FALSE;
	
	if (tsATS.ptApply != NULL)
	{
		if (tsATS.ptApply->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC)
		{
			u16Vacpeak = (u16_t)((f32_t)tsATS.ptApply->ptMoniAC->u16RealRMS * 1.4);
		}
		else if (tsATS.ptApply->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_DC)
		{
			u16Vacpeak = tsATS.ptApply->ptMoniAC->u16RealRMS;
		}
		else
		{
			u16Vacpeak = Q15_;
		}
		
		if (GET_MOMIDC_VBULK_RealInstant > u16Vacpeak)
		{
			u16ReturnVaule = TRUE;
		}
	}
	return u16ReturnVaule;
}

/***************************************************************************
*   brief  Check ATS have apply source
*   note   
****************************************************************************/
u16_t CheckApplyInput(void)
{
	if (tsATS.ptApply != NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/***************************************************************************
*   brief  Get input which is Applying 
*   note   
****************************************************************************/
sATSManager_t* GetApplyInputRef(void)
{
	u16_t i;
	
	for (i=0; i<ATS_SourceTag_Num; i++)
	{
		if (tsATS.ptSource[i]->nFlag.u16Bits.u1Apply == TRUE)
		{
			break;
		}
	}
	
	if (i < ATS_SourceTag_Num)
	{
		return tsATS.ptSource[i];
	}
	else
	{
		return NULL;
	}
}

/***************************************************************************
*   brief  Get Walk in Random timer
*   note   Use rand function  % 15 + 1 (step is 1ms)
*          random number range is 0 ~ 32767
*		   if random number larger than limit, it will redo rand() again 
****************************************************************************/
static u32_t GetWalkInTime(void)
{
	f32_t f32RandomNumber;
    u32_t u32RandomNumber;
	
	tsATS.nFlag.u16Bits.u1WalkInRandomTime = TRUE;
	f32RandomNumber = ((f32_t)rand() / (f32_t)Q15_) * (f32_t)tsATS.sTimer.u32RandomTime_Range;	// 0 ~ 13999, unit is 1ms
	u32RandomNumber = (u32_t)(f32RandomNumber + 0.5);
	u32RandomNumber += ((u32_t)tsATS.sTimer.u8WalkinLow * 1000); // 1000 ~ 14999, unit is 1ms ,step is 1ms
	u32RandomNumber = u32RandomNumber * 10; // 10000 ~ 149990, unit is 0.1ms
	tsATS.sTimer.u8Get_WalkinTime = (u8_t)(u32RandomNumber / 10000); // unit is 1s , u8 = u32RandomNumber/10000;

	return u32RandomNumber;
}

/****************************************************************************
*	Brief	check input valid
*	Usefull AC : 160-315, DC : 200-432
*	Valid   AC : 176-315, DC : 235-432
*
*	Note   : 1. Standby mode turn-on at 120V~315V , below 100V turn-off
*	         2. In Timer0 10kHz ISR
****************************************************************************/
static inline void Check_Input_Valid(void)
{
	u16_t i;

    for (i=0; i<ATS_InputTag_Num; i++)
	{
		// Check Input Valid
        if ((tsATS.tsInput[i].nFault.u16All == 0) &&
            (tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1SourceGood))
        {
            tsATS.tsInput[i].nFlag.u16Bits.u1Valid = TRUE;
			tsATS.tsInput[i].nFlag.u16Bits.u1Useful = TRUE;
			tsATS.tsInput[i].nFlag.u16Bits.u1Standby = TRUE;

			if (GET_PFC_FAULT)
			{
				tsATS.tsInput[i].nFlag.u16Bits.u2Health = HealthInValid;
			}
			else
			{
				tsATS.tsInput[i].nFlag.u16Bits.u2Health = HealthValid;
			}
        }
        else
        {
            tsATS.tsInput[i].nFlag.u16Bits.u1Valid = FALSE;

			// Check Input Useful, Input not valid, ATS On for maintain Bulk voltage
			if ((tsATS.tsInput[i].nFault.u16All == 0) &&
            	(tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1SourcePresent) &&
            	(tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1Dropout == FALSE) &&
            	(tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1OverVoltageProtect == FALSE) &&
            	(tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1FreqError == FALSE))
        	{
            	tsATS.tsInput[i].nFlag.u16Bits.u1Useful = TRUE;
				tsATS.tsInput[i].nFlag.u16Bits.u1Standby = TRUE;

				if (GET_PFC_FAULT)
				{
					tsATS.tsInput[i].nFlag.u16Bits.u2Health = HealthInValid;
				}
				else
				{
					tsATS.tsInput[i].nFlag.u16Bits.u2Health = HealthUsefull;
				}
        	}
			// Standby mode range : 120Vac~315Vac , ATS On, PFC and D2D off
			else if ((tsATS.tsInput[i].nFault.u16All == 0) &&
	                 (tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1Dropout == FALSE) &&
	                 (tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1OverVoltageProtect == FALSE) &&
	                 (tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1FreqError == FALSE))
			{
                tsATS.tsInput[i].nFlag.u16Bits.u1Useful = FALSE;
				tsATS.tsInput[i].nFlag.u16Bits.u1Standby = TRUE;
				
				if (GET_PFC_FAULT)
				{
					tsATS.tsInput[i].nFlag.u16Bits.u2Health = HealthInValid;
				}
				else
				{
					tsATS.tsInput[i].nFlag.u16Bits.u2Health = HealthStandBy;
				}
			}
			// ATS off
        	else
        	{
        	    tsATS.tsInput[i].nFlag.u16Bits.u1Useful = FALSE;
				tsATS.tsInput[i].nFlag.u16Bits.u1Standby = FALSE;
				tsATS.tsInput[i].nFlag.u16Bits.u2Health = HealthInValid;
        	}
        }
    }
}

/****************************************************************************
*	Brief	check prefer source is change from PSC
*	Note	In Timer0 10kHz ISR
****************************************************************************/
static inline void Check_Prefer_Source(void)
{
	if (tsATS.sContr.u8PreferSource != tsATS.sContr.u8PreferSource_PSC)
	{
		tsATS.sContr.u8PreferSource = tsATS.sContr.u8PreferSource_PSC;

		// Swap ptSource point
		if (tsATS.sContr.u8PreferSource == ATS_ApplySourceis1)
		{
			tsATS.ptSource[ATS_SourceTag_Primary] = &tsATS.tsInput[ATS_InputTag_Input1];
			tsATS.ptSource[ATS_SourceTag_Secondary] = &tsATS.tsInput[ATS_InputTag_Input2];
		}
		else
		{
			tsATS.ptSource[ATS_SourceTag_Primary] = &tsATS.tsInput[ATS_InputTag_Input2];
			tsATS.ptSource[ATS_SourceTag_Secondary] = &tsATS.tsInput[ATS_InputTag_Input1];
		}

		// Swap ATS state
		if (tsATS.eATSstate == ATSStatus_Pri)
		{
			tsATS.eATSstate = ATSStatus_Sec;
			tsATS.nFlag.u16Bits.u2ATSEnable = SecondaryInput;
		}
		else if (tsATS.eATSstate == ATSStatus_Sec)
		{
			tsATS.eATSstate = ATSStatus_Pri;
			tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
		}

		// Force switching to Primary if primary source is valid
		if (tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u2Health == HealthValid)
		{
			if ((tsATS.eATSstate == ATSStatus_Sec) ||
				(tsATS.eATSstate == ATSStatus_BBU))
			{
				if (tsATS.eATSstate == ATSStatus_Sec)
				{
					Log_Status_Transfer(eATSTransfer_State_SSP);
				}
				else
				{
					Transmit_AC_Recovery();
					Log_Status_Transfer(eATSTransfer_State_SBP);
				}
				
				tsATS.eATSstate = ATSStatus_Switch;
				tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
			}
		}

		Reset_Timer();
	}
}

/***************************************************************************
*   brief  ATS Reset status, ATS off
*   note   1. Assign apply source (AC1 or AC2) while input valid
*          2. In Timer0 10kHz ISR
****************************************************************************/
static inline void ATS_Reset(void)
{
	if (tsATS.ePreATSstate != tsATS.eATSstate)
	{
		SET_PFC(PFCDisable);
		tsATS.sTimer.u16InputReadyDelay = 0;
		tsATS.ePreATSstate = tsATS.eATSstate;
	}

	// When AC1 and AC2 recovery at the same time, wait AC ready and choose Pri source first.
	if ((tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u2Health) ||
		(tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u2Health))
	{
		// InputReadyTime is OBSERVE delay +1s , wait 4s
		if (tsATS.sTimer.u16InputReadyDelay < tsATS.sTimer.u16InputReadyTime)
		{
			tsATS.sTimer.u16InputReadyDelay += 1;
		}
	}
	else
	{
		tsATS.sTimer.u16InputReadyDelay = 0;
	}

	if (tsATS.sTimer.u16InputReadyDelay == tsATS.sTimer.u16InputReadyTime)
	{
		tsATS.nFlag.u16Bits.u1FirstOn = TRUE;

		// Force clear AC loss / recovery flag
		tsATS.nFlag.u16Bits.u1AC_Recovery_Log = FALSE;
		tsATS.nFlag.u16Bits.u1AC_Loss_Log = FALSE;
		
		if (tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u2Health >= tsATS.ptSource[ATS_SourceTag_Secondary]->nFlag.u16Bits.u2Health)
		{
			tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
			tsATS.eATSstate = ATSStatus_Switch;
		}
		else
		{
			tsATS.nFlag.u16Bits.u2ATSEnable = SecondaryInput;
			tsATS.eATSstate = ATSStatus_Switch;
		}
	}
}

/***************************************************************************
*   brief  ATS Switching(transition) status
*   note   In Timer0 10kHz ISR
****************************************************************************/
static inline void ATS_Switching(void)
{
	if (tsATS.ePreATSstate != tsATS.eATSstate)
	{
		Reset_Timer();
		tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
		tsATS.ePreATSstate = tsATS.eATSstate;
	}

	switch (tsATS.nFlag.u16Bits.u2ATSEnable)
	{
		case NoInput:
			if (tsATS.ptApply == NULL)
			{
				tsATS.eATSstate = ATSStatus_Reset;
			}	
			break;
		
		case PrimaryInput:
			if (tsATS.ptApply == tsATS.ptSource[ATS_SourceTag_Primary])
			{
				if ((tsATS.ptApply->nFlag.u16Bits.u2Health == HealthInValid) &&
					(tsATS.nFlag.u16Bits.u1FirstOn))
				{
					tsATS.nFlag.u16Bits.u2ATSEnable = NoInput;
				}
				else if (tsATS.ptApply->eSwitchState > ATSSwitch_PreTurnOnATSRelay)
				{
					Log_Update_ATSwitchCNT();
					tsATS.eATSstate = ATSStatus_Pri;
				}
			}				
			break;
			
		case SecondaryInput:
			if (tsATS.ptApply == tsATS.ptSource[ATS_SourceTag_Secondary])
			{
				if ((tsATS.ptApply->nFlag.u16Bits.u2Health == HealthInValid) &&
					(tsATS.nFlag.u16Bits.u1FirstOn))
				{
					tsATS.nFlag.u16Bits.u2ATSEnable = NoInput;
				}	
				else if (tsATS.ptApply->eSwitchState > ATSSwitch_PreTurnOnATSRelay)
				{
					Log_Update_ATSwitchCNT();
					tsATS.eATSstate = ATSStatus_Sec;
				}			
			}
			break;

		case BBUInput:
			tsATS.eATSstate = ATSStatus_BBU;
			break;
			
		default:
			break;
	}
}

/***************************************************************************
*   brief  ATS at Primary source
*   note   In Timer0 10kHz ISR
****************************************************************************/
static inline void ATS_Primary(void)
{
	if (tsATS.ePreATSstate != tsATS.eATSstate)
	{
		tsATS.ePreATSstate = tsATS.eATSstate;
	}

	if (tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u2Health == HealthValid)
	{
		Transmit_AC_Recovery();
		tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
		SET_PFC(PFCEnable);
	}
	else if (GET_LOG_BBU_Valid)
	{
		Transmit_AC_Loss();
		Log_Status_Transfer(eATSTransfer_State_SPB);	//S1B
		tsATS.nFlag.u16Bits.u2ATSEnable = BBUInput;
		tsATS.eATSstate = ATSStatus_Switch;
	}
	else if (tsATS.ptSource[ATS_SourceTag_Secondary]->nFlag.u16Bits.u2Health == HealthValid)
	{
		Transmit_AC_Loss();
		if (Delay(&tsATS.sTimer.u32Drop_Delay))
		{
			Log_Status_Transfer(eATSTransfer_State_SPS);	//S12
			tsATS.nFlag.u16Bits.u2ATSEnable = SecondaryInput;
			tsATS.eATSstate = ATSStatus_Switch;
		}
	}
	else if (tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u2Health)
	{
		Transmit_AC_Loss();
		tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
		
		if ((SET_PFC_State == PFC_State_Off) && 
			(tsATS.nFlag.u16Bits.u1PFCEnable == FALSE))
		{
			// S11
			// Standby mode stay here,  ATS keep on , PFC off
		}
		else
		{
			tsATS.nFlag.u16Bits.u1RideThrough = TRUE;
		}
	}
	else if (tsATS.ptSource[ATS_SourceTag_Secondary]->nFlag.u16Bits.u2Health)
	{
		Transmit_AC_Loss();
		if (Delay(&tsATS.sTimer.u32Drop_Delay))
		{
			Log_Status_Transfer(eATSTransfer_State_SPS);	//S12
			tsATS.nFlag.u16Bits.u2ATSEnable = SecondaryInput;
			tsATS.eATSstate = ATSStatus_Switch;
		}
	}
	else
	{
		Transmit_AC_Loss();
		tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
		
		// Consider Input UV and OV condition
		if (((SET_PFC_State == PFC_State_Off) || (tsATS.sTimer.u32RideThroughTimeOut == 0)) && 
			 (tsATS.nFlag.u16Bits.u1PFCEnable == FALSE))
		{
			// Turn off ATS
			Log_Status_Transfer(eATSTransfer_State_Off);	//S1Off
			tsATS.nFlag.u16Bits.u2ATSEnable = NoInput;
			tsATS.eATSstate = ATSStatus_Switch;
		}
		else
		{
			tsATS.nFlag.u16Bits.u1RideThrough = TRUE;
		}
	}	
}

/***************************************************************************
*   brief  ATS at Secondary source
*   note   In Timer0 10kHz ISR
****************************************************************************/
static inline void ATS_Secondary(void)
{
	if (tsATS.ePreATSstate != tsATS.eATSstate)
	{
		tsATS.ePreATSstate = tsATS.eATSstate;
	}

	if (tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u2Health == HealthValid)
	{
		if (tsATS.ptSource[ATS_SourceTag_Secondary]->nFlag.u16Bits.u2Health == HealthValid)
		{
			tsATS.nFlag.u16Bits.u1TimeStartCNT = TRUE;
			tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
			
		    if (Delay(&tsATS.sTimer.sVar.u32StabilizationDelay))	//300s
            {
                if (tsATS.nFlag.u16Bits.u1WalkInRandomTime == FALSE)
                {
                	tsATS.sTimer.u32WalkinTime = GetWalkInTime();
                }
   
                if (Delay(&tsATS.sTimer.u32WalkinTime))
                {
                	Log_Status_Transfer(eATSTransfer_State_SSP);	//S21#1
                    tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
					tsATS.eATSstate = ATSStatus_Switch;
                }                   
            }
			else
			{
				Transmit_AC_Recovery();
				SET_PFC(PFCEnable);
			}
		}
		else
		{
			Transmit_AC_Loss();
			
			if (Delay(&tsATS.sTimer.u32Drop_Delay))
			{
				Log_Status_Transfer(eATSTransfer_State_SSP);	//S21#2
				tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
				tsATS.eATSstate = ATSStatus_Switch;
			}	
		}
	}
	else if (tsATS.ptSource[ATS_SourceTag_Secondary]->nFlag.u16Bits.u2Health == HealthValid)
	{
		Transmit_AC_Recovery();
		Reset_Timer();
		tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
		SET_PFC(PFCEnable);
	}
	else if (GET_LOG_BBU_Valid)
	{
		Transmit_AC_Loss();
		Log_Status_Transfer(eATSTransfer_State_SSB);	//S2B
		tsATS.nFlag.u16Bits.u2ATSEnable = BBUInput;
		tsATS.eATSstate = ATSStatus_Switch;
	}
	else if (tsATS.ptSource[ATS_SourceTag_Secondary]->nFlag.u16Bits.u2Health)
	{
		Transmit_AC_Loss();
		Reset_Timer();
		tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
		
		if ((SET_PFC_State == PFC_State_Off) && 
			(tsATS.nFlag.u16Bits.u1PFCEnable == FALSE))
		{
			// S22
			// Standby mode stay here,  ATS keep on , PFC off
		}
		else
		{
			tsATS.nFlag.u16Bits.u1RideThrough = TRUE;
		}	
	}
	else if (tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u2Health)
	{
		Transmit_AC_Loss();
		if (Delay(&tsATS.sTimer.u32Drop_Delay))
		{
			Log_Status_Transfer(eATSTransfer_State_SSP);	//S21#2
			tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
			tsATS.eATSstate = ATSStatus_Switch;
		}
	}
	else
	{
		Transmit_AC_Loss();
		Reset_Timer();
		tsATS.sTimer.u32Drop_Delay = Input_Drop_delay;
		
		if (((SET_PFC_State == PFC_State_Off) || (tsATS.sTimer.u32RideThroughTimeOut == 0)) && 
			 (tsATS.nFlag.u16Bits.u1PFCEnable == FALSE))
		{
			// Turn off ATS
			Log_Status_Transfer(eATSTransfer_State_Off);	//S2Off
			tsATS.nFlag.u16Bits.u2ATSEnable = NoInput;
			tsATS.eATSstate = ATSStatus_Switch;
		}
		else
		{
			tsATS.nFlag.u16Bits.u1RideThrough = TRUE;
		}
	}
}

/***************************************************************************
*   brief  ATS at BBU source
*   note   In Timer0 10kHz ISR
****************************************************************************/
static inline void ATS_BBU(void)
{
	if (tsATS.ePreATSstate != tsATS.eATSstate)
	{
        tsATS.sTimer.u32ATSSelect_CNT = ATS_SeletS1_delay; // For BBU transfer to S1 first
		tsATS.ePreATSstate = tsATS.eATSstate;
		tsATS.sTimer.u16WalkinTime_Out = WalkTimeOut_Default; // 0xFFFF means no walking time
	}

	if (tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u2Health == HealthValid)
	{
		if ((tsATS.nFlag.u16Bits.u1TimeStartCNT) &&
			(tsATS.nFlag.u16Bits.u1OutageStartCNT))
		{
			tsATS.sTimer.sVar.u32OutageDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8OutageDelay;
			tsATS.nFlag.u16Bits.u1WalkInRandomTime = FALSE;
			tsATS.nFlag.u16Bits.u1OutageStartCNT = FALSE;
		}

		if (GET_LOG_BBUMode_Valid)
		{
            tsATS.nFlag.u16Bits.u1TimeStartCNT = TRUE;
            tsATS.nFlag.u16Bits.u1ReturnStartCNT = TRUE;

            if (Delay(&tsATS.sTimer.sVar.u32ReturnDelay))
            {
                if (tsATS.nFlag.u16Bits.u1WalkInRandomTime == FALSE)
                {
                    tsATS.sTimer.u32WalkinTime = GetWalkInTime();
                    Transmit_AC_Recovery();
                }

                if (Delay(&tsATS.sTimer.u32WalkinTime))
                {
                    Log_Status_Transfer(eATSTransfer_State_SBP);	//BS1#1
                    tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
                    tsATS.eATSstate = ATSStatus_Switch;
                    tsATS.sTimer.u16WalkinTime_Out = (tsATS.sTimer.u8WalkinHigh + SET_LOG_HEARTBEAT_TIMEOUT - tsATS.sTimer.u8Get_WalkinTime) * 10; // ByPass to D2D (WALK_H + Time_Out - Walk_Random)
                    tsATS.sContr.u8Force_D2DOn = FALSE; // Force D2D turn off until "u16WalkinTime_Out" is reach
                }
            }
		}
		else
		{
			Transmit_AC_Recovery();
			Log_Status_Transfer(eATSTransfer_State_SBP);	//BS1#2
			tsATS.nFlag.u16Bits.u2ATSEnable = PrimaryInput;
			tsATS.eATSstate = ATSStatus_Switch;
            tsATS.sTimer.u16WalkinTime_Out = WalkTimeOut_Default; // 0xFFFF means no walking time
		}
	}
	else if (tsATS.ptSource[ATS_SourceTag_Secondary]->nFlag.u16Bits.u2Health == HealthValid)
	{
		if ((tsATS.nFlag.u16Bits.u1TimeStartCNT) &&
			(tsATS.nFlag.u16Bits.u1ReturnStartCNT))
		{
			tsATS.sTimer.sVar.u32ReturnDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8ReturnDelay;
			tsATS.nFlag.u16Bits.u1WalkInRandomTime = FALSE;
			tsATS.nFlag.u16Bits.u1ReturnStartCNT = FALSE;
		}
	
        if (GET_LOG_BBUMode_Valid)
        {
            tsATS.nFlag.u16Bits.u1TimeStartCNT = TRUE;
            tsATS.nFlag.u16Bits.u1OutageStartCNT = TRUE;

            if ((Delay(&tsATS.sTimer.sVar.u32OutageDelay)) && // OutageDelay default is 90s
                (GET_LOG_BBUMode_Valid == 1))
            {
                if (tsATS.nFlag.u16Bits.u1WalkInRandomTime == FALSE)
                {
                    tsATS.sTimer.u32WalkinTime = GetWalkInTime();
                    Transmit_AC_Recovery();
                }

                if (Delay(&tsATS.sTimer.u32WalkinTime))
                {
                    Log_Status_Transfer(eATSTransfer_State_SBS);	//BS2#1
                    tsATS.nFlag.u16Bits.u2ATSEnable = SecondaryInput;
                    tsATS.eATSstate = ATSStatus_Switch;
                    tsATS.sTimer.u16WalkinTime_Out = (tsATS.sTimer.u8WalkinHigh + SET_LOG_HEARTBEAT_TIMEOUT - tsATS.sTimer.u8Get_WalkinTime) * 10; // ByPass to D2D (WALK_H + Time_Out - Walk_Random)
                    tsATS.sContr.u8Force_D2DOn = FALSE; // Force D2D turn off until "u16WalkinTime_Out" is reach.
                }
            }
		}
		else
		{
            // Add BBU emergency transfer to ATS delay time, primary is transfer to S1.
            if (Delay(&tsATS.sTimer.u32ATSSelect_CNT))
            {
                Transmit_AC_Recovery();

                Log_Status_Transfer(eATSTransfer_State_SBS);    //BS2#2
                tsATS.nFlag.u16Bits.u2ATSEnable = SecondaryInput;
                tsATS.eATSstate = ATSStatus_Switch;
                tsATS.sTimer.u16WalkinTime_Out = WalkTimeOut_Default; // 0xFFFF means no walking time
            }
		}
	}
	else if (GET_LOG_BBU_Valid)
	{
		Reset_Timer();
	}
	else
	{
		// BBU off
		tsATS.nFlag.u16Bits.u2ATSEnable = NoInput;
		tsATS.eATSstate = ATSStatus_Switch;
        tsATS.sTimer.u16WalkinTime_Out = WalkTimeOut_Default; // 0xFFFF means no walking time
	}
}

/***************************************************************************
*   brief  ATS in Ride through (Follow ITIC spec)
*   note    
*			Input Loss		0V			20ms~35ms	CNTdown reset to 35ms
*			Not Usefull		<155		12s
*			UVP				155~165		12s			
*			Normal			>170		keep works	CNTup reset to 0	
*
****************************************************************************/
static inline void ATS_RideThrough(void)
{
	tsATS.nFlag.u16Bits.u1RideThrough = FALSE;
	tsATS.nFlag.u16Bits.u1RideThrough_Action = TRUE;

	if (tsATS.ptApply != NULL)
	{
		// Separate input status into Input Loss, Not Usefull, UVP, Normal
		if (tsATS.ptApply->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_Loss)
		{
			SET_PFC(PFCDisable);
			tsATS.eITICstate = ATS_ITIC_Loss;
		}
		// source is not present
		else if ((tsATS.ptApply->nFlag.u16Bits.u2Health < HealthUsefull) ||
				 (tsATS.ptApply->ptMoniAC->nFlag.u16Bits.u1OverVoltageProtect == TRUE))
		{
			// add OVP for fault injection can not shut down PFC issue
			SET_PFC(PFCEnable);
			tsATS.eITICstate = ATS_ITIC_Notusefull;
			tsATS.sTimer.u32RideThroughTimeOut = Default_RideThroughTimeOut;
		}
		else if (tsATS.ptApply->ptMoniAC->nFlag.u16Bits.u1BrownoutProtect == TRUE)
		{
			SET_PFC(PFCEnable);
			tsATS.eITICstate = ATS_ITIC_UVP;
			tsATS.sTimer.u32RideThroughTimeOut = Default_RideThroughTimeOut;
		}
		else
		{
			// PSU at brownout warning or input valid, PSU keep going
			SET_PFC(PFCEnable);
			tsATS.eITICstate = ATS_ITIC_Normal;
			tsATS.sTimer.u32RideThroughCNT = 0;
			tsATS.sTimer.u32RideThroughTimeOut = Default_RideThroughTimeOut;
		}

		// Check ITIC Time out 12s
		if ((tsATS.eITICstate == ATS_ITIC_Notusefull) &&
			(tsATS.sTimer.u32RideThroughCNT > Default_RideThroughTimeOut_2))
		{
			tsATS.sTimer.u32RideThroughTimeOut = 0;
		}
		// Check ITIC Time out 12s
		else if ((tsATS.eITICstate == ATS_ITIC_UVP) &&
				 (tsATS.sTimer.u32RideThroughCNT > Default_RideThroughACBack))
		{
			tsATS.sTimer.u32RideThroughTimeOut = 0;
		}
		// check AC Input OVP Fast
		else if ((tsATS.ptApply->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC) &&
				 (tsATS.ptApply->ptMoniAC->u16RealRMS_WF > 3400))
		{
			tsATS.sTimer.u32RideThroughTimeOut = 0;
		}
		// check DC Input OVP Fast
		else if ((tsATS.ptApply->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_DC) &&
				 (tsATS.ptApply->ptMoniAC->u16RealRMS_WF > 4700))
		{
			tsATS.sTimer.u32RideThroughTimeOut = 0;
		}

		// turn off ATS and PFC
		if ((tsATS.ptApply->nFault.u16All != 0) ||
			(tsATS.sTimer.u32RideThroughTimeOut == 0) ||
			(SET_PFC_State == PFC_State_Off))
		{
			SET_PFC(PFCDisable);
		}
		// Vin > 250 (Vbulk > 350V) and FreqError during calibration
		// Turn off PFC and D2D, stay here for Vbulk calibration
		else if ((tsATS.ptApply->ptMoniAC->nFlag.u16Bits.u1FreqError == TRUE) &&
				 (SET_CALI_KEY_OK == TRUE))
		{
			SET_PFC(PFCDisable);
			tsATS.sTimer.u32RideThroughCNT = 0;
			tsATS.nFlag.u16Bits.u1BulkCalimode = TRUE;
		}
	}

	if (tsATS.sTimer.u32RideThroughCNT < Q31_1)
	{
		tsATS.sTimer.u32RideThroughCNT ++;
	}

	if (tsATS.sTimer.u32RideThroughTimeOut != 0)
	{
		tsATS.sTimer.u32RideThroughTimeOut --;
	}
}

/***************************************************************************
*   brief  Release role token after apply input break off, and Assign new apply source
*   note   1. only be executed during operating state
*          2. If u2ATSEnable is NoInput , u1Apply is zero and (ATS_Manager function) will turn-off all switch
****************************************************************************/
static inline void ATS_UpdateSourceRole(void)
{
    psNextSource = NULL;

	// Reset Source Role
	if (tsATS.ptApply != NULL)
	{
		if ((tsATS.ptApply->nFlag.u16Bits.u1Apply == 0) && 
			(tsATS.ptApply->ptSwitch[ATS_SwitchTag_ATSRelay]->eState == SwitchDriver_State_OFF))
		{
			tsATS.ptApply = NULL;
			// Turn off PFC when ATS Relay off
			SET_PFC(PFCDisable);
        }
	}

	// Set Next apply source
	if (tsATS.nFlag.u16Bits.u2ATSEnable == PrimaryInput)
	{
		psNextSource = tsATS.ptSource[ATS_SourceTag_Primary];
	}
	else if (tsATS.nFlag.u16Bits.u2ATSEnable == SecondaryInput)
	{
		psNextSource = tsATS.ptSource[ATS_SourceTag_Secondary];
	}

	// Check Next apply source status
	if (psNextSource != NULL)
	{
		// Assign new apply source 
		if (tsATS.ptApply == NULL)
		{
			tsATS.ptApply = psNextSource;
			tsATS.ptApply->nFlag.u16Bits.u1Apply = 1;
		}
		// Apply source is not psNextSource, turn off apply source
		else if (tsATS.ptApply != psNextSource)
		{
			tsATS.ptApply->nFlag.u16Bits.u1Apply = 0;
		}
		// apply source is psNextSource, no action
	}
	else if (tsATS.ptApply != NULL)
	{
		// No available input source, turn off apply source
		tsATS.ptApply->nFlag.u16Bits.u1Apply = 0;
	}
}

/***************************************************************************
*   brief  Detect ATS relay Short fault
*   note
****************************************************************************/
static void ATS_Detect_ATSRelay_ShortFault(sATSManager_t* psInput)
{
    // no any apply source
    // check relay short fault during no any apply source
    // check condtion is Present, InputStatus, and input voltage similar (within 10V)
    u16_t u16DiffVoltage;

    if (GET_MOMIAC_VPFC_REALRMS_WF > psInput->ptMoniAC->u16RealRMS_WF)
    {
        u16DiffVoltage = GET_MOMIAC_VPFC_REALRMS_WF - psInput->ptMoniAC->u16RealRMS_WF;
    }
    else
    {
        u16DiffVoltage = psInput->ptMoniAC->u16RealRMS_WF - GET_MOMIAC_VPFC_REALRMS_WF;
    }

    if ((psInput->ptMoniAC->nFlag.u16Bits.u1SourcePresent) &&
        (GET_MOMIAC_VPFC_PRESENT_FLAG) &&
        (GET_MOMIAC_VPFC_INPUTSTATUS == psInput->ptMoniAC->nStatus.u16Bits.u2InputStatus) &&
        (u16DiffVoltage < Relay_Short_VDiff))
    {
        // Middle voltage should be blackout in 30ms.
        // The duration is caused by the Middle voltage on X-capacitor need to discharge very long time,
        // If the switch components have no damage, the polarity should be keep the same over than 25ms and then trigger AcPresent flag be cleared.
        // so if middle voltage keep present over than 30ms, that means something damaged.

		if (psInput->u16RelayShort_CNT < Relay_Short_delay)	// 100ms
		{
			psInput->u16RelayShort_CNT += 1;
		}
		else if (psInput->nFault.u16Bits.u1RealyShort == 0)
		{
			psInput->nFault.u16Bits.u1RealyShort = 1;
			psInput->u8RelayShort_RecoveryCNT = GET_LOG_FAULT_DELAY;

			if (psInput->u8RelayShort_FaultCNT <= GET_LOG_FAULT_COUNT_LIMIT)	// 3
			{
				psInput->u8RelayShort_FaultCNT += 1;
			}
		}
    }
    else
    {
        psInput->u16RelayShort_CNT = 0;
    }
}

/***************************************************************************
*   brief  Detect ATS relay Open fault
*   note
****************************************************************************/
static void ATS_Detect_ATSRelay_OpenFault(sATSManager_t* psInput)
{
    if ((psInput->ptMoniAC->nFlag.u16Bits.u1SourcePresent) &&
        (GET_MOMIAC_VPFC_REALRMS_WF < 1000))
    {
		if (psInput->u16RelayOpen_CNT < Relay_Open_delay)	// 300ms
		{
			psInput->u16RelayOpen_CNT += 1;
		}
		else if (psInput->nFault.u16Bits.u1RealyOpen == 0)
		{
			psInput->nFault.u16Bits.u1RealyOpen = 1;
			psInput->u8RelayOpen_RecoveryCNT = GET_LOG_FAULT_DELAY;

			if (psInput->u8RelayOpen_FaultCNT <= GET_LOG_FAULT_COUNT_LIMIT)	// 3
			{
				psInput->u8RelayOpen_FaultCNT += 1;
			}
		}
    }
    else
    {
    	psInput->u16RelayOpen_CNT = 0;
    }
}

/***************************************************************************
*   brief  ATS Operating Manager for rising power
*   note   relay short fault detect when no any apply input to check voltage
****************************************************************************/
static void ATS_Manager(sATSManager_t* psInput)
{
	switch (psInput->eSwitchState)
	{
		case ATSSwitch_StaticOff:
			if (psInput->ePreSwitchState != psInput->eSwitchState)
			{
				TurnOffAllSwitch(psInput);
				psInput->ePreSwitchState = psInput->eSwitchState;
				psInput->u16ElapsedTime = 0;
			}

			if (psInput->nFlag.u16Bits.u1Apply)
			{
				if (psInput->u16ElapsedTime > ATS_Switch_Dead_time)
				{
					if (tsATS.nFlag.u16Bits.u1FirstOn)
					{
						if (psInput->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC)
						{
							//ATS relay turn on at zero cross when ATS is first turn on
							if (SwitchTiming(MoniAC_RelayONZC, (eMoniACTag_t)psInput->eTag))
							{
								psInput->eSwitchState = ATSSwitch_PreTurnOnATSRelay;
							}
						}
						else
						{
							psInput->eSwitchState = ATSSwitch_PreTurnOnATSRelay;
						}	
					}
					else
					{
						psInput->eSwitchState = ATSSwitch_PreTurnOnATSRelay;
					}				
				}
			}
			else if (GetApplyInputRef() == NULL)
			{
			    ATS_Detect_ATSRelay_ShortFault(psInput);
				psInput->u16ElapsedTime = 0; //clear ElapsedTime
			}
			else
			{
				psInput->u16ElapsedTime = 0; //clear ElapsedTime
			}
			
			break;

		case ATSSwitch_PreTurnOnATSRelay:
			if (psInput->ePreSwitchState != psInput->eSwitchState)
			{
				tsATS.nFlag.u16Bits.u1FirstOn = FALSE;
				SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_ATSRelay], SwitchDriver_State_TurnOn);
				psInput->ePreSwitchState = psInput->eSwitchState;
				psInput->u16ElapsedTime = 0;
			}

			if (psInput->nFlag.u16Bits.u1Apply)
			{
				if(psInput->u16ElapsedTime > RelayTurnOnDelayTime)
				{
					psInput->eSwitchState = ATSSwitch_ATSRelayOn;
				}
			}
			else
			{
				psInput->eSwitchState = ATSSwitch_StaticOff;
			}

			break;

		case ATSSwitch_ATSRelayOn:
			if (psInput->ePreSwitchState != psInput->eSwitchState)
			{
				psInput->ePreSwitchState = psInput->eSwitchState;
				psInput->u16ElapsedTime = 0;
			}
			
			if (psInput->nFlag.u16Bits.u1Apply)
			{
				if ((psInput->u16ElapsedTime > IGBT_TurnOn_delay) &&
					(IS_PFC_INRUSH_IGBT_ON == TRUE))
				{
					// Turn on IGBT when PFC finished PTC charge Bulk-cap
					psInput->eSwitchState = ATSSwitch_IGBTOn;
				}
			}
			else
			{
				psInput->eSwitchState = ATSSwitch_StaticOff;
			}
			
			break;


		case ATSSwitch_IGBTOn:
			if (psInput->ePreSwitchState != psInput->eSwitchState)
			{
				SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_InrushIGBT], SwitchDriver_State_StaticON);
				psInput->ePreSwitchState = psInput->eSwitchState;
			}
			
			if (psInput->nFlag.u16Bits.u1Apply)
			{
				// Turn on Inrush Relay when Bulk-cap voltage more than Input peak voltage
				if (IS_InrushRelay_On())
				{
					if (psInput->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC)
					{
						//Inrush relay turn on at zero cross
						if (SwitchTiming(MoniAC_RelayONZC, (eMoniACTag_t)psInput->eTag))
						{
							psInput->eSwitchState = ATSSwitch_PreTurnOnInrushRelay;
						}
					}
					else
					{
						//Inrush relay turn on immediately
						psInput->eSwitchState = ATSSwitch_PreTurnOnInrushRelay;
					}				
				}

				// Detect ATS relay open fault
				ATS_Detect_ATSRelay_OpenFault(psInput);
			}
			else
			{
				psInput->eSwitchState = ATSSwitch_StaticOff;
			}
			
			psInput->u16ElapsedTime = 0; //clear ElapsedTime

			break;

		case ATSSwitch_PreTurnOnInrushRelay:
			if (psInput->ePreSwitchState != psInput->eSwitchState)
			{
				SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_InrushRelay], SwitchDriver_State_TurnOn);
				psInput->ePreSwitchState = psInput->eSwitchState;
				psInput->u16ElapsedTime = 0;
			}

			if (psInput->nFlag.u16Bits.u1Apply)
			{
				if (psInput->u16ElapsedTime > InrushRelay_TurnOn_delay)
				{
					if (psInput->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC)
					{
						//Inrush IGBT turn off at zero cross
						if (SwitchTiming(MoniAC_SwitchZC, (eMoniACTag_t)psInput->eTag))
						{
							psInput->eSwitchState = ATSSwitch_StaticOn;
						}
					}
					else
					{
						//Inrush relay turn on immediately
						psInput->eSwitchState = ATSSwitch_StaticOn;
					}
				}

                // Detect ATS relay open fault
                ATS_Detect_ATSRelay_OpenFault(psInput);
			}
			else
			{
				psInput->eSwitchState = ATSSwitch_StaticOff;
			}
			
			break;

		case ATSSwitch_StaticOn:
			if (psInput->ePreSwitchState != psInput->eSwitchState)
			{
				SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_ATSRelay], SwitchDriver_State_StaticON);
				SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_InrushRelay], SwitchDriver_State_StaticON);
				SetSwitchState(psInput->ptSwitch[ATS_SwitchTag_InrushIGBT], SwitchDriver_State_OFF);
				psInput->ePreSwitchState = psInput->eSwitchState;
			}

			if (psInput->nFlag.u16Bits.u1Apply)
			{
                // Detect ATS relay open fault
                ATS_Detect_ATSRelay_OpenFault(psInput);
				
			}
			else
			{
				// Input source is AC, not drop out condition, no fault , Vbulk > 380V: wait ZC turn off Relay 
				if ((psInput->ptMoniAC->nStatus.u16Bits.u2InputStatus == MoniAC_InputStatus_AC) &&
					(psInput->ptMoniAC->nFlag.u16Bits.u1Dropout == FALSE) &&
					(psInput->nFault.u16All == 0) &&
					(GET_MOMIDC_VBULK_RealInstant > 3800))
				{
					//ATS relay turn off at zero cross
					if (SwitchTiming(MoniAC_RelayOFFZC, (eMoniACTag_t)psInput->eTag))
					{
						psInput->eSwitchState = ATSSwitch_StaticOff;
					}
				}
				else
				{
					//ATS relay turn off immediately
					psInput->eSwitchState = ATSSwitch_StaticOff;
				}
			}
			
			psInput->u16ElapsedTime = 0; //clear ElapsedTime

			break;

		default:
			break;

	}

	if (psInput->u16ElapsedTime < Q15_)
	{
		psInput->u16ElapsedTime ++;
	}	
}

/****************************************************************************
*	Brief	ATS OFF
*	Note	1. no any valid input
*	        2. In Timer0 10kHz ISR
****************************************************************************/
static inline void ATS_OFF(void)
{	
	if (tsATS.ePreState != tsATS.eState)
	{
		tsATS.ePreState = tsATS.eState;
	}

	// startup delay for hall sensor finished calibration
	if (tsATS.nFlag.u16Bits.u1StartUp)
	{
		if ((tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u2Health) ||
	   		(tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u2Health))
		{
			tsATS.eState = ATS_State_Operating;
		}
	}
}

/****************************************************************************
*	Brief	ATS Normal Operating
*	Note	In Timer0 10kHz ISR
****************************************************************************/
static void ATS_Operating(void)
{
	if (tsATS.ePreState != tsATS.eState)
	{
		tsATS.ePreState = tsATS.eState;
		tsATS.eATSstate = ATSStatus_Reset;
		tsATS.nFlag.u16Bits.u2ATSEnable = NoInput;
		tsATS.nFlag.u16Bits.u1RideThrough = FALSE;
	}

	if ((tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u2Health == HealthInValid) &&
	    (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u2Health == HealthInValid))
	{
		if (tsATS.eATSstate == ATSStatus_Reset)
		{
			tsATS.eState = ATS_State_Off;
		}
	}

    switch (tsATS.eATSstate)
	{
		case ATSStatus_Reset:
			ATS_Reset();
			break;
		
		case ATSStatus_Switch:
			ATS_Switching();
			break;
			
		case ATSStatus_Pri:
			ATS_Primary();
			break;

		case ATSStatus_Sec:
			ATS_Secondary();
			break;

		case ATSStatus_BBU:
			ATS_BBU();
			break;
			
		default:
			break;
	}

	// Ride Through function
	if (tsATS.nFlag.u16Bits.u1RideThrough)
	{
		ATS_RideThrough();
	}
	else if (tsATS.nFlag.u16Bits.u1RideThrough_Action)
	{
		tsATS.nFlag.u16Bits.u1RideThrough_Action = FALSE;
		tsATS.nFlag.u16Bits.u1BulkCalimode = FALSE;
		tsATS.nFlag.u16Bits.u1ExtendRideThrough = FALSE;
		tsATS.sTimer.u32RideThroughTimeOut = Default_RideThroughTimeOut;
		tsATS.sTimer.u32RideThroughCNT = 0;
	}

	ATS_UpdateSourceRole();
	ATS_Manager(tsATS.ptSource[ATS_SourceTag_Primary]);
	ATS_Manager(tsATS.ptSource[ATS_SourceTag_Secondary]);
}

/****************************************************************************
*	Brief	ATS Suspend
*	Note	1. ATS read to boot code, stop here
*	        2. In Timer0 10kHz ISR
****************************************************************************/
static inline void ATS_Suspend(void)
{
	if (tsATS.ePreState != tsATS.eState)
	{
		tsATS.ePreState = tsATS.eState;
	}
}

/****************************************************************************
*	Brief	Automatic Transfer Switch state machine
*	Note	In Timer0 10kHz ISR
****************************************************************************/
void ATS_Handler(void)
{
	Check_Input_Valid();
	Check_Prefer_Source();
	
	switch (tsATS.eState)
	{
		case ATS_State_Off:
			ATS_OFF();
		break;

		case ATS_State_Operating:
			ATS_Operating();
		break;

		case ATS_State_Suspend:
			ATS_Suspend();
		break;
	
		default:
		break;
	}
}

/***************************************************************************
*   brief  ATS start up delay in 1ms loop
*   note   1. ATS startup count for hall sensor doing calibration
*          2. at 1ms while loop
****************************************************************************/
static inline void ATS_Start_Up_Delay(void)
{

#ifdef EnableATSFunction

	if (tsATS.nFlag.u16Bits.u1StartUp == FALSE)
	{
		if (tsATS.sTimer.u16StartUp_Dealy < ATS_Start_up_delay)
		{
			tsATS.sTimer.u16StartUp_Dealy ++;
		}
		else
		{
			tsATS.nFlag.u16Bits.u1StartUp = TRUE;
			tsATS.sTimer.u16StartUp_Dealy = 0;
		}
	}
	
#endif
}

/***************************************************************************
*   brief  ATS LED GREEN Handler
*   note   1. Displays LED indicators according to input source apply
*          2. LED blinking means AC source is good , but ATS relay is not connected
****************************************************************************/
static void ATS_LED_GREEN_Handler(sATSManager_t* ptSource)
{
	if (ptSource->nFlag.u16Bits.u1Apply)
	{
		LED_SetState(ptSource->psACLED, LED_SOLID_GREEN);
	}
	else
	{
		LED_SetState(ptSource->psACLED, LED_BLINKING_GREEN);
	}
}

/***************************************************************************
*   brief  ATS LED Sub Handler
*   note   Displays LED indicators according to input source health
****************************************************************************/
static void ATS_LED_Sub_Handler(void)
{
	u16_t i;

    for (i=0; i<ATS_InputTag_Num; i++)
    {
        if (tsATS.tsInput[i].nFlag.u16Bits.u1Valid == TRUE)
        {
            ATS_LED_GREEN_Handler(&tsATS.tsInput[i]);
        }
        else if ((tsATS.tsInput[i].ptMoniAC->nFlag.u16Bits.u1Dropout) &&
			     (tsATS.tsInput[i].ptMoniAC->sConfig.sDropout.eTriggerType == TriggerAutoRecover))
        {
        	LED_SetState(tsATS.tsInput[i].psACLED, LED_STATIC_OFF);    
        }
        else
        {
            LED_SetState(tsATS.tsInput[i].psACLED, LED_SOLID_ORANGE);
        }
    }
}

/***************************************************************************
*   brief  ATS LED Handler in 1ms loop
*   note   1. Change LED indicator according to single feed mode value
*          2. at 1ms while loop
****************************************************************************/
static inline void ATS_LED_Handler(void)
{
	if (tsATS.sContr.u8SINGLE_FEED_MODE == SIGNAL_INPUT_SOURCE)
	{
		if ((tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Valid == TRUE) &&
			(tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Valid == FALSE))
		{
			ATS_LED_GREEN_Handler(&tsATS.tsInput[ATS_InputTag_Input1]);
			LED_SetState(tsATS.tsInput[ATS_InputTag_Input2].psACLED, LED_STATIC_OFF);
		}
		else if ((tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Valid == FALSE) &&
				 (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Valid == TRUE))
		{
			LED_SetState(tsATS.tsInput[ATS_InputTag_Input1].psACLED, LED_STATIC_OFF);
			ATS_LED_GREEN_Handler(&tsATS.tsInput[ATS_InputTag_Input2]);
		}
		else
		{
			ATS_LED_Sub_Handler();
		}
	}
	else
	{
		ATS_LED_Sub_Handler();
	}
}

/***************************************************************************
*   brief  ATS 1ms periodically process
*   note   
****************************************************************************/
void ATS_1ms_Periodically_Process(void)
{
	ATS_Start_Up_Delay();
	ATS_LED_Handler();
}

/***************************************************************************
*   brief  ATS 100ms periodically process
*   note   1. For BS1(1) and BS2(1) used
*          2. 34.5s pass "u1ForceD2DOn" to D2D clear transition by ModBus
*          3. 35s "D2D_EN" enable
****************************************************************************/
void ATS_100ms_Periodically_Process(void)
{
    if ((tsATS.sTimer.u16WalkinTime_Out > WalkTimeOut) &&
        (tsATS.sTimer.u16WalkinTime_Out < WalkTimeOut_Default))
    {
        if (GET_LOG_BBUMode_Valid == 0)
        {
            tsATS.sTimer.u16WalkinTime_Out = WalkTimeOut;
        }
        else
        {
            Delay((u32_t*)&tsATS.sTimer.u16WalkinTime_Out);
            tsATS.sTimer.u16WalkinTime_Out_DefaultCNT = 0;
        }
    }
    else if (tsATS.sTimer.u16WalkinTime_Out <= WalkTimeOut)
    {
        if (tsATS.sTimer.u16WalkinTime_Out_DefaultCNT < WalkTimeOut_Delay_CNT)
        {
            tsATS.sTimer.u16WalkinTime_Out_DefaultCNT ++;
            tsLog.nStatus_Transition.u8Bits.u1ForceD2DOn = TRUE;
        }
        else
        {
            tsATS.sTimer.u16WalkinTime_Out = WalkTimeOut_Default;
            tsATS.sContr.u8Force_D2DOn = TRUE;
            tsLog.nStatus_Transition.u8Bits.u1ForceD2DOn = FALSE;
        }
    }

    /* Debug ATS state machine used */
//    Debug_1 = (u32_t)tsATS.sTimer.u32WalkinTime;
//    Debug_2 = (u32_t)tsATS.nFlag.u16Bits.u2ATSEnable;
//    Debug_2 = (u32_t)tsATS.sTimer.u16WalkinTime_Out;
//    Debug_3 = (u32_t)tsATS.sTimer.sVar.u32OutageDelay;
//    Debug_4 = (u32_t)tsATS.sTimer.sVar.u32StabilizationDelay;
}

/***************************************************************************
*   brief  ATS 1s periodically process
*   note   Relay fault recovery
****************************************************************************/
void ATS_1s_Periodically_Process(void)
{
    u8_t i;
	u8_t u8FaultCNT_Max = 0;


    for (i=0; i<ATS_InputTag_Num; i++)
    {
    	// Relay open
    	if ((tsATS.tsInput[i].nFault.u16Bits.u1RealyOpen == TRUE) &&
			(tsATS.tsInput[i].u8RelayOpen_FaultCNT <= GET_LOG_FAULT_COUNT_LIMIT))
    	{
    		if (tsATS.tsInput[i].u8RelayOpen_RecoveryCNT != 0)
    		{
    		 	tsATS.tsInput[i].u8RelayOpen_RecoveryCNT --;
    		}
			else
			{
				tsATS.tsInput[i].nFault.u16Bits.u1RealyOpen = 0;
				tsATS.tsInput[i].u16RelayOpen_CNT = 0;
				tsATS.tsInput[i].u16RelayOpen_FaultCNT_RecoveryCNT = 0;
				tsATS.tsInput[i].u8RelayOpen_RecoveryCNT = GET_LOG_FAULT_DELAY;
			}
    	}
		else if ((tsATS.tsInput[i].nFault.u16Bits.u1RealyOpen == TRUE) &&
				 (tsATS.tsInput[i].u8RelayOpen_FaultCNT > GET_LOG_FAULT_COUNT_LIMIT))
		{
			if (tsATS.tsInput[i].u16RelayOpen_FaultCNT_RecoveryCNT < 3600)	//1hr
			{
				tsATS.tsInput[i].u16RelayOpen_FaultCNT_RecoveryCNT ++;
			}
			else
			{
				tsATS.tsInput[i].nFault.u16Bits.u1RealyOpen = 0;
				tsATS.tsInput[i].u16RelayOpen_CNT = 0;
				tsATS.tsInput[i].u16RelayOpen_FaultCNT_RecoveryCNT = 0;
				tsATS.tsInput[i].u8RelayOpen_FaultCNT = 0;
				tsATS.tsInput[i].u8RelayOpen_RecoveryCNT = GET_LOG_FAULT_DELAY;	
			}
		}

		// Relay short
		if ((tsATS.tsInput[i].nFault.u16Bits.u1RealyShort == TRUE) &&
			(tsATS.tsInput[i].u8RelayShort_FaultCNT <= GET_LOG_FAULT_COUNT_LIMIT))
    	{
    		if (tsATS.tsInput[i].u8RelayShort_RecoveryCNT != 0)
    		{
    		 	tsATS.tsInput[i].u8RelayShort_RecoveryCNT --;
    		}
			else
			{
				tsATS.tsInput[i].nFault.u16Bits.u1RealyShort = 0;
				tsATS.tsInput[i].u16RelayShort_CNT = 0;
				tsATS.tsInput[i].u16RelayShort_FaultCNT_RecoveryCNT = 0;
				tsATS.tsInput[i].u8RelayShort_RecoveryCNT = GET_LOG_FAULT_DELAY;
			}
    	}
		else if ((tsATS.tsInput[i].nFault.u16Bits.u1RealyShort == TRUE) &&
				 (tsATS.tsInput[i].u8RelayShort_FaultCNT > GET_LOG_FAULT_COUNT_LIMIT))
		{
			if (tsATS.tsInput[i].u16RelayShort_FaultCNT_RecoveryCNT < 3600)	//1hr
			{
				tsATS.tsInput[i].u16RelayShort_FaultCNT_RecoveryCNT ++;
			}
			else
			{
				tsATS.tsInput[i].nFault.u16Bits.u1RealyShort = 0;
				tsATS.tsInput[i].u16RelayShort_CNT = 0;
				tsATS.tsInput[i].u16RelayShort_FaultCNT_RecoveryCNT = 0;
				tsATS.tsInput[i].u8RelayShort_FaultCNT = 0;
				tsATS.tsInput[i].u8RelayShort_RecoveryCNT = GET_LOG_FAULT_DELAY;
			}
		}

		// update fault count maximum
		if (u8FaultCNT_Max < tsATS.tsInput[i].u8RelayOpen_FaultCNT)
		{
			u8FaultCNT_Max = tsATS.tsInput[i].u8RelayOpen_FaultCNT;
		}

		if (u8FaultCNT_Max < tsATS.tsInput[i].u8RelayShort_FaultCNT)
		{
			u8FaultCNT_Max = tsATS.tsInput[i].u8RelayShort_FaultCNT;
		}
    }
	
	GET_LOG_FAULT_COUNT = u8FaultCNT_Max;
}

/***************************************************************************
*   brief  Update Stabilization delay time
*   note   
****************************************************************************/
void Update_StabilizationDelay(void)
{
	tsATS.sTimer.sVar.u32StabilizationDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u16StabilizationDelay;
}

/***************************************************************************
*   brief  Update Observe window delay time
*   note   
****************************************************************************/
void Update_ObserveWindow(void)
{
	tsATS.sTimer.sVar.u32ObserveWindow = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8ObserveWindow;
	tsATS.sTimer.u16InputReadyTime = 10000 * ((u16_t)tsATS.sTimer.sConst.u8ObserveWindow + 1);
}

/***************************************************************************
*   brief  Update Outage delaytime
*   note   
****************************************************************************/
void Update_OutageDelay(void)
{
	tsATS.sTimer.sVar.u32OutageDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8OutageDelay;
}

/***************************************************************************
*   brief  Update random number limit
*   note   
****************************************************************************/
void Update_Random_Number_Range(void)
{
	tsATS.sTimer.u32RandomTime_Range = ((u32_t)tsATS.sTimer.u8WalkinHigh - (u32_t)tsATS.sTimer.u8WalkinLow) * 1000;
}

/***************************************************************************
*   brief  PSU plug out, shut down all of switching then MCU restart
*   note   
****************************************************************************/
void PSUPlugOut(void)
{
	// Turn off PFC
	PeriEPwm_PFC_Disable();
	SET_PFC_Volt_State = PFC_VOLT_State_Reset;
	SET_PFC_Curr_State = PFC_CURR_State_Reset;
	SET_PFC_State = PFC_State_Off;	
	SET_GPIO_D2D_DIS;
	SET_PFC(PFCDisable);

	// Turn off ATS
	tsATS.nFlag.u16Bits.u1StartUp = 0;
	tsATS.ptApply = NULL;
	tsATS.eState = ATS_State_Off;
	tsATS.eATSstate = ATSStatus_Reset;
	tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Apply = 0;
	tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Apply = 0;
	tsATS.tsInput[ATS_InputTag_Input1].eSwitchState = ATSSwitch_StaticOff;
	tsATS.tsInput[ATS_InputTag_Input2].eSwitchState = ATSSwitch_StaticOff;
	TurnOffAllSwitch(tsATS.ptSource[ATS_SourceTag_Primary]);
	TurnOffAllSwitch(tsATS.ptSource[ATS_SourceTag_Secondary]);
	
	/*
	Peripheral_Stop();
	
	ServiceDog();	// Reset the watchdog counter

	EALLOW;
	WdRegs.WDCR.all = 0x0028;	// Enable the watchdog 0x0028
	EDIS;
	
	while(1) {}	//delay 12ms and then MCU restart
	*/
}

/***************************************************************************
*   brief  Ready to enter boot/APP mode
*   note   
****************************************************************************/
u16_t Is_Ready_to_Switch(void)
{
	tsATS.eState = ATS_State_Suspend;
	SET_PFC_State = PFC_State_Off;
	SET_PFC_Volt_State = PFC_VOLT_State_Reset;
	SET_PFC_Curr_State = PFC_CURR_State_Reset;
	PeriEPwm_PFC_Disable();
	SET_PFC(PFCDisable);
	
	return TRUE;
}

/***************************************************************************
*   brief  ATS Initialize
*   note   Only be executed when MCU power on
****************************************************************************/
void ATS_Initialize(void)
{
	u16_t u16Srand;
	memset(&tsATS, 0, sizeof(tsATS));
	tsATS.eState = ATS_State_Off;
	tsATS.eATSstate = ATSStatus_Reset;

	tsATS.sContr.u8PreferSource_PSC = SET_PREFER_SOURCE;
	tsATS.sContr.u8PreferSource = tsATS.sContr.u8PreferSource_PSC;
	tsATS.sContr.u8SINGLE_FEED_MODE = DEFAULT_SINGLE_FEED_MODE;

	tsATS.sTimer.u8WalkinLow = DEFAULT_WALKIN_DELAY_TIME_LOW;
	tsATS.sTimer.u8WalkinHigh = DEFAULT_WALKIN_DELAY_TIME_HIGH;
	tsATS.sTimer.u32RandomTime_Range = ((u32_t)tsATS.sTimer.u8WalkinHigh - (u32_t)tsATS.sTimer.u8WalkinLow) * 1000;
	tsATS.sTimer.u32RideThroughTimeOut = Default_RideThroughTimeOut;
	tsATS.sTimer.sConst.u8ObserveWindow = DEFAULT_OBSERVE_DELAY_TIME;
	tsATS.sTimer.sConst.u16StabilizationDelay = DEFAULT_STABILIZATION_DELAY_TIME;
	tsATS.sTimer.sConst.u8OutageDelay = DEFAULT_OUTAGE_DELAY_TIME;
	tsATS.sTimer.sConst.u8ReturnDelay = DEFAULT_RETURN_DELAY_TIME;
	tsATS.sTimer.sVar.u32ObserveWindow = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8ObserveWindow;
	tsATS.sTimer.sVar.u32StabilizationDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u16StabilizationDelay; // When ATS source is S2 now and S1 also valid keep 300s then source will do Walkin-time turn to S1
	tsATS.sTimer.sVar.u32OutageDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8OutageDelay;
	tsATS.sTimer.sVar.u32ReturnDelay = T_100usToSec * (u32_t)tsATS.sTimer.sConst.u8ReturnDelay;
    tsATS.sTimer.u16InputReadyTime =  (u16_t)(10000 * ((f32_t)tsATS.sTimer.sConst.u8ObserveWindow + (f32_t)0.1));

	tsATS.tsInput[ATS_InputTag_Input1].eTag = ATS_InputTag_Input1;
	tsATS.tsInput[ATS_InputTag_Input1].ptSwitch[ATS_SwitchTag_ATSRelay] = GetSwitchDriverRef(SwitchDriver_Tag_ATS_Relay1);
	tsATS.tsInput[ATS_InputTag_Input1].ptSwitch[ATS_SwitchTag_InrushRelay] = GetSwitchDriverRef(SwitchDriver_Tag_PFC_Relay);
	tsATS.tsInput[ATS_InputTag_Input1].ptSwitch[ATS_SwitchTag_InrushIGBT] = GetSwitchDriverRef(SwitchDriver_Tag_PFC_IGBT);
	tsATS.tsInput[ATS_InputTag_Input1].ptMoniAC = GetMoniACRef(MoniAC_Tag_VAC1);
	tsATS.tsInput[ATS_InputTag_Input1].psACLED = GetLedRef(LED_Tag_AC1);

	tsATS.tsInput[ATS_InputTag_Input2].eTag = ATS_InputTag_Input2;
	tsATS.tsInput[ATS_InputTag_Input2].ptSwitch[ATS_SwitchTag_ATSRelay] = GetSwitchDriverRef(SwitchDriver_Tag_ATS_Relay2);
	tsATS.tsInput[ATS_InputTag_Input2].ptSwitch[ATS_SwitchTag_InrushRelay] = GetSwitchDriverRef(SwitchDriver_Tag_PFC_Relay);
	tsATS.tsInput[ATS_InputTag_Input2].ptSwitch[ATS_SwitchTag_InrushIGBT] = GetSwitchDriverRef(SwitchDriver_Tag_PFC_IGBT);
	tsATS.tsInput[ATS_InputTag_Input2].ptMoniAC = GetMoniACRef(MoniAC_Tag_VAC2);
	tsATS.tsInput[ATS_InputTag_Input2].psACLED = GetLedRef(LED_Tag_AC2);

	if (tsATS.sContr.u8PreferSource == ATS_ApplySourceis1)
	{
		tsATS.ptSource[ATS_SourceTag_Primary] = &tsATS.tsInput[ATS_InputTag_Input1];
		tsATS.ptSource[ATS_SourceTag_Secondary] = &tsATS.tsInput[ATS_InputTag_Input2];
	}
	else
	{
		tsATS.ptSource[ATS_SourceTag_Primary] = &tsATS.tsInput[ATS_InputTag_Input2];
		tsATS.ptSource[ATS_SourceTag_Secondary] = &tsATS.tsInput[ATS_InputTag_Input1];
	}

	// srand from calibration value
	u16Srand = (u16_t)(GET_LOG_TOT_WORK_TIME & 0xffff);
	srand(tsATS.tsInput[ATS_InputTag_Input1].ptMoniAC->psCali->u16Slope ^ u16Srand);
    tsATS.sTimer.u16WalkinTime_Out = WalkTimeOut_Default; // 0xFFFF means no walking time
    tsATS.sContr.u8Force_D2DOn = TRUE;
}


/****************************************************************************
*	End of Function
****************************************************************************/

