/****************************************************************************
 *	File	Monitor_DC.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/25 - 1st release
 ****************************************************************************/

#ifndef _MONITOR_DC_H
#define	_MONITOR_DC_H

#include "CONFIG_Define.h"
#include "SERV_Threshold.h"
#include "SERV_Calibration.h"

/****************************************************************************
*	Public parameter definition
****************************************************************************/

#define MOMIDC_CLEAR_FAULT				(0x0001)

#define GET_MOMIDC_VBULK_OVP			tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1OVP
#define GET_MOMIDC_VBULK_OVW            tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1OVW
#define GET_MOMIDC_VBULK_UVP			tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1UVP
#define GET_MOMIDC_VBULK_UVW            tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1UVW
#define GET_MOMIDC_VBULK_GOOD           tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1Good


#define GET_MOMIDC_VAUX1_GOOD			tsMoniDC[MoniDC_Tag_VAux1].nFlag.u16Bits.u1Good
#define GET_MOMIDC_VAUX1_OVP			tsMoniDC[MoniDC_Tag_VAux1].nFlag.u16Bits.u1OVP
#define GET_MOMIDC_VAUX1_UVP			tsMoniDC[MoniDC_Tag_VAux1].nFlag.u16Bits.u1UVP

#define GET_MOMIDC_VAUX2_GOOD			tsMoniDC[MoniDC_Tag_VAux2].nFlag.u16Bits.u1Good
#define GET_MOMIDC_VAUX2_OVP			tsMoniDC[MoniDC_Tag_VAux2].nFlag.u16Bits.u1OVP
#define GET_MOMIDC_VAUX2_UVP			tsMoniDC[MoniDC_Tag_VAux2].nFlag.u16Bits.u1UVP

#define GET_MOMIDC_VBULK_FLAG			tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16All
#define GET_MOMIDC_VAUX1_FLAG			tsMoniDC[MoniDC_Tag_VAux1].nFlag.u16All
#define GET_MOMIDC_VAUX2_FLAG			tsMoniDC[MoniDC_Tag_VAux2].nFlag.u16All


#define SET_MOMIDC_VBULK_CALI			UpdateMoniDCCalibration(MoniDC_Tag_Vbulk)
#define SET_MOMIDC_VAUX1_CALI			UpdateMoniDCCalibration(MoniDC_Tag_VAux1)
#define SET_MOMIDC_VAUX2_CALI			UpdateMoniDCCalibration(MoniDC_Tag_VAux2)

#define CLEAR_MOMIDC_VBULK_OVP			MoniDC_Clear_Vbulk_OVFault()
//#define CLEAR_MOMIDC_VBULK_UVP		MoniDC_Clear_Vbulk_UVFault()
#define CHECK_MOMIDC_VBULK_UVP			MoniDC_Check_Vbulk_UVFault()

#define GET_MOMIDC_VBULK_RealInstant    tsMoniDC[MoniDC_Tag_Vbulk].u16RealInstant
#define GET_MOMIDC_VBULK_REALRMS_WF		tsMoniDC[MoniDC_Tag_Vbulk].u16RealRMS_WF

#define GET_MOMIDC_VAUX1_REALRMS_WF		tsMoniDC[MoniDC_Tag_VAux1].u16RealRMS_WF
#define GET_MOMIDC_VAUX2_REALRMS_WF		tsMoniDC[MoniDC_Tag_VAux2].u16RealRMS_WF

#define GET_MOMIDC_IAUX1_REALRMS_WF		tsMoniDC[MoniDC_Tag_VAux1].u16CurrentRMS
#define GET_MOMIDC_IAUX2_REALRMS_WF		tsMoniDC[MoniDC_Tag_VAux2].u16CurrentRMS



// For Fault injection

#define SET_MOMIDC_VAUX1_OVP_Latch		tsMoniDC[MoniDC_Tag_VAux1].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerLatch
#define SET_MOMIDC_VAUX1_OVP_Clear		tsMoniDC[MoniDC_Tag_VAux1].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover

#define SET_MOMIDC_VAUX2_OVP_Latch		tsMoniDC[MoniDC_Tag_VAux2].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerLatch
#define SET_MOMIDC_VAUX2_OVP_Clear		tsMoniDC[MoniDC_Tag_VAux2].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover

// VBulk Fault Injection
#define SET_MOMIDC_VBULK_FIJ            tsMoniDC[MoniDC_Tag_Vbulk].nFlag.u16Bits.u1FIJ

#define SET_MOMIDC_VBULK_OVP_Latch		tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerLatch
#define SET_MOMIDC_VBULK_OVP_Clear		tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sOVP.nTriggerType.u16Bits.u2ProtectEnable = TriggerAutoRecover

#define SET_MOMIDC_VBULK_UVP_Latch      tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sUVP.eTriggerType = TriggerLatch
#define SET_MOMIDC_VBULK_UVP_Clear      tsMoniDC[MoniDC_Tag_Vbulk].sConfig.sUVP.eTriggerType = TriggerAutoRecover

// Get VBulk OVP & UVP count
#define GET_MOMIDC_VBULK_OVP_Count      tsMoniDC[MoniDC_Tag_Vbulk].u16OVP_CNT
#define GET_MOMIDC_VBULK_UVP_Count      tsMoniDC[MoniDC_Tag_Vbulk].u16UVP_CNT



/****************************************************************************
*	Public macro definition
****************************************************************************/

/****************************************************************************
*	Public enumeration definition 
****************************************************************************/

typedef enum
{
	MoniDC_Tag_Vbulk = 0,
	MoniDC_Tag_VAux1,
	MoniDC_Tag_VAux2,
	MoniDC_Tag_Num
}eMoniDCTag_t;


typedef enum
{
	MoniDC_Type_VBulk,
	MoniDC_Type_VAux,
}eMoniDCType_t;

/****************************************************************************
*	Public structure definition 
****************************************************************************/

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1Good 				: 1;
		u16_t u1OVP 				: 1;
		u16_t u1OVW 				: 1;
		u16_t u1UVP					: 1;
		u16_t u1UVW					: 1;
		u16_t u1OCP					: 1;
		u16_t u1OCW					: 1;
		u16_t u1FIJ 				: 1;
        u16_t uReserved             : 8;
	}u16Bits;
}nMoniDCFlag_t;

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1FirstPresent		: 1;	// first time into present, no used
		u16_t uReserved				: 15;
	}u16Bits;
}nMoniDCStatus_t;


typedef struct
{
	sBetweenThreshold_t sSourceGood;
	sDualThreshold_t	sOVP;
    sSingleThreshold_t  sOVW;
	sSingleThreshold_t 	sUVP;
    sSingleThreshold_t  sUVW;
}sMoniDCConfig_t;


typedef struct
{
	eMoniDCTag_t eTag;				// Source report identifier
	eMoniDCType_t eType;			// Identifier Voltage or Current
	nMoniDCFlag_t nFlag;			// Monitor Flag
	nMoniDCStatus_t nStatus;		// Monitor Status
	sMoniDCConfig_t sConfig;		// Monitor Configuration
	sCaliCoeff_t* psCali;           // measure calibration

	/* Key Variable */
	u16_t* pu16ADC_Q12;				// ADC Q12 input value from SERV_ADCFilter
	u16_t  u16RealInstant;			// Unit is 0.1V/A
	u16_t  u16RealRMS_WF;			// Unit is 0.1V/A, VBulk OPV1, for reporting
	u16_t* pu16ADC1_Q12;			// ADC Q12 input value from SERV_ADCFilter
	u16_t  u16RealInstant1;			// Unit is 0.1V/A
    u16_t  u16RealRMS_WF1;          // Unit is 0.1V/A, VBulk detect
	u16_t* pu16ADC2_Q12;			// ADC Q12 input value from SERV_ADCFilter
	u16_t  u16RealInstant2;			// Unit is 0.1V/A
    u16_t  u16RealRMS_WF2;          // Unit is 0.1V/A, VBulk OPV2
	u16_t  u16CurrentRMS;			// only for IAux1/2 report used, default 0A

    /* VBulk OVP & UVP count */
	u16_t u16OVP_CNT;               // VBulk OVP count
	u16_t u16UVP_CNT;               // VBulk UVP count

	/* Constant */
	f32_t f32Cali_Gain;				// Calibration Gain
	f32_t f32Cali_Offset;			// Calibration Offset
}sMoniDC_t;


/****************************************************************************
*	Public export variable
****************************************************************************/
extern sMoniDC_t tsMoniDC[MoniDC_Tag_Num];

/****************************************************************************
*	Public export function prototype
****************************************************************************/
extern void MoniDC_Initialize(void);
extern sMoniDC_t* GetMoniDCRef(eMoniDCTag_t eTag);
extern void UpdateMoniDCCalibration(eMoniDCTag_t eTag);
extern void MoniDC_10ms_Periodically_Process(void);
extern void MoniDC_1ms_Periodically_Process(void);
extern void MoniDC_Clear_Vbulk_OVFault(void);
//extern void MoniDC_Clear_Vbulk_UVFault(void);
extern void MoniDC_Check_Vbulk_UVFault(void);



#endif
