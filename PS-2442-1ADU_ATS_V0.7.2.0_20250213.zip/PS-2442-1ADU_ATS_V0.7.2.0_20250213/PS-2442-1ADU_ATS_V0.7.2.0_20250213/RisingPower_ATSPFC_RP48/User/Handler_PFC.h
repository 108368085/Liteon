/****************************************************************************
 *	File	Handler_PFC.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/09 - 1st release
 ****************************************************************************/


#ifndef _HANDLER_PFC_H_
#define _HANDLER_PFC_H_


#include "CONFIG_Define.h"
#include "Monitor_AC.h"
#include "SERV_SwitchDriver.h"


/****************************************************************************
*	Public parameter definition
****************************************************************************/
#define IS_PFC_INRUSH_IGBT_ON		tsPFC.nSFlag.u16Bits.u1InrushIGBTOn


// CBC config
#ifdef Enable20AHallSensor

    #define PFC_CBC_Current_Limit       22  //22A per phase, unit is 1A
    #define PFC_CBC_HIGH                (Q11_ + (u16_t)(((f32_t)PFC_CBC_Current_Limit / 50) * Q12_))    //40A:100, 20A:50
    #define PFC_CBC_Low                 (Q11_ - (u16_t)(((f32_t)PFC_CBC_Current_Limit / 50) * Q12_))    //40A:100, 20A:50

#else 

/* For 4.2KW */
//#define PFC_CBC_Current_Limit     30  //30A per phase, unit is 1A
//#define PFC_CBC_HIGH              (Q11_ + (u16_t)(((f32_t)PFC_CBC_Current_Limit / 100) * Q12_))   //40A:100, 20A:50
//#define PFC_CBC_Low               (Q11_ - (u16_t)(((f32_t)PFC_CBC_Current_Limit / 100) * Q12_))   //40A:100, 20A:50

/* For 4.4KW */
    #define Sensitivity1                (f32_t)0.033 // ACS733KLATR-40AB-T Sensitivity , unit is 0.02  mV/A
    #define Sensitivity2                (f32_t)0.02  // ACS733KLATR-65AB-T Sensitivity , unit is 0.033 mV/A
    #define PFC_CBC_Current_Limit       (f32_t)40    // 40A per phase, unit is 1A
    #define PFC_CBC_HIGH                (Q11_ + (u16_t)(Sensitivity1 * PFC_CBC_Current_Limit * 1241.21))
    #define PFC_CBC_Low                 (Q11_ - (u16_t)(Sensitivity1 * PFC_CBC_Current_Limit * 1241.21))

#endif



#define SET_PFC_State				tsPFC.eState
#define SET_PFC_Volt_State			tsPFC.eVoltState
#define SET_PFC_Curr_State			tsPFC.eCurrState

#define GET_PFC_PROT_FLAG			tsPFC.nPFlag.u16All
#define SET_PFC_A_CBC				tsPFC.nPFlag.u16Bits.u1PFC_phase_A_CBC = 1
#define SET_PFC_B_CBC				tsPFC.nPFlag.u16Bits.u1PFC_phase_B_CBC = 1

#define GET_PFC_ENABLE				tsPFC.nSFlag.u16Bits.u1PFC_Enable
#define GET_PFC_INRUSH_RELAY_ON		tsPFC.nSFlag.u16Bits.u1InrushRealyOn

#define GET_PFC_FAULT				tsPFC.nSFlag.u16Bits.u1PFC_Fault


// For Fault injection

#define GET_PFC_PTC_FAULT			tsPFC.nPFlag.u16Bits.u1PTC_Fault
#define SET_PFC_PTC_FAULT_Latch		tsPFC.nPFlag.u16Bits.u1PTC_Fault = 1
#define SET_PFC_PTC_FAULT_Clear		tsPFC.nPFlag.u16Bits.u1PTC_Fault = 0

#define GET_PFC_SS_FAULT			tsPFC.nPFlag.u16Bits.u1SoftStart_Fail
#define SET_PFC_SS_FAULT_Latch		tsPFC.nPFlag.u16Bits.u1SoftStart_Fail = 1
#define SET_PFC_SS_FAULT_Clear		tsPFC.nPFlag.u16Bits.u1SoftStart_Fail = 0

#define GET_PFC_RELAY_FAULT			tsPFC.nPFlag.u16Bits.u1PFC_Relay_Fail
#define SET_PFC_RELAY_FAULT_Latch	tsPFC.nPFlag.u16Bits.u1PFC_Relay_Fail = 1
#define SET_PFC_RELAY_FAULT_Clear	tsPFC.nPFlag.u16Bits.u1PFC_Relay_Fail = 0

#define GET_PFC_PI_KEY				0xAA552301
#define SET_PFC_PI_KEY				tsPFC.sConfigPara.u32PI_Control_Key
#define GET_PFC_V_KP				tsPFC.sVOLT_PI.u32KP_L
#define GET_PFC_V_KI				tsPFC.sVOLT_PI.u32KITS_L
#define GET_PFC_V_KP_2              tsPFC.sVOLT_PI.u32KP_H    //Error>20V
#define GET_PFC_V_KI_2              tsPFC.sVOLT_PI.u32KITS_H  //Error>20V
#define GET_PFC_I_KP				tsPFC.sCURR_PI.u32KP_H   //u32KP_H
#define GET_PFC_I_KI				tsPFC.sCURR_PI.u32KITS_L //u32KITS_L
#define GET_PFC_DUTY_FEED_SHIFT		tsPFC.sConfigPara.u32Duty_feedward_shift
#define GET_PFC_FEEDWARD_GAIN       tsPFC.sConfigPara.u16Report_feedward_Gain
#define GET_PFC_V_PIOUT				tsPFC.sVOLT_PI.i32PIout
#define GET_PFC_KPKILevel           tsPFC.sConPara.u32DynamicKPKILevel
#define GET_PFC_VBULK_H             tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15
#define GET_PFC_VBULK_M             tsPFC.sConfigPara.u16VBulkRef_Limit_M_Q15
#define GET_PFC_VBULK_L             tsPFC.sConfigPara.u16VBulkRef_Limit_L_Q15
#define GET_PFC_VBULK_LL            tsPFC.sConfigPara.u16VBulkRef_Limit_MIN_Q15
#define GET_PFC_VBULK_442V          tsPFC.sConfigPara.u16VBulkRef_442V_Q15
#define GET_PFC_Freq                tsPFC.sPFCRara.u16VinFreq


#define GET_PFC_SoftStart_Count          tsPFC.sConPara.u16Const_SyncRectifierTurnOnDelay
#define GET_PFC_Normal_Phase             tsPFC.sConPara.u16Report_Normal_Phase_Change
#define GET_PFC_SoftStart_Phase          tsPFC.sConPara.u16Report_SoftStart_Phase_Change
#define GET_PFC_SoftStart_IntegralGain   tsPFC.sCURR_PI.u32Const_IntegralGain
#define GET_PFC_SoftStart_Iref           tsPFC.sConPara.u16Const_SoftStartIref

/****************************************************************************
*	Public macro definition
****************************************************************************/

/****************************************************************************
*	Public enumeration definition 
****************************************************************************/

typedef enum
{
	PFC_State_Off = 1,
	PFC_State_PTC,
	PFC_State_IGBTOn,
	PFC_State_Softstart,
    PFC_State_Operating,
    PFC_State_Suspend,
    PFC_State_Vbulk_SlewRate,
}ePFCState_t;

typedef enum
{
	PFC_VOLT_State_Reset = 1,
	PFC_VOLT_State_Operating,
}ePFC_Volt_State_t;

typedef enum
{
	PFC_CURR_State_Reset = 1,
	PFC_CURR_State_Operating,
}ePFC_Curr_State_t;

typedef enum
{
    PFC_CURRENT_LOOP_1 = 1,
    PFC_CURRENT_LOOP_2,
    PFC_VOLTAGE_LOOP,
}eCalculation_Type_t;

typedef enum
{
	PFC_CBC_A = 0,
	PFC_CBC_B,
}ePFC_CBC_Event_t;

/****************************************************************************
*	Public structure definition 
****************************************************************************/

typedef union
{
	u16_t u16All;	
	struct
	{
		u16_t u1PFC_Enable		    : 1;	// 0:PFC Disable , 1:PFC Enable, ATS to PFC, enable PFC
		u16_t u1PFC_OK		    	: 1;	// 0:PFC NOT OK , 1:PFC OK, PFC at operation mode(Vbulk OK)
		u16_t u2PFC_Vin_Status	    : 2;	// 0:NA , 1:AC input, 2:DC input, 3:input loss
		u16_t u1Vin_Polarity	    : 1;	// 1:Positive polarity ; 0:Negative polarity
		u16_t u1VoltagePIFast		: 1;	// 0:slow , 1:fast
		u16_t u1VoltagePIRequest_AC : 1;	// 0:do nothing, 1:Need to do Voltage PI control
		u16_t u1VoltagePIRequest_1K : 1;	// 0:do nothing, 1:Need to do Voltage PI control

		u16_t u2PFC_Polarity 		: 2;	// 0:DeadZone, 1:Positive, 2:Negative
		u16_t u1InrushIGBTOn		: 1;	// 0:Inrush IGBT off, 1:Inrush IGBT on
		u16_t u1InrushRealyOn		: 1;	// 0:Inrush relay off, 1:Inrush relay on
		u16_t u1SinglePFC			: 1;	// 0:Interleaved PFC, 1:single PFC (phase A) while light Load
		u16_t u1PFC_Fault			: 1;	// 0:PFC not failure, 1:PFC device fault, PFC to ATS, turn off ATS
		u16_t u1PFC_Vpeak_Ready		: 1;	// 0:PFC Vpeak not ready, 1:PFC Vpeak ready
        u16_t u1PFC_Vbulk_SlewRate  : 1;    //
	}u16Bits;
}nPFC_State_Flag_t;

typedef union
{
	u16_t u16All;	
	struct
	{
		u16_t u1PTC_Fault	    	: 1;	//10s auto recovery
		u16_t u1SoftStart_Fail		: 1;	//10s auto recovery
		u16_t u1PFC_Relay_Fail	    : 1;	//PFC inrush relay fail for fault injection, 10min PTC or softstart retry fail will into latch mode
		u16_t u1Vbulk_OV		    : 1;	//From MoniDC, 10s auto recovery
		u16_t u1Vbulk_UV		    : 1;	//From MoniDC, auto recovery	
		u16_t u1PFC_OCP			    : 1;	//PFC RMS current protect, auto recovery
		u16_t u1PFC_phase_A_CBC	    : 1;	//CBC protection flag, Reserved
		u16_t u1PFC_phase_B_CBC	    : 1;	//CBC protection flag, Reserved
		
		u16_t u1Inlet_UTP	    	: 1;	//auto recovery
		u16_t u1Inlet_OTP	    	: 1;	//auto recovery
		u16_t u1PFC_UTP			    : 1;	//auto recovery
		u16_t u1PFC_OTP			    : 1;	//auto recovery
		u16_t u1ATS_UTP	    		: 1;	//auto recovery
		u16_t u1ATS_OTP	    		: 1;	//auto recovery
        u16_t u1SinglePhase_OCP     : 1;
		u16_t Reserved				: 1;
	}u16Bits;
}nPFC_Protect_Flag_t;


typedef struct
{
	u16_t* 	pu16Vin_nnn_Q12;		//ADC input from SERV_ADCFilter
	i16_t* 	pi16Vin_sin_Q12;		//ADC input from SERV_ADCFilter
	u16_t* 	pu16IinA_nnn_Q12;		//ADC input from SERV_ADCFilter
	i16_t* 	pi16IinA_sin_Q12;		//ADC input from SERV_ADCFilter
	u16_t* 	pu16IinB_nnn_Q12;		//ADC input from SERV_ADCFilter
	i16_t* 	pi16IinB_sin_Q12;		//ADC input from SERV_ADCFilter
	u16_t* 	pu16Vbulk_DET_Q12;		//ADC input from SERV_ADCFilter
	u16_t 	u16VinRMS;				//RMS value from MoniAC unit is 0.1V
	u16_t 	u16Vinpeak_Q15;			//Vac peak value from MoniAC ATS per half cycle
	u16_t 	u16Vbulk_DET_Q15;		//pu16Vbulk_DET_Q12  << 3
    u16_t   u16Vbulk_DET_NOF_Q15;   //pu16ADCInstant_Q12 << 3
	u16_t 	u16Vbulk_DET_ZC_Q15;	//Saving Vulk value when AC zero cross
	u16_t 	u16Vbulk_Ref_Q15;		//Bulkacp Reference voltage for softstart
	u16_t 	u16Vbulk_Target_Q15;	//Bulkacp target Reference voltage for operation
	u16_t 	u16VinFreq;				//Vac freq, unit is 0.1Hz
	u16_t 	u16VPFC_Peak_Ready_CNT;	//VPFC peak ready count
}sPFC_Parameter_t;


typedef struct
{
    u16_t   u16PTC_ChargeTime_CNT;      //PTC
    u16_t   u16PTC_SustainedTime_CNT;
    u16_t   u16PTC_Fault_Recovery_CNT;
    u16_t   u16SS_RisingTime_CNT;       //SoftStart
    u16_t   u16SS_RisingStep_Volt;
    u16_t   u16SS_Fault_Recovery_CNT;
    u16_t   u16UV_Fault_Recovery_CNT;   //Bulk UV fault
    u16_t   u16OV_Fault_Recovery_CNT;   //Bulk OV fault
    u16_t   u16PWMEnableCNT;            //Prevent PWM not enable

    u16_t   u16SoftStart_Duty_Control;
    u64_t   u16Report_SoftStart_Phase_Change;
    u64_t   u16Report_Normal_Phase_Change;
    u16_t   u16Const_SyncRectifierTurnOnDelay;
    u16_t   u16SyncRectifierTurnOnDelay;

    u16_t   u16Const_SoftStartIref;
    u16_t   u16SoftStartIref;
    u16_t   u16EnablePFCDelay;          // unit is 0.1ms
    u16_t   u16PFCRelayFaultCNT;
    u16_t   u16BBUMode_Turnoff_CNT;     // unit is 0.1ms, set point is 60ms
    u16_t   u16VrefLoadLevel;           // 1: min, 2:L , 3:M , 4: H, 5:max
    u16_t   u16VrefVinLevel;            // 1: VinRMS < VacLevel_L, 2:VinRMS > VacLevel_H
    u32_t   u32DynamicKPKILevel;        // 0,1,2....10
    u16_t   u16FrequencyLevel;          // 1:50KHz , 0:40KHz
    u16_t   u16Suspend_CNT;             // PFC in Suspend mode during 2s, go back to off mode
    i32_t   i32IXcapCompensate;         //Compensate current of Xcap
}sControl_Parameter_t;


typedef struct
{
    u16_t   u16VBulkRef_Limit_MAX_Q15;
    u16_t   u16VBulkRef_Limit_H_Q15;
    u16_t   u16VBulkRef_Limit_M_Q15;
    u16_t   u16VBulkRef_Limit_L_Q15;
    u16_t   u16VBulkRef_SlewRate_Q15;
    u16_t   u16VBulkRef_420V_Q15;
    u16_t   u16VBulkRef_438V_Q15;
    u16_t   u16VBulkRef_439V_Q15;
    u16_t   u16VBulkRef_442V_Q15;
    u16_t   u16VBulkRef_Limit_MIN_Q15;
    u16_t   u16PTC_Target_differ_Voltage; // Target is 70V
    u16_t   u16VBulkshort_Limit_L_Q15;
    u16_t   u16VBulk_5V_Q15;
    u16_t   u16VBulk_10V_Q15;
    u16_t   u16VBulk_20V_Q15;
    u16_t   u16VBulk_35V_Q15;
    u16_t   u16VBulk_470V_Q15;              // For ITIC 200% used
    f32_t   f32DynamicBulkVG;               //Dynamic Bulk Voltage gain
    f32_t   f32DynamicBulkVG_DC;            //Dynamic Bulk Voltage gain for DC input
    f32_t   f32DynamicBulkIG;               //Dynamic Bulk Current gain
    f32_t   f32DynamicBulkPG;               //Dynamic Bulk Power gain
    u16_t   u16Vacpeak_10V_THRESHOLD_Q15;
    u16_t   u16Vacpeak_20V_THRESHOLD_Q15;
    u16_t   u16Vacpeak_THRESHOLD_H_Q15;
    u16_t   u16Vacpeak_THRESHOLD_L_Q15;
    i16_t   i16Iacpeak_Poslimit;
    i16_t   i16Iacpeak_Neglimit;
    i32_t   i32Iacpeak_Lightload_L;
    i32_t   i32Iacpeak_Lightload_H;
    u32_t   u32Iac_Sense_OCP;
    i32_t   i32Xcap_Currentadjust;
    f32_t   f32XcapCompensate;
    i16_t   i16PhaseChange_V_Pos_Q15;
    i16_t   i16PhaseChange_V_Neg_Q15;

    i16_t   i16PhaseChange_SoftStart_V_Pos_Q15;
    i16_t   i16PhaseChange_SoftStart_V_Neg_Q15;

    u32_t   u32Duty_feedward_shift;
    f32_t   f32Duty_feedward_Gain;          // 1.03 > 1 backward, <1 forward
    u16_t   u16Report_feedward_Gain;        // For Report Duty Gain , unit is 0.01
    u32_t   u32PI_Control_Key;
    f32_t   f32BUS_FS;
    f32_t   f32PFC_FS;
    f32_t   f32IAC_FS;
    f32_t   f32PFC_to_BUS;

    /* Variable Frequency */
    u16_t   u16HighFreq;
    u16_t   u16LowFreq;
}sConfig_Parameter_t;


typedef struct
{
    eCalculation_Type_t eType;
    u32_t u32KP;                //Q15
    u32_t u32KITS;              //Q20
    i32_t i32Ref;               //Q15 Voltage Vref is Vbulk Q15, Current Vref is Iref Q15
    i32_t i32Error;             //Q15
    i32_t i32ErrorPre;          //Q15 Previously Error
    i32_t i32Integral;          //Q30
    i32_t i32IntegralPre;       //Q30 Previously Integral
    i32_t i32IntegralGain;      //Q30 integral gain for zero cross soft start
    u32_t u32Const_IntegralGain;//Q30 Const integral gain for zero cross soft start
    f32_t f32Integral_Poslimit; //Q30
    f32_t f32Integral_Neglimit; //Q30
    i32_t i32PIout;             //Q16
    f32_t f32PIout_Poslimit;    //Q30
    f32_t f32PIout_Neglimit;    //Q30
    u16_t u16AdjustGain_H;      //Q15
    u16_t u16AdjustGain_L;      //Q15
    u32_t u32KP_SS;             //Q15 for softstart
    u32_t u32KP_H;              //Q15
    u32_t u32KP_L;              //Q15
    u32_t u32KITS_SS;           //Q20 for softstart
    u32_t u32KITS_H;            //Q20
    u32_t u32KITS_L;            //Q20
}sPI_Parameter_t;


typedef struct
{
	ePFCState_t eState;					// Current state
	ePFCState_t ePreState;				// Previously state
	ePFC_Volt_State_t eVoltState;
	ePFC_Volt_State_t ePreVoltState;
	ePFC_Curr_State_t eCurrState;
	ePFC_Curr_State_t ePreCurrState;
	nPFC_State_Flag_t nSFlag;
	nPFC_Protect_Flag_t nPFlag;
	sPFC_Parameter_t sPFCRara;			// key Variable
	sControl_Parameter_t sConPara;		// Variable
	sConfig_Parameter_t sConfigPara;	// Constant
	sPI_Parameter_t sVOLT_PI;
	sPI_Parameter_t sCURR_PI;
	sPI_Parameter_t sCURR2_PI;
	sSwitchDriver_t* psPFCRelay;
	sSwitchDriver_t* psPFCIGBT;
}sPFC_t;



/****************************************************************************
*	Public export variable
****************************************************************************/
extern sPFC_t tsPFC;


/****************************************************************************
*	Public export function prototype
****************************************************************************/
extern void PFC_Initialize(void);
extern void PFC_Handler(void);
extern void PFC_PI_V_KP(u8_t u8Action);
extern void PFC_PI_V_KI(u8_t u8Action);
extern void PFC_PI_I_KP(u8_t u8Action);
extern void PFC_PI_I_KI(u8_t u8Action);
extern void PFC_PI_Duty_Feed_Shift(u8_t u8Action);
extern void PFC_PI_Duty_Feed_Gain(u8_t u8Action);
extern void PFC_VBULK_Adjust(u8_t u8Action);
extern void PFC_Voltage_Loop_Handler(void);
extern void PFC_Current_Loop_Handler(void);
extern void PFC_1s_Periodically_Process(void);
extern void PFC_1ms_Periodically_Process(void);
extern void PFC_10ms_Periodically_Process(void);

extern void PFC_SoftStart_Count(u8_t u8Action);
extern void PFC_Normal_Change_Phase(u8_t u8Action);
extern void PFC_SoftStart_Change_Phase(u8_t u8Action);
extern void PFC_Adjust_Iref_IntegralGain(u8_t u8Action);
extern void PFC_Adjust_Iref_Gain(u8_t u8Action);


#endif /* HANDLER_PFC_H_ */
