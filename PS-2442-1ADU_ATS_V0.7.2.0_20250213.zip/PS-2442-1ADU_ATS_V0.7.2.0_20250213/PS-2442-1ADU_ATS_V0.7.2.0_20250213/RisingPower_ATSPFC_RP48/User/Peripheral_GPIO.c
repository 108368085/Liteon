/****************************************************************************
 *	File	Peripheral_GPIO.c
 * 	Brief	Configure and control GPIO module on TI 28004x platform
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

/****************************************************************************
*	Included Files
****************************************************************************/

#include "F28x_Project.h"
#include "Peripheral_GPIO.h"


/****************************************************************************
    Private parameter definition
****************************************************************************/


//Input Pins
#define PIN_PSU_NOT_IN_SHELF		GPIO_PIN_40

//Output Pins
#define PIN_EEPROM_EN				GPIO_PIN_25
#define PIN_D2D_EN					GPIO_PIN_58	//change
#define PIN_DEBUG1					GPIO_PIN_56
#define PIN_DEBUG2					GPIO_PIN_57
#define PIN_AC2_OFF					GPIO_PIN_32	//change
#define PIN_AC1_OFF					GPIO_PIN_24	//change
#define PIN_AC1_RELAY_EN			GPIO_PIN_39
#define PIN_AC1_24V_DIS				GPIO_PIN_59
#define PIN_BBU_ACTIVE				GPIO_PIN_34
#define PIN_AC2_RELAY_EN			GPIO_PIN_6
#define PIN_AC2_24V_DIS				GPIO_PIN_29


/****************************************************************************
	Private macro definition
****************************************************************************/

#define CONFIG_GPIO_OUTPUT(GPIOPin, DefaultState)                 			\
        do                                                                  \
        {                                                                   \
            GPIO_SetupPinMux(GPIOPin, GPIO_MUX_CPU1, 0);                   	\
            GPIO_SetupPinOptions(GPIOPin, GPIO_OUTPUT, GPIO_PUSHPULL);     	\
            GPIO_WritePin(GPIOPin, DefaultState);       					\
        }while(0)


/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

/****************************************************************************
	Private variable declaration
****************************************************************************/
sPeriGPIO_t ptsGPIOs[eGPIO_Num] =
{
//  Pin Name       			GPIO PIN Number			Default state		I/O Direction           
    {eGPIO_EEPROM_EN, 		PIN_EEPROM_EN,        	GPIO_PIN_SET,		GPIO_Output},
	{eGPIO_D2D_EN,			PIN_D2D_EN,				GPIO_PIN_CLEAR,		GPIO_Output},
	{eGPIO_Debug_1, 		PIN_DEBUG1,        		GPIO_PIN_CLEAR,		GPIO_Output},
	{eGPIO_Debug_2, 		PIN_DEBUG2,        		GPIO_PIN_CLEAR,		GPIO_Output},
	{eGPIO_AC2_OFF, 		PIN_AC2_OFF,        	GPIO_PIN_SET,		GPIO_Output},
	{eGPIO_AC1_OFF, 		PIN_AC1_OFF,        	GPIO_PIN_SET,		GPIO_Output},
	{eGPIO_AC1_RELAY_EN, 	PIN_AC1_RELAY_EN,       GPIO_PIN_CLEAR,		GPIO_Output},
	{eGPIO_AC1_24V_DIS, 	PIN_AC1_24V_DIS,        GPIO_PIN_SET,		GPIO_Output},
	{eGPIO_BBU_ACTIVE, 		PIN_BBU_ACTIVE,        	GPIO_PIN_CLEAR,		GPIO_Output},
	{eGPIO_AC2_RELAY_EN,	PIN_AC2_RELAY_EN,		GPIO_PIN_CLEAR,		GPIO_Output},
	{eGPIO_AC2_24V_DIS, 	PIN_AC2_24V_DIS,        GPIO_PIN_SET,		GPIO_Output},
	{eGPIO_PSU_NOT_Inshelf, PIN_PSU_NOT_IN_SHELF,   GPIO_PIN_CLEAR,		GPIO_Input},
};


/**
 *  @brief  Get pin State of target pin
 *  @param  psGPIO: Which GPIO is attempted to get its State
 *  @retval Pin state of target pin
 */
ePeriGPIO_PinState_t PeriGPIO_GetState(sPeriGPIO_t* psGPIO)
{
    /* use the example function of platform */
    return (ePeriGPIO_PinState_t)GPIO_ReadPin(psGPIO->u16Pin);
}

/**
 *  @brief  Get GPIO reference
 *  @param  eTag: Which pin is attempted to get its reference
 *  @retval None
 */
sPeriGPIO_t* PeriGPIO_GetPin(ePeriGPIO_Pin_Tag_t eTag)
{
    return &ptsGPIOs[eTag];
}

/**
 *  @brief  Set target pin state to high
 *  @param  psGPIO: Which GPIO is attempted to set to high 
 *  @retval None
 */
void PeriGPIO_SetState(sPeriGPIO_t* psGPIO)
{
    /* use the example function of platform */
    GPIO_WritePin(psGPIO->u16Pin , 1);
	psGPIO->eState = GPIO_PIN_SET;
}

/**
 *  @brief  Set target pin state to low
 *  @param  psGPIO: Which GPIO is attempted to set to low
 *  @retval None
 */
void PeriGPIO_ClearState(sPeriGPIO_t* psGPIO)
{
    /* use the example function of platform */
    GPIO_WritePin(psGPIO->u16Pin, 0);
	psGPIO->eState = GPIO_PIN_CLEAR;
}

void PeriGPIO_ToggleState(sPeriGPIO_t* psGPIO)
{
    volatile u32_t *gpioDataReg;
    u32_t pinMask;
    gpioDataReg = (volatile u32_t *)&GpioDataRegs + (psGPIO->u16Pin/32)*GPY_DATA_OFFSET;
    pinMask = 1UL << (psGPIO->u16Pin % 32);
    gpioDataReg[GPYTOGGLE] = pinMask;

	/* Up date GPIO state */
	if (psGPIO->eState == GPIO_PIN_CLEAR)
	{
		psGPIO->eState = GPIO_PIN_SET;
	}
	else
	{
		psGPIO->eState = GPIO_PIN_CLEAR;
	}
}

/**
 *  @brief  GPIO Initialize
 *  @retval None
 */
void PeriGPIO_Initialize(void)
{
	u16_t i;

	InitGpio();

	//
	// Configure Input Pins for general purpose
	//
	
	// PSU_NOT_In_shelf
	GPIO_SetupPinMux(ptsGPIOs[eGPIO_PSU_NOT_Inshelf].u16Pin, GPIO_MUX_CPU1, 0);
    GPIO_SetupPinOptions(ptsGPIOs[eGPIO_PSU_NOT_Inshelf].u16Pin, GPIO_INPUT, GPIO_QUAL3 | GPIO_PULLUP | GPIO_QUAL6);

	//sampling Period = 2x50x(SYSCLK cycles 10ns) = 1us
	GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 = 0x32; //Qualification sampling period for GPIO40 to GPIO47

	//
	// Configure Output Pins for general purpose
	//

    for (i=0; i<(eGPIO_Num -1); i++)	//For Output setting
    {
        CONFIG_GPIO_OUTPUT(ptsGPIOs[i].u16Pin, ptsGPIOs[i].eState);
    }

}

