/** @file       SERV_Threshold.c
 *  @author     Adonis Wang
 *  @brief      This module is used to protection flag threshold
 *  @version    1.0
 *  @date       
 */

#include "SERV_Threshold.h"


/****************************************************************************
	Private marco definition 
****************************************************************************/

/****************************************************************************
	Private enumeration definition
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 69
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Delay, ".TI.ramfunc");
#pragma CODE_SECTION(Single_Threshold, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declare
****************************************************************************/

/****************************************************************************
	Public variable declare
****************************************************************************/



/***************************************************************************
*   brief  Delay method
*   note   
****************************************************************************/
static u16_t Delay(u16_t* u16Delay)
{
	if (*u16Delay == 0)
	{
		return 1;
	}
	else
	{
		*u16Delay -= 1;
		return 0;
	}
}

/***************************************************************************
*   brief  Single Threshold 
*   note   
****************************************************************************/
void Single_Threshold(sSingleThreshold_t *psConfig, i16_t i16Value, u16_t *u16Flag)
{
	if (psConfig->eTriggerType == TriggerDisable)
	{
		*u16Flag &= (~psConfig->u16SetBits);	//Clear bit
		psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
		psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
	}
	else
	{
		// Upper Limit
		if (psConfig->eLimitType == Limit_Upper)
		{
			// Assert Flag
			if (i16Value > psConfig->i16SetThreshold) 
			{		 
				if (Delay(&psConfig->sVar.u16SetDelay))
				{
					*u16Flag |= psConfig->u16SetBits;	//Set bit
				}
			
				psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
			}
			// Deassert Flag
			else if (i16Value < psConfig->i16ClearThreshold)
			{
				if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
					(psConfig->eTriggerType == TriggerAutoRecover)) 	
				{
					*u16Flag &= (~psConfig->u16SetBits);	//Clear bit
				}
			
				psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
			}
		}
		// Lower Limit
		else
		{
			// Assert Flag
			if (i16Value < psConfig->i16SetThreshold) 
			{		 
				if (Delay(&psConfig->sVar.u16SetDelay))
				{
					*u16Flag |= psConfig->u16SetBits;	//Set bit
				}
			
				psConfig->sVar.u16ClearDelay = psConfig->sConst.u16ClearDelay;
			}
			// Deassert Flag
			else if (i16Value > psConfig->i16ClearThreshold)
			{
				if ((Delay(&psConfig->sVar.u16ClearDelay)) &&
					(psConfig->eTriggerType == TriggerAutoRecover)) 	
				{
					*u16Flag &= (~psConfig->u16SetBits);	//Clear bit
				}
			
				psConfig->sVar.u16SetDelay = psConfig->sConst.u16SetDelay;
			}
		}
	}
}




