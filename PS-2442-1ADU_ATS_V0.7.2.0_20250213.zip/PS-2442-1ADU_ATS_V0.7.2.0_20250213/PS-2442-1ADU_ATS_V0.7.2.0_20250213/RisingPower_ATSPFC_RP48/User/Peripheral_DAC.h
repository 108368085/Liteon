/****************************************************************************
 *	File	Peripheral_DAC.h
 * 	Brief	Header file for Peripheral DAC module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/
 
#ifndef _PERIPHERAL_DAC_H_
#define _PERIPHERAL_DAC_H_

#include "CONFIG_Define.h"

/****************************************************************************
    Public parameter definition
****************************************************************************/

/****************************************************************************
	Public macro definition
****************************************************************************/
#define PERI_DAC_0V0		0
#define PERI_DAC_0V5       	621
#define PERI_DAC_1V0       	1241
#define PERI_DAC_1V5       	1861
#define PERI_DAC_2V0       	2482
#define PERI_DAC_2V5       	3103
#define PERI_DAC_3V0       	3723
#define PERI_DAC_3V3       	4095

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/

extern void PeriDac_Initialize(void);
extern void PeriDac_Start(void);
extern void PeriDac_Stop(void);
extern void PeriDacA_SetValue(u16_t u16Value);
extern void PeriDacB_SetValue(u16_t u16Value);

#endif
