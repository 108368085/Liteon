/****************************************************************************
 *	File	Peripheral_CpuTimer.h
 * 	Brief	Header file for Peripheral CpuTimer module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/
 
#ifndef _PERIPHERAL_CPU_TIMER_H_
#define _PERIPHERAL_CPU_TIMER_H_

#include "CONFIG_Define.h"
#include "Peripheral.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/
#define CPU_TIMER_CLOCK_BASE			1000000UL  	// 1MHz, Unit is Hz
#define CPU_TIMER_10KHz_FREQUENCY       10000       // Unit is Hz
#define CPU_TIMER_1KHz_FREQUENCY        1000        // Unit is Hz

#define CPU_TIMER_FREQUENCY_IN_MHZ		SYS_CLK_OUT / CPU_TIMER_CLOCK_BASE  // Unit is MHz

/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void PeriCpuTimer_Initialize(void);
extern void PeriCpuTimer_Start(void);
extern void PeriCpuTimer_Stop(void);

#endif
