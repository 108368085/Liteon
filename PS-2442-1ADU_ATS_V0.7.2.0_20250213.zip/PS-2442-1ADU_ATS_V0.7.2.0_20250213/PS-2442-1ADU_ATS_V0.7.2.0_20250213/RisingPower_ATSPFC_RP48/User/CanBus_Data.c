/****************************************************************************
 *	File	CanBus_Data.c
 * 	Brief	CanBus Server Database
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 *	 History 2021/05/13 - 1st release
 ****************************************************************************/

/* Include header file of data owner */
#include <string.h>
#include <math.h>
#include "CONFIG_RisingPower.h"
#include "CANBus_Data.h"
#include "CANBus_Server.h"
#include "Monitor_AC.h"
#include "Monitor_DC.h"
#include "Monitor_TP.h"
#include "SERV_LOG.h"
#include "SERV_LED.h"
#include "SERV_FFT.h"
#include "SERV_Calibration.h"
#include "E2P_Data.h"
#include "E2P_BlackBox.h"
#include "E2P_Waveform.h"
#include "Handler_ATS.h"
#include "Handler_PFC.h"
#include "FLASH_IAP.h"



/****************************************************************************
	Private parameter definition
****************************************************************************/


/****************************************************************************
	Private macro definition
****************************************************************************/
#define CONFIG_LM(eTag, Gain, Source)                   								\
					do																	\
					{																	\
						ptsLiteralMonitor[eTag].sSource.pi16Reg = Source;				\
						ptsLiteralMonitor[eTag].sSource.u16Gain = Gain;					\
						ptsLiteralMonitor[eTag].i8Exponent = DYNAMIC_EXPONENT;			\
					}while(0)


#define CONFIG_GV(eTag, Size, Source)                   													\
					do																						\
					{																						\
						ptsGuardVarNode[eTag].sLocalTag.u16PrivyIdentifier = eTag;							\
						ptsGuardVarNode[eTag].pVar = Source;												\
						ptsGuardVarNode[eTag].u16VarSize = Size;											\
						ptsGuardVarNode[eTag].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler; 	\
						ptsGuardVarNode[eTag].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;	\
						GuardVarList_AppendNode(&ptsGuardVarList[eTag], &ptsGuardVarNode[eTag]);			\
					}while(0)

#define CONFIG_PD(eTag, Length, ARRAY, RdBuff, WrBuff)                   				\
					do																	\
					{																	\
						ptsCANBusPageData[eTag].u8Length = Length;						\
						ptsCANBusPageData[eTag].u8Array = ARRAY;						\
						ptsCANBusPageData[eTag].pu8ReadBuff = RdBuff;					\
						ptsCANBusPageData[eTag].psWriteBuff = WrBuff;					\
						ptsCANBusPageData[eTag].psNext = NULL;							\
					}while(0)

#define CONFIG_CMD(COMMTYPE, COMMCODE, PAGEDATA)  CANBusData_JoinPageData(CANBusData_GetCommandStructure(COMMTYPE, COMMCODE), &ptsCANBusPageData[PAGEDATA]);

#define CONFIG_BLACKBOX(eBlackBoxItemTag, eTag)   BlackBox_Initial_Item(eBlackBoxItemTag, ptsCANBusPageData[eTag].pu8ReadBuff)



/****************************************************************************
	Private enumeration definition
****************************************************************************/
enum
{
	eCANBusPageData_GET_VARIABLE,
	eCANBusPageData_SET_VARIABLE,
	eCANBusPageData_CLEAR_FAULTS,
	eCANBusPageData_COMPATIBILITY_NUMBER,
    eCANBusPageData_FAULT_RECOVERY,
	eCANBusPageData_CAN_TO_SEL,
	eCANBusPageData_STATUS_WORD,
	eCANBusPageData_STATUS_RELAY_S1,
	eCANBusPageData_STATUS_RELAY_S2,
	eCANBusPageData_STATUS_RELAY_PFC,
	eCANBusPageData_STATUS_TRANSFER,
	eCANBusPageData_STATUS_TEMP,
	eCANBusPageData_STATUS_OTHER,
	eCANBusPageData_STATUS_LED,
	eCANBusPageData_STATUS_ATS_SOURCE,
	eCANBusPageData_STATUS_CML,
	eCANBusPageData_STATUS_BOOTLOADER,
	eCANBusPageData_READ_VS1,
	eCANBusPageData_READ_VS2,
	eCANBusPageData_READ_VAC,
	eCANBusPageData_READ_IAC,
	eCANBusPageData_READ_FS1,
	eCANBusPageData_READ_FS2,
	eCANBusPageData_READ_PS1,
	eCANBusPageData_READ_PS2,
	eCANBusPageData_READ_MAXPS1,
	eCANBusPageData_READ_MAXPS2,
	eCANBusPageData_READ_AVGPS1,
	eCANBusPageData_READ_AVGPS2,
	eCANBusPageData_READ_TINLET,
	eCANBusPageData_READ_TATS,
	eCANBusPageData_READ_SWITCH_TIMES,
	eCANBusPageData_READ_TOTAL_SWITCH_TIMES,
    eCANBusPageData_READ_HARMONIC_ACK,
	eCANBusPageData_READ_VS1_HARMONIC,
	eCANBusPageData_READ_VS2_HARMONIC,
    eCANBusPageData_READ_HARMONIC_ACK_2,
    eCANBusPageData_READ_VS1_HARMONIC_2,
    eCANBusPageData_READ_VS2_HARMONIC_2,
	eCANBusPageData_READ_VAUX1,
	eCANBusPageData_READ_VAUX2,
	eCANBusPageData_READ_IAUX1,
	eCANBusPageData_READ_IAUX2,
	eCANBusPageData_READ_BBU_COUNT,
	eCANBusPageData_MAJOR_REVISION,
	eCANBusPageData_MINOR_REVISION,
	eCANBusPageData_BLACKBOX_READ_START,
	eCANBusPageData_BLACKBOX_READ_DATA,
	eCANBusPageData_BLACKBOX_READ_STOP,
	eCANBusPageData_WAVEFORM_TRIGGER,
	eCANBusPageData_WAVEFORM_READ_START,
	eCANBusPageData_WAVEFORM_READ_DATA,
	eCANBusPageData_WAVEFORM_READ_STOP,
	eCANBusPageData_FW_UPDATE_START,
	eCANBusPageData_FW_UPDATE_HEADER_START,
	eCANBusPageData_FW_UPDATE_HEADER_DATA,
	eCANBusPageData_FW_UPDATE_HEADER_STOP,
	eCANBusPageData_FW_UPDATE_BLOCK_START,
	eCANBusPageData_FW_UPDATE_BLOCK_DATA,
	eCANBusPageData_FW_UPDATE_BLOCK_STOP,
	eCANBusPageData_FW_UPDATE_STOP,
	eCANBusPageData_EDIT_STATUS_INPUT,
	eCANBusPageData_EDIT_STATUS_TEMP,
	eCANBusPageData_EDIT_STATUS_OTHER,
	eCANBusPageData_EDIT_TEMP,
    eCANBusPageData_EDIT_VBULK,
	eCANBusPageData_BMC_UNIX_TIMESTAMP,
	eCANBusPageData_ATS_PRI_SRC,
	eCANBusPageData_SINGLE_FEED_MODE,
	eCANBusPageData_OBSERVE_WINDOW,
	eCANBusPageData_OUTAGE_DELAY,
	eCANBusPageData_WALKIN_LOW,
	eCANBusPageData_WALKIN_HIGH,
	eCANBusPageData_STABILIZATION_DELAY,
	eCANBusPageData_BLACKBOX_PAGE,
	eCANBusPageData_WAVEFORM_PAGE,
	eCANBusPageData_REQ_BBU_NUMBER,
	eCANBusPageData_HEARTBEAT_TIMEOUT,
	eCANBusPageData_FAULT_COUNT,
	eCANBusPageData_FAULT_COUNT_LIMIT,
	eCANBusPageData_FAULT_DELAY,
	eCANBusPageData_NOMINAL_VOLGATE,
	eCANBusPageData_FACTORY_MODE,
	eCANBusPageData_CALIBRATION_KEY,
	eCANBusPageData_CALIBRATION_CLEAR,
	eCANBusPageData_CALIBRATION_STORE,
	eCANBusPageData_INTERNAL_DEBUGGER,
	eCANBusPageData_RESET_EEPROM_LOG,
	eCANBusPageData_INTERNAL_REVISION,
	eCANBusPageData_FW_RELEASE_DATE,
	eCANBusPageData_STATUS_PFC,
	eCANBusPageData_STATUS_PFC2D2D,
	eCANBusPageData_STATUS_D2D2PFC,
	eCANBusPageData_STATUS_INPUT,
	eCANBusPageData_READ_VBULK,
	eCANBusPageData_READ_POS_TOTAL,
	eCANBusPageData_READ_POS_LAST,
	eCANBusPageData_READ_TPFC,
	eCANBusPageData_READ_TD2D,
	eCANBusPageData_READ_VPFC,
	eCANBusPageData_READ_DEBUG_A,
	eCANBusPageData_READ_DEBUG_B,
	eCANBusPageData_READ_DEBUG_C,
	eCANBusPageData_READ_DEBUG_D,
	eCANBusPageData_CALI_VS1,
	eCANBusPageData_CALI_VS2,
	eCANBusPageData_CALI_VPFC,
	eCANBusPageData_CALI_VBULK,
	eCANBusPageData_CALI_IAC,
	eCANBusPageData_PI_KEY,
	eCANBusPageData_PI_V_KP,
	eCANBusPageData_PI_V_KI,
	eCANBusPageData_PI_I_KP,
	eCANBusPageData_PI_I_KI,
	eCANBusPageData_PI_D_F_S,
	eCANBusPageData_PI_V_PIOUT,
	eCANBusPageData_VBULK_REF,
	eCANBusPageData_Duty_feedward_Gain,
	eCANBusPageData_PFC_SoftStart_Count,
	eCANBusPageData_PFC_Normal_Change_Phase,
	eCANBusPageData_PFC_SoftStart_Change_Phase,
	eCANBusPageData_PFC_SoftStart_IntegralGain,
    eCANBusPageData_PFC_SoftStart_Iref,
    eCANBusPageData_BlackBox_Record_Harmonic1, //Only for BlackBox record S1 Harmonic
    eCANBusPageData_BlackBox_Record_Harmonic2, //Only for BlackBox record S2 Harmonic
	eCANBusPageData_Num,
};

//enum eCANBusLiteralMonitorEnumeration
//{
//	eCANBusData_LM_VS1,
//	eCANBusData_LM_VS2,
//	eCANBusData_LM_VAC,
//	eCANBusData_LM_IAC,
//	eCANBusData_LM_FS1,
//	eCANBusData_LM_FS2,
//	eCANBusData_LM_PS1,
//	eCANBusData_LM_PS2,
//	eCANBusData_LM_MAXPS1,
//	eCANBusData_LM_MAXPS2,
//	eCANBusData_LM_AVGPS1,
//	eCANBusData_LM_AVGPS2,
//	eCANBusData_LM_TINLET,
//	eCANBusData_LM_TATS,
//	eCANBusData_LM_VAUX1,
//	eCANBusData_LM_VAUX2,
//	eCANBusData_LM_IAUX1,
//	eCANBusData_LM_IAUX2,
//	eCANBusData_LM_VBULK,
//	eCANBusData_LM_TPFC,
//	eCANBusData_LM_TD2D,
//	eCANBusData_LM_VPFC,
//    eCANBusData_LM_Read_VS1_Harmonic,
//    eCANBusData_LM_Read_VS2_Harmonic,
//	eCANBusData_LM_Num,
//};

enum eCANBusDataGuardVar
{
	eCANBusData_GV_GET_VARIABLE,
	eCANBusData_GV_SET_VARIABLE,
	eCANBusData_GV_CLEAR_FAULTS,
    eCANBusData_GV_READ_HARMONIC_ACK,
    eCANBusData_GV_READ_HARMONIC_VS1,
	eCANBusData_GV_READ_HARMONIC_VS2,
    eCANBusData_GV_READ_HARMONIC_ACK_2,
    eCANBusData_GV_READ_HARMONIC_VS1_2,
    eCANBusData_GV_READ_HARMONIC_VS2_2,
	eCANBusData_GV_BLACKBOX_READ_START,
	eCANBusData_GV_BLACKBOX_READ_DATA,
	eCANBusData_GV_WAVEFORM_TRIGGER,
	eCANBusData_GV_WAVEFORM_READ_START,
	eCANBusData_GV_WAVEFORM_READ_DATA,
	eCANBusData_GV_FW_UPDATE_START,
	eCANBusData_GV_FW_UPDATE_HEADER_START,
	eCANBusData_GV_FW_UPDATE_HEADER_DATA,
	eCANBusData_GV_FW_UPDATE_HEADER_STOP,
	eCANBusData_GV_FW_UPDATE_BLOCK_START,
	eCANBusData_GV_FW_UPDATE_BLOCK_DATA,
	eCANBusData_GV_FW_UPDATE_BLOCK_STOP,
	eCANBusData_GV_FW_UPDATE_STOP,
	eCANBusData_GV_EDIT_STATUS_INPUT,
	eCANBusData_GV_EDIT_STATUS_TEMP,
	eCANBusData_GV_EDIT_STATUS_OTHER,
	eCANBusData_GV_EDIT_TEMP,
    eCANBusData_GV_EDIT_VBULK,
	eCANBusData_GV_BMC_UNIX_TIMESTAMP,
	eCANBusData_GV_ATS_PRI_SRC,
	eCANBusData_GV_SINGLE_FEED_MODE,
	eCANBusData_GV_OBSERVE_WINDOW,
	eCANBusData_GV_OUTAGE_DELAY,
	eCANBusData_GV_WALKIN_LOW,
	eCANBusData_GV_WALKIN_HIGH,
	eCANBusData_GV_STABILIZATION_DELAY,
	eCANBusData_GV_BLACKBOX_PAGE,
	eCANBusData_GV_WAVEFORM_PAGE,
	eCANBusData_GV_REQ_BBU_NUMBER,
	eCANBusData_GV_HEARTBEAT_TIMEOUT,
	eCANBusData_GV_FAULT_COUNT,
	eCANBusData_GV_FAULT_COUNT_LIMIT,
	eCANBusData_GV_FAULT_DELAY,
	eCANBusData_GV_NOMINAL_VOLTAGE,
	eCANBusData_GV_FACTORY_MODE,
	eCANBusData_GV_CALIBRATION_KEY,
	eCANBusData_GV_CALIBRATION_CLEAR,
	eCANBusData_GV_CALIBRATION_STORE,
	eCANBusData_GV_INTERNAL_DEBUGGER,
	eCANBusData_GV_RESET_EEPROM_LOG,
	eCANBusData_GV_CALIBRATION_VS1,
	eCANBusData_GV_CALIBRATION_VS2,
	eCANBusData_GV_CALIBRATION_VPFC,
	eCANBusData_GV_CALIBRATION_VBULK,
	eCANBusData_GV_CALIBRATION_IAC,
	eCANBusData_GV_PI_KEY,
	eCANBusData_GV_PI_V_KP,
	eCANBusData_GV_PI_V_KI,
	eCANBusData_GV_PI_I_KP,
	eCANBusData_GV_PI_I_KI,
	eCANBusData_GV_PI_D_F_S,
	eCANBusData_GV_PI_V_PIOUT,
	eCANBusData_GV_VBULK_REF,
	eCANBusData_GV_Duty_feedward_Gain,
    eCANBusData_GV_PFC_SoftStart_Count,
    eCANBusData_GV_PFC_Normal_Change_Phase,
    eCANBusData_GV_PFC_SoftStart_Change_Phase,
    eCANBusData_GV_PFC_SoftStart_IntegralGain,
    eCANBusData_GV_PFC_SoftStart_Iref,
	eCANBusData_GV_Num,
};

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 656 -> 104
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Real_To_Literal_11, ".TI.ramfunc");
#pragma CODE_SECTION(Literal_To_Real, ".TI.ramfunc");
//#pragma CODE_SECTION(LiteralMonitor_Update, ".TI.ramfunc");
#pragma CODE_SECTION(CANBusData_GetCommandStructure, ".TI.ramfunc");
//#pragma CODE_SECTION(GuardVarDataCheckRequestHandler, ".TI.ramfunc");
//#pragma CODE_SECTION(GuardVarDataWriteRequestHandler, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusData_10ms_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusData_Set_BlackBox_Data_Length, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusData_Set_Waveform_Data_Length, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declare
****************************************************************************/
// base on 20210412 file

u16_t u16LiternalCNT;		// liternal convert index

u16_t u16CANCommandCount;	//Record Command List number

u8_t pu8SensorData[eCANBUS_SENSOR_Num];		//Sensor data for polling

sCANBusCmdStr_t ptsCANBusCommandList[] =
{
//	Command Type					Command								Protocol					Page				Read	Write	Page Data
	{CANBUS_COMMTYPE_EMERGENCY,		CANBUS_CMD_AC_LOSS,					CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	0,		0,		NULL},
	{CANBUS_COMMTYPE_EMERGENCY,		CANBUS_CMD_DEVICE_FAIL,				CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_EMERGENCY,		CANBUS_CMD_AC_RECOVER,				CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	0,		0,		NULL},
	{CANBUS_COMMTYPE_NMT,			CANBUS_CMD_HEARTBEAT,				CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_NMT,			CANBUS_CMD_GET_VARIABLE,			CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	8,		1,		NULL},
	{CANBUS_COMMTYPE_NMT,			CANBUS_CMD_SET_VARIABLE,			CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	8,		8,		NULL},
	{CANBUS_COMMTYPE_NMT,			CANBUS_CMD_CLEAR_LATCHING_FAULTS,	CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		1,		NULL},
	{CANBUS_COMMTYPE_NMT,			CANBUS_CMD_COMPATIBILITY_NUMBER,	CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	1,		0,		NULL},
    {CANBUS_COMMTYPE_NMT,           CANBUS_CMD_FAULT_RECOVERY,          CANBUS_Protocol_Read,       CANBUS_One_PAGE,    3,      0,      NULL},
	{CANBUS_COMMTYPE_NMT,			CANBUS_CMD_CAN_TO_SEL,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	5,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_WORD,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_INPUT,			CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	3,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_TRANSFER,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_TEMP,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_OTHER,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_LED,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_ATS_SOURCE,		CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_CML,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_BOOTLOADER,		CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_VOLTAGE,			CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	6,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_CURRENT,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_FREQ,				CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER,				CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER_EXTRA,		CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	8,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_TEMP,				CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_ATS_SWITCH_TIMES,	CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	8,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_HARMONIC,			CANBUS_Protocol_WandR,		CANBUS_Multi_PAGE,	6,		1,		NULL},
    {CANBUS_COMMTYPE_SENSOR_DATA,   CANBUS_CMD_READ_HARMONIC_2,         CANBUS_Protocol_WandR,      CANBUS_Multi_PAGE,  6,      1,      NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_VOLTAGE_EXTRA,		CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_CURRENT_EXTRA,		CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_BBU_COUNT,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_FW_REVISION,		CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_BLOCK_READ,	CANBUS_CMD_BLACKBOX_READ_START,		CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	4,		2,		NULL},
	{CANBUS_COMMTYPE_BLOCK_READ,	CANBUS_CMD_BLACKBOX_READ_DATA,		CANBUS_Protocol_Write,		CANBUS_One_PAGE,	8,		0,		NULL},
	{CANBUS_COMMTYPE_BLOCK_READ,	CANBUS_CMD_BLACKBOX_READ_STOP,		CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_BLOCK_READ,	CANBUS_CMD_WAVEFORM_TRIGGER,		CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_BLOCK_READ,	CANBUS_CMD_WAVEFORM_READ_START,		CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	4,		2,		NULL},
	{CANBUS_COMMTYPE_BLOCK_READ,	CANBUS_CMD_WAVEFORM_READ_DATA,		CANBUS_Protocol_Write,		CANBUS_One_PAGE,	8,		0,		NULL},
	{CANBUS_COMMTYPE_BLOCK_READ,	CANBUS_CMD_WAVEFORM_READ_STOP,		CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE, 	CANBUS_CMD_FW_UPDATE_START, 		CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_HEADER_START,	CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		0,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_HEADER_DATA,	CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		8,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_HEADER_STOP,	CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_BLOCK_START,	CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		7,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_BLOCK_DATA,	CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		8,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_BLOCK_STOP,	CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_STOP,			CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		3,		NULL},	
	{CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_STATUS_INPUT,		CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		3,		NULL},
	{CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_STATUS_TEMP,		CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_STATUS_OTHER,		CANBUS_Protocol_WandR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_TEMP,				CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	1,		3,		NULL},
    {CANBUS_COMMTYPE_FAULTINJECT,   CANBUS_CMD_EDIT_VBulk,              CANBUS_Protocol_Write,      CANBUS_One_PAGE,    0,      1,      NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_BMC_UNIX_TIMESTAMP,		CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	4,		4,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_ATS_PRIMARY_SOURCE,		CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_SINGLE_FEED_MODE,		CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_OBSERVE_WINDOW,			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_OUTAGE_DELAY,			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_WALKIN_LOW,				CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_WALKIN_HIGH, 			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_STABILIZATION_DELAY, 	CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	2,		2,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_BLACKBOX_PAGE,			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_WAVEFORM_PAGE,			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_REQ_BBU_NUMBER,			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_HEARTBEAT_TIMEOUT,		CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_FAULT_COUNT,				CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_FAULT_COUNT_LIMIT,		CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_FAULT_DELAY,				CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_VARIABLE,      CANBUS_CMD_NOMINAL_VOLTAGE,         CANBUS_Protocol_WorR,       CANBUS_One_PAGE,    2,      2,      NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_FACTORY_MODE,			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	1,		1,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALIBRATION_KEY,			CANBUS_Protocol_WorR,		CANBUS_One_PAGE,	4,		4,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALIBRATION_CLEAR,		CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		1,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALIBRATION_STORE,		CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		1,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_INTERNAL_DEBUGGER,		CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		1,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_RESET_EEPROM_LOG,		CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		1,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_INTERNAL_REVISION,		CANBUS_Protocol_Read,		CANBUS_One_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_FW_RELEASE_DATE,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_PFC,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_PFC2D2D,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_D2D2PFC,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_INPUT_ATS,		CANBUS_Protocol_Read,		CANBUS_One_PAGE,	1,		0,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VS1,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VS2,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_IAC,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VBULK,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_POS_TOTAL,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	4,		0,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_POS_LAST,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	4,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_PFC_TEMP,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_D2D_TEMP,			CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VPFC,				CANBUS_Protocol_Read,		CANBUS_One_PAGE,	2,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_DEBUG_1,			CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	8,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_DEBUG_2,			CANBUS_Protocol_Read,		CANBUS_Multi_PAGE,	8,		0,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VS1,				CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		4,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VS2,				CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		4,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VPFC,				CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		4,		NULL},
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VBULK,				CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		4,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_IAC,				CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		4,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_KEY,					CANBUS_Protocol_Write,		CANBUS_One_PAGE,	0,		4,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_V_KP,					CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	4,		1,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_V_KI,					CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	4,		1,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_I_KP,					CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	4,		1,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_I_KI,					CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	4,		1,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_D_F_S,				CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	4,		1,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_V_PIOUT,				CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	4,		0,		NULL},	
	{CANBUS_COMMTYPE_MFR,			CANBUS_CMD_VBULK_REF,				CANBUS_Protocol_Broadcast,	CANBUS_One_PAGE,	2,		1,		NULL},
	{CANBUS_COMMTYPE_MFR,           CANBUS_CMD_Duty_feedward_Gain,      CANBUS_Protocol_Broadcast,  CANBUS_One_PAGE,    4,      1,      NULL},
    {CANBUS_COMMTYPE_MFR,           CANBUS_CMD_PFC_SoftStart_Count,     CANBUS_Protocol_Broadcast,  CANBUS_One_PAGE,    4,      1,      NULL},
    {CANBUS_COMMTYPE_MFR,           CANBUS_CMD_Nromal_Phase_Change,     CANBUS_Protocol_Broadcast,  CANBUS_One_PAGE,    4,      1,      NULL},
    {CANBUS_COMMTYPE_MFR,           CANBUS_CMD_SoftStart_Phase_Change,  CANBUS_Protocol_Broadcast,  CANBUS_One_PAGE,    4,      1,      NULL},
    {CANBUS_COMMTYPE_MFR,           CANBUS_CMD_SoftStart_IntegralGain,  CANBUS_Protocol_Broadcast,  CANBUS_One_PAGE,    4,      1,      NULL},
    {CANBUS_COMMTYPE_MFR,           CANBUS_CMD_SoftStart_Iref,          CANBUS_Protocol_Broadcast,  CANBUS_One_PAGE,    2,      1,      NULL},
    {CANBUS_COMMTYPE_MFR,           CANBUS_CMD_BlackBox_Record_Harmonic, CANBUS_Protocol_Read,      CANBUS_Multi_PAGE,  4,      0,      NULL},
};

sCANBusPageData_t ptsCANBusPageData[eCANBusPageData_Num];
sLiteralMonitor_t ptsLiteralMonitor[eCANBusData_LM_Num];
sGuardVarNode_t ptsGuardVarNode[eCANBusData_GV_Num];
sGuardVarList_t ptsGuardVarList[eCANBusData_GV_Num];


/****************************************************************************
	Public variable declare
****************************************************************************/


/**
 *  @brief  Convert value in real format to literal 11 format
 *  @note   In this function, mantissa is 11-bits.
 *  @param  i32Value: value in real format
 *  @param  i8Exponent: Static exponent value or "DYNAMIC_EXPONENT"
 *  @param  u16Gain: gain of value
 *  @retval value in literal format
 */
static u16_t Real_To_Literal_11(i32_t i32Value, i8_t i8Exponent, u16_t u16Gain)
{
    u16_t u16Literal = 0;
    i32_t i32MaxMantissa = (i32_t)1023L * u16Gain;
    i32_t i32MinMantissa = (i32_t)511L * u16Gain;
    i16_t i16Mantissa = 0;
    
    u8_t u8Negative = 0;
    
    if (i32Value == 0)
    {
        i8Exponent = 0;
    }
    else if (i8Exponent == DYNAMIC_EXPONENT)
    {
        i8Exponent = 0;

        if (i32Value < 0)
        {
            i32Value = abs(i32Value);
            u8Negative = 1;
        }
        
        /* Reduce large mantissa until it fits into specified mantissa bits */
        while ((i32Value >= i32MaxMantissa) && (i8Exponent < 15))
        {
            i32Value >>= 1;
            i8Exponent += 1;
        }
        
        /* Increase small mantissa to improve precision */
        while ((i32Value <= i32MinMantissa) && (i8Exponent > -15))
        {
            i32Value <<= 1;
            i8Exponent -= 1;
        }
    }
    

    /* Convert mantissa */
    i16Mantissa = i32Value / u16Gain;

    if (u8Negative)
    {
        i16Mantissa = -i16Mantissa;
    }

    u16Literal = i16Mantissa & 0x07FF;
    u16Literal |=  (i8Exponent << 11);

    return u16Literal;
}

/**
 *  @brief  Convert value in real format to literal 16 format
 *  @note   In this function, i8Exponent should be a static value
 *  @param  i32Value: value in real format
 *  @param  i8Exponent: static exponent
 *  @param  u16Gain: gain of value
 *  @retval value in literal format
 */

/*
static u16_t Real_To_Literal_16(i32_t i32Value, i8_t i8Exponent, u16_t u16Gain)
{
    // Convert mantissa
    if (i8Exponent > 0)
    {
        i32Value /= u16Gain;
    }
    else
    {
        i32Value = i32Value * (1 << abs(i8Exponent));
        i32Value /= u16Gain;
    }
    
    return (u16_t)(i32Value & 0xFFFF);
}
*/
 
/**
 *  @brief  Convert value in literal 11 format to real format
 *  @param  u16Literal: value in literal 11 format
 *  @param  u16Gain: gain of real value
 *  @retval value in real format
 */


i32_t Literal_To_Real(u16_t u16Literal, u16_t u16Gain)
{
    u16_t u16Exponent = (u16Literal & 0xF800) >> 11;
    i32_t i32Mantissa = (i32_t)(u16Literal & 0x07FF);
    i32_t i32RealValue;

    if (i32Mantissa & 0x0400)      //  value < 0
    {
        i32Mantissa = -((i32Mantissa ^ 0x7FF) + 1);
    }

    i32Mantissa *= u16Gain;

    if (u16Exponent & 0x10)
    {
        u16Exponent = ((u16Exponent ^ 0x1F) + 1);
        i32RealValue = i32Mantissa / (1 << u16Exponent);
    }
    else
    {
        i32RealValue = i32Mantissa * (1 << u16Exponent);
    }
    
    return i32RealValue;
}


/**
 *  @brief  Update literal monitor value
 *  @note   This function will updated its source in real format to literal format
 *  @param  psMonitor: Pointer to a sLiteralMonitor_t structure which is attempted to update
 *  @retval None
 */
void LiteralMonitor_Update(sLiteralMonitor_t* psMonitor)
{
    psMonitor->u16LiteralValue = Real_To_Literal_11(*psMonitor->sSource.pi16Reg, psMonitor->i8Exponent, psMonitor->sSource.u16Gain);
}

/**
 *  @brief  Override source value of literal monitor
 *  @param  psMonitor: Pointer to a sLiteralMonitor_t structure which is attempted to override its source 
 *  @retval RequestDenied: This override request had been denied
 *  @retval RequestAccepted: This override request had been accepted
 */
 
/*
static u16_t LiteralMonitor_Override(sLiteralMonitor_t* psMonitor, u16_t u16LiteralValue)
{
    i16_t i16RealValue = Literal_To_Real(u16LiteralValue, psMonitor->sSource.u16Gain);
    u8_t u8RealData[2] = {0, 0};
    sGuardVarAccessRequest_t sAccessRequest;
    
    // Build a dummy access request
    sAccessRequest.pu8Data = u8RealData;
    __WordToLByte(sAccessRequest.pu8Data, i16RealValue);
    sAccessRequest.u16Length = 2;
    sAccessRequest.u16Offset = 0;

    if (GuardVarList_CheckRequest(psMonitor->sSource.psGuardVarList, sAccessRequest) == RequestDenied)
    {
        return RequestDenied;
    }
    
    GuardVarList_WriteRequest(psMonitor->sSource.psGuardVarList, sAccessRequest);
    
    return RequestAccepted;
}
*/

/**
 *  @brief  Get Command Structure
 *  @param  u8Command: Inquiry command code
 *  @retval Pointer to a sCANBusCmdStr_t structure which is inquiring
 */
sCANBusCmdStr_t* CANBusData_GetCommandStructure(u8_t u8CommandType, u8_t u8Command)
{
    u8_t i;
    
    for (i=0; i<u16CANCommandCount; i++)
    {
        if ((ptsCANBusCommandList[i].u8Command_Type == u8CommandType) &&
			(ptsCANBusCommandList[i].u8Command == u8Command))
        {
            break;
        }
    }
    
    if (i < u16CANCommandCount)
    {
        return &ptsCANBusCommandList[i];
    }
    else
    {
        return NULL;
    }
}

/**
 *  @brief  Join Page data structure into corresponding command structure
 *  @param  psCmd: Pointer to a sCANBusCmdStr_t structure which is attempted to join
 *  @param  psData: Pointer to a sCANBusPageData_t structure which attempted to join
 *  @retval None
 */
static void CANBusData_JoinPageData(sCANBusCmdStr_t* psCmd, sCANBusPageData_t* psData)
{
    if (psCmd->psData == NULL)
    {
        psCmd->psData = psData;
    }
    else
    {
        sCANBusPageData_t* psJoinedData = psCmd->psData;
        
        while (psJoinedData->psNext != NULL)
        {
            psJoinedData = psJoinedData->psNext;
        }
		
        psJoinedData->psNext = psData;
    }
}

/**
 *  @brief  Check guard variable data is valid or not
 *  @param  psNode: Pointer to a sGuardVarNode_t structure which is attempted to write
 *  @param  sRequest: Guard variable access request
 *  @retval RequestDenied: This access request is denied
 *  @retval RequestAccepted: This access request is accepted
 */
static u16_t GuardVarDataCheckRequestHandler(struct sGuardVarNode* psNode, sGuardVarAccessRequest_t sRequest)
{
    u16_t u16Response;

    switch (psNode->sLocalTag.u16PrivyIdentifier)
    {
		case eCANBusData_GV_GET_VARIABLE:
		case eCANBusData_GV_SET_VARIABLE:
		case eCANBusData_GV_CLEAR_FAULTS:
		case eCANBusData_GV_READ_HARMONIC_ACK:
		case eCANBusData_GV_READ_HARMONIC_VS1:
        case eCANBusData_GV_READ_HARMONIC_VS2:
        case eCANBusData_GV_READ_HARMONIC_ACK_2:
        case eCANBusData_GV_READ_HARMONIC_VS1_2:
        case eCANBusData_GV_READ_HARMONIC_VS2_2:
		case eCANBusData_GV_BLACKBOX_READ_START:
		case eCANBusData_GV_BLACKBOX_READ_DATA:
		case eCANBusData_GV_WAVEFORM_TRIGGER:
		case eCANBusData_GV_WAVEFORM_READ_START:
		case eCANBusData_GV_WAVEFORM_READ_DATA:
		case eCANBusData_GV_FW_UPDATE_START:
		case eCANBusData_GV_FW_UPDATE_HEADER_START:
		case eCANBusData_GV_FW_UPDATE_HEADER_DATA:
		case eCANBusData_GV_FW_UPDATE_HEADER_STOP:
		case eCANBusData_GV_FW_UPDATE_BLOCK_START:
		case eCANBusData_GV_FW_UPDATE_BLOCK_DATA:
		case eCANBusData_GV_FW_UPDATE_BLOCK_STOP:
		case eCANBusData_GV_FW_UPDATE_STOP:
		case eCANBusData_GV_EDIT_STATUS_INPUT:
		case eCANBusData_GV_EDIT_STATUS_TEMP:
		case eCANBusData_GV_EDIT_STATUS_OTHER:
		case eCANBusData_GV_EDIT_TEMP:
		case eCANBusData_GV_BMC_UNIX_TIMESTAMP:
		case eCANBusData_GV_HEARTBEAT_TIMEOUT:
		case eCANBusData_GV_FAULT_COUNT_LIMIT:
		case eCANBusData_GV_FAULT_DELAY:
			u16Response = RequestAccepted;
			break;

        case eCANBusData_GV_EDIT_VBULK:
            if (GET_WRITE_PROTECT == DISABLE_WRITE_PROTECT)
            {
                u16Response = RequestAccepted;
            }
            break;

//		case eCANBusData_GV_READ_HARMONIC:
//			if (*sRequest.pu8Data <= Report_Amount)
//         	{
//  				u16Response = RequestAccepted;
//      		}
//        	else
//          	{
//      			u16Response = RequestDenied;
//     		}
//   			break;


// Variable part

		case eCANBusData_GV_ATS_PRI_SRC:
			if ((*sRequest.pu8Data == ATS_ApplySourceis1) ||
				(*sRequest.pu8Data == ATS_ApplySourceis2))
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;

		case eCANBusData_GV_SINGLE_FEED_MODE:
			if ((*sRequest.pu8Data == SIGNAL_INPUT_SOURCE) || 
        		(*sRequest.pu8Data == DUAL_INPUT_SOURCE))
         	{
  				u16Response = RequestAccepted;
      		}
        	else
          	{
      			u16Response = RequestDenied;
     		}
   			break;

		case eCANBusData_GV_OBSERVE_WINDOW:
			if ((*sRequest.pu8Data >= MINIMUM_OBSERVE_DELAY_TIME) && 
				(*sRequest.pu8Data <= MAXIMUM_OBSERVE_DELAY_TIME))
       		{
       			Update_ObservationWindow(*sRequest.pu8Data);
       			u16Response = RequestAccepted;
     		}
     		else
      		{
     			u16Response = RequestDenied;
			}
			break;
                
		case eCANBusData_GV_OUTAGE_DELAY:
			if ((*sRequest.pu8Data >= MINIMUM_OUTAGE_DELAY_TIME) && 
				(*sRequest.pu8Data <= MAXIMUM_OUTAGE_DELAY_TIME))
      		{
         		u16Response = RequestAccepted;
			}
			else
			{
 				u16Response = RequestDenied;
			}
			break;
                
		case eCANBusData_GV_WALKIN_LOW:
			if ((*sRequest.pu8Data >= MINIMUM_WALKIN_DELAY_TIME_LOW) && 
				(*sRequest.pu8Data <= MAXIMUM_WALKIN_DELAY_TIME_LOW))
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;
                
		case eCANBusData_GV_WALKIN_HIGH:
			if ((*sRequest.pu8Data >= MINIMUM_WALKIN_DELAY_TIME_HIGH) && 
				(*sRequest.pu8Data <= MAXIMUM_WALKIN_DELAY_TIME_HIGH))
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;
                
		case eCANBusData_GV_STABILIZATION_DELAY:
			if ((__LByteToWord(sRequest.pu8Data) >= MINIMUM_STABILIZATION_DELAY_TIME) && 
				(__LByteToWord(sRequest.pu8Data) <= MAXIMUM_STABILIZATION_DELAY_TIME))
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;

		case eCANBusData_GV_BLACKBOX_PAGE:
//			if (BlackBox_IsTargetEventExist(*sRequest.pu8Data) == TRUE)
//
//			{
//				u16Response = RequestAccepted;
//			}
		    if (*sRequest.pu8Data <= 9)
		    {
		        u16Response = RequestAccepted;
		    }
			else
			{
				u16Response = RequestDenied;
			}
			break;
		
		case eCANBusData_GV_WAVEFORM_PAGE:
//			if ((BlackBox_IsTargetEventExist(*sRequest.pu8Data) == TRUE) ||
//				(*sRequest.pu8Data == 0xFF))
//			{
//				u16Response = RequestAccepted;
//			}
            if ((*sRequest.pu8Data <= 9) || (*sRequest.pu8Data == 0xFF))
            {
                u16Response = RequestAccepted;
            }
			else
			{
				u16Response = RequestDenied;
			}
			break;

		case eCANBusData_GV_REQ_BBU_NUMBER:
			if (*sRequest.pu8Data <= SHELF_DEVICE_NUMBER)
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;
			
		case eCANBusData_GV_FAULT_COUNT:
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_NOMINAL_VOLTAGE:
			if ((__LByteToWord(sRequest.pu8Data) == 200) || 
				(__LByteToWord(sRequest.pu8Data) == 240) ||
				(__LByteToWord(sRequest.pu8Data) == 277))
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;

// User define Part

		case eCANBusData_GV_FACTORY_MODE:
			if ((*sRequest.pu8Data == DISABLE_WRITE_PROTECT) ||
     			(*sRequest.pu8Data == ENABLE_WRITE_PROTECT))
         	{
     			u16Response = RequestAccepted;
      		}
    		else
       		{
   				u16Response = RequestDenied;
     		}
      		break;

		case eCANBusData_GV_INTERNAL_DEBUGGER:
			if (GET_WRITE_PROTECT == DISABLE_WRITE_PROTECT)
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;

		case eCANBusData_GV_RESET_EEPROM_LOG:
			if (GET_WRITE_PROTECT != DISABLE_WRITE_PROTECT)
			{
				u16Response = RequestDenied;
			}
			else if (*sRequest.pu8Data == TRUE)
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}
			break;

// Calibration Part

		case eCANBusData_GV_CALIBRATION_KEY:
			if (GET_WRITE_PROTECT != DISABLE_WRITE_PROTECT)
			{
				u16Response = RequestDenied;
			}
            else if (sRequest.u16Length != psNode->u16VarSize)
            {
                u16Response = RequestDenied;
            }
            else if (Calibration_IsValidManufacturerKey(sRequest.pu8Data) == FALSE)
            {
                u16Response = RequestDenied;
            }
            else
            {
                u16Response = RequestAccepted;
            }
            break;

		case eCANBusData_GV_CALIBRATION_CLEAR:
		case eCANBusData_GV_CALIBRATION_STORE:
		case eCANBusData_GV_CALIBRATION_VS1:
		case eCANBusData_GV_CALIBRATION_VS2:
		case eCANBusData_GV_CALIBRATION_VPFC:
		case eCANBusData_GV_CALIBRATION_VBULK:
		case eCANBusData_GV_CALIBRATION_IAC:
			if (GET_WRITE_PROTECT != DISABLE_WRITE_PROTECT)
			{
				u16Response = RequestDenied;
			}
			else if (Calibration_IsValidManufacturerKey(GET_CALI_KEY) == FALSE)
            {
                u16Response = RequestDenied;
            }
            else
            {
                u16Response = RequestAccepted;
            }
            break;

// PI Control Part
		case eCANBusData_GV_PI_KEY:
			if (GET_WRITE_PROTECT != DISABLE_WRITE_PROTECT)
			{
				u16Response = RequestDenied;
			}
            else if (__LByteToDWord(sRequest.pu8Data) == GET_PFC_PI_KEY)
            {
                u16Response = RequestAccepted;
            }
            else
            {
                u16Response = RequestDenied;
            }
            break;
	
		case eCANBusData_GV_PI_V_KP:
		case eCANBusData_GV_PI_V_KI:
		case eCANBusData_GV_PI_I_KP:
		case eCANBusData_GV_PI_I_KI:
		case eCANBusData_GV_PI_D_F_S:
		case eCANBusData_GV_VBULK_REF:
		case eCANBusData_GV_Duty_feedward_Gain:
		case eCANBusData_GV_PFC_SoftStart_Count:
		case eCANBusData_GV_PFC_Normal_Change_Phase:
		case eCANBusData_GV_PFC_SoftStart_Change_Phase:
		case eCANBusData_GV_PFC_SoftStart_IntegralGain:
        case eCANBusData_GV_PFC_SoftStart_Iref:
			if (SET_PFC_PI_KEY == GET_PFC_PI_KEY)
			{
				u16Response = RequestAccepted;
			}
			else
			{
				u16Response = RequestDenied;
			}	
			break;			

    	default:
          	u16Response = RequestDenied;
           	break;
  	}
    return u16Response;
}

/**
 *  @brief  Write data of request to guard variable node after checked all guard variable accepted that request
 *  @param  psNode: Pointer to a sGuardVarNode_t structure which is attempted to write
 *  @param  sRequest: Guard variable access request
 *  @retval RequestDenied: This access request is denied
 *  @retval RequestAccepted: This access request is accepted
 */
static u16_t GuardVarDataWriteRequestHandler(struct sGuardVarNode* psNode, sGuardVarAccessRequest_t sRequest)
{
    u16_t u16Response;
	i16_t i16Temp;
	sCANBusCmdStr_t* psCmdbuff;

    switch (psNode->sLocalTag.u16PrivyIdentifier)
    {

// 1 Bytes

		case eCANBusData_GV_ATS_PRI_SRC:
        case eCANBusData_GV_SINGLE_FEED_MODE:
		case eCANBusData_GV_BLACKBOX_PAGE:
		case eCANBusData_GV_WAVEFORM_PAGE:
		case eCANBusData_GV_REQ_BBU_NUMBER:
		case eCANBusData_GV_HEARTBEAT_TIMEOUT:
		case eCANBusData_GV_FAULT_COUNT:
		case eCANBusData_GV_FAULT_COUNT_LIMIT:
		case eCANBusData_GV_FAULT_DELAY:
		case eCANBusData_GV_FACTORY_MODE:
            *((u8_t*)psNode->pVar) = *sRequest.pu8Data;
            u16Response = RequestAccepted;
            break;

// update count
		case eCANBusData_GV_OUTAGE_DELAY:
			*((u8_t*)psNode->pVar) = *sRequest.pu8Data;
			Update_OutageDelay();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_OBSERVE_WINDOW:
			*((u8_t*)psNode->pVar) = *sRequest.pu8Data;
			Update_ObserveWindow();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_WALKIN_LOW:
		case eCANBusData_GV_WALKIN_HIGH:
			*((u8_t*)psNode->pVar) = *sRequest.pu8Data;
			Update_Random_Number_Range();
			u16Response = RequestAccepted;
			break;

// 2 Bytes
		case eCANBusData_GV_STABILIZATION_DELAY:
            *((u16_t*)psNode->pVar) = __LByteToWord(sRequest.pu8Data);
			Update_StabilizationDelay();
            u16Response = RequestAccepted;
            break;

		case eCANBusData_GV_NOMINAL_VOLTAGE:
            *((u16_t*)psNode->pVar) = __LByteToWord(sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;
// 4 Bytes

		case eCANBusData_GV_BMC_UNIX_TIMESTAMP:
			Log_TimeStamp_Shift(__LByteToDWord(sRequest.pu8Data));
            //*((u32_t*)psNode->pVar) = __LByteToDWord(sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

// Harmonic function
        case eCANBusData_GV_READ_HARMONIC_ACK:
            FFT_Read_Rarmonic(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

        case eCANBusData_GV_READ_HARMONIC_VS1:
            LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_Read_VS1_Harmonic]); // Need transfer to Linear11
            u16Response = RequestAccepted;
            break;

        case eCANBusData_GV_READ_HARMONIC_VS2:
            LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_Read_VS2_Harmonic]); // Need transfer to Linear11
            u16Response = RequestAccepted;
            break;

		case eCANBusData_GV_READ_HARMONIC_ACK_2:
			FFT_Read_Rarmonic_2(*sRequest.pu8Data);
            u16Response = RequestAccepted;
   			break;
   			
   		case eCANBusData_GV_READ_HARMONIC_VS1_2:
   			LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_Read_VS1_Harmonic_2]); // Need transfer to Linear11
            u16Response = RequestAccepted;
   			break;

		case eCANBusData_GV_READ_HARMONIC_VS2_2:
		    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_Read_VS2_Harmonic_2]); // Need transfer to Linear11
            u16Response = RequestAccepted;
   			break;

// Other function
		case eCANBusData_GV_GET_VARIABLE:
			CANBusServer_Variable_Data(CANBUS_CMD_GET_VARIABLE, sRequest.pu8Data);
			u16Response = RequestAccepted;
            break;

		case eCANBusData_GV_SET_VARIABLE:
			CANBusServer_Variable_Data(CANBUS_CMD_SET_VARIABLE, sRequest.pu8Data);
			u16Response = RequestAccepted;
            break;

		case eCANBusData_GV_CLEAR_FAULTS:
			*((u8_t*)psNode->pVar) = *sRequest.pu8Data;
            Log_Clear_Fault();
            u16Response = RequestAccepted;
            break;

		case eCANBusData_GV_INTERNAL_DEBUGGER:
            *((u8_t*)psNode->pVar) = *sRequest.pu8Data;
			Log_Internal_debugger();
            u16Response = RequestAccepted;
            break;
			
		case eCANBusData_GV_RESET_EEPROM_LOG:
            *((u8_t*)psNode->pVar) = *sRequest.pu8Data;
			E2pData_Clear();
            u16Response = RequestAccepted;
            break;

// BlackBox function

		case eCANBusData_GV_BLACKBOX_READ_START:
            *((u16_t*)psNode->pVar) = __LByteToWord(sRequest.pu8Data);

            //first block: obtain the current event number
            if((*((u16_t*)psNode->pVar)) == 0)
                BlackBox_UpdateReportBaseIndex();

            // Read start call back
			BlackBox_Read_Start();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_BLACKBOX_READ_DATA:
			BlackBox_Read_Data();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_WAVEFORM_TRIGGER:
			Waveform_StartCapture();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_WAVEFORM_READ_START:
            *((u16_t*)psNode->pVar) = __LByteToWord(sRequest.pu8Data);

            //first block: obtain the current event number
            if((*((u16_t*)psNode->pVar)) == 0)
                BlackBox_UpdateReportBaseIndex();

            // Read start call back
			Waveform_Read_Start();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_WAVEFORM_READ_DATA:
			Waveform_Read_Data();
			u16Response = RequestAccepted;
			break;

// Bootloader function

		case eCANBusData_GV_FW_UPDATE_START:
			IAP_Program_START();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_FW_UPDATE_HEADER_START:
			IAP_HEADER_START();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_FW_UPDATE_HEADER_DATA:
			memcpy((u8_t*)psNode->pVar, sRequest.pu8Data, sRequest.u16Length);
			IAP_HEADER_DTAT();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_FW_UPDATE_HEADER_STOP:
			*((u8_t*)psNode->pVar) = *sRequest.pu8Data;
			IAP_HEADER_STOP();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_FW_UPDATE_BLOCK_START:
			SET_IAP_CURRENT_PROGRAM_BLOCK = ((((u32_t)sRequest.pu8Data[2]) << 16) + (((u32_t)sRequest.pu8Data[1]) << 8) + ((u32_t)sRequest.pu8Data[0])); // Byte 0~2: Block sequence number
			SET_IAP_MAX_PROGRAM_BYTE = sRequest.pu8Data[3]; // Byte 3 : Maximum number of bytes inside this block
			SET_IAP_MAX_PROGRAM_BLOCK = ((((u32_t)sRequest.pu8Data[6]) << 16) + (((u32_t)sRequest.pu8Data[5]) << 8) + ((u32_t)sRequest.pu8Data[4])); // Byte 4~6: Max block sequence number
			IAP_BLOCK_START();
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_FW_UPDATE_BLOCK_DATA:
			memcpy((u8_t*)psNode->pVar, sRequest.pu8Data, sRequest.u16Length);
			IAP_BLOCK_DTAT();
			u16Response = RequestAccepted;
			break;
		
		case eCANBusData_GV_FW_UPDATE_BLOCK_STOP:
			*((u8_t*)psNode->pVar) = *sRequest.pu8Data;
			IAP_BLOCK_STOP();
			u16Response = RequestAccepted;
			break;
		
		case eCANBusData_GV_FW_UPDATE_STOP:	
			SET_IAP_CRC16 = (((u16_t)sRequest.pu8Data[1]) << 8) + ((u16_t)sRequest.pu8Data[0]);
			SET_IAP_FWAction = (u8_t)sRequest.pu8Data[2];	// Reserved abort function
			IAP_Program_STOP();
			u16Response = RequestAccepted;
			break;

// Fault Injection function
			
		case eCANBusData_GV_EDIT_STATUS_INPUT:
			Log_EDIT_Status_Input(sRequest.pu8Data[0], sRequest.pu8Data[1], sRequest.pu8Data[2]);
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_EDIT_STATUS_TEMP:
			Log_EDIT_Status_Temp(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_EDIT_STATUS_OTHER:
			Log_EDIT_Status_Other(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_EDIT_TEMP:
			u16Response = ((u16_t)sRequest.pu8Data[1]) + ((u16_t)sRequest.pu8Data[2] << 8);
			i16Temp = (i16_t)Literal_To_Real(u16Response , 10);
			Log_EDIT_Temp(sRequest.pu8Data[0] , i16Temp);
			u16Response = RequestAccepted;
			break;

        case eCANBusData_GV_EDIT_VBULK:
            Log_EDIT_VBULK_Protection(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

// Calibration function

		case eCANBusData_GV_CALIBRATION_KEY:
			memcpy((u8_t*)psNode->pVar, sRequest.pu8Data, CALIBRATION_KEY_LENGTH);
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_CALIBRATION_CLEAR:
			if (*sRequest.pu8Data == 0xFF)
			{
				Calibration_ResetCoefficient(eCalibration_Tag_VS1);
				Calibration_ResetCoefficient(eCalibration_Tag_VS2);
				Calibration_ResetCoefficient(eCalibration_Tag_VPFC);
				Calibration_ResetCoefficient(eCalibration_Tag_Current);
				Calibration_ResetCoefficient(eCalibration_Tag_VBus);
				SET_MOMIAC_VAC1_CALI;
				SET_MOMIAC_VAC2_CALI;
				SET_MOMIAC_VPFC_CALI;
				SET_MOMIDC_VBULK_CALI;
				SET_MOMIAC_IPFC_CALI;
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VS1)
			{
				Calibration_ResetCoefficient(eCalibration_Tag_VS1);
				SET_MOMIAC_VAC1_CALI;
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VS2)
			{
				Calibration_ResetCoefficient(eCalibration_Tag_VS2);
				SET_MOMIAC_VAC2_CALI;
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VPFC)
			{
				Calibration_ResetCoefficient(eCalibration_Tag_VPFC);
				SET_MOMIAC_VPFC_CALI;
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VBULK)
			{
				Calibration_ResetCoefficient(eCalibration_Tag_VBus);
				SET_MOMIDC_VBULK_CALI;
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_IAC)
			{
				Calibration_ResetCoefficient(eCalibration_Tag_Current);
				SET_MOMIAC_IPFC_CALI;
			}
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_CALIBRATION_STORE:
			if (*sRequest.pu8Data == 0xFF)
			{
				Calibration_StoreCoefficient(eCalibration_Tag_VS1);
				Calibration_StoreCoefficient(eCalibration_Tag_VS2);
				Calibration_StoreCoefficient(eCalibration_Tag_VPFC);
				Calibration_StoreCoefficient(eCalibration_Tag_VBus);
				Calibration_StoreCoefficient(eCalibration_Tag_Current);
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VS1)
			{
				Calibration_StoreCoefficient(eCalibration_Tag_VS1);
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VS2)
			{
				Calibration_StoreCoefficient(eCalibration_Tag_VS2);
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VPFC)
			{
				Calibration_StoreCoefficient(eCalibration_Tag_VPFC);
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_VBULK)
			{
				Calibration_StoreCoefficient(eCalibration_Tag_VBus);
			}
			else if (*sRequest.pu8Data == CANBUS_CMD_CALI_IAC)
			{
				Calibration_StoreCoefficient(eCalibration_Tag_Current);
			}
			u16Response = RequestAccepted;
			break;
	
		case eCANBusData_GV_CALIBRATION_VS1:
			Calibration_SetCoefficient(eCalibration_Tag_VS1, (u16_t)(__LByteToWord(&sRequest.pu8Data[0])), (i16_t)(__LByteToWord(&sRequest.pu8Data[2])));
			SET_MOMIAC_VAC1_CALI;
			u16Response = RequestAccepted;
			break;
		
		case eCANBusData_GV_CALIBRATION_VS2:
			Calibration_SetCoefficient(eCalibration_Tag_VS2, (u16_t)(__LByteToWord(&sRequest.pu8Data[0])), (i16_t)(__LByteToWord(&sRequest.pu8Data[2])));		
			SET_MOMIAC_VAC2_CALI;
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_CALIBRATION_VPFC:
			Calibration_SetCoefficient(eCalibration_Tag_VPFC, (u16_t)(__LByteToWord(&sRequest.pu8Data[0])), (i16_t)(__LByteToWord(&sRequest.pu8Data[2])));		
			SET_MOMIAC_VPFC_CALI;
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_CALIBRATION_VBULK:
			Calibration_SetCoefficient(eCalibration_Tag_VBus, (u16_t)(__LByteToWord(&sRequest.pu8Data[0])), (i16_t)(__LByteToWord(&sRequest.pu8Data[2])));		
			SET_MOMIDC_VBULK_CALI;
			u16Response = RequestAccepted;
			break;

		case eCANBusData_GV_CALIBRATION_IAC:
			Calibration_SetCoefficient(eCalibration_Tag_Current, (u16_t)(__LByteToWord(&sRequest.pu8Data[0])), (i16_t)(__LByteToWord(&sRequest.pu8Data[2])));		
			SET_MOMIAC_IPFC_CALI;
			u16Response = RequestAccepted;
			break;

// PI Control Part

		case eCANBusData_GV_PI_KEY:
            *((u32_t*)psNode->pVar) = __LByteToDWord(sRequest.pu8Data);

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_PI_V_KP);
			psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_PI_V_KI);
			psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_PI_I_KP);
			psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_PI_I_KI);
			psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_PI_D_F_S);
			psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_PI_V_PIOUT);
			psCmdbuff->u8Protocol = CANBUS_Protocol_Read;

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_VBULK_REF);
			psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

            psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_Duty_feedward_Gain);
            psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

            psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_PFC_SoftStart_Count);
            psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

            psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_Nromal_Phase_Change);
            psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

            psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_SoftStart_Phase_Change);
            psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

            psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_SoftStart_IntegralGain);
            psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

            psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_MFR, CANBUS_CMD_SoftStart_Iref);
            psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;

			psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_FAULTINJECT, CANBUS_CMD_EDIT_TEMP);
			psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;
            u16Response = RequestAccepted;
            break;

		case eCANBusData_GV_PI_V_KP:
			PFC_PI_V_KP(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;
			
		case eCANBusData_GV_PI_V_KI:
			PFC_PI_V_KI(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;
		
		case eCANBusData_GV_PI_I_KP:
			PFC_PI_I_KP(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;
			
		case eCANBusData_GV_PI_I_KI:
			PFC_PI_I_KI(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;
			
		case eCANBusData_GV_PI_D_F_S:
			PFC_PI_Duty_Feed_Shift(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;	

		case eCANBusData_GV_VBULK_REF:
			PFC_VBULK_Adjust(*sRequest.pu8Data);
			u16Response = RequestAccepted;
			break;

        case eCANBusData_GV_Duty_feedward_Gain:
            PFC_PI_Duty_Feed_Gain(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

        case eCANBusData_GV_PFC_SoftStart_Count:
            PFC_SoftStart_Count(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

        case eCANBusData_GV_PFC_Normal_Change_Phase:
            PFC_Normal_Change_Phase(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

        case eCANBusData_GV_PFC_SoftStart_Change_Phase:
            PFC_SoftStart_Change_Phase(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

        case eCANBusData_GV_PFC_SoftStart_IntegralGain:
            PFC_Adjust_Iref_IntegralGain(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

        case eCANBusData_GV_PFC_SoftStart_Iref:
            PFC_Adjust_Iref_Gain(*sRequest.pu8Data);
            u16Response = RequestAccepted;
            break;

        default:
            u16Response = RequestDenied;
            break;
    }

    return u16Response;
}

/**
 *  @brief  CANBus Data Periodically Process
 *  @note   This function would be executed every 10ms in background
 *  @retval None
 */
void CANBusData_10ms_Periodically_Process(void)
{
	LiteralMonitor_Update(&ptsLiteralMonitor[u16LiternalCNT]);
	u16LiternalCNT += 1;
	
	if (u16LiternalCNT >= eCANBusData_LM_Num)
	{
		u16LiternalCNT = 0;
	}
}

/**
 *  @brief  Change eCANBusPageData_BLACKBOX_READ_DATA length
 *  @note   call back from E2P_blackbox
 */
void CANBusData_Set_BlackBox_Data_Length(u8_t Length)
{
	ptsCANBusPageData[eCANBusPageData_BLACKBOX_READ_DATA].u8Length = Length;
}

/**
 *  @brief  Change eCANBusPageData_WAVEFORM_READ_DATA length
 *  @note   call back from E2P_blackbox
 */
void CANBusData_Set_Waveform_Data_Length(u8_t Length)
{
	ptsCANBusPageData[eCANBusPageData_BLACKBOX_READ_DATA].u8Length = Length;
}

/**
 *  @brief  Initial Literal Monitor
 *  @retval None
 */
static inline void CANBusData_Initial_LiternalMonitor(void)
{
	u16_t i;
	
    for (i=0; i<eCANBusData_LM_Num; i++)
    {
        memset(&ptsLiteralMonitor[i], 0, sizeof(ptsLiteralMonitor[i]));
	}

	//			    Tag					           	Gain	    Source
	CONFIG_LM(eCANBusData_LM_VS1,		              10, 	    (i16_t*)&GET_MOMIAC_VAC1_REALRMS_WF);
	CONFIG_LM(eCANBusData_LM_VS2,	            	  10, 	    (i16_t*)&GET_MOMIAC_VAC2_REALRMS_WF);
	CONFIG_LM(eCANBusData_LM_VAC,	                  10, 	    (i16_t*)&GET_LOG_VAC);
	CONFIG_LM(eCANBusData_LM_IAC,	                  1000, 	(i16_t*)&GET_LOG_IAC);
	CONFIG_LM(eCANBusData_LM_FS1,		              100,  	(i16_t*)&GET_MOMIAC_VAC1_FREQ_WF);
	CONFIG_LM(eCANBusData_LM_FS2,	               	  100,  	(i16_t*)&GET_MOMIAC_VAC2_FREQ_WF);
	CONFIG_LM(eCANBusData_LM_PS1,		              1, 		(i16_t*)&GET_LOG_POWER1);
	CONFIG_LM(eCANBusData_LM_PS2,		              1, 		(i16_t*)&GET_LOG_POWER2);
	CONFIG_LM(eCANBusData_LM_MAXPS1,	              1, 		(i16_t*)&GET_LOG_MAXPOWER1);
	CONFIG_LM(eCANBusData_LM_MAXPS2,	              1, 		(i16_t*)&GET_LOG_MAXPOWER2);
	CONFIG_LM(eCANBusData_LM_AVGPS1,	              1, 		(i16_t*)&GET_LOG_AVGPOWER1);
	CONFIG_LM(eCANBusData_LM_AVGPS2,	              1, 		(i16_t*)&GET_LOG_AVGPOWER2);
	CONFIG_LM(eCANBusData_LM_TINLET,	              10,   	(i16_t*)&GET_MOMITP_INLET_Temper);
	CONFIG_LM(eCANBusData_LM_TATS,		              10,   	(i16_t*)&GET_MOMITP_ATS_Temper);
	CONFIG_LM(eCANBusData_LM_VAUX1,		              10,   	(i16_t*)&GET_MOMIDC_VAUX1_REALRMS_WF);
	CONFIG_LM(eCANBusData_LM_VAUX2,		              10,   	(i16_t*)&GET_MOMIDC_VAUX2_REALRMS_WF);
	CONFIG_LM(eCANBusData_LM_IAUX1,		              10,   	(i16_t*)&GET_MOMIDC_IAUX1_REALRMS_WF);
	CONFIG_LM(eCANBusData_LM_IAUX2,		              10, 	    (i16_t*)&GET_MOMIDC_IAUX2_REALRMS_WF);
	CONFIG_LM(eCANBusData_LM_VBULK,		              10,   	(i16_t*)&GET_MOMIDC_VBULK_REALRMS_WF);
	CONFIG_LM(eCANBusData_LM_TPFC,		              10, 	    (i16_t*)&GET_MOMITP_PFC_Temper);
	CONFIG_LM(eCANBusData_LM_TD2D,		              10, 	    (i16_t*)&GET_MOMITP_D2D_Temper);
	CONFIG_LM(eCANBusData_LM_VPFC,		              10, 	    (i16_t*)&GET_MOMIAC_VPFC_REALRMS_WF);
    CONFIG_LM(eCANBusData_LM_Read_VS1_Harmonic,       100,      (i16_t*)&GET_READ_HARMONIC_VAC1);
    CONFIG_LM(eCANBusData_LM_Read_VS2_Harmonic,       100,      (i16_t*)&GET_READ_HARMONIC_VAC2);
    CONFIG_LM(eCANBusData_LM_Read_VS1_Harmonic_2,     100,      (i16_t*)&GET_READ_HARMONIC_VAC1_2);
    CONFIG_LM(eCANBusData_LM_Read_VS2_Harmonic_2,     100,      (i16_t*)&GET_READ_HARMONIC_VAC2_2);
}

/**
 *  @brief  Initial Guard Variable, Configure Guard Variable Node and list
 *  @retval None
 */
static inline void CANBusData_Initial_GuardVar(void)
{
	u16_t i;
	
    for (i=0; i<eCANBusData_GV_Num; i++)
    {
        memset(&ptsGuardVarNode[i], 0, sizeof(ptsGuardVarNode[i]));
		memset(&ptsGuardVarList[i], 0, sizeof(ptsGuardVarList[i]));
	}

	// 			Tag 									Size 	Source
	CONFIG_GV(eCANBusData_GV_GET_VARIABLE,				1,		NULL);
	CONFIG_GV(eCANBusData_GV_SET_VARIABLE,				8,		NULL);
	CONFIG_GV(eCANBusData_GV_CLEAR_FAULTS,				1,		&SET_LOG_CLEARFAULT);
    CONFIG_GV(eCANBusData_GV_READ_HARMONIC_ACK,         1,      NULL);
	CONFIG_GV(eCANBusData_GV_READ_HARMONIC_VS1, 		1,		NULL);
	CONFIG_GV(eCANBusData_GV_READ_HARMONIC_VS2,			1,		NULL);
    CONFIG_GV(eCANBusData_GV_READ_HARMONIC_ACK_2,       1,      NULL);
    CONFIG_GV(eCANBusData_GV_READ_HARMONIC_VS1_2,       1,      NULL);
    CONFIG_GV(eCANBusData_GV_READ_HARMONIC_VS2_2,       1,      NULL);
	CONFIG_GV(eCANBusData_GV_BLACKBOX_READ_START,		2,		&E2P_BLACKBOX_BLOCK_SEQUENCE);
	CONFIG_GV(eCANBusData_GV_BLACKBOX_READ_DATA,		0,		NULL);
	CONFIG_GV(eCANBusData_GV_WAVEFORM_TRIGGER,			0,		NULL);
	CONFIG_GV(eCANBusData_GV_WAVEFORM_READ_START,		2,		&E2P_WAVEFORM_BLOCK_SEQUENCE);
	CONFIG_GV(eCANBusData_GV_WAVEFORM_READ_DATA,		0,		NULL);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_START,			0,		NULL);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_HEADER_START,	0,		NULL);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_HEADER_DATA,		8,		SET_IAP_RECEIVE_DATA);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_HEADER_STOP,		1,		&SET_IAP_CRC8);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_BLOCK_START,		7,		NULL);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_BLOCK_DATA,		8,		SET_IAP_RECEIVE_DATA);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_BLOCK_STOP,		1,		&SET_IAP_CRC8);
	CONFIG_GV(eCANBusData_GV_FW_UPDATE_STOP,			3,		NULL);
	CONFIG_GV(eCANBusData_GV_EDIT_STATUS_INPUT,			3,		NULL);
	CONFIG_GV(eCANBusData_GV_EDIT_STATUS_TEMP,			1,		NULL);
	CONFIG_GV(eCANBusData_GV_EDIT_STATUS_OTHER,			1,		NULL);
	CONFIG_GV(eCANBusData_GV_EDIT_TEMP,					3,		NULL);
    CONFIG_GV(eCANBusData_GV_EDIT_VBULK,                1,      NULL);
	CONFIG_GV(eCANBusData_GV_BMC_UNIX_TIMESTAMP,		4,		&GET_LOG_UNIX_TIME);
	CONFIG_GV(eCANBusData_GV_ATS_PRI_SRC,				1,		&SET_ATS_PREFER_SOURCE);
	CONFIG_GV(eCANBusData_GV_SINGLE_FEED_MODE, 			1,		&SET_ATS_SINGLE_FEED_MODE);
	CONFIG_GV(eCANBusData_GV_OBSERVE_WINDOW, 			1,		&SET_ATS_OBSERVE_WINDOW);
	CONFIG_GV(eCANBusData_GV_OUTAGE_DELAY, 				1,		&SET_ATS_OUTAGE_DELAY);
	CONFIG_GV(eCANBusData_GV_WALKIN_LOW, 				1,		&SET_ATS_WALK_IN_LOW);
	CONFIG_GV(eCANBusData_GV_WALKIN_HIGH, 				1,		&SET_ATS_WALK_IN_HIGH);
	CONFIG_GV(eCANBusData_GV_STABILIZATION_DELAY, 		2,		&SET_ATS_STABILIZE_DELAY);
	CONFIG_GV(eCANBusData_GV_BLACKBOX_PAGE, 			1,		&E2P_BLACKBOX_PAGE);
	CONFIG_GV(eCANBusData_GV_WAVEFORM_PAGE, 			1,		&E2P_WAVEFORM_PAGE);
	CONFIG_GV(eCANBusData_GV_REQ_BBU_NUMBER, 			1,		&SET_LOG_REQ_BBU_NUMBER);
	CONFIG_GV(eCANBusData_GV_HEARTBEAT_TIMEOUT, 		1,		&SET_LOG_HEARTBEAT_TIMEOUT);
	CONFIG_GV(eCANBusData_GV_FAULT_COUNT, 				1,		&GET_LOG_FAULT_COUNT);
	CONFIG_GV(eCANBusData_GV_FAULT_COUNT_LIMIT, 		1,		&GET_LOG_FAULT_COUNT_LIMIT);
	CONFIG_GV(eCANBusData_GV_FAULT_DELAY, 				1,		&GET_LOG_FAULT_DELAY);
	CONFIG_GV(eCANBusData_GV_NOMINAL_VOLTAGE,           2,      &GET_LOG_NOMINAL_VOLTAGE);
	CONFIG_GV(eCANBusData_GV_FACTORY_MODE, 				1,		&GET_WRITE_PROTECT);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_KEY, 			4,		GET_CALI_KEY);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_CLEAR, 		0,		NULL);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_STORE, 		0,		NULL);
	CONFIG_GV(eCANBusData_GV_INTERNAL_DEBUGGER, 		1,		&GET_LOG_INTERNAL_DEBUGGER);
	CONFIG_GV(eCANBusData_GV_RESET_EEPROM_LOG, 			1,		&GET_E2P_CLEAR_DATA);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_VS1, 			0,		NULL);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_VS2, 			0,		NULL);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_VPFC, 			0,		NULL);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_VBULK, 		0,		NULL);
	CONFIG_GV(eCANBusData_GV_CALIBRATION_IAC, 			0,		NULL);
	CONFIG_GV(eCANBusData_GV_PI_KEY, 					4,		&SET_PFC_PI_KEY);
	CONFIG_GV(eCANBusData_GV_PI_V_KP, 					1,		NULL);
	CONFIG_GV(eCANBusData_GV_PI_V_KI, 					1,		NULL);
	CONFIG_GV(eCANBusData_GV_PI_I_KP, 					1,		NULL);
	CONFIG_GV(eCANBusData_GV_PI_I_KI, 					1,		NULL);
	CONFIG_GV(eCANBusData_GV_PI_D_F_S, 					1,		NULL);
	CONFIG_GV(eCANBusData_GV_PI_V_PIOUT, 				0,		NULL);
	CONFIG_GV(eCANBusData_GV_VBULK_REF, 				1,		NULL);
	CONFIG_GV(eCANBusData_GV_Duty_feedward_Gain,        1,      NULL);
	CONFIG_GV(eCANBusData_GV_PFC_SoftStart_Count,       1,      NULL);
	CONFIG_GV(eCANBusData_GV_PFC_Normal_Change_Phase,   1,      NULL);
	CONFIG_GV(eCANBusData_GV_PFC_SoftStart_Change_Phase, 1,      NULL);
	CONFIG_GV(eCANBusData_GV_PFC_SoftStart_IntegralGain, 1,      NULL);
    CONFIG_GV(eCANBusData_GV_PFC_SoftStart_Iref,         1,      NULL);
} 

/**
 *  @brief  Initial page data
 *  @retval None
 */
static inline void CANBusData_Initial_PageData(void)
{
	u16_t i;
	
    for (i=0; i<eCANBusPageData_Num; i++)
    {
        memset(&ptsCANBusPageData[i], 0, sizeof(ptsCANBusPageData[i]));
	}

	// 			Tag 								Length	Array	Read 		Write
	CONFIG_PD(eCANBusPageData_GET_VARIABLE, 			8,	1,	(u8_t*)GET_LOG_VARIABLE, &ptsGuardVarList[eCANBusData_GV_GET_VARIABLE]);
	CONFIG_PD(eCANBusPageData_SET_VARIABLE, 			8,	1,	(u8_t*)GET_LOG_VARIABLE, &ptsGuardVarList[eCANBusData_GV_SET_VARIABLE]);
	CONFIG_PD(eCANBusPageData_CLEAR_FAULTS, 			0,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CLEAR_FAULTS]);
	CONFIG_PD(eCANBusPageData_COMPATIBILITY_NUMBER, 	1,	0,	(u8_t*)&SET_LOG_COMPATIBILITY_NUMBER, NULL);
    CONFIG_PD(eCANBusPageData_FAULT_RECOVERY,           3,  0,  (u8_t*)&GET_LOG_VBulk_Protect_CNT, NULL);
	CONFIG_PD(eCANBusPageData_CAN_TO_SEL, 				5,	0,	NULL, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_WORD, 				2,	0,	(u8_t*)&GET_LOG_STATUS_WORD, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_RELAY_S1, 			1,	0,	(u8_t*)&GET_LOG_STATUS_RELAY_S1, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_RELAY_S2, 			1,	0,	(u8_t*)&GET_LOG_STATUS_RELAY_S2, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_RELAY_PFC, 		1,	0,	(u8_t*)&GET_LOG_STATUS_RELAY_PFC, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_TRANSFER, 			2,	0,	(u8_t*)&GET_LOG_STATUS_TRANSFER, NULL); //Adding u8_t in front of it is to turn it into a pointer
	CONFIG_PD(eCANBusPageData_STATUS_TEMP, 				1,	0,	(u8_t*)&GET_LOG_STATUS_TEMP, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_OTHER, 			1,	0,	(u8_t*)&GET_LOG_STATUS_OTHER, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_LED, 				1,	0,	(u8_t*)&GET_STATUS_LED, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_ATS_SOURCE, 		1,	0,	(u8_t*)&GET_LOG_STATUS_SRC, NULL);	
	CONFIG_PD(eCANBusPageData_STATUS_CML, 				1,	0,	(u8_t*)&GET_LOG_STATUS_CML, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_BOOTLOADER, 		1,	0,	(u8_t*)&GET_STATUS_BOOTLOADER, NULL);
	CONFIG_PD(eCANBusPageData_READ_VS1, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_VS1].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_VS2, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_VS2].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_VAC, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_VAC].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_IAC, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_IAC].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_FS1, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_FS1].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_FS2, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_FS2].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_PS1, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_PS1].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_PS2, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_PS2].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_MAXPS1, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_MAXPS1].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_MAXPS2, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_MAXPS2].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_AVGPS1, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_AVGPS1].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_AVGPS2, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_AVGPS2].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_TINLET, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_TINLET].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_TATS, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_TATS].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_SWITCH_TIMES, 		4,	0,	(u8_t*)&GET_LOG_SWITCH_TIME, NULL);
	CONFIG_PD(eCANBusPageData_READ_TOTAL_SWITCH_TIMES,	4,	0,	(u8_t*)&GET_LOG_TOT_SWITCH_TIME, NULL);
	CONFIG_PD(eCANBusPageData_READ_HARMONIC_ACK,        2,  0,  (u8_t*)&GET_READ_HARMONIC_ACK, &ptsGuardVarList[eCANBusData_GV_READ_HARMONIC_ACK]);
    CONFIG_PD(eCANBusPageData_READ_VS1_HARMONIC,        2,  0,  (u8_t*)&ptsLiteralMonitor[eCANBusData_LM_Read_VS1_Harmonic].u16LiteralValue, &ptsGuardVarList[eCANBusData_GV_READ_HARMONIC_VS1]);
    CONFIG_PD(eCANBusPageData_READ_VS2_HARMONIC,        2,  0,  (u8_t*)&ptsLiteralMonitor[eCANBusData_LM_Read_VS2_Harmonic].u16LiteralValue, &ptsGuardVarList[eCANBusData_GV_READ_HARMONIC_VS2]);
    CONFIG_PD(eCANBusPageData_READ_HARMONIC_ACK_2,      2,  0,  (u8_t*)&GET_READ_HARMONIC_ACK_2, &ptsGuardVarList[eCANBusData_GV_READ_HARMONIC_ACK_2]);
    CONFIG_PD(eCANBusPageData_READ_VS1_HARMONIC_2,      2,  0,  (u8_t*)&ptsLiteralMonitor[eCANBusData_LM_Read_VS1_Harmonic_2].u16LiteralValue, &ptsGuardVarList[eCANBusData_GV_READ_HARMONIC_VS1_2]);
    CONFIG_PD(eCANBusPageData_READ_VS2_HARMONIC_2,      2,  0,  (u8_t*)&ptsLiteralMonitor[eCANBusData_LM_Read_VS2_Harmonic_2].u16LiteralValue, &ptsGuardVarList[eCANBusData_GV_READ_HARMONIC_VS2_2]);
	CONFIG_PD(eCANBusPageData_READ_VAUX1,				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_VAUX1].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_VAUX2,				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_VAUX2].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_IAUX1,				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_IAUX1].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_IAUX2,				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_IAUX2].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_BBU_COUNT,			1,	0,	(u8_t*)&GET_LOG_BBU_Valid_Count, NULL);
	CONFIG_PD(eCANBusPageData_MAJOR_REVISION, 			1,	0,	(u8_t*)&GET_MAJOR_REVISION, NULL);
	CONFIG_PD(eCANBusPageData_MINOR_REVISION, 			1,	0,	(u8_t*)&GET_MINOR_REVISION, NULL);
	CONFIG_PD(eCANBusPageData_BLACKBOX_READ_START,		4,	0,	(u8_t*)&E2P_BLACKBOX_RESPONSE_READ_START, &ptsGuardVarList[eCANBusData_GV_BLACKBOX_READ_START]);
	CONFIG_PD(eCANBusPageData_BLACKBOX_READ_DATA,		8,	1,	(u8_t*)E2P_BLACKBOX_PUBLISH_DATA, &ptsGuardVarList[eCANBusData_GV_BLACKBOX_READ_DATA]);
	CONFIG_PD(eCANBusPageData_BLACKBOX_READ_STOP, 		1,	0,	(u8_t*)&E2P_BLACKBOX_CRC8, NULL);
	CONFIG_PD(eCANBusPageData_WAVEFORM_TRIGGER, 		1,	0,	(u8_t*)&E2P_WAVEFORM_ACK, &ptsGuardVarList[eCANBusData_GV_WAVEFORM_TRIGGER]);
	CONFIG_PD(eCANBusPageData_WAVEFORM_READ_START,		4,	0,	(u8_t*)&E2P_WAVEFORM_RESPONSE_READ_START, &ptsGuardVarList[eCANBusData_GV_WAVEFORM_READ_START]);
	CONFIG_PD(eCANBusPageData_WAVEFORM_READ_DATA,		8,	1,	(u8_t*)E2P_BLACKBOX_PUBLISH_DATA, &ptsGuardVarList[eCANBusData_GV_WAVEFORM_READ_DATA]);
	CONFIG_PD(eCANBusPageData_WAVEFORM_READ_STOP, 		1,	0,	(u8_t*)&E2P_BLACKBOX_CRC8, NULL);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_START, 			1,	0,	(u8_t*)&GET_IAP_ACK, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_START]);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_HEADER_START, 	1,	0,	(u8_t*)&GET_IAP_ACK, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_HEADER_START]);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_HEADER_DATA, 	8,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_HEADER_DATA]);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_HEADER_STOP, 	1,	0,	(u8_t*)&GET_IAP_ACK, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_HEADER_STOP]);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_BLOCK_START,	1,	0,	(u8_t*)&GET_IAP_ACK, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_BLOCK_START]);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_BLOCK_DATA,		8,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_BLOCK_DATA]);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_BLOCK_STOP,		1,	0,	(u8_t*)&GET_IAP_ACK, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_BLOCK_STOP]);
	CONFIG_PD(eCANBusPageData_FW_UPDATE_STOP, 			1,	0,	(u8_t*)&GET_IAP_ACK, &ptsGuardVarList[eCANBusData_GV_FW_UPDATE_STOP]);
	CONFIG_PD(eCANBusPageData_EDIT_STATUS_INPUT, 		1,	0,	(u8_t*)&GET_LOG_FAULTINJECTACK, &ptsGuardVarList[eCANBusData_GV_EDIT_STATUS_INPUT]);
	CONFIG_PD(eCANBusPageData_EDIT_STATUS_TEMP, 		1,	0,	(u8_t*)&GET_LOG_FAULTINJECTACK, &ptsGuardVarList[eCANBusData_GV_EDIT_STATUS_TEMP]);
	CONFIG_PD(eCANBusPageData_EDIT_STATUS_OTHER, 		1,	0,	(u8_t*)&GET_LOG_FAULTINJECTACK, &ptsGuardVarList[eCANBusData_GV_EDIT_STATUS_OTHER]);
	CONFIG_PD(eCANBusPageData_EDIT_TEMP, 				1,	0,	(u8_t*)&GET_LOG_FAULTINJECTACK, &ptsGuardVarList[eCANBusData_GV_EDIT_TEMP]);
    CONFIG_PD(eCANBusPageData_EDIT_VBULK,               1,  0,  NULL, &ptsGuardVarList[eCANBusData_GV_EDIT_VBULK]);
	CONFIG_PD(eCANBusPageData_BMC_UNIX_TIMESTAMP, 		4,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_BMC_UNIX_TIMESTAMP].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_BMC_UNIX_TIMESTAMP]);
	CONFIG_PD(eCANBusPageData_ATS_PRI_SRC, 				1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_ATS_PRI_SRC].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_ATS_PRI_SRC]);
	CONFIG_PD(eCANBusPageData_SINGLE_FEED_MODE, 		1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_SINGLE_FEED_MODE].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_SINGLE_FEED_MODE]);
	CONFIG_PD(eCANBusPageData_OBSERVE_WINDOW, 			1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_OBSERVE_WINDOW].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_OBSERVE_WINDOW]);
	CONFIG_PD(eCANBusPageData_OUTAGE_DELAY, 			1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_OUTAGE_DELAY].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_OUTAGE_DELAY]);
	CONFIG_PD(eCANBusPageData_WALKIN_LOW, 				1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_WALKIN_LOW].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_WALKIN_LOW]);
	CONFIG_PD(eCANBusPageData_WALKIN_HIGH, 				1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_WALKIN_HIGH].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_WALKIN_HIGH]);
	CONFIG_PD(eCANBusPageData_STABILIZATION_DELAY, 		2,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_STABILIZATION_DELAY].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_STABILIZATION_DELAY]);
	CONFIG_PD(eCANBusPageData_BLACKBOX_PAGE, 			1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_BLACKBOX_PAGE].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_BLACKBOX_PAGE]);
	CONFIG_PD(eCANBusPageData_WAVEFORM_PAGE, 			1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_WAVEFORM_PAGE].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_WAVEFORM_PAGE]);
	CONFIG_PD(eCANBusPageData_REQ_BBU_NUMBER, 			1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_REQ_BBU_NUMBER].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_REQ_BBU_NUMBER]);
	CONFIG_PD(eCANBusPageData_HEARTBEAT_TIMEOUT, 		1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_HEARTBEAT_TIMEOUT].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_HEARTBEAT_TIMEOUT]);
	CONFIG_PD(eCANBusPageData_FAULT_COUNT, 				1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_FAULT_COUNT].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_FAULT_COUNT]);
	CONFIG_PD(eCANBusPageData_FAULT_COUNT_LIMIT, 		1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_FAULT_COUNT_LIMIT].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_FAULT_COUNT_LIMIT]);
	CONFIG_PD(eCANBusPageData_FAULT_DELAY, 				1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_FAULT_DELAY].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_FAULT_DELAY]);
	CONFIG_PD(eCANBusPageData_NOMINAL_VOLGATE,          2,  0,  (u8_t*)ptsGuardVarList[eCANBusData_GV_NOMINAL_VOLTAGE].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_NOMINAL_VOLTAGE]);
	CONFIG_PD(eCANBusPageData_FACTORY_MODE, 			1,	0,	(u8_t*)ptsGuardVarList[eCANBusData_GV_FACTORY_MODE].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_FACTORY_MODE]);
	CONFIG_PD(eCANBusPageData_CALIBRATION_KEY, 			4,	1,	(u8_t*)ptsGuardVarList[eCANBusData_GV_CALIBRATION_KEY].psHeadNode->pVar, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_KEY]);
	CONFIG_PD(eCANBusPageData_CALIBRATION_CLEAR,		1,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_CLEAR]);
	CONFIG_PD(eCANBusPageData_CALIBRATION_STORE, 		1,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_STORE]);
	CONFIG_PD(eCANBusPageData_INTERNAL_DEBUGGER,		1,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_INTERNAL_DEBUGGER]);
	CONFIG_PD(eCANBusPageData_RESET_EEPROM_LOG,			1,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_RESET_EEPROM_LOG]);
	CONFIG_PD(eCANBusPageData_INTERNAL_REVISION, 		4,	0,	(u8_t*)&GET_IAP_INTERNAL_REVISION, NULL);
	CONFIG_PD(eCANBusPageData_FW_RELEASE_DATE, 			4,	0,	(u8_t*)&GET_IAP_RELEASE_DATE, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_PFC, 				2,	0,	(u8_t*)&GET_LOG_STATUS_PFC, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_PFC2D2D, 			2,	0,	(u8_t*)&GET_LOG_STATUS_P2D, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_D2D2PFC, 			2,	0,	(u8_t*)&GET_LOG_STATUS_D2P, NULL);
	CONFIG_PD(eCANBusPageData_STATUS_INPUT, 			1,	0,	(u8_t*)&GET_LOG_STATUS_INPUT, NULL);
	CONFIG_PD(eCANBusPageData_READ_VBULK, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_VBULK].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_POS_TOTAL, 			4,	0,	(u8_t*)&GET_LOG_TOT_WORK_TIME, NULL);
	CONFIG_PD(eCANBusPageData_READ_POS_LAST, 			4,	0,	(u8_t*)&GET_LOG_WORK_TIME, NULL);
	CONFIG_PD(eCANBusPageData_READ_TPFC, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_TPFC].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_TD2D, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_TD2D].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_VPFC, 				2,	0,	(u8_t*)&ptsLiteralMonitor[eCANBusData_LM_VPFC].u16LiteralValue, NULL);
	CONFIG_PD(eCANBusPageData_READ_DEBUG_A, 			4,	0,	(u8_t*)&Debug_1, NULL); // GET_PFC_KPKILevel
	CONFIG_PD(eCANBusPageData_READ_DEBUG_B, 			4,	0,	(u8_t*)&Debug_2, NULL); // GET_PFC_V_PIOUT
	CONFIG_PD(eCANBusPageData_READ_DEBUG_C, 			4,	0,	(u8_t*)&Debug_3, NULL);
	CONFIG_PD(eCANBusPageData_READ_DEBUG_D, 			4,	0,	(u8_t*)&Debug_4, NULL);
	CONFIG_PD(eCANBusPageData_CALI_VS1,					4,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_VS1]);
	CONFIG_PD(eCANBusPageData_CALI_VS2, 				4,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_VS2]);	
	CONFIG_PD(eCANBusPageData_CALI_VPFC, 				4,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_VPFC]);
	CONFIG_PD(eCANBusPageData_CALI_VBULK, 				4,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_VBULK]);
	CONFIG_PD(eCANBusPageData_CALI_IAC, 				4,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_CALIBRATION_IAC]);
	CONFIG_PD(eCANBusPageData_PI_KEY, 					4,	0,	NULL, &ptsGuardVarList[eCANBusData_GV_PI_KEY]);
	CONFIG_PD(eCANBusPageData_PI_V_KP, 					4,	0,	(u8_t*)&GET_PFC_V_KP, &ptsGuardVarList[eCANBusData_GV_PI_V_KP]);
	CONFIG_PD(eCANBusPageData_PI_V_KI,					4,	0,	(u8_t*)&GET_PFC_V_KI, &ptsGuardVarList[eCANBusData_GV_PI_V_KI]);
	CONFIG_PD(eCANBusPageData_PI_I_KP,					4,	0,	(u8_t*)&GET_PFC_I_KP, &ptsGuardVarList[eCANBusData_GV_PI_I_KP]);
	CONFIG_PD(eCANBusPageData_PI_I_KI,					4,	0,	(u8_t*)&GET_PFC_I_KI, &ptsGuardVarList[eCANBusData_GV_PI_I_KI]);
	CONFIG_PD(eCANBusPageData_PI_D_F_S,					4,	0,	(u8_t*)&GET_PFC_DUTY_FEED_SHIFT, &ptsGuardVarList[eCANBusData_GV_PI_D_F_S]);
	CONFIG_PD(eCANBusPageData_PI_V_PIOUT,				4,	0,	(u8_t*)&GET_PFC_V_PIOUT, &ptsGuardVarList[eCANBusData_GV_PI_V_PIOUT]);
	CONFIG_PD(eCANBusPageData_VBULK_REF,				2,	0,	(u8_t*)&GET_PFC_VBULK_M, &ptsGuardVarList[eCANBusData_GV_VBULK_REF]);
	CONFIG_PD(eCANBusPageData_Duty_feedward_Gain,       4,  0,  (u8_t*)&GET_PFC_FEEDWARD_GAIN, &ptsGuardVarList[eCANBusData_GV_Duty_feedward_Gain]);
    CONFIG_PD(eCANBusPageData_PFC_SoftStart_Count,      4,  0,  (u8_t*)&GET_PFC_SoftStart_Count, &ptsGuardVarList[eCANBusData_GV_PFC_SoftStart_Count]);
    CONFIG_PD(eCANBusPageData_PFC_Normal_Change_Phase,  4,  0,  (u8_t*)&GET_PFC_Normal_Phase, &ptsGuardVarList[eCANBusData_GV_PFC_Normal_Change_Phase]);
    CONFIG_PD(eCANBusPageData_PFC_SoftStart_Change_Phase, 4,  0,  (u8_t*)&GET_PFC_SoftStart_Phase, &ptsGuardVarList[eCANBusData_GV_PFC_SoftStart_Change_Phase]);
    CONFIG_PD(eCANBusPageData_PFC_SoftStart_IntegralGain, 4,  0,  (u8_t*)&GET_PFC_SoftStart_IntegralGain, &ptsGuardVarList[eCANBusData_GV_PFC_SoftStart_IntegralGain]);
    CONFIG_PD(eCANBusPageData_PFC_SoftStart_Iref,         2,  0,  (u8_t*)&GET_PFC_SoftStart_Iref, &ptsGuardVarList[eCANBusData_GV_PFC_SoftStart_Iref]);
    CONFIG_PD(eCANBusPageData_BlackBox_Record_Harmonic1,   2,  0,  (u8_t*)&ptsLiteralMonitor[eCANBusData_LM_Read_VS1_Harmonic].u16LiteralValue, NULL); //Only for BlackBox record S1 Harmonic
    CONFIG_PD(eCANBusPageData_BlackBox_Record_Harmonic2,   2,  0,  (u8_t*)&ptsLiteralMonitor[eCANBusData_LM_Read_VS2_Harmonic].u16LiteralValue, NULL); //Only for BlackBox record S2 Harmonic
}

/**
 *  @brief  connect page data to blackbox
 *  @retval None
 */
static inline void CANBusData_Initial_BlackBox(void)
{
	// 				BlackBoxItemTag							PageData 						
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_BMC_UNIX_TIMESTAMP, 		eCANBusPageData_BMC_UNIX_TIMESTAMP);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_WORD, 			eCANBusPageData_STATUS_WORD);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_TRANSFER, 		eCANBusPageData_STATUS_TRANSFER);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_ATS_SOURCE, 		eCANBusPageData_STATUS_ATS_SOURCE);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_RELAY_S1, 		eCANBusPageData_STATUS_RELAY_S1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_RELAY_S2, 		eCANBusPageData_STATUS_RELAY_S2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_RELAY_PFC, 		eCANBusPageData_STATUS_RELAY_PFC);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_TEMP, 			eCANBusPageData_STATUS_TEMP);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_OTHER, 			eCANBusPageData_STATUS_OTHER);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_LED, 				eCANBusPageData_STATUS_LED);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STATUS_BOOTLOADER, 		eCANBusPageData_STATUS_BOOTLOADER);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_VS1, 				eCANBusPageData_READ_VS1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_VS2, 				eCANBusPageData_READ_VS2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_VAC, 				eCANBusPageData_READ_VAC);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_IAC, 				eCANBusPageData_READ_IAC);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_FS1, 				eCANBusPageData_READ_FS1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_FS2, 				eCANBusPageData_READ_FS2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_PS1, 				eCANBusPageData_READ_PS1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_PS2, 				eCANBusPageData_READ_PS2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_MAXPS1, 			eCANBusPageData_READ_MAXPS1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_MAXPS2, 			eCANBusPageData_READ_MAXPS2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_AVGPS1, 			eCANBusPageData_READ_AVGPS1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_AVGPS2, 			eCANBusPageData_READ_AVGPS2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_TINLET, 			eCANBusPageData_READ_TINLET);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_TATS, 				eCANBusPageData_READ_TATS);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_SWITCH_TIMES, 		eCANBusPageData_READ_SWITCH_TIMES);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_TOTAL_SWITCH_TIMES, eCANBusPageData_READ_TOTAL_SWITCH_TIMES);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_VS1_HARMONIC, 		eCANBusPageData_BlackBox_Record_Harmonic1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_VS2_HARMONIC, 		eCANBusPageData_BlackBox_Record_Harmonic2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_BBU_COUNT, 			eCANBusPageData_READ_BBU_COUNT);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_VAUX1, 				eCANBusPageData_READ_VAUX1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_VAUX2, 				eCANBusPageData_READ_VAUX2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_IAUX1, 				eCANBusPageData_READ_IAUX1);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_READ_IAUX2, 				eCANBusPageData_READ_IAUX2);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_MAJOR_REVISION, 			eCANBusPageData_MAJOR_REVISION);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_MINOR_REVISION, 			eCANBusPageData_MINOR_REVISION);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_ATS_PRI_SRC, 			eCANBusPageData_ATS_PRI_SRC);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_SINGLE_FEED_MODE, 		eCANBusPageData_SINGLE_FEED_MODE);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_OBSERVE_WINDOW, 			eCANBusPageData_OBSERVE_WINDOW);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_OUTAGE_DELAY, 			eCANBusPageData_OUTAGE_DELAY);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_WALKIN_LOW, 				eCANBusPageData_WALKIN_LOW);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_WALKIN_HIGH, 			eCANBusPageData_WALKIN_HIGH);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_STABILIZATION_DELAY, 	eCANBusPageData_STABILIZATION_DELAY);
	CONFIG_BLACKBOX(eBLACKBOX_ITEM_BLACKBOX_PAGE, 			eCANBusPageData_BLACKBOX_PAGE);
}

/**
 *  @brief  Initial Command Structure, connect pagedate to command list
 *  @Note	Do not become circular data when adding pagedata to CMD
 */
static inline void CANBusData_Initial_CMDStructure(void)
{
	//			COMMTYPE						COMMCODE							PageData
	CONFIG_CMD(	CANBUS_COMMTYPE_EMERGENCY,		CANBUS_CMD_DEVICE_FAIL, 			eCANBusPageData_STATUS_WORD);
	CONFIG_CMD( CANBUS_COMMTYPE_NMT,			CANBUS_CMD_HEARTBEAT, 				eCANBusPageData_STATUS_WORD);
	CONFIG_CMD(	CANBUS_COMMTYPE_NMT,			CANBUS_CMD_GET_VARIABLE, 			eCANBusPageData_GET_VARIABLE);
	CONFIG_CMD(	CANBUS_COMMTYPE_NMT,			CANBUS_CMD_SET_VARIABLE, 			eCANBusPageData_SET_VARIABLE);
	CONFIG_CMD(	CANBUS_COMMTYPE_NMT,			CANBUS_CMD_CLEAR_LATCHING_FAULTS, 	eCANBusPageData_CLEAR_FAULTS);
	CONFIG_CMD(	CANBUS_COMMTYPE_NMT,			CANBUS_CMD_COMPATIBILITY_NUMBER, 	eCANBusPageData_COMPATIBILITY_NUMBER);
    CONFIG_CMD( CANBUS_COMMTYPE_NMT,            CANBUS_CMD_FAULT_RECOVERY,          eCANBusPageData_FAULT_RECOVERY);
	CONFIG_CMD(	CANBUS_COMMTYPE_NMT,			CANBUS_CMD_CAN_TO_SEL, 				eCANBusPageData_CAN_TO_SEL);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_WORD, 			eCANBusPageData_STATUS_WORD);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_INPUT, 			eCANBusPageData_STATUS_RELAY_S1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_INPUT,			eCANBusPageData_STATUS_RELAY_S2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_INPUT,  			eCANBusPageData_STATUS_RELAY_PFC);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_TRANSFER, 		eCANBusPageData_STATUS_TRANSFER);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_TEMP, 			eCANBusPageData_STATUS_TEMP);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_OTHER, 			eCANBusPageData_STATUS_OTHER);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_LED, 				eCANBusPageData_STATUS_LED);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_ATS_SOURCE, 		eCANBusPageData_STATUS_ATS_SOURCE);	
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_CML, 				eCANBusPageData_STATUS_CML);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_STATUS_BOOTLOADER, 		eCANBusPageData_STATUS_BOOTLOADER);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_VOLTAGE, 			eCANBusPageData_READ_VS1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_VOLTAGE, 			eCANBusPageData_READ_VS2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_VOLTAGE, 			eCANBusPageData_READ_VAC);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_CURRENT, 			eCANBusPageData_READ_IAC);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_FREQ, 				eCANBusPageData_READ_FS1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_FREQ, 				eCANBusPageData_READ_FS2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER, 				eCANBusPageData_READ_PS1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER, 				eCANBusPageData_READ_PS2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER_EXTRA, 		eCANBusPageData_READ_MAXPS1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER_EXTRA, 		eCANBusPageData_READ_MAXPS2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER_EXTRA, 		eCANBusPageData_READ_AVGPS1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_POWER_EXTRA, 		eCANBusPageData_READ_AVGPS2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_TEMP, 				eCANBusPageData_READ_TINLET);
	CONFIG_CMD( CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_TEMP,				eCANBusPageData_READ_TATS);	
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_ATS_SWITCH_TIMES, 	eCANBusPageData_READ_SWITCH_TIMES);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_ATS_SWITCH_TIMES, 	eCANBusPageData_READ_TOTAL_SWITCH_TIMES);
    CONFIG_CMD( CANBUS_COMMTYPE_SENSOR_DATA,    CANBUS_CMD_READ_HARMONIC,           eCANBusPageData_READ_HARMONIC_ACK);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_HARMONIC, 			eCANBusPageData_READ_VS1_HARMONIC);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_HARMONIC, 			eCANBusPageData_READ_VS2_HARMONIC);
    CONFIG_CMD( CANBUS_COMMTYPE_SENSOR_DATA,    CANBUS_CMD_READ_HARMONIC_2,         eCANBusPageData_READ_HARMONIC_ACK_2);
    CONFIG_CMD( CANBUS_COMMTYPE_SENSOR_DATA,    CANBUS_CMD_READ_HARMONIC_2,         eCANBusPageData_READ_VS1_HARMONIC_2);
    CONFIG_CMD( CANBUS_COMMTYPE_SENSOR_DATA,    CANBUS_CMD_READ_HARMONIC_2,         eCANBusPageData_READ_VS2_HARMONIC_2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_VOLTAGE_EXTRA, 		eCANBusPageData_READ_VAUX1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_VOLTAGE_EXTRA, 		eCANBusPageData_READ_VAUX2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_CURRENT_EXTRA, 		eCANBusPageData_READ_IAUX1);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_CURRENT_EXTRA, 		eCANBusPageData_READ_IAUX2);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_BBU_COUNT, 			eCANBusPageData_READ_BBU_COUNT);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_FW_REVISION, 		eCANBusPageData_MAJOR_REVISION);
	CONFIG_CMD(	CANBUS_COMMTYPE_SENSOR_DATA,	CANBUS_CMD_READ_FW_REVISION, 		eCANBusPageData_MINOR_REVISION);
	CONFIG_CMD(	CANBUS_COMMTYPE_BLOCK_READ,		CANBUS_CMD_BLACKBOX_READ_START, 	eCANBusPageData_BLACKBOX_READ_START);
	CONFIG_CMD(	CANBUS_COMMTYPE_BLOCK_READ,		CANBUS_CMD_BLACKBOX_READ_DATA, 		eCANBusPageData_BLACKBOX_READ_DATA);
	CONFIG_CMD(	CANBUS_COMMTYPE_BLOCK_READ,		CANBUS_CMD_BLACKBOX_READ_STOP, 		eCANBusPageData_BLACKBOX_READ_STOP);
	CONFIG_CMD( CANBUS_COMMTYPE_BLOCK_READ, 	CANBUS_CMD_WAVEFORM_TRIGGER, 		eCANBusPageData_WAVEFORM_TRIGGER);
	CONFIG_CMD(	CANBUS_COMMTYPE_BLOCK_READ,		CANBUS_CMD_WAVEFORM_READ_START, 	eCANBusPageData_WAVEFORM_READ_START);
	CONFIG_CMD(	CANBUS_COMMTYPE_BLOCK_READ,		CANBUS_CMD_WAVEFORM_READ_DATA, 		eCANBusPageData_WAVEFORM_READ_DATA);
	CONFIG_CMD(	CANBUS_COMMTYPE_BLOCK_READ,		CANBUS_CMD_WAVEFORM_READ_STOP, 		eCANBusPageData_WAVEFORM_READ_STOP);
	CONFIG_CMD(	CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_START, 		eCANBusPageData_FW_UPDATE_START);
	CONFIG_CMD(	CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_HEADER_START, 	eCANBusPageData_FW_UPDATE_HEADER_START);
	CONFIG_CMD(	CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_HEADER_DATA, 	eCANBusPageData_FW_UPDATE_HEADER_DATA);
	CONFIG_CMD(	CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_HEADER_STOP, 	eCANBusPageData_FW_UPDATE_HEADER_STOP);
	CONFIG_CMD(	CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_BLOCK_START, 	eCANBusPageData_FW_UPDATE_BLOCK_START);
	CONFIG_CMD(	CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_BLOCK_DATA, 	eCANBusPageData_FW_UPDATE_BLOCK_DATA);
	CONFIG_CMD(	CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_BLOCK_STOP, 	eCANBusPageData_FW_UPDATE_BLOCK_STOP);
	CONFIG_CMD( CANBUS_COMMTYPE_FW_UPDATE,		CANBUS_CMD_FW_UPDATE_STOP,			eCANBusPageData_FW_UPDATE_STOP);
	CONFIG_CMD( CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_STATUS_INPUT,		eCANBusPageData_EDIT_STATUS_INPUT);
	CONFIG_CMD( CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_STATUS_TEMP,		eCANBusPageData_EDIT_STATUS_TEMP);
	CONFIG_CMD( CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_STATUS_OTHER,		eCANBusPageData_EDIT_STATUS_OTHER);
	CONFIG_CMD( CANBUS_COMMTYPE_FAULTINJECT,	CANBUS_CMD_EDIT_TEMP,				eCANBusPageData_EDIT_TEMP);
    CONFIG_CMD( CANBUS_COMMTYPE_FAULTINJECT,    CANBUS_CMD_EDIT_VBulk,              eCANBusPageData_EDIT_VBULK);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_BMC_UNIX_TIMESTAMP, 		eCANBusPageData_BMC_UNIX_TIMESTAMP);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_ATS_PRIMARY_SOURCE, 		eCANBusPageData_ATS_PRI_SRC);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_SINGLE_FEED_MODE, 		eCANBusPageData_SINGLE_FEED_MODE);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_OBSERVE_WINDOW, 			eCANBusPageData_OBSERVE_WINDOW);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_OUTAGE_DELAY, 			eCANBusPageData_OUTAGE_DELAY);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_WALKIN_LOW, 				eCANBusPageData_WALKIN_LOW);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_WALKIN_HIGH, 			eCANBusPageData_WALKIN_HIGH);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_STABILIZATION_DELAY, 	eCANBusPageData_STABILIZATION_DELAY);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_BLACKBOX_PAGE, 			eCANBusPageData_BLACKBOX_PAGE);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_WAVEFORM_PAGE, 			eCANBusPageData_WAVEFORM_PAGE);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_REQ_BBU_NUMBER, 			eCANBusPageData_REQ_BBU_NUMBER);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_HEARTBEAT_TIMEOUT, 		eCANBusPageData_HEARTBEAT_TIMEOUT);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_FAULT_COUNT, 			eCANBusPageData_FAULT_COUNT);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_FAULT_COUNT_LIMIT, 		eCANBusPageData_FAULT_COUNT_LIMIT);
	CONFIG_CMD(	CANBUS_COMMTYPE_VARIABLE,		CANBUS_CMD_FAULT_DELAY, 			eCANBusPageData_FAULT_DELAY);
	CONFIG_CMD( CANBUS_COMMTYPE_VARIABLE,       CANBUS_CMD_NOMINAL_VOLTAGE,         eCANBusPageData_NOMINAL_VOLGATE);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_FACTORY_MODE, 			eCANBusPageData_FACTORY_MODE);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALIBRATION_KEY, 		eCANBusPageData_CALIBRATION_KEY);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALIBRATION_CLEAR, 		eCANBusPageData_CALIBRATION_CLEAR);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALIBRATION_STORE, 		eCANBusPageData_CALIBRATION_STORE);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_INTERNAL_DEBUGGER, 		eCANBusPageData_INTERNAL_DEBUGGER);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_RESET_EEPROM_LOG, 		eCANBusPageData_RESET_EEPROM_LOG);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_INTERNAL_REVISION, 		eCANBusPageData_INTERNAL_REVISION);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_FW_RELEASE_DATE, 		eCANBusPageData_FW_RELEASE_DATE);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_PFC, 				eCANBusPageData_STATUS_PFC);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_PFC2D2D, 			eCANBusPageData_STATUS_PFC2D2D);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_D2D2PFC, 			eCANBusPageData_STATUS_D2D2PFC);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_STATUS_INPUT_ATS, 		eCANBusPageData_STATUS_INPUT);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VS1, 				eCANBusPageData_READ_VS1);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VS2, 				eCANBusPageData_READ_VS2);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_IAC, 				eCANBusPageData_READ_IAC);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VBULK, 				eCANBusPageData_READ_VBULK);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_POS_TOTAL, 			eCANBusPageData_READ_POS_TOTAL);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_POS_LAST, 			eCANBusPageData_READ_POS_LAST);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_PFC_TEMP,			eCANBusPageData_READ_TPFC);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_D2D_TEMP,			eCANBusPageData_READ_TD2D);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_VPFC,				eCANBusPageData_READ_VPFC);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_DEBUG_1,			eCANBusPageData_READ_DEBUG_A);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_DEBUG_1,			eCANBusPageData_READ_DEBUG_B);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_DEBUG_2,			eCANBusPageData_READ_DEBUG_C);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_READ_DEBUG_2,			eCANBusPageData_READ_DEBUG_D);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VS1, 				eCANBusPageData_CALI_VS1);
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VS2, 				eCANBusPageData_CALI_VS2);		
	CONFIG_CMD(	CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VPFC, 				eCANBusPageData_CALI_VPFC);	
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_VBULK,				eCANBusPageData_CALI_VBULK);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_CALI_IAC,				eCANBusPageData_CALI_IAC);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_KEY,					eCANBusPageData_PI_KEY);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_V_KP,					eCANBusPageData_PI_V_KP);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_V_KI,					eCANBusPageData_PI_V_KI);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_I_KP,					eCANBusPageData_PI_I_KP);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_I_KI,					eCANBusPageData_PI_I_KI);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_D_F_S,				eCANBusPageData_PI_D_F_S);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_PI_V_PIOUT,				eCANBusPageData_PI_V_PIOUT);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,			CANBUS_CMD_VBULK_REF,				eCANBusPageData_VBULK_REF);
	CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_Duty_feedward_Gain,      eCANBusPageData_Duty_feedward_Gain);
    CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_PFC_SoftStart_Count,     eCANBusPageData_PFC_SoftStart_Count);
    CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_Nromal_Phase_Change,     eCANBusPageData_PFC_Normal_Change_Phase);
    CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_SoftStart_Phase_Change,  eCANBusPageData_PFC_SoftStart_Change_Phase);
    CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_SoftStart_IntegralGain,  eCANBusPageData_PFC_SoftStart_IntegralGain);
    CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_SoftStart_Iref,          eCANBusPageData_PFC_SoftStart_Iref);
    CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_BlackBox_Record_Harmonic, eCANBusPageData_BlackBox_Record_Harmonic1);
    CONFIG_CMD( CANBUS_COMMTYPE_MFR,            CANBUS_CMD_BlackBox_Record_Harmonic, eCANBusPageData_BlackBox_Record_Harmonic2);
}

/**
 *  @brief  Initial Sensor data
 *  @retval None
 */
static inline void CANBusData_Initial_SensorData(void)
{
	u16_t i;
	
    for (i=0; i<eCANBUS_SENSOR_Num; i++)
    {
        memset(&pu8SensorData[i], 0, sizeof(pu8SensorData[i]));
	}
	
	pu8SensorData[eCANBUS_SENSOR_STATUS_WORD] 			= CANBUS_CMD_STATUS_WORD;
	pu8SensorData[eCANBUS_SENSOR_STATUS_INPUT] 			= CANBUS_CMD_STATUS_INPUT;
	pu8SensorData[eCANBUS_SENSOR_STATUS_TRANSFER] 		= CANBUS_CMD_STATUS_TRANSFER;
	pu8SensorData[eCANBUS_SENSOR_STATUS_TEMP] 			= CANBUS_CMD_STATUS_TEMP;
	pu8SensorData[eCANBUS_SENSOR_STATUS_OTHER] 			= CANBUS_CMD_STATUS_OTHER;
	pu8SensorData[eCANBUS_SENSOR_STATUS_LED] 			= CANBUS_CMD_STATUS_LED;
	pu8SensorData[eCANBUS_SENSOR_STATUS_ATS_SOURCE] 	= CANBUS_CMD_STATUS_ATS_SOURCE;
	pu8SensorData[eCANBUS_SENSOR_STATUS_CML] 			= CANBUS_CMD_STATUS_CML;
	pu8SensorData[eCANBUS_SENSOR_STATUS_BOOTLOADER] 	= CANBUS_CMD_STATUS_BOOTLOADER;
	pu8SensorData[eCANBUS_SENSOR_READ_VOLTAGE] 			= CANBUS_CMD_READ_VOLTAGE;
	pu8SensorData[eCANBUS_SENSOR_READ_CURRENT] 			= CANBUS_CMD_READ_CURRENT;
	pu8SensorData[eCANBUS_SENSOR_READ_FREQ] 			= CANBUS_CMD_READ_FREQ;
	pu8SensorData[eCANBUS_SENSOR_READ_POWER] 			= CANBUS_CMD_READ_POWER;
	pu8SensorData[eCANBUS_SENSOR_READ_POWER_EXTRA] 		= CANBUS_CMD_READ_POWER_EXTRA;
	pu8SensorData[eCANBUS_SENSOR_READ_TEMP] 			= CANBUS_CMD_READ_TEMP;
	pu8SensorData[eCANBUS_SENSOR_READ_ATS_SWITCH_TIMES] = CANBUS_CMD_READ_ATS_SWITCH_TIMES;
	pu8SensorData[eCANBUS_SENSOR_READ_HARMONIC] 		= CANBUS_CMD_READ_HARMONIC;
    pu8SensorData[eCANBUS_SENSOR_READ_HARMONIC_2]       = CANBUS_CMD_READ_HARMONIC_2;
	pu8SensorData[eCANBUS_SENSOR_READ_VOLTAGE_EXTRA] 	= CANBUS_CMD_READ_VOLTAGE_EXTRA;
	pu8SensorData[eCANBUS_SENSOR_READ_CURRENT_EXTRA] 	= CANBUS_CMD_READ_CURRENT_EXTRA;
	pu8SensorData[eCANBUS_SENSOR_READ_BBU_COUNT] 		= CANBUS_CMD_READ_BBU_COUNT;
	pu8SensorData[eCANBUS_SENSOR_READ_FW_REVISION] 		= CANBUS_CMD_READ_FW_REVISION;
}

/**
 *  @brief  Initial CANBus Database
 *  @retval None
 */
void CANBusData_Initialize(void)
{
	u16LiternalCNT = 0;
	u16CANCommandCount = __ElementCountOf(ptsCANBusCommandList);
	
    CANBusData_Initial_LiternalMonitor();
    CANBusData_Initial_GuardVar();
	CANBusData_Initial_PageData();
	CANBusData_Initial_BlackBox();
	CANBusData_Initial_CMDStructure();
	CANBusData_Initial_SensorData();


#ifdef EnableTempFIJ

	sCANBusCmdStr_t* psCmdbuff;
	psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_FAULTINJECT, CANBUS_CMD_EDIT_TEMP);
	psCmdbuff->u8Protocol = CANBUS_Protocol_WandR;
	
#endif 
}
