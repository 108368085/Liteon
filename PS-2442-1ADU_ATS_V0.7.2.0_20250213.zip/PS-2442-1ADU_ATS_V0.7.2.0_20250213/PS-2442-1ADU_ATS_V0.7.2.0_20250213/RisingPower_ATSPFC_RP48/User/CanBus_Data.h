/****************************************************************************
 *	File	CanBus_Data.h
 * 	Brief	Header file for CanBus Database
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 ****************************************************************************/

#ifndef _CANBUS_DATA_H_
#define _CANBUS_DATA_H_

#include "SERV_GuardVar.h"
#include "CONFIG_Define.h"
#include "CONFIG_RisingPower.h"
#include "Peripheral_CAN.h"


 
/****************************************************************************
    Public parameter definition
****************************************************************************/

#define DYNAMIC_EXPONENT            0xFF

// if data is multi page, make sure those page data have same length
#define CANBUS_One_PAGE           	1
#define CANBUS_Multi_PAGE           0xFF


/**
 *  Data Frame Definition
 *  The Identifier (ID) field shall be partitioned and defined as follows
 *	ID = 0xABBCCDD, 29 bits in total
 *	A = Communication type, 5 bits
 *	BB = Address, 8 bits / 1 byte
 *	CC = Command Code, 8 bits / 1 byte
 *	DD = Extension Command Code, 8 bits / 1 byte
 *	Control bits [2~6] shall contain the data length (number of bytes, 0 - 8)
 */


/****************************************************************************
	Public macro definition
****************************************************************************/

/** Communication type, 5 bits */
#define CANBUS_COMMTYPE_EMERGENCY        	0x00 	// Sending faults that require highest priority, such as AC input fail or output fail
#define CANBUS_COMMTYPE_NMT            		0x01	// Network Management Protocol, used by Controller Device (PSC) to manage all Responder Devices (ATSPSU, BBU) on the bus
#define CANBUS_COMMTYPE_SYNC           		0x02	// For collecting all SDR data from Responder devices
#define CANBUS_COMMTYPE_SENSOR_DATA    		0x03	// For PSC to read sensor data from PSU and BBU
#define CANBUS_COMMTYPE_TIME    			0x04	// For synchronizing timestamp
#define CANBUS_COMMTYPE_BLOCK_READ    		0x05	// For data transfers more than 8bytes (FRU, black box reading)
#define CANBUS_COMMTYPE_FW_UPDATE    		0x06	// PSC to PSU and BBU FW update
#define CANBUS_COMMTYPE_FAULTINJECT 		0x1E	// For Fault injection
#define CANBUS_COMMTYPE_MFR    				0x1F	// User definition command
#define CANBUS_COMMTYPE_VARIABLE			0x2F	// For variable address



/** Command Code Summary , follow by can bus spec 20220103*/

// 00 EMERGENCY
#define CANBUS_CMD_AC_LOSS       			0x01	//ATS
#define CANBUS_CMD_DEVICE_FAIL     			0x02	//ALL
#define CANBUS_CMD_AC_RECOVER      			0xF0	//ATS


// 01 NMT
#define CANBUS_CMD_HEARTBEAT     			0x01	//ALL
#define CANBUS_CMD_PSU_ENABLE     			0x02	//D2D
#define CANBUS_CMD_PSU_ON     				0x03	//D2D
#define CANBUS_CMD_GET_VARIABLE     		0xF0	//ALL
#define CANBUS_CMD_SET_VARIABLE     		0xF1	//ALL
#define CANBUS_CMD_BBU_PROXY				0xF2	//BBU
#define CANBUS_CMD_CLEAR_LATCHING_FAULTS	0xF3	//ALL
#define CANBUS_CMD_COMPATIBILITY_NUMBER		0xF4	//ALL
#define CANBUS_CMD_FAULT_RECOVERY           0xF7    //ALL
#define CANBUS_CMD_CAN_TO_SEL	     		0xFF	//ALL

// 02 SYNC
#define CANBUS_CMD_SYNC	     				0x01	//ALL

// 03 SENSOR_DATA
#define CANBUS_CMD_STATUS_WORD     			0x01	//ALL
#define CANBUS_CMD_STATUS_VOUT     			0x02	//D2D,BBU
#define CANBUS_CMD_STATUS_IOUT     			0x03	//D2D,BBU
#define CANBUS_CMD_STATUS_INPUT    			0x04	//ATS,BBU
#define CANBUS_CMD_STATUS_TRANSFER   		0x05	//ATS
#define CANBUS_CMD_STATUS_RELAYS  			0x06	//ATS->remove
#define CANBUS_CMD_STATUS_TEMP	 			0x07	//ALL
#define CANBUS_CMD_STATUS_OTHER	 			0x08	//ALL
#define CANBUS_CMD_STATUS_LED	 			0x09	//ALL
#define CANBUS_CMD_STATUS_FANS	 			0x0A	//D2D,BBU
#define CANBUS_CMD_STATUS_ATS_SOURCE	 	0x0B	//ATS
#define CANBUS_CMD_STATUS_CML			 	0x0C	//ALL
#define CANBUS_CMD_STATUS_BOOTLOADER	 	0xD3	//ALL

#define CANBUS_CMD_READ_VOLTAGE 			0x10	//ALL
#define CANBUS_CMD_READ_CURRENT				0x11	//ALL
#define CANBUS_CMD_READ_FREQ				0x12	//ATS
#define CANBUS_CMD_READ_POWER				0x13	//ALL
#define CANBUS_CMD_READ_POWER_EXTRA			0x14	//ALL
#define CANBUS_CMD_READ_TEMP				0x15	//ALL
#define CANBUS_CMD_READ_FAN_SPEED			0x16	//D2D,BBU
#define CANBUS_CMD_READ_ATS_SWITCH_TIMES	0x17	//ATS
#define CANBUS_CMD_READ_HARMONIC			0x18	//ATS
#define CANBUS_CMD_READ_VOLTAGE_EXTRA		0x19	//ALL
#define CANBUS_CMD_READ_CURRENT_EXTRA		0x1A	//ALL
#define CANBUS_CMD_READ_TEMP_EXTRA			0x1B	//BBU
#define CANBUS_CMD_READ_SPARE_PSU_POWER		0x1C	//D2D
#define CANBUS_CMD_READ_BBU_COUNT			0x1D	//ATS


#define CANBUS_CMD_BATTERY_MODE				0x30	//BBU
#define CANBUS_CMD_READ_BATT_REL_SOC		0x31	//BBU
#define CANBUS_CMD_READ_BATT_ABS_SOC		0x32	//BBU
#define CANBUS_CMD_AT_RATE_TIME_TO_FULL		0x34	//BBU
#define CANBUS_CMD_AT_RATE_TIME_TO_EMPTY	0x35	//BBU
#define CANBUS_CMD_AT_RATE_OK				0x36	//BBU
#define CANBUS_CMD_AVERAGE_CURRENT			0x37	//BBU
#define CANBUS_CMD_MAX_ERROR				0x38	//BBU
#define CANBUS_CMD_REM_CAP					0x39	//BBU
#define CANBUS_CMD_READ_BATT_FULLCH_CAP		0x3A	//BBU
#define CANBUS_CMD_RUN_TIME_TO_EMPTY		0x3B	//BBU
#define CANBUS_CMD_AVERAGE_TIME_TO_EMPTY	0x3C	//BBU
#define CANBUS_CMD_AVERAGE_TIME_TO_FULL		0x3D	//BBU
#define CANBUS_CMD_CYCLE_COUNT				0x3E	//BBU
#define CANBUS_CMD_DESIGN_CAPACITY			0x3F	//BBU
#define CANBUS_CMD_STATUS_BATTERY			0x40	//BBU

#define CANBUS_CMD_READ_FW_REVISION			0x42	//ALL
#define CANBUS_CMD_FAN_BROADCAST			0x43	//D2D,BBU
#define CANBUS_CMD_READ_HARMONIC_2          0x44    //ATS



// 04 TIME




// 05 BLOCK_READ
#define CANBUS_CMD_FRU_READ_START			0x01	//D2D,BBU
#define CANBUS_CMD_FRU_READ_DATA			0x02	//D2D,BBU
#define CANBUS_CMD_FRU_READ_STOP			0x03	//D2D,BBU

#define CANBUS_CMD_BLACKBOX_READ_START		0x04	//ALL
#define CANBUS_CMD_BLACKBOX_READ_DATA		0x05	//ALL
#define CANBUS_CMD_BLACKBOX_READ_STOP		0x06	//ALL

#define CANBUS_CMD_CELL_VOLTAGE_READ_START	0x07	//BBU
#define CANBUS_CMD_CELL_VOLTAGE_READ_DATA	0x08	//BBU
#define CANBUS_CMD_CELL_VOLTAGE_READ_STOP	0x09	//BBU

#define CANBUS_CMD_WAVEFORM_TRIGGER			0x0A	//ATS
#define CANBUS_CMD_WAVEFORM_READ_START		0x0B	//ATS
#define CANBUS_CMD_WAVEFORM_READ_DATA		0x0C	//ATS
#define CANBUS_CMD_WAVEFORM_READ_STOP		0x0D	//ATS



// 06 FW_UPDATE
#define CANBUS_CMD_FW_UPDATE_START			0x03	//ALL
#define CANBUS_CMD_FW_UPDATE_HEADER_START	0x04	//ALL
#define CANBUS_CMD_FW_UPDATE_HEADER_DATA	0x05	//ALL
#define CANBUS_CMD_FW_UPDATE_HEADER_STOP	0x06	//ALL
#define CANBUS_CMD_FW_UPDATE_BLOCK_START	0x07	//ALL
#define CANBUS_CMD_FW_UPDATE_BLOCK_DATA		0x08	//ALL
#define CANBUS_CMD_FW_UPDATE_BLOCK_STOP		0x09	//ALL
#define CANBUS_CMD_FW_UPDATE_STOP			0x0A	//ALL




// 1E FAULTINJECT
#define CANBUS_CMD_EDIT_STATUS_WORD     	0x01	//ALL->remove
#define CANBUS_CMD_EDIT_STATUS_VOUT     	0x02	//D2D
#define CANBUS_CMD_EDIT_STATUS_IOUT     	0x03	//D2D
#define CANBUS_CMD_EDIT_STATUS_INPUT    	0x04	//ATS
#define CANBUS_CMD_EDIT_STATUS_TRANSFER   	0x05	//ATS->remove
#define CANBUS_CMD_EDIT_STATUS_RELAYS  		0x06	//ATS->remove
#define CANBUS_CMD_EDIT_STATUS_TEMP	 		0x07	//ALL
#define CANBUS_CMD_EDIT_STATUS_OTHER	 	0x08	//ALL
#define CANBUS_CMD_EDIT_STATUS_LED	 		0x09	//ALL->remove
#define CANBUS_CMD_EDIT_STATUS_FANS	 		0x0A	//D2D
#define CANBUS_CMD_EDIT_STATUS_ATS_SOURCE	0x0B	//ATS->remove
#define CANBUS_CMD_EDIT_STATUS_BOOTLOADER	0xD3	//ALL->remove
#define CANBUS_CMD_EDIT_BATTERY_MODE		0x30	//BBU
#define CANBUS_CMD_EDIT_STATUS_BATTERY		0x40	//BBU
#define CANBUS_CMD_EDIT_TEMP                0x41	//ALL->For test code
#define CANBUS_CMD_EDIT_VBulk               0x99    //ALL->For test code



// 1F MFR
#define CANBUS_CMD_FACTORY_MODE     		0x00
#define CANBUS_CMD_CALIBRATION_KEY     		0x01
#define CANBUS_CMD_CALIBRATION_CLEAR     	0x02
#define CANBUS_CMD_CALIBRATION_STORE     	0x03
#define CANBUS_CMD_CALIBRATION_READ_STSTUS 	0x04
#define CANBUS_CMD_INTERNAL_DEBUGGER		0x05
//#define CANBUS_CMD_FAULTINJECT_DATA 		0x06
#define CANBUS_CMD_RESET_EEPROM_LOG 		0x07
#define CANBUS_CMD_INTERNAL_REVISION 		0x08
#define CANBUS_CMD_FW_RELEASE_DATE 			0x09

#define CANBUS_CMD_STATUS_PFC 				0x10
#define CANBUS_CMD_STATUS_PFC2D2D 			0x11
#define CANBUS_CMD_STATUS_D2D2PFC 			0x12
#define CANBUS_CMD_STATUS_INPUT_ATS			0x13

#define CANBUS_CMD_READ_VS1		 			0x15
#define CANBUS_CMD_READ_VS2		 			0x16
#define CANBUS_CMD_READ_IAC		 			0x17
#define CANBUS_CMD_READ_VBULK	 			0x18
#define CANBUS_CMD_READ_POS_TOTAL           0x19
#define CANBUS_CMD_READ_POS_LAST            0x1A
#define CANBUS_CMD_READ_PFC_TEMP            0x1B
#define CANBUS_CMD_READ_D2D_TEMP            0x1C
#define CANBUS_CMD_READ_VPFC	            0x1D
#define CANBUS_CMD_READ_DEBUG_1	            0x1E
#define CANBUS_CMD_READ_DEBUG_2	            0x1F


#define CANBUS_CMD_CALI_VS1		 			0x20
#define CANBUS_CMD_CALI_VS2		 			0x21
#define CANBUS_CMD_CALI_VPFC	 			0x22
#define CANBUS_CMD_CALI_VBULK	 			0x30
#define CANBUS_CMD_CALI_IAC		 			0x40

#define CANBUS_CMD_PI_KEY		 			0x60
#define CANBUS_CMD_PI_V_KP		 			0x61
#define CANBUS_CMD_PI_V_KI		 			0x62
#define CANBUS_CMD_PI_I_KP		 			0x63
#define CANBUS_CMD_PI_I_KI		 			0x64
#define CANBUS_CMD_PI_D_F_S		 			0x65
#define CANBUS_CMD_PI_V_PIOUT	 			0x66
#define CANBUS_CMD_VBULK_REF	 			0x67
#define CANBUS_CMD_Duty_feedward_Gain       0x68
#define CANBUS_CMD_PFC_SoftStart_Count      0x69
#define CANBUS_CMD_Nromal_Phase_Change      0x70
#define CANBUS_CMD_SoftStart_Phase_Change   0x71
#define CANBUS_CMD_SoftStart_IntegralGain   0x72
#define CANBUS_CMD_SoftStart_Iref           0x73
#define CANBUS_CMD_BlackBox_Record_Harmonic 0x74    //Only for BlackBox record harmonic


// 2F Variable
#define CANBUS_CMD_BMC_UNIX_TIMESTAMP		0x01	//ALL
#define CANBUS_CMD_ATS_PRIMARY_SOURCE		0x02	//ATS
#define CANBUS_CMD_SINGLE_FEED_MODE         0x03	//ATS
#define CANBUS_CMD_OBSERVE_WINDOW           0x04	//ATS
#define CANBUS_CMD_OUTAGE_DELAY             0x05	//ATS
#define CANBUS_CMD_WALKIN_LOW               0x06	//ATS
#define CANBUS_CMD_WALKIN_HIGH              0x07	//ATS
#define CANBUS_CMD_STABILIZATION_DELAY      0x08	//ATS
#define CANBUS_CMD_BLACKBOX_PAGE            0x09	//ALL
#define CANBUS_CMD_WAVEFORM_PAGE            0x0A	//ATS
#define CANBUS_CMD_REQ_PSU_COUNT            0x0B	//D2D
#define CANBUS_CMD_BBU_SWITCH_THRESHOLD     0x0C	//BBU
#define CANBUS_CMD_BBU_EMERGENCY_THRESHOLD  0x0D	//BBU
#define CANBUS_CMD_REQ_BBU_NUMBER  			0x0E	//ATS
#define CANBUS_CMD_HEARTBEAT_TIMEOUT		0x0F	//ALL
#define CANBUS_CMD_TRANSITION_DELAY			0x10	//BBU
#define CANBUS_CMD_FAULT_COUNT				0x11	//ALL
#define CANBUS_CMD_FAULT_COUNT_LIMIT		0x12	//ALL
#define CANBUS_CMD_STARTUP_TIMEOUT			0x13	//D2D
#define CANBUS_CMD_FAULT_DELAY				0x14	//ALL
#define CANBUS_CMD_PEAKSHAVING_ENABLE		0x15	//BBU
#define CANBUS_CMD_PEAKSHAVING_SET			0x16	//BBU
#define CANBUS_CMD_POWER_SHEDDING_ENABLE	0x17	//D2D
#define CANBUS_CMD_DELAY_NO_PSC				0x18	//D2D
#define CANBUS_CMD_MAXIMUM_CHARGE_SETTING	0x19	//BBU
#define CANBUS_CMD_CANBUS_TIMEOUT 			0x1A	//BBU
#define CANBUS_CMD_NOMINAL_VOLTAGE 		    0x1B	//ATS




/****************************************************************************
	Public enumeration definition 
****************************************************************************/
enum eCANBusLiteralMonitorEnumeration
{
    eCANBusData_LM_VS1,
    eCANBusData_LM_VS2,
    eCANBusData_LM_VAC,
    eCANBusData_LM_IAC,
    eCANBusData_LM_FS1,
    eCANBusData_LM_FS2,
    eCANBusData_LM_PS1,
    eCANBusData_LM_PS2,
    eCANBusData_LM_MAXPS1,
    eCANBusData_LM_MAXPS2,
    eCANBusData_LM_AVGPS1,
    eCANBusData_LM_AVGPS2,
    eCANBusData_LM_TINLET,
    eCANBusData_LM_TATS,
    eCANBusData_LM_VAUX1,
    eCANBusData_LM_VAUX2,
    eCANBusData_LM_IAUX1,
    eCANBusData_LM_IAUX2,
    eCANBusData_LM_VBULK,
    eCANBusData_LM_TPFC,
    eCANBusData_LM_TD2D,
    eCANBusData_LM_VPFC,
    eCANBusData_LM_Read_VS1_Harmonic,
    eCANBusData_LM_Read_VS2_Harmonic,
    eCANBusData_LM_Read_VS1_Harmonic_2,
    eCANBusData_LM_Read_VS2_Harmonic_2,
    eCANBusData_LM_Num,
};


typedef enum eCANBusSensorData
{
    eCANBUS_SENSOR_STATUS_WORD,
	eCANBUS_SENSOR_STATUS_INPUT,
    eCANBUS_SENSOR_STATUS_TRANSFER,
    eCANBUS_SENSOR_STATUS_TEMP,
    eCANBUS_SENSOR_STATUS_OTHER,
    eCANBUS_SENSOR_STATUS_LED,
    eCANBUS_SENSOR_STATUS_ATS_SOURCE,
    eCANBUS_SENSOR_STATUS_CML,
    eCANBUS_SENSOR_STATUS_BOOTLOADER,
    eCANBUS_SENSOR_READ_VOLTAGE,
    eCANBUS_SENSOR_READ_CURRENT,
    eCANBUS_SENSOR_READ_FREQ,
    eCANBUS_SENSOR_READ_POWER,
    eCANBUS_SENSOR_READ_POWER_EXTRA,
    eCANBUS_SENSOR_READ_TEMP,
    eCANBUS_SENSOR_READ_ATS_SWITCH_TIMES,
    eCANBUS_SENSOR_READ_HARMONIC,
    eCANBUS_SENSOR_READ_HARMONIC_2,
    eCANBUS_SENSOR_READ_VOLTAGE_EXTRA,
    eCANBUS_SENSOR_READ_CURRENT_EXTRA,
    eCANBUS_SENSOR_READ_BBU_COUNT,
    eCANBUS_SENSOR_READ_FW_REVISION,
    eCANBUS_SENSOR_Num,
}eCANBusSensorData_t;


typedef enum eCANBusProtocol
{
    CANBUS_Protocol_Broadcast,
    CANBUS_Protocol_Read,
    CANBUS_Protocol_Write,
    CANBUS_Protocol_WandR,
    CANBUS_Protocol_WorR,
}eCANBusProtocol_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef struct sLiteralMonitor
{
    struct
    {
        i16_t* pi16Reg;
        u16_t u16Gain;
        sGuardVarList_t* psGuardVarList;
    }sSource;
    
    u16_t u16LiteralValue;
    i8_t i8Exponent;    
}sLiteralMonitor_t;


typedef struct sCANBusPageData
{
	u8_t u8Length;					// individual data length(priority readlength > writelength)
	u8_t u8Array;					// 0: Read data is not u8 Array, 1: Read data is u8 Array and length > 1
    u8_t* pu8ReadBuff;				// point to read data
    sGuardVarList_t* psWriteBuff;	// point to GV
    struct sCANBusPageData* psNext;
}sCANBusPageData_t;

typedef struct sCANBusCmdStr
{
	u8_t u8Command_Type;			// A
    u8_t u8Command;					// CC
	u8_t u8Protocol;				// Read, Write, Broadcast...
	u8_t u8Page;					// One page or multi page 
    u8_t u8ReadLength;				// Total Read length
    u8_t u8WriteLength;    			// Total write length, choose max length if spec define variable
    sCANBusPageData_t* psData;
}sCANBusCmdStr_t;



/****************************************************************************
	Public export variable
****************************************************************************/
extern u8_t pu8SensorData[eCANBUS_SENSOR_Num];
extern sLiteralMonitor_t ptsLiteralMonitor[eCANBusData_LM_Num];

/****************************************************************************
	Public export function prototype
****************************************************************************/
i32_t Literal_To_Real(u16_t u16Literal, u16_t u16Gain);
extern sCANBusCmdStr_t* CANBusData_GetCommandStructure(u8_t u8CommandType, u8_t u8Command);
extern void CANBusData_10ms_Periodically_Process(void);
extern void CANBusData_Set_BlackBox_Data_Length(u8_t Length);
extern void CANBusData_Set_Waveform_Data_Length(u8_t Length);
extern void LiteralMonitor_Update(sLiteralMonitor_t* psMonitor);
extern void CANBusData_Initialize(void);

#endif
