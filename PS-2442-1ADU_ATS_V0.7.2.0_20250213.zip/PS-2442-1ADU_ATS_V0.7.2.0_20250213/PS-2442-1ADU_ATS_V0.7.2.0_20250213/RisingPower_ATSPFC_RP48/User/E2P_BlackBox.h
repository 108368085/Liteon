/** @file       E2P_BlackBox.h
 *  @brief      Header file for Black Box
 *  @author     Adonis Wang
 *  @version    2.0
 *  @date       2017-10-25 1.0 create by ollie
 */
 
#ifndef _E2P_BLACKBOX_H_
#define _E2P_BLACKBOX_H_

#include "E2P_Waveform.h"
#include "E2P_Driver.h"
#include "CONFIG_Define.h"



/****************************************************************************
    Public parameter definition
****************************************************************************/
#define MAXIMUM_BLACK_BOX_EVENT_NUMBER			10			// 10
#define E2P_BLACK_BOX_RETRIEVE_SIZE				64
#define E2P_BLACK_BOX_PUBLISH_SIZE				8
#define BLACK_BOX_STORE_ADDRESS_OFFSET          1280  // EEPROM of page 20 start for Black box of page1
                                                      // 512 Kbit (64 Kbytes) of EEPROM , 1024 pages of 64 bytes (Address size is 0xFFFF)

#define E2P_BLACKBOX_PAGE						tsBlackBoxHandler.sPublisher.u8BlackBox_Page
#define E2P_BLACKBOX_BLOCK_SEQUENCE				tsBlackBoxHandler.sPublisher.u16BlackBox_Read_Block_Sequence
#define E2P_BLACKBOX_RESPONSE_READ_START		tsBlackBoxHandler.sPublisher.u32BlackBox_Response_Read_Start

#define E2P_WAVEFORM_PAGE						tsBlackBoxHandler.sPublisher.u8Waveform_Page
#define E2P_WAVEFORM_BLOCK_SEQUENCE				tsBlackBoxHandler.sPublisher.u16Waveform_Read_Block_Sequence
#define E2P_WAVEFORM_RESPONSE_READ_START		tsBlackBoxHandler.sPublisher.u32Waveform_Response_Read_Start
#define E2P_WAVEFORM_ACK						tsBlackBoxHandler.sPublisher.u8Waveform_ACK

#define E2P_BLACKBOX_PUBLISH_DATA				tsBlackBoxHandler.sPublisher.pu8PublishData
#define E2P_BLACKBOX_CRC8						tsBlackBoxHandler.sPublisher.u8DataCRC8

#define SET_BLACKBOX_RECORD_EVENT_NUM			tsBlackBoxHandler.u16RecordedEventNumber
#define SET_BLACKBOX_LATEST_INDEX				tsBlackBoxHandler.i16LatestSectionIndex

#define SET_BLACKBOX_WAVEFORM_CAPTURE_0			tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_Capture = 0
#define SET_BLACKBOX_WAVEFORM_CAPTURE_1			tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_Capture = 1


/****************************************************************************
	Public macro definition
****************************************************************************/


// BLACK BOX DATA MAP, size unit is byte
// Per page is 64 bytes , we use 65 page in one event

#define BLACKBOX_ADDR_BMC_UNIX_TIMESTAMP		0
#define BLACKBOX_SIZE_BMC_UNIX_TIMESTAMP		4

#define BLACKBOX_ADDR_STATUS_WORD				(BLACKBOX_ADDR_BMC_UNIX_TIMESTAMP + BLACKBOX_SIZE_BMC_UNIX_TIMESTAMP)
#define BLACKBOX_SIZE_STATUS_WORD				2

#define BLACKBOX_ADDR_STATUS_TRANSFER			(BLACKBOX_ADDR_STATUS_WORD + BLACKBOX_SIZE_STATUS_WORD)
#define BLACKBOX_SIZE_STATUS_TRANSFER			2

#define BLACKBOX_ADDR_STATUS_ATS_SOURCE			(BLACKBOX_ADDR_STATUS_TRANSFER + BLACKBOX_SIZE_STATUS_TRANSFER)
#define BLACKBOX_SIZE_STATUS_ATS_SOURCE			1

#define BLACKBOX_ADDR_STATUS_RELAY_S1			(BLACKBOX_ADDR_STATUS_ATS_SOURCE + BLACKBOX_SIZE_STATUS_ATS_SOURCE)
#define BLACKBOX_SIZE_STATUS_RELAY_S1			1

#define BLACKBOX_ADDR_STATUS_RELAY_S2			(BLACKBOX_ADDR_STATUS_RELAY_S1 + BLACKBOX_SIZE_STATUS_RELAY_S1)
#define BLACKBOX_SIZE_STATUS_RELAY_S2			1

#define BLACKBOX_ADDR_STATUS_RELAY_PFC			(BLACKBOX_ADDR_STATUS_RELAY_S2 + BLACKBOX_SIZE_STATUS_RELAY_S2)
#define BLACKBOX_SIZE_STATUS_RELAY_PFC			1

#define BLACKBOX_ADDR_STATUS_TEMP				(BLACKBOX_ADDR_STATUS_RELAY_PFC + BLACKBOX_SIZE_STATUS_RELAY_PFC)
#define BLACKBOX_SIZE_STATUS_TEMP				1

#define BLACKBOX_ADDR_STATUS_OTHER				(BLACKBOX_ADDR_STATUS_TEMP + BLACKBOX_SIZE_STATUS_TEMP)
#define BLACKBOX_SIZE_STATUS_OTHER				1

#define BLACKBOX_ADDR_STATUS_LED				(BLACKBOX_ADDR_STATUS_OTHER + BLACKBOX_SIZE_STATUS_OTHER)
#define BLACKBOX_SIZE_STATUS_LED				1

#define BLACKBOX_ADDR_STATUS_BOOTLOADER			(BLACKBOX_ADDR_STATUS_LED + BLACKBOX_SIZE_STATUS_LED)
#define BLACKBOX_SIZE_STATUS_BOOTLOADER			1

#define BLACKBOX_ADDR_READ_VS1					(BLACKBOX_ADDR_STATUS_BOOTLOADER + BLACKBOX_SIZE_STATUS_BOOTLOADER)
#define BLACKBOX_SIZE_READ_VS1					2

#define BLACKBOX_ADDR_READ_VS2					(BLACKBOX_ADDR_READ_VS1 + BLACKBOX_SIZE_READ_VS1)
#define BLACKBOX_SIZE_READ_VS2					2

#define BLACKBOX_ADDR_READ_VAC					(BLACKBOX_ADDR_READ_VS2 + BLACKBOX_SIZE_READ_VS2)
#define BLACKBOX_SIZE_READ_VAC					2

#define BLACKBOX_ADDR_READ_IAC					(BLACKBOX_ADDR_READ_VAC + BLACKBOX_SIZE_READ_VAC)
#define BLACKBOX_SIZE_READ_IAC					2

#define BLACKBOX_ADDR_READ_FS1					(BLACKBOX_ADDR_READ_IAC + BLACKBOX_SIZE_READ_IAC)
#define BLACKBOX_SIZE_READ_FS1					2

#define BLACKBOX_ADDR_READ_FS2					(BLACKBOX_ADDR_READ_FS1 + BLACKBOX_SIZE_READ_FS1)
#define BLACKBOX_SIZE_READ_FS2					2

#define BLACKBOX_ADDR_READ_PS1					(BLACKBOX_ADDR_READ_FS2 + BLACKBOX_SIZE_READ_FS2)
#define BLACKBOX_SIZE_READ_PS1					2

#define BLACKBOX_ADDR_READ_PS2					(BLACKBOX_ADDR_READ_PS1 + BLACKBOX_SIZE_READ_PS1)
#define BLACKBOX_SIZE_READ_PS2					2

#define BLACKBOX_ADDR_READ_MAXPS1				(BLACKBOX_ADDR_READ_PS2 + BLACKBOX_SIZE_READ_PS2)
#define BLACKBOX_SIZE_READ_MAXPS1				2

#define BLACKBOX_ADDR_READ_MAXPS2				(BLACKBOX_ADDR_READ_MAXPS1 + BLACKBOX_SIZE_READ_MAXPS1)
#define BLACKBOX_SIZE_READ_MAXPS2				2

#define BLACKBOX_ADDR_READ_AVGPS1				(BLACKBOX_ADDR_READ_MAXPS2 + BLACKBOX_SIZE_READ_MAXPS2)
#define BLACKBOX_SIZE_READ_AVGPS1				2

#define BLACKBOX_ADDR_READ_AVGPS2				(BLACKBOX_ADDR_READ_AVGPS1 + BLACKBOX_SIZE_READ_AVGPS1)
#define BLACKBOX_SIZE_READ_AVGPS2				2

#define BLACKBOX_ADDR_READ_TINLET				(BLACKBOX_ADDR_READ_AVGPS2 + BLACKBOX_SIZE_READ_AVGPS2)
#define BLACKBOX_SIZE_READ_TINLET				2

#define BLACKBOX_ADDR_READ_TATS					(BLACKBOX_ADDR_READ_TINLET + BLACKBOX_SIZE_READ_TINLET)
#define BLACKBOX_SIZE_READ_TATS					2

#define BLACKBOX_ADDR_READ_SWITCH_TIMES			(BLACKBOX_ADDR_READ_TATS + BLACKBOX_SIZE_READ_TATS)
#define BLACKBOX_SIZE_READ_SWITCH_TIMES			4

#define BLACKBOX_ADDR_READ_TOTAL_SWITCH_TIMES	(BLACKBOX_ADDR_READ_SWITCH_TIMES + BLACKBOX_SIZE_READ_SWITCH_TIMES)
#define BLACKBOX_SIZE_READ_TOTAL_SWITCH_TIMES	4

#define BLACKBOX_ADDR_READ_VS1_HARMONIC			(BLACKBOX_ADDR_READ_TOTAL_SWITCH_TIMES + BLACKBOX_SIZE_READ_TOTAL_SWITCH_TIMES)
#define BLACKBOX_SIZE_READ_VS1_HARMONIC			2

#define BLACKBOX_ADDR_READ_VS2_HARMONIC			(BLACKBOX_ADDR_READ_VS1_HARMONIC + BLACKBOX_SIZE_READ_VS1_HARMONIC)
#define BLACKBOX_SIZE_READ_VS2_HARMONIC			2

#define BLACKBOX_ADDR_READ_BBU_COUNT			(BLACKBOX_ADDR_READ_VS2_HARMONIC + BLACKBOX_SIZE_READ_VS2_HARMONIC)
#define BLACKBOX_SIZE_READ_BBU_COUNT			1

#define BLACKBOX_ADDR_READ_VAUX1				(BLACKBOX_ADDR_READ_BBU_COUNT + BLACKBOX_SIZE_READ_BBU_COUNT)
#define BLACKBOX_SIZE_READ_VAUX1				2

#define BLACKBOX_ADDR_READ_VAUX2				(BLACKBOX_ADDR_READ_VAUX1 + BLACKBOX_SIZE_READ_VAUX1)
#define BLACKBOX_SIZE_READ_VAUX2				2

#define BLACKBOX_ADDR_READ_IAUX1				(BLACKBOX_ADDR_READ_VAUX2 + BLACKBOX_SIZE_READ_VAUX2)
#define BLACKBOX_SIZE_READ_IAUX1				2

#define BLACKBOX_ADDR_READ_IAUX2				(BLACKBOX_ADDR_READ_IAUX1 + BLACKBOX_SIZE_READ_IAUX1)
#define BLACKBOX_SIZE_READ_IAUX2				2

#define BLACKBOX_ADDR_MAJOR_REVISION			(BLACKBOX_ADDR_READ_IAUX2 + BLACKBOX_SIZE_READ_IAUX2)
#define BLACKBOX_SIZE_MAJOR_REVISION			1

#define BLACKBOX_ADDR_MINOR_REVISION			(BLACKBOX_ADDR_MAJOR_REVISION + BLACKBOX_SIZE_MAJOR_REVISION)
#define BLACKBOX_SIZE_MINOR_REVISION			1

#define BLACKBOX_ADDR_ATS_PRI_SRC				(BLACKBOX_ADDR_MINOR_REVISION + BLACKBOX_SIZE_MINOR_REVISION)
#define BLACKBOX_SIZE_ATS_PRI_SRC				1

#define BLACKBOX_ADDR_SINGLE_FEED_MODE			(BLACKBOX_ADDR_ATS_PRI_SRC + BLACKBOX_SIZE_ATS_PRI_SRC)
#define BLACKBOX_SIZE_SINGLE_FEED_MODE			1

#define BLACKBOX_ADDR_OBSERVE_WINDOW			(BLACKBOX_ADDR_SINGLE_FEED_MODE + BLACKBOX_SIZE_SINGLE_FEED_MODE)
#define BLACKBOX_SIZE_OBSERVE_WINDOW			1

#define BLACKBOX_ADDR_OUTAGE_DELAY				(BLACKBOX_ADDR_OBSERVE_WINDOW + BLACKBOX_SIZE_OBSERVE_WINDOW)
#define BLACKBOX_SIZE_OUTAGE_DELAY				1

#define BLACKBOX_ADDR_WALKIN_LOW				(BLACKBOX_ADDR_OUTAGE_DELAY + BLACKBOX_SIZE_OUTAGE_DELAY)
#define BLACKBOX_SIZE_WALKIN_LOW				1

#define BLACKBOX_ADDR_WALKIN_HIGH				(BLACKBOX_ADDR_WALKIN_LOW + BLACKBOX_SIZE_WALKIN_LOW)
#define BLACKBOX_SIZE_WALKIN_HIGH				1

#define BLACKBOX_ADDR_STABILIZATION_DELAY		(BLACKBOX_ADDR_WALKIN_HIGH + BLACKBOX_SIZE_WALKIN_HIGH)
#define BLACKBOX_SIZE_STABILIZATION_DELAY		2

#define BLACKBOX_ADDR_BLACKBOX_PAGE				(BLACKBOX_ADDR_STABILIZATION_DELAY + BLACKBOX_SIZE_STABILIZATION_DELAY)
#define BLACKBOX_SIZE_BLACKBOX_PAGE				1

#define BLACKBOX_ADDR_BLACKBOX_RESERVED			(BLACKBOX_ADDR_BLACKBOX_PAGE + BLACKBOX_SIZE_BLACKBOX_PAGE)
#define BLACKBOX_SIZE_BLACKBOX_RESERVED			52

#define BLACKBOX_ADDR_WAVEFORM_LOG				(BLACKBOX_ADDR_BLACKBOX_RESERVED + BLACKBOX_SIZE_BLACKBOX_RESERVED)
#define BLACKBOX_SIZE_WAVEFORM_LOG				4000

#define BLACKBOX_ADDR_RESERVED					(BLACKBOX_ADDR_WAVEFORM_LOG + BLACKBOX_SIZE_WAVEFORM_LOG)
#define BLACKBOX_SIZE_RESERVED					32

#define BLACKBOX_DATA_SIZE						BLACKBOX_ADDR_RESERVED
#define BLACKBOX_EVENT_SIZE						(BLACKBOX_DATA_SIZE + BLACKBOX_SIZE_RESERVED)


/****************************************************************************
	Public enumeration definition 
****************************************************************************/
typedef enum eBlackBoxItemTag
{
	eBLACKBOX_ITEM_BMC_UNIX_TIMESTAMP,
	eBLACKBOX_ITEM_STATUS_WORD,
	eBLACKBOX_ITEM_STATUS_TRANSFER,
	eBLACKBOX_ITEM_STATUS_ATS_SOURCE,
	eBLACKBOX_ITEM_STATUS_RELAY_S1,
	eBLACKBOX_ITEM_STATUS_RELAY_S2,
	eBLACKBOX_ITEM_STATUS_RELAY_PFC,
	eBLACKBOX_ITEM_STATUS_TEMP,
	eBLACKBOX_ITEM_STATUS_OTHER,
	eBLACKBOX_ITEM_STATUS_LED,
	eBLACKBOX_ITEM_STATUS_BOOTLOADER,
	eBLACKBOX_ITEM_READ_VS1,
	eBLACKBOX_ITEM_READ_VS2,
	eBLACKBOX_ITEM_READ_VAC,
	eBLACKBOX_ITEM_READ_IAC,
	eBLACKBOX_ITEM_READ_FS1,
	eBLACKBOX_ITEM_READ_FS2,
	eBLACKBOX_ITEM_READ_PS1,
	eBLACKBOX_ITEM_READ_PS2,
	eBLACKBOX_ITEM_READ_MAXPS1,
	eBLACKBOX_ITEM_READ_MAXPS2,
	eBLACKBOX_ITEM_READ_AVGPS1,
	eBLACKBOX_ITEM_READ_AVGPS2,
	eBLACKBOX_ITEM_READ_TINLET,
	eBLACKBOX_ITEM_READ_TATS,
	eBLACKBOX_ITEM_READ_SWITCH_TIMES,
	eBLACKBOX_ITEM_READ_TOTAL_SWITCH_TIMES,
	eBLACKBOX_ITEM_READ_VS1_HARMONIC,
	eBLACKBOX_ITEM_READ_VS2_HARMONIC,
	eBLACKBOX_ITEM_READ_BBU_COUNT,
	eBLACKBOX_ITEM_READ_VAUX1,
	eBLACKBOX_ITEM_READ_VAUX2,
	eBLACKBOX_ITEM_READ_IAUX1,
	eBLACKBOX_ITEM_READ_IAUX2,
	eBLACKBOX_ITEM_MAJOR_REVISION,
	eBLACKBOX_ITEM_MINOR_REVISION,
	eBLACKBOX_ITEM_ATS_PRI_SRC,
	eBLACKBOX_ITEM_SINGLE_FEED_MODE,
	eBLACKBOX_ITEM_OBSERVE_WINDOW,
	eBLACKBOX_ITEM_OUTAGE_DELAY,
	eBLACKBOX_ITEM_WALKIN_LOW,
	eBLACKBOX_ITEM_WALKIN_HIGH,
	eBLACKBOX_ITEM_STABILIZATION_DELAY,
	eBLACKBOX_ITEM_BLACKBOX_PAGE,
	eBLACKBOX_ITEM_BLACKBOX_RESERVED,
	eBLACKBOX_ITEM_WAVEFORM_LOG,
	eBLACKBOX_ITEM_NUM,
}eBlackBoxItemTag_t;

/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef struct sBlackBoxItem
{
    eBlackBoxItemTag_t eTag;
    u16_t u16Address;	// EEPROM address
    u16_t u16Size;
    u8_t* pu8Source;    // point to PMbusdata/CANbusdata
}sBlackBoxItem_t;

typedef union nBlackBoxRecorderFlag
{
    u16_t u16All;
    struct
    {
        u16_t u1Recording       : 1;        // Recorder is collecting data to RAM when bit was asserted
        u16_t u1Awaiting        : 1;        // Recorder is awaiting EEPROM when bit was asserted
        u16_t u1Storing         : 1;        // Recorder is storing data to EEPROM when bit was asserted
        u16_t u1Failure         : 1;        // Recorder trigger an error while push data into EEPROM
        u16_t u1Interrupted     : 1;
		u16_t uReserved       	: 11;
    }u16Bits;
}nBlackBoxRecorderFlag_t;

typedef struct sBlackBoxRecorder
{
    nBlackBoxRecorderFlag_t nFlag;
    u8_t pu8Data[BLACKBOX_DATA_SIZE];
    u16_t u16PushingBytes;
    u16_t u16StoredBytes;
    u16_t u16FailureRetryTimes;
    sWaveformRecorderConfig_t sWaveformRecorderConfig;
}sBlackBoxRecorder_t;

typedef union nBlackBoxPublisherFlag
{
    u16_t u16All;
    struct
    {
        u16_t u1BlackBox_ReadStart	: 1;	// Receive read start and check EEPROM data
        u16_t u1BlackBox_ReadData	: 1;	// Receive read Data and start to retrieve EEPROM data
        u16_t u1Waveform_ReadStart	: 1;	// Receive read start and check EEPROM data
        u16_t u1Waveform_ReadData	: 1;	// Receive read Data and start to retrieve EEPROM data
        u16_t u1Awaiting        	: 1;	// Publisher is awaiting EEPROM idle when bit was asserted 
        u16_t u1Retrieving      	: 1;	// Publisher is retrieving data form EEPROM when bit was asserted
        u16_t u1Failure         	: 1;	// Publisher trigger an error while retrieve data from EEPROM
		u16_t u1Waveform_Capture   	: 1;	// 1: waveform capture finished, 0:no waveform capture data
		u16_t uReserved       		: 8;
    }u16Bits;
}nBlackBoxPublisherFlag_t;

typedef struct sBlackBoxPublisher
{
    nBlackBoxPublisherFlag_t nFlag;

	u8_t  u8BlackBox_Page;					// Inquiry which blackbox page, value region is from 0 to (MAXIMUM_BLACK_BOX_EVENT_NUMBER-1)
	u32_t u32BlackBox_Max_Block_Number;		// Maximum block sequency, 0,1,2..
	u32_t u32BlackBox_Byte_of_LastBlock;	// Number of bytes in the last Block
	u32_t u32BlackBox_Response_Read_Start;	// Mix of ACK, Max_Block_Number and Byte_of_LastBlock
	u16_t u16BlackBox_Read_Block_Sequence;	// Attempt to Read which block sequency, 0,1,2..	

	u8_t  u8Waveform_Page;
	u32_t u32Waveform_Max_Block_Number;		// Maximum block sequency, 0,1,2..
	u32_t u32Waveform_Byte_of_LastBlock;	// Number of bytes in the last Block
	u32_t u32Waveform_Response_Read_Start;	// Mix of ACK, Max_Block_Number and Byte_of_LastBlock
	u16_t u16Waveform_Read_Block_Sequence;	// Attempt to Read which block sequency, 0,1,2..

	u8_t  u8Waveform_ACK;
	u8_t  u8DataCRC8;						// Publish data CRC8
    u16_t u16FailureRetryTimes;
	
    u8_t pu8RetrieveData[E2P_BLACK_BOX_RETRIEVE_SIZE];	// retrieve data from EEPROM
    u8_t pu8PublishData[E2P_BLACK_BOX_PUBLISH_SIZE];	// Publish data to Canbus
}sBlackBoxPublisher_t;

typedef struct sBlackBoxHandler
{	
    u16_t u16RecordedEventNumber;           // How many event is stored in EEPROM
    i16_t i16LatestSectionIndex;            // Section index of latest event
    i16_t i16ReportBaseIndex;               // Based index of the publisher
    
    sBlackBoxRecorder_t sRecorder;			// MCU to EEPROM
    sBlackBoxPublisher_t sPublisher;   		// EEPROM to MCU
    sE2pDriverInfo_t* psE2pDriver;

}sBlackBoxHandler_t;


/****************************************************************************
	Public export variable
****************************************************************************/
extern sBlackBoxHandler_t tsBlackBoxHandler;

/****************************************************************************
	Public export function prototype
****************************************************************************/

extern void BlackBox_StartRecord(void);
extern void BlackBox_Waveform_Callback(void);
extern u16_t BlackBox_IsTargetEventExist(u16_t u16EventIndex);
extern void BlackBox_Read_Start(void);
extern void BlackBox_Read_Data(void);
extern void Waveform_Read_Start(void);
extern void Waveform_Read_Data(void);
extern void BlackBox_Background_Process(void);
extern void BlackBox_1min_Periodically_Process(void);
extern void BlackBox_Initial_Item(eBlackBoxItemTag_t eTag, u8_t* pu8Source);
extern void BlackBox_UpdateReportBaseIndex(void);
extern void BlackBox_Initialize(void);


#endif
