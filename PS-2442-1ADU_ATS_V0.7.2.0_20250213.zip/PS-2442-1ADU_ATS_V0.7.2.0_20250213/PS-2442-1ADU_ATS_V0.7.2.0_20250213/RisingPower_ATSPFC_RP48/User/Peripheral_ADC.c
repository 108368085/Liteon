/****************************************************************************
 *	File	Peripheral_ADC.c
 * 	Brief	Configure and control ADC module on TI 28004x platform
 *  @note       In this file, we use two ADC module: ADCa, ADCb and ADCc 
 *              In order to avoid switch noise interfere,
 *              ADCa have to handle 6 SOC
 *                  -SOC0: ADC_CHANNEL_I_PFC_B
 *                  -SOC1: ADC_CHANNEL_V_PFC_N
 *                  -SOC2: ADC_CHANNEL_V_AC1_L
 *                  -SOC3: ADC_CHANNEL_V_AC2_N
 *                  -SOC4: ADC_CHANNEL_T_INLET
 *                  -SOC5: ADC_CHANNEL_T_ATS
 *
 *              ADCb have to handle 5 SOC
 *                  -SOC0: ADC_CHANNEL_I_PFC_A
 *                  -SOC1: ADC_CHANNEL_V_PFC_L
 *                  -SOC2: ADC_CHANNEL_V_AC1_N
 *                  -SOC3: ADC_CHANNEL_V_AC2_L
 *                  -SOC4: ADC_CHANNEL_T_PFC
 *                  -SOC5: ADC_CHANNEL_T_D2D
 *
 *              ADCc have to handle 5 SOC
 *                  -SOC0: ADC_CHANNEL_V_PFC_OVP1
 *                  -SOC1: ADC_CHANNEL_V_PFC_DET
 *                  -SOC2: ADC_CHANNEL_V_PFC_OVP2
 *                  -SOC3: ADC_CHANNEL_V_AUX1
 *                  -SOC4: ADC_CHANNEL_V_AUX2
 *
 *  @note       This peripheral generate a interrupt after ADCa-EOC5 event triggered
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

#include "F28x_Project.h"
#include "Peripheral_ADC.h"
#include "Peripheral.h"
#include "sw_prioritized_isr_levels.h"
#include <string.h>
#include "SysTime.h"


/****************************************************************************
    Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/
//ADC_A
#define ADC_CHANNEL_I_PFC_B         eADCINA9
#define ADC_CHANNEL_V_PFC_N         eADCINA3
#define ADC_CHANNEL_V_AC1_L         eADCINA6
#define ADC_CHANNEL_V_AC2_N         eADCINA10
#define ADC_CHANNEL_T_INLET         eADCINA8
#define ADC_CHANNEL_T_ATS	        eADCINA5

//ADC_B
#define ADC_CHANNEL_I_PFC_A         eADCINB8
#define ADC_CHANNEL_V_PFC_L         eADCINB6
#define ADC_CHANNEL_V_AC1_N         eADCINB2
#define ADC_CHANNEL_V_AC2_L         eADCINB0
#define ADC_CHANNEL_T_PFC       	eADCINB4
#define ADC_CHANNEL_T_D2D       	eADCINB3


//ADC_C
#define ADC_CHANNEL_V_PFC_OVP1      eADCINC5
#define ADC_CHANNEL_V_PFC_DET       eADCINC1
#define ADC_CHANNEL_V_PFC_OVP2     	eADCINC3
#define ADC_CHANNEL_V_AUX1       	eADCINC0
#define ADC_CHANNEL_V_AUX2       	eADCINC2



/* S+H time is (ACQPS + 1)xSYSCLK cycles, (20+1)*10ns=210ns */
#define CONFIG_SOC(ADCREG, SOC_NUM, _CHSEL, _ACQPS, _TRIGSEL)                \
        do                                                                   \
        {                                                                    \
            ADCREG.ADC##SOC_NUM##CTL.bit.CHSEL = _CHSEL;                     \
            ADCREG.ADC##SOC_NUM##CTL.bit.ACQPS = _ACQPS;                     \
            ADCREG.ADC##SOC_NUM##CTL.bit.TRIGSEL = _TRIGSEL;                 \
        }while(0)
/****************************************************************************
	Private enumeration definition 
****************************************************************************/
enum ADC_CHSEL_ENUMERATION
{
    eADCINA0 = 0,
    eADCINA1,
    eADCINA2,
    eADCINA3,
    eADCINA4,
    eADCINA5,
    eADCINA6,
    eADCINA7,
    eADCINA8,
    eADCINA9,
    eADCINA10,
    eADCINB0 = eADCINA0,
    eADCINB1,
    eADCINB2,
    eADCINB3,
    eADCINB4,
    eADCINB5,
    eADCINB6,
    eADCINB7,
    eADCINB8,
    eADCINB9,
    eADCINB10,
    eADCINC0 = eADCINA0,
    eADCINC1,
    eADCINC2,
    eADCINC3,
    eADCINC4,
    eADCINC5,
    eADCINC6,
    eADCINC7,
    eADCINC8,
    eADCINC9,
    eADCINC10,
};

enum ADC_SOC_TRIGGER_ENUMERATION
{
    eAdcSoc_Trigger_Software = 0,
    eAdcSoc_Trigger_CpuTimer0,
    eAdcSoc_Trigger_CpuTimer1,
    eAdcSoc_Trigger_CpuTimer2,
    eAdcSoc_Trigger_ExternGPIO,
    eAdcSoc_Trigger_ePWM1_SOCA,
    eAdcSoc_Trigger_ePWM1_SOCB,
    eAdcSoc_Trigger_ePWM2_SOCA,
    eAdcSoc_Trigger_ePWM2_SOCB,
    eAdcSoc_Trigger_ePWM3_SOCA,
    eAdcSoc_Trigger_ePWM3_SOCB,
    eAdcSoc_Trigger_ePWM4_SOCA,
    eAdcSoc_Trigger_ePWM4_SOCB,
    eAdcSoc_Trigger_ePWM5_SOCA,
    eAdcSoc_Trigger_ePWM5_SOCB,
    eAdcSoc_Trigger_ePWM6_SOCA,
    eAdcSoc_Trigger_ePWM6_SOCB,
    eAdcSoc_Trigger_ePWM7_SOCA,
    eAdcSoc_Trigger_ePWM7_SOCB,
    eAdcSoc_Trigger_ePWM8_SOCA,
    eAdcSoc_Trigger_ePWM8_SOCB,
};

enum ADC_INT_TRIGGER_ENUMERATION
{
    eAdcInt_Trigger_EOC0,
    eAdcInt_Trigger_EOC1,
    eAdcInt_Trigger_EOC2,
    eAdcInt_Trigger_EOC3,
    eAdcInt_Trigger_EOC4,
    eAdcInt_Trigger_EOC5,
    eAdcInt_Trigger_EOC6,
    eAdcInt_Trigger_EOC7,
    eAdcInt_Trigger_EOC8,
    eAdcInt_Trigger_EOC9,
    eAdcInt_Trigger_EOC10,
    eAdcInt_Trigger_EOC11,
    eAdcInt_Trigger_EOC12,
    eAdcInt_Trigger_EOC13,
    eAdcInt_Trigger_EOC14,
    eAdcInt_Trigger_EOC15,
};

/****************************************************************************
	Private structure definition 
****************************************************************************/


/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 142
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(ISR_ADCa_EOC, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/
u16_t ADCResult[ADC_Tag_Num];


/**
 *  @brief  Interrupt for end of conversion event of high speed sampling on ADCa
 *  @note   Due to we need use software prioritized interrupt service,
 *          So we need to insert our application code between the branch mechanism code
 *  @retval None
 */
__interrupt void ISR_ADCa_EOC(void)
{
    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER1.all;   // Store IER
    IER |= M_INT1;
    IER &= MINT1;                                           // Set "global" priority
    PieCtrlRegs.PIEIER1.all &= MG1_1;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");
    EINT;
    
    /* User code Start */

	// ADToDo: use DMA
	ADCResult[ADC_I_PFC_B] 		= AdcaResultRegs.ADCRESULT0;
	ADCResult[ADC_V_PFC_N] 		= AdcaResultRegs.ADCRESULT1;
	ADCResult[ADC_V_AC1_L] 		= AdcaResultRegs.ADCRESULT2;
	ADCResult[ADC_V_AC2_N] 		= AdcaResultRegs.ADCRESULT3;
	ADCResult[ADC_T_INLET] 		= AdcaResultRegs.ADCRESULT4;
	ADCResult[ADC_T_ATS] 		= AdcaResultRegs.ADCRESULT5;
	
	ADCResult[ADC_I_PFC_A] 		= AdcbResultRegs.ADCRESULT0;
	ADCResult[ADC_V_PFC_L] 		= AdcbResultRegs.ADCRESULT1;
	ADCResult[ADC_V_AC1_N] 		= AdcbResultRegs.ADCRESULT2;
	ADCResult[ADC_V_AC2_L] 		= AdcbResultRegs.ADCRESULT3;
	ADCResult[ADC_T_PFC] 		= AdcbResultRegs.ADCRESULT4;
	ADCResult[ADC_T_D2D] 		= AdcbResultRegs.ADCRESULT5;
	
	ADCResult[ADC_V_PFC_OVP1] 	= AdccResultRegs.ADCRESULT0;
	ADCResult[ADC_V_PFC_DET] 	= AdccResultRegs.ADCRESULT1;
	ADCResult[ADC_V_PFC_OVP2] 	= AdccResultRegs.ADCRESULT2;
	ADCResult[ADC_V_AUX1] 		= AdccResultRegs.ADCRESULT3;
	ADCResult[ADC_V_AUX2] 		= AdccResultRegs.ADCRESULT4;

	INTERRUPT_ADC();

	/* User code End */

   
    //
    // Clear the interrupt flag
    //
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    //
    // Check if overflow has occurred
    //
    if (1 == AdcaRegs.ADCINTOVF.bit.ADCINT1)
    {
        AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
        AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
    }
   
    DINT;
    PieCtrlRegs.PIEIER1.all = TempPIEIER;      // Restore IER


    /* Branch mechanism code End */
}


/**
 *  @brief  Initial ADCa module
 *  @retval None
 */
static inline void PeriAdc_Initial_ADCa(void)
{
    EALLOW;
    
	/* Set ADCCLK divider to 2, 100M / 2 = 50MHz */
    AdcaRegs.ADCCTL2.bit.PRESCALE = 2;
	   
    /* Set pulse positions to late, EOC trips after conversion completed */
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    /* Configure each SOC of ADC
     *         ADCREG SOC_NUM      _CHSEL   		 _ACQPS 		_TRIGSEL
     */
    CONFIG_SOC(AdcaRegs, SOC0, ADC_CHANNEL_I_PFC_B,		20, eAdcSoc_Trigger_ePWM8_SOCA);
    CONFIG_SOC(AdcaRegs, SOC1, ADC_CHANNEL_V_PFC_N,		20, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdcaRegs, SOC2, ADC_CHANNEL_V_AC1_L,		20, eAdcSoc_Trigger_ePWM8_SOCA);
    CONFIG_SOC(AdcaRegs, SOC3, ADC_CHANNEL_V_AC2_N,		20, eAdcSoc_Trigger_ePWM8_SOCA);
	CONFIG_SOC(AdcaRegs, SOC4, ADC_CHANNEL_T_INLET,		20, eAdcSoc_Trigger_ePWM7_SOCA);
	CONFIG_SOC(AdcaRegs, SOC5, ADC_CHANNEL_T_ATS,		20, eAdcSoc_Trigger_ePWM8_SOCA);

    /* Configure ADCa_INT1 Interrupt */
    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = eAdcInt_Trigger_EOC5;  // End of EOC5 to trigger ADCa_INT1
    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;                       // Enable ADCa_INT1
    AdcaRegs.ADCINTSEL1N2.bit.INT1CONT = 1;                    // Enable ADCa_INT1 continue mode
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;                     // Make sure INT1 flag had been cleared

    /* Check if overflow has occurred */  
    if (1 == AdcaRegs.ADCINTOVF.bit.ADCINT1)
    {
        AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
    }
	
    /* 
     *  Enable IER and PieCtrlRegs for ADCa_INT1
     *  PIE Channel: 1.1
     */
    IER |= M_INT1;                    							// Enable PIE Group 1 interrupt
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;             				// Enable ADCa_INT1 in the PIE Group 1
    
    /* Re-mapped ADCa_INT1 interrupt function */
    PieVectTable.ADCA1_INT = &ISR_ADCa_EOC;

	/* Power up the ADC */
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    
    /* Delay 1000us to allow ADC time to power up */
    DELAY_US(1000);
	
    EDIS;
}


/**
 *  @brief  Initial ADCb module
 *  @retval None
 */
static inline void PeriAdc_Initial_ADCb(void)
{
    EALLOW;
    
	/* Set ADCCLK divider to 2, 100M / 2 = 50MHz */
    AdcbRegs.ADCCTL2.bit.PRESCALE = 2;
	
    /* Set pulse positions to late, EOC trips after conversion completed */
    AdcbRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    /* Configure each SOC of ADC
     *         ADCREG SOC_NUM      _CHSEL   		 _ACQPS 		_TRIGSEL
     */
    CONFIG_SOC(AdcbRegs, SOC0, ADC_CHANNEL_I_PFC_A,		20, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdcbRegs, SOC1, ADC_CHANNEL_V_PFC_L,		20, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdcbRegs, SOC2, ADC_CHANNEL_V_AC1_N,		20, eAdcSoc_Trigger_ePWM8_SOCA);
    CONFIG_SOC(AdcbRegs, SOC3, ADC_CHANNEL_V_AC2_L,		20, eAdcSoc_Trigger_ePWM8_SOCA);
	CONFIG_SOC(AdcbRegs, SOC4, ADC_CHANNEL_T_PFC,		20, eAdcSoc_Trigger_ePWM8_SOCA);
	CONFIG_SOC(AdcbRegs, SOC5, ADC_CHANNEL_T_D2D,		20, eAdcSoc_Trigger_ePWM7_SOCA);
	
    /* Power up the ADC */
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    
    /* Delay 1000us to allow ADC time to power up */
    DELAY_US(1000);
    
    EDIS;
}


/**
 *  @brief  Initial ADCc module
 *  @retval None
 */
static inline void PeriAdc_Initial_ADCc(void)
{
    EALLOW;
    
	/* Set ADCCLK divider to 2, 100M / 2 = 50MHz */
    AdccRegs.ADCCTL2.bit.PRESCALE = 2;
	    
    /* Set pulse positions to late, EOC trips after conversion completed */
    AdccRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    /* Configure each SOC of ADC
     *         ADCREG SOC_NUM      _CHSEL   		 _ACQPS 		_TRIGSEL
     */
    CONFIG_SOC(AdccRegs, SOC0, ADC_CHANNEL_V_PFC_OVP1,	20, eAdcSoc_Trigger_ePWM8_SOCA);
    CONFIG_SOC(AdccRegs, SOC1, ADC_CHANNEL_V_PFC_DET,	20, eAdcSoc_Trigger_ePWM8_SOCA);
	CONFIG_SOC(AdccRegs, SOC2, ADC_CHANNEL_V_PFC_OVP2,	20, eAdcSoc_Trigger_ePWM8_SOCA);
	CONFIG_SOC(AdccRegs, SOC3, ADC_CHANNEL_V_AUX1,		20, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdccRegs, SOC4, ADC_CHANNEL_V_AUX2,		20, eAdcSoc_Trigger_ePWM7_SOCA);
 
 
    /* Power up the ADC */
    AdccRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    
    /* Delay 1000us to allow ADC time to power up */
    DELAY_US(1000);
    
    EDIS;
}



/**
 *  @brief  Initial ADC module - Set ADC configurations and power up the ADC 
 *          for ADC A and ADC B
 *  @retval None
 */
void PeriAdc_Initialize(void)
{

#ifdef DEMO_BOARD
	SetVREF(ADC_ADCA, ADC_INTERNAL, ADC_VREF3P3);
	SetVREF(ADC_ADCB, ADC_INTERNAL, ADC_VREF3P3);
	SetVREF(ADC_ADCC, ADC_INTERNAL, ADC_VREF3P3);
#else
	SetVREF(ADC_ADCA, ADC_EXTERNAL, ADC_VREF3P3);
    SetVREF(ADC_ADCB, ADC_EXTERNAL, ADC_VREF3P3);
    SetVREF(ADC_ADCC, ADC_EXTERNAL, ADC_VREF3P3);
#endif

    PeriAdc_Initial_ADCa();
    PeriAdc_Initial_ADCb();
	PeriAdc_Initial_ADCc();
}

/**
 *  @brief  Start peripheral - ADC
 *  @retval None
 */
void PeriAdc_Start(void)
{
	;
}

/**
 *  @brief  Stop peripheral - ADC
 *  @retval None
 */
void PeriAdc_Stop(void)
{
    EALLOW;
    
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 0;
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 0;
	AdccRegs.ADCCTL1.bit.ADCPWDNZ = 0;
    DELAY_US(1000);

    /* Disable ADCa interrupt */
    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 0;
    
    /* Clear ADCa INT flag */
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

	/* Clear ADCa INT overflow flag */
	AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1;
    
    /* Disable ADCa interrupt in the PIE */
    PieCtrlRegs.PIEIER1.bit.INTx1 = 0;

    /* Acknowledge the PIE group 1 */
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
    
    EDIS;
}
