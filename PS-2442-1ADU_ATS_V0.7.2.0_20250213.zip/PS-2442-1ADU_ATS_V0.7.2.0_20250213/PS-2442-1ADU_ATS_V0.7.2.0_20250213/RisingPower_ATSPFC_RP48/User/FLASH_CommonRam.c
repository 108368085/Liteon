/** @file       FLASH_CommonRam.c
 *  @brief      Common RAM is declared in RAM and it is used to communicate between BOOT Code and UAP Code
 *  @author     Adonis Wang
 *  @version    2.0
 *  @history    modify from ollie chen
 */
 
#include "FLASH_CommonRam.h"

/****************************************************************************
	Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

/****************************************************************************
	Private variable declare
****************************************************************************/

#pragma DATA_SECTION (pu16CommonRam, "CommonRamSection");
u16_t pu16CommonRam[COMMON_RAM_SIZE];

#pragma DATA_SECTION (pu16RamPointer, "RamPointerSection");
u16_t* pu16RamPointer;


/**
 *  @brief  Push data to Common RAM
 *  @param  u16RamAddress: Address of data which is attempted to push
 *  @param  u16Data: data is attempted to push
 *  @retval None
 */
void CommonRam_PushData(u16_t u16RamAddress, u16_t u16Data)
{
    if (u16RamAddress < COMMON_RAM_SIZE)
    {
        pu16CommonRam[u16RamAddress] = u16Data;
    }
}

/**
 *  @brief  Pop data from Common RAM
 *  @param  u16RamAddress: Address of data which is attempted to pop
 *  @retval Pop data
 */
u16_t CommonRam_PopData(u16_t u16RamAddress)
{
    if (u16RamAddress < COMMON_RAM_SIZE)
    {
        return pu16CommonRam[u16RamAddress];
    }
    else
    {
        return 0xFFFF;
    }
}

/**
 *  @brief  Clear all the application ram section
 *  @param  none
 *  @retval none
 */
void ClearApplicationRam(void)
{
    pu16RamPointer = (u16_t*)RAM_START_ADDRESS;
    while(pu16RamPointer <= ((u16_t*)RAM_END_ADDRESS))
    {
        *pu16RamPointer = 0;
        pu16RamPointer++;
    }
}
