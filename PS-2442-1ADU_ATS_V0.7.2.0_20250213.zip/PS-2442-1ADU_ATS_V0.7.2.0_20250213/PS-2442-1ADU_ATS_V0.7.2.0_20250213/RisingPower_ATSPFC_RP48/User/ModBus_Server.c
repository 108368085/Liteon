/** @file       ModBus_Server.c
 *  @author     Ollie Chen
 *  @brief      ModBus Server Application
 *  @version    1.0
 *  @date       2017-10-25
*/

#include <string.h>
#include "ModBus_Server.h"
#include "ModBus_Data.h"
#include "SERV_CRC.h"
#include "Peripheral_SCI.h"



/****************************************************************************
	Private macro definition
****************************************************************************/

/** 
    The size of RX buffer should be support write multiple holding register.
    @verbatim
      Server Address        (1 byte)
    + Function Code         (1 byte)
    + Register Address      (2 bytes)
    + Register Quantities   (2 bytes)
    + Payload Byte length   (1 byte)
    + Payload               (2*MBUS_MAX_QUAN_WRITE_REGISTER bytes)
    + CRC                   (2 bytes)
    ----------------------------------------------------------
    =                       2*MBUS_MAX_QUAN_WRITE_REGISTER + 9
    @endverbatim
*/
#define MBUS_RX_BUFF_SIZE       (MBUS_QUAN_WRITE_REGISTER*2 + 9)

/** 
    The size of TX buffer should be support read input/holding register. 
    @verbatim
      Server Address        (1 byte)
    + Function Code         (1 byte)
    + Payload Byte length   (1 byte)
    + Payload               (2*MBUS_MAX_QUAN_READ_REGISTER bytes)
    + CRC                   (2 bytes)
    -------------------------------------------------------------
    =                       2*MBUS_MAX_QUAN_READ_REGISTER + 5
    @endverbatim
*/
#define MBUS_TX_BUFF_SIZE       (MBUS_QUAN_READ_REGISTER*2 + 5)
   
#define MBUS_RECEIVE_TIMEOUT    10  ///< 100ms, unit is 10ms.
#define MBUS_REQUEST_TIMEOUT    10  ///< 100ms, unit is 10ms.

#define MBUS_REPLY_PRIORITY     1

#define MBUS_SERVER_SELF_ADDRESS         0x01

/****************************************************************************
	Private enumeration definition
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/** ModBus Server Flag */
typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1FrameReceived			:1;		///< Received a request frame from physical driver, after put the response data in the Tx buffer, clear the flag.
		u16_t u1RequestProcessing		:1;		///< Request is processing, Set the flag when process processing and clear flag after When the request processed.
		u16_t u14Reserved				:14;
	}u16Bits;
}nMBusServerFlag_t;

/** ModBus Server Structure */
typedef struct
{
    nMBusServerFlag_t nFlag;            ///< ModBus Server Flag
    
    /** Receive Timeout Count, The count would be accumulated after received data from driver. 
        If the request frame did NOT received in limit time, Server would flush the RX buffer and driver buffer */
    u16_t u16ReceiveTimeout;        

	/** Request Timeout Count, The count would be accumulated after received request from client. 
        If the request did NOT be processed in limit time,
        Server would abandon this request and send exception "MBUS_EXCEPTION_REQUEST_FAIL" to client.*/
    u16_t u16RequestTimeout;        
    
	u16_t u16ServerAddress;             ///< ModBus server address
	u8_t u8FuncCode;                    ///< Used to store Function Code of ModBus request
    u8_t u8Exception;                   ///< Used to store Error Code when trigger exception
	u16_t u16RegAddr;			        ///< Used to store Register Address of access request
	u16_t u16RegQua;				    ///< Used to store Register Quantities of access request
    
    // Receive 
    u16_t u16RxByte;                    ///< The variable indicated how many byte received from driver
	u8_t pu8RxBuff[MBUS_RX_BUFF_SIZE];  ///< The array is used to store data received from driver
    
    // Transmit
    u16_t u16TxLength;			        ///< The variable indicated how many byte attempted to transmit, NOT include CRC 
	u8_t pu8TxBuff[MBUS_TX_BUFF_SIZE];  ///< The array is used to store data attempted to transmit.

	// Physical driver interface
	sUartDriverInterface_t sDriver;     ///< Driver interface
    u16_t u16DriverChannel;             ///< Which Driver channel is this server connect to
    
}sMBusServer_t;

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 884 -> 312
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(MBusServer_Reset, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_IsSupportedFunctionCode, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_TriggerException, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ReceiveTimeout, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_RequestTimeout, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_10ms_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_AwaitFrame, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_CheckCoilRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ProcessCoilRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ReadCoilHandler, ".TI.ramfunc");
#pragma CODE_SECTION(MBusServer_CheckHoldingRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ProcessReadHoldingRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ReadHoldingHandler, ".TI.ramfunc");
#pragma CODE_SECTION(MBusServer_CheckInputRequest, ".TI.ramfunc");
#pragma CODE_SECTION(MBusServer_ProcessInputRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ReadInputHandler, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ProcessWriteSingleHoldingRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_WriteSingleHoldingHandler, ".TI.ramfunc");
#pragma CODE_SECTION(MBusServer_ProcessWriteMultipleHoldingRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_WriteMultipleHoldingHandler, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ReplyToClient, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_ParseFrame, ".TI.ramfunc");
//#pragma CODE_SECTION(MBusServer_Background_Process, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declare
****************************************************************************/
sMBusServer_t ptsMBusServer[eMBusServer_IF_Num];


/****************************************************************************
	Public variable declare
****************************************************************************/

/**
    @brief  Reset ModBus Server structure and its physical driver RX buffer
            after finished the request/response transaction
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static void MBusServer_Reset(sMBusServer_t* psMBusServer)
{
    /* Reset driver RxBuffer */
    psMBusServer->sDriver.pfRxReset(psMBusServer->u16DriverChannel);
	psMBusServer->nFlag.u16Bits.u1FrameReceived = 0;
	psMBusServer->nFlag.u16Bits.u1RequestProcessing = 0;
	
	psMBusServer->u16ReceiveTimeout = 0;
    psMBusServer->u16RequestTimeout = 0;
    
    psMBusServer->u16RxByte = 0;
    psMBusServer->u8FuncCode = 0;
    psMBusServer->u16RegAddr = 0;
    psMBusServer->u16RegQua = 0;
    psMBusServer->u8Exception = 0;
}

/**
    @brief  Check specified function code is supported or not
    @param  u8FunctionCode: function code
    @retval 0: The function code is NOT supported
    @retval 1: The function code is supported
*/
static u16_t MBusServer_IsSupportedFunctionCode(u8_t u8FunctionCode)
{
    u16_t u16Support;
    
    switch (u8FunctionCode)
    {
        case MBUS_FC_READ_COILS:
        case MBUS_FC_READ_HOLDING:
        case MBUS_FC_READ_INPUT:
        case MBUS_FC_WRITE_SINGLE_HOLDING:
        case MBUS_FC_WRITE_MULTIPLE_HOLDING:
            u16Support = 1;
            break;

		default:
            u16Support = 0;
            break;
    }
    
    return u16Support;
}

/**
    @brief  Trigger an exception of ModBus access request. This function will build the response message.
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @param  eExceptionCode: Exception Code.
    @retval None
*/
static void MBusServer_TriggerException(sMBusServer_t* psMBusServer, eMBUS_REQ_EXCEPTIONS_t eExceptionCode)
{
    psMBusServer->u8Exception = eExceptionCode;
    
    /* Build response message */
    psMBusServer->pu8TxBuff[0] = psMBusServer->u16ServerAddress;
	psMBusServer->pu8TxBuff[1] = psMBusServer->u8FuncCode | 0x80;
	psMBusServer->pu8TxBuff[2] = psMBusServer->u8Exception;
	psMBusServer->u16TxLength = 3;
}

/**
    @brief  If request did not be received within limited time,
            this function would ignore the previous received data 
            and reset ModBus Server structure.
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static inline void MBusServer_ReceiveTimeout(sMBusServer_t* psMBusServer)
{
    /* 
        In order to prevent wrong reset mechanism, 
        This function should check the first byte of RX buffer is the same with server address
        and the second byte is supported function code 
    */
    if ((0 != psMBusServer->u16RxByte) &&
        (0 == psMBusServer->nFlag.u16Bits.u1FrameReceived) &&
        (psMBusServer->pu8RxBuff[0] == psMBusServer->u16ServerAddress) &&
        (MBusServer_IsSupportedFunctionCode(psMBusServer->pu8RxBuff[1])))
    {
        if (psMBusServer->u16ReceiveTimeout < MBUS_RECEIVE_TIMEOUT)
        {
            psMBusServer->u16ReceiveTimeout += 1;
        }
        else
        {
            MBusServer_Reset(psMBusServer);
        }
    }
    else
    {
        psMBusServer->u16ReceiveTimeout = 0;
    }
}

/**
    @brief  If request had NOT processed within limited time,
            this function would abandon request, send an exception message to client,
            and reset this ModBus server structure
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static inline void MBusServer_RequestTimeout(sMBusServer_t* psMBusServer)
{
    if (psMBusServer->nFlag.u16Bits.u1RequestProcessing == 1)
    {
        if (psMBusServer->u16RequestTimeout < MBUS_REQUEST_TIMEOUT)		//~50ms time out for event log
        {
            psMBusServer->u16RequestTimeout++;
        }
        else
        {
            MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_REQUEST_FAIL);
        }
    }
}

/**
    @brief  Process Timeout Mechanism, It include receive timeout and request timeout
    @param  pvSubscriberObjs: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/    
void MBusServer_10ms_Periodically_Process(void)
{
	u16_t i;
	
	for (i=0; i<eMBusServer_IF_Num; i++)
	{
		MBusServer_ReceiveTimeout(&ptsMBusServer[i]);
    	MBusServer_RequestTimeout(&ptsMBusServer[i]);
	}
}

/**
    @brief  Await for client send an access request frame
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static inline void MBusServer_AwaitFrame(sMBusServer_t* psMBusServer)
{
    u16_t u16ExpectLength = MBUS_RX_BUFF_SIZE;
    
    /* Get Rx Data from driver */
    psMBusServer->u16RxByte = psMBusServer->sDriver.pfGetRxByte(psMBusServer->u16DriverChannel, psMBusServer->pu8RxBuff, MBUS_RX_BUFF_SIZE);
    
    /* At least The frame length should be greater than 8 bytes at least */
    if ((psMBusServer->u16RxByte >= 8) &&
        (psMBusServer->u16RxByte < MBUS_RX_BUFF_SIZE) &&
        (psMBusServer->pu8RxBuff[0] == psMBusServer->u16ServerAddress))
    {	
        /* parse function code */
        switch (psMBusServer->pu8RxBuff[1])
        {
            case MBUS_FC_READ_COILS:
            case MBUS_FC_READ_HOLDING:
            case MBUS_FC_READ_INPUT:
            case MBUS_FC_WRITE_SINGLE_HOLDING:
                u16ExpectLength = 8;
                break;
			
            case MBUS_FC_WRITE_MULTIPLE_HOLDING:
                u16ExpectLength = (__MByteToWord(&psMBusServer->pu8RxBuff[4]) * 2 + 9);
                break;
			
            default:
                u16ExpectLength = 0;
                break;
        }			
        
        /* Unsupported function code */
        if (u16ExpectLength == 0)
        {
            MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_UNSUPPORT_FUNCTION);
        }
        else if (psMBusServer->u16RxByte == u16ExpectLength)
        {
            psMBusServer->nFlag.u16Bits.u1FrameReceived = 1;
        }
        else if (psMBusServer->u16RxByte > u16ExpectLength)
        {
            /* Received bytes over than expect */
            MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
        }
    }
}

/**
    @brief  Check requesting coil register is all support in ModBus database
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval <RequestDenied>: the access request content is invalid.
    @retval <ReqeustAccepted>: the access request content is valid.
*/
static u16_t MBusServer_CheckCoilRequest(sMBusServer_t* psMBusServer)
{
	u16_t u16CheckResult = RequestAccepted;
	u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
	u16_t u16CheckedQuantities = 0;
	
	sCoilRegNode_t* psRegisterNode;
	
    /** Check quantity not violent Modbus specification */
	if ((psMBusServer->u16RegQua > MBUS_MAX_QUAN_READ_COIL) || 
        (0 == psMBusServer->u16RegQua))
	{
		MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
        u16CheckResult = RequestDenied;
	}
    else
    {
        while (u16CheckedQuantities < psMBusServer->u16RegQua)
        {
            psRegisterNode = MBusData_SearchCoilRegNode(u16RegisterAddress);
            
            if (psRegisterNode != NULL)
            {
                if (psRegisterNode->pu16Reg != NULL)
                {
                    // Request Address did not contents in the register node
                    if ((psMBusServer->u16RegQua - u16CheckedQuantities) > (psRegisterNode->u16EndAddr - u16RegisterAddress + 1))
                    {
                        u16CheckedQuantities += (psRegisterNode->u16EndAddr - u16RegisterAddress + 1);
                        u16RegisterAddress = (psRegisterNode->u16EndAddr + 1);
                    }
                    else
                    {
                        u16CheckedQuantities = psMBusServer->u16RegQua;
                    }
                }
                else
                {
                    MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_REQUEST_FAIL);
                    u16CheckResult = RequestDenied;
                    break;
                }
            }
            else
            {
                MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_ADDRESS);
                u16CheckResult = RequestDenied;
                break;
            }
        }
    }
	
	return u16CheckResult;
}

/**
    @brief  Process read coil request
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval <RequestDenied>: the request had been denied or failed.
    @retval <ReqeustAccepted>: the request had been processed.
*/
static void MBusServer_ProcessCoilRequest(sMBusServer_t* psMBusServer)
{	
	u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
	u16_t u16ProcessedQuantities = 0;
	u16_t u16BitIndex = 0;
	sCoilRegNode_t* psRegisterNode;	
	
    /* Build response message - Byte Count */
    if ((psMBusServer->u16RegQua % 8) == 0)
    {
        psMBusServer->pu8TxBuff[2] = psMBusServer->u16RegQua / 8;		// Byte count
    }
    else
    {
        psMBusServer->pu8TxBuff[2] = psMBusServer->u16RegQua / 8 + 1;	// Byte Count
    }
    
    /* Build response message - Payload */
	while (u16ProcessedQuantities < psMBusServer->u16RegQua)
	{
		psRegisterNode = MBusData_SearchCoilRegNode(u16RegisterAddress);
        u16BitIndex = u16RegisterAddress - psRegisterNode->u16StartAddr + psRegisterNode->u16StartBit;
        
        if (*psRegisterNode->pu16Reg & (1<<u16BitIndex))
        {
            psMBusServer->pu8TxBuff[3 + u16ProcessedQuantities / 8] |= (1 << u16ProcessedQuantities % 8);
        }
        else
        {
            psMBusServer->pu8TxBuff[3 + u16ProcessedQuantities / 8] &= ~(1 << u16ProcessedQuantities % 8);
        }
        
        u16ProcessedQuantities += 1;
        u16RegisterAddress += 1;
	}
	
    /* Assign response message TX length */
    psMBusServer->u16TxLength = 3 + psMBusServer->pu8TxBuff[2];

}

/**
    @brief  Read Coil request handler
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static void MBusServer_ReadCoilHandler(sMBusServer_t* psMBusServer)
{		
    /* Check requested register is in support range */
    if (MBusServer_CheckCoilRequest(psMBusServer) == RequestAccepted)
    {
        /* Fill requested register data into TxBuff */
        MBusServer_ProcessCoilRequest(psMBusServer);
    }
}

/**
    @brief  Check requesting holding register is all support in ModBus database,
            the requesting quantities is valid, and requesting register is available.
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval <RequestDenied>: the request had been denied or failed.
    @retval <ReqeustAccepted>: the request had been processed.
*/
static u16_t MBusServer_CheckHoldingRequest(sMBusServer_t* psMBusServer)
{
    u16_t u16CheckResult = RequestAccepted;
    u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
    u16_t u16CheckedQuantities = 0;
    sHoldingRegNode_t* psRegisterNode;
    
    if ((psMBusServer->u16RegQua > MBUS_MAX_QUAN_READ_REGISTER) ||
        (0 == psMBusServer->u16RegQua))
    {
        MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
        u16CheckResult = RequestDenied;
    }
    else
    {
        while (u16CheckedQuantities < psMBusServer->u16RegQua)
        {
            psRegisterNode = MBusData_SearchHoldingRegNode(u16RegisterAddress);
            
            if (psRegisterNode == NULL)
            {
                MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_ADDRESS);
                u16CheckResult = RequestDenied;
                break;
            }
            else 
            {

                // Holding register node declared but its content is empty
                if ((psRegisterNode->psGuardVarList == NULL) ||
                    (psRegisterNode->psGuardVarList->psHeadNode == NULL) ||
                    (psRegisterNode->psGuardVarList->psHeadNode->pVar == NULL))
                {
                    MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_REQUEST_FAIL);
                    u16CheckResult = RequestDenied;
                    break;
                }
                
                // Request Address did not contents in the register node
                if ((psMBusServer->u16RegQua - u16CheckedQuantities) > (psRegisterNode->u16EndAddr - u16RegisterAddress + 1))
                {
                    u16CheckedQuantities += (psRegisterNode->u16EndAddr - u16RegisterAddress + 1);
                    u16RegisterAddress = (psRegisterNode->u16EndAddr + 1);
                }
                else
                {
                    u16CheckedQuantities = psMBusServer->u16RegQua;
                }
            }
        }
    }
    
	return u16CheckResult;
}

/**
    @brief  Process read holding register request, fill the holding register valiue into TX buffer
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval <RequestDenied>: the request had been denied or failed.
    @retval <ReqeustAccepted>: the request had been processed.    
*/
static void MBusServer_ProcessReadHoldingRequest(sMBusServer_t* psMBusServer)
{
	u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
	u16_t u16ProcessedQuantities = 0;
	u16_t u16Offset;
	sHoldingRegNode_t* psRegisterNode;
	
    /* Build response message - Byte Count */
    psMBusServer->pu8TxBuff[2] = psMBusServer->u16RegQua * 2;   // byte count
    
    /* Build response message - Payload */
	while (u16ProcessedQuantities < psMBusServer->u16RegQua)
	{
		psRegisterNode = MBusData_SearchHoldingRegNode(u16RegisterAddress);
        u16Offset = u16RegisterAddress - psRegisterNode->u16StartAddr;
        __WordToMByte(&psMBusServer->pu8TxBuff[3 + u16ProcessedQuantities * 2], *((u16_t*)(psRegisterNode->psGuardVarList->psHeadNode->pVar) + u16Offset));
        
        u16ProcessedQuantities += 1;
        u16RegisterAddress += 1;
	}
	
    psMBusServer->u16TxLength = 3 + psMBusServer->pu8TxBuff[2]; // ID, Function Code, byte Count + N Bytes. Not included CRC yet.
	    
}

/**
    @brief  Read Holding Register Request Handler
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static void MBusServer_ReadHoldingHandler(sMBusServer_t* psMBusServer)
{
    /* Check requested register is in support range */
    if (MBusServer_CheckHoldingRequest(psMBusServer) == RequestAccepted)
    {
        /* Fill requested register data into TxBuff */
        MBusServer_ProcessReadHoldingRequest(psMBusServer);
    }
}

/**
    @brief  Check requesting input register is all support in ModBus database
    @param  pointer to a sMBusServer_t structure that attempted to operate
    @retval <RequestDenied>: the access request content is invalid.
    @retval <ReqeustAccepted>: the access request content is valid.
*/
static u16_t MBusServer_CheckInputRequest(sMBusServer_t* psMBusServer)
{
	u16_t u16CheckResult = RequestAccepted;
	u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
	u16_t u16CheckedQuantities = 0;
	
	sInputRegNode_t *psRegisterNode;
	
    /** Check quantity not violent Modbus specification */
    if ((psMBusServer->u16RegQua > MBUS_MAX_QUAN_READ_REGISTER) || 
        (0 == psMBusServer->u16RegQua))
	{
		MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
        u16CheckResult = RequestDenied;
	}
    else
    {
        while (u16CheckedQuantities < psMBusServer->u16RegQua)
        {
            psRegisterNode = MBusData_SearchInputRegNode(u16RegisterAddress);
            
            if (psRegisterNode != NULL)
            {
                if (psRegisterNode->pu16Reg != NULL)
                {
                    // Request Address did not contents in the register node
                    if ((psMBusServer->u16RegQua - u16CheckedQuantities) > (psRegisterNode->u16EndAddr - u16RegisterAddress + 1))
                    {
                        u16CheckedQuantities += (psRegisterNode->u16EndAddr - u16RegisterAddress + 1);
                        u16RegisterAddress = (psRegisterNode->u16EndAddr + 1);
                    }
                    else
                    {
                        u16CheckedQuantities = psMBusServer->u16RegQua;
                    }
                }
                else
                {
                    MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_REQUEST_FAIL);
                    u16CheckResult = RequestDenied;
                    break;
                }
            }
            else
            {
                MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_ADDRESS);
                u16CheckResult = RequestDenied;
                break;
            }
        }
    }
	
	return u16CheckResult;
}

/**
    @brief  Process read input request (normal input register)
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval <RequestDenied>: the request had been denied or failed.
    @retval <ReqeustAccepted>: the request had been processed.
*/
static void MBusServer_ProcessInputRequest(sMBusServer_t* psMBusServer)
{
	u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
	u16_t u16ProcessedQuantities = 0;
	u16_t u16Offset;
	sInputRegNode_t* psRegisterNode;

    /* Build response message - Byte Count */
    psMBusServer->pu8TxBuff[2] = psMBusServer->u16RegQua * 2;
    
    /* Build response message - Payload */
	while (u16ProcessedQuantities < psMBusServer->u16RegQua)
	{
		psRegisterNode = MBusData_SearchInputRegNode(u16RegisterAddress);
        u16Offset = u16RegisterAddress - psRegisterNode->u16StartAddr;
        __WordToMByte(&psMBusServer->pu8TxBuff[3 + u16ProcessedQuantities * 2], *(psRegisterNode->pu16Reg+u16Offset));
			
        u16ProcessedQuantities += 1;
        u16RegisterAddress += 1;
	}

    psMBusServer->u16TxLength = 3 + psMBusServer->pu8TxBuff[2];

}

/**
    @brief  Read Input Request Handler
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static void MBusServer_ReadInputHandler(sMBusServer_t* psMBusServer)
{
    /* Check requested register is in support range */
    if (MBusServer_CheckInputRequest(psMBusServer) == RequestAccepted)
    {
        /* Fill requested register data into TxBuff */
        MBusServer_ProcessInputRequest(psMBusServer);
    }
}

/**
    @brief   Process write single holding register request
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate  
    @retval <RequestDenied>: the request had been denied or failed.
    @retval <ReqeustAccepted>: the request had been processed. 
*/
static u16_t MBusServer_ProcessWriteSingleHoldingRequest(sMBusServer_t* psMBusServer)
{
    u16_t i;
    u16_t u16Response = RequestProcessed;
	u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
	sHoldingRegNode_t* psRegisterNode;
	sGuardVarAccessRequest_t sAccessRequest;
    psRegisterNode = MBusData_SearchHoldingRegNode(u16RegisterAddress);
    
    /* Build guard variable write request message */
    sAccessRequest.u16Offset = (u16RegisterAddress - psRegisterNode->u16StartAddr) << 1;	// << 1 is for converts word offset to byte Offset
    sAccessRequest.pu8Data = &psMBusServer->pu8RxBuff[4];
    sAccessRequest.u16Length = 2;	// Single Word
    
    /* Check access request by Guard variable node */
    if (GuardVarList_CheckRequest(psRegisterNode->psGuardVarList, sAccessRequest) == RequestDenied)
    {
        MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
        return RequestDenied;
    }

    /* Write access request to guard variable node */
    u16Response = GuardVarList_WriteRequest(psRegisterNode->psGuardVarList, sAccessRequest);
    
    if (u16Response == RequestDenied)
    {
        MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_REQUEST_FAIL);
        return RequestDenied;
    }
    else if (u16Response == RequestAccepted)
    {
        for (i=2; i<6; i++)
        {
            psMBusServer->pu8TxBuff[i] = psMBusServer->pu8RxBuff[i];
        }
    }
    
    psMBusServer->u16TxLength = 6;
    
    return RequestProcessed;
}

/**
    @brief  Write Single Holding Register Request Handler
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static void MBusServer_WriteSingleHoldingHandler(sMBusServer_t* psMBusServer)
{
    if (MBusServer_CheckHoldingRequest(psMBusServer) == RequestAccepted)
    {
        MBusServer_ProcessWriteSingleHoldingRequest(psMBusServer);
    }
}

/**
    @brief  Process write multiple holding register request
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval <RequestDenied>: the request had been denied or failed.
    @retval <ReqeustAccepted>: the request had been processed. 
*/
static u16_t MBusServer_ProcessWriteMultipleHoldingRequest(sMBusServer_t* psMBusServer)
{
    u16_t u16RegisterAddress = psMBusServer->u16RegAddr;
    u16_t u16ProcessedQuantities = 0;
	sHoldingRegNode_t* psRegisterNode;
    sGuardVarAccessRequest_t sAccessRequest;
    
	while (u16ProcessedQuantities < psMBusServer->u16RegQua)
	{
		psRegisterNode = MBusData_SearchHoldingRegNode(u16RegisterAddress);
	
		/* Build guard variable write request message */
		sAccessRequest.u16Offset = (u16RegisterAddress - psRegisterNode->u16StartAddr) << 1;	// << 1 is for converts word offset to byte Offset
		sAccessRequest.pu8Data = &psMBusServer->pu8RxBuff[7 + (u16ProcessedQuantities << 1)];
		
		if (((psMBusServer->u16RegQua - u16ProcessedQuantities) << 1) > psRegisterNode->psGuardVarList->psHeadNode->u16VarSize)
		{
			sAccessRequest.u16Length = psRegisterNode->psGuardVarList->psHeadNode->u16VarSize;
		}
		else
		{
			sAccessRequest.u16Length = (psMBusServer->u16RegQua - u16ProcessedQuantities) << 1;
		}
		
        /* Check access request by Gaurd variable node */
        if (GuardVarList_CheckRequest(psRegisterNode->psGuardVarList, sAccessRequest) == RequestDenied)
        {
            MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
            return RequestDenied;
        }
        else
		{
			u16RegisterAddress += (sAccessRequest.u16Length >> 1);
			u16ProcessedQuantities += (sAccessRequest.u16Length >> 1);
		}
    }  

    /* All guard variable register node had been checked, reset processed quantities and start address */
	u16ProcessedQuantities = 0;
    u16RegisterAddress = psMBusServer->u16RegAddr;
    
    while (u16ProcessedQuantities < psMBusServer->u16RegQua)
	{		
		psRegisterNode = MBusData_SearchHoldingRegNode(u16RegisterAddress);
		sAccessRequest.u16Offset = (u16RegisterAddress - psRegisterNode->u16StartAddr) << 1;	// << 1 is for converts word offset to byte Offset
		sAccessRequest.pu8Data = &psMBusServer->pu8RxBuff[7 + (u16ProcessedQuantities << 1)];
    
        if (((psMBusServer->u16RegQua - u16ProcessedQuantities) << 1) > psRegisterNode->psGuardVarList->psHeadNode->u16VarSize)
		{
			sAccessRequest.u16Length = psRegisterNode->psGuardVarList->psHeadNode->u16VarSize;
		}
		else
		{
			sAccessRequest.u16Length = (psMBusServer->u16RegQua - u16ProcessedQuantities) << 1;
		}
		
        if (GuardVarList_WriteRequest(psRegisterNode->psGuardVarList, sAccessRequest) == RequestDenied)
        {
            MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_REQUEST_FAIL);
            return RequestDenied;
        }
        else
		{
			u16RegisterAddress += (sAccessRequest.u16Length >> 1);
			u16ProcessedQuantities += (sAccessRequest.u16Length >> 1);
		}
	}

    /* Build response message - register address */
    __WordToMByte(&psMBusServer->pu8TxBuff[2], psMBusServer->u16RegAddr);

	/* Build response message - register quantities */
    __WordToMByte(&psMBusServer->pu8TxBuff[4], psMBusServer->u16RegQua);
    
    psMBusServer->u16TxLength = 6;    // Server Address, Function Code, Register Address, Register Quantities

	return RequestProcessed;
}

/**
    @brief  Write Multiple Holding Register Request Handler
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None  
*/
static void MBusServer_WriteMultipleHoldingHandler(sMBusServer_t* psMBusServer)
{
    if (MBusServer_CheckHoldingRequest(psMBusServer) == RequestAccepted)
    {
        MBusServer_ProcessWriteMultipleHoldingRequest(psMBusServer);
    }
}

/**
    @brief  Reply to Client. This function would calculate the CRC and send this message to client.
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static inline void MBusServer_ReplyToClient(sMBusServer_t* psMBusServer)
{
    u16_t u16CRCValue = CalCRC16(MBUS_CRC_SEED, psMBusServer->pu8TxBuff, psMBusServer->u16TxLength, MBUS_CRC_SWAP);
    __WordToMByte(&psMBusServer->pu8TxBuff[psMBusServer->u16TxLength], u16CRCValue);
    psMBusServer->sDriver.pfTxWrite(psMBusServer->u16DriverChannel, psMBusServer->u16TxLength + 2, psMBusServer->pu8TxBuff);
}

/**
    @brief  Parse received frame
    @param  psMBusServer: pointer to a sMBusServer_t structure that attempted to operate
    @retval None
*/
static inline void MBusServer_ParseFrame(sMBusServer_t* psMBusServer)
{
    u16_t u16CrcValue;
    
    if (psMBusServer->sDriver.pfCheckTxIdle(psMBusServer->u16DriverChannel) <= MBUS_REPLY_PRIORITY)
    {
        /* Get Function Code*/
        psMBusServer->u8FuncCode = psMBusServer->pu8RxBuff[1];

		/* Get Access Register Address */
        psMBusServer->u16RegAddr = __MByteToWord(&psMBusServer->pu8RxBuff[2]);

		/* Get Access Register Quantities */
        if (psMBusServer->u8FuncCode == MBUS_FC_WRITE_SINGLE_HOLDING)
        {
            psMBusServer->u16RegQua = 1;
        }
        else
        {
            psMBusServer->u16RegQua = __MByteToWord(&psMBusServer->pu8RxBuff[4]);
        }

		/* Check CRC */
        if (psMBusServer->u8FuncCode == MBUS_FC_WRITE_MULTIPLE_HOLDING)
        {
            // +7: Server Address(1), Function Code(1), Register Address(2), Register Quantitie(2), Byte Count(1), Write Data(2*N)
            u16CrcValue = CalCRC16(MBUS_CRC_SEED, psMBusServer->pu8RxBuff, psMBusServer->u16RegQua * 2 + 7, MBUS_CRC_SWAP);

			if (u16CrcValue != __MByteToWord(&psMBusServer->pu8RxBuff[psMBusServer->u16RegQua * 2 + 7]))
            {
                MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
            }
        }
        else
        {
            // 6: Server Address(1), Function Code(1), Register Address(2), Register Quantities or write single word Data(2)
            u16CrcValue = CalCRC16(MBUS_CRC_SEED, psMBusServer->pu8RxBuff, 6, MBUS_CRC_SWAP);

			if (u16CrcValue != __MByteToWord(&psMBusServer->pu8RxBuff[6]))
            {
                MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_INVALID_DATA);
            }
        }
        
        /* Build response message - Server Address */
        psMBusServer->pu8TxBuff[0] = psMBusServer->u16ServerAddress;

		/* Build reponse message - Function Code */
        psMBusServer->pu8TxBuff[1] = psMBusServer->u8FuncCode;

        if (psMBusServer->u8Exception == MBUS_EXCEPTION_NONE)
        {
            switch (psMBusServer->u8FuncCode)
            {
                case MBUS_FC_READ_COILS:
                    MBusServer_ReadCoilHandler(psMBusServer);
                    break;
				
                case MBUS_FC_READ_HOLDING:
                    MBusServer_ReadHoldingHandler(psMBusServer);
                    break;
				
                case MBUS_FC_READ_INPUT:
                    MBusServer_ReadInputHandler(psMBusServer);
                    break;
				
                case MBUS_FC_WRITE_SINGLE_HOLDING:
                    MBusServer_WriteSingleHoldingHandler(psMBusServer);
                    break;
				
                case MBUS_FC_WRITE_MULTIPLE_HOLDING:
                    MBusServer_WriteMultipleHoldingHandler(psMBusServer);
                    break;
				
                default:
                    MBusServer_TriggerException(psMBusServer, MBUS_EXCEPTION_UNSUPPORT_FUNCTION);
                    break;
            }
        }
        
        if (0 == psMBusServer->nFlag.u16Bits.u1RequestProcessing)
        {
            /* Reply to Client */
            MBusServer_ReplyToClient(psMBusServer);

			/* Reset MBus Server */
            MBusServer_Reset(psMBusServer);
        }
    }
}

/**
    @brief  ModBus Server Background Process.
    @retval None
*/
void MBusServer_Background_Process(void)
{
    u16_t i;

    for(i=0; i<eMBusServer_IF_Num; i++)
    {
        if (0 == ptsMBusServer[i].nFlag.u16Bits.u1FrameReceived)
        {
            MBusServer_AwaitFrame(&ptsMBusServer[i]);
        }
        else if (0 == ptsMBusServer[i].nFlag.u16Bits.u1RequestProcessing)
        {
            MBusServer_ParseFrame(&ptsMBusServer[i]);
        }
    }
}

/**
 *  @brief  Initialize the ModBus Server according to the specified parameters
 *  @param  u16IF: Which ModBus Server Interface attempted to initialize
 *  @param  u16ServerAddress: Set specified server address to this ModBus server
 *  @param  psDriverInterface: Pointer to a sUartDriverInterface_t structure which is attempted to use
 *  @param  u16DriverChannel: Which Physical driver channel is wanted to use
 *  @retval None
 */
void MBusServer_Initialize(void)
{
	u16_t i;
	
	for (i=0; i<eMBusServer_IF_Num; i++)
	{
		memset(&ptsMBusServer[i], 0, sizeof(ptsMBusServer[i]));
		
	    /* Link to physical driver */
    	ptsMBusServer[i].sDriver = gtUartDriverInterface;
    	ptsMBusServer[i].u16DriverChannel = ePeriSCI_Channel_A;
    
    	/* Initial the structure variables */
    	ptsMBusServer[i].nFlag.u16All = 0;

		ptsMBusServer[i].u16ReceiveTimeout = 0;
		ptsMBusServer[i].u16RequestTimeout = 0;

    	ptsMBusServer[i].u16ServerAddress = MBUS_SERVER_SELF_ADDRESS;
		ptsMBusServer[i].u8FuncCode = 0;
		ptsMBusServer[i].u8Exception = 0;
		ptsMBusServer[i].u16RegAddr = 0x0000;
		ptsMBusServer[i].u16RegQua = 0;
		ptsMBusServer[i].u16RxByte = 0;
		ptsMBusServer[i].u16TxLength = 0;
	}	   
}
