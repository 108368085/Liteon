/****************************************************************************
 *	File	SERV_FFT.c
 * 	Brief	RFFT calculation
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2019/05/29 - 1st release
 *  Modify: C:\ti\controlSUITE\libs\dsp\FPU\v131\examples\2833x_RFFT
 ****************************************************************************/

#include "SERV_FFT.h"
#include "math.h"
#include "float.h"
#include <string.h>
#include "Monitor_AC.h"
#include "SERV_ADCFilter.h"
#include "SERV_Calibration.h"
#include "Peripheral.h"
#include "CONFIG_RisingPower.h"
#include "SERV_LOG.h"


//Buffer alignment for the input array
#pragma DATA_SECTION(AC1_RFFTin1Buff,"RFFTdata1");
#pragma DATA_SECTION(AC2_RFFTin1Buff,"RFFTdata1");

//Output of FFT
#pragma DATA_SECTION(AC1_RFFToutBuff,"RFFTdata2");
#pragma DATA_SECTION(AC2_RFFToutBuff,"RFFTdata2");

//Additional Buffer used in Magnitude calc
#pragma DATA_SECTION(AC1_RFFTmagBuff,"RFFTdata3");
#pragma DATA_SECTION(AC2_RFFTmagBuff,"RFFTdata3");

//Twiddle buffer
#pragma DATA_SECTION(AC1_RFFTF32Coef,"RFFTdata4");
#pragma DATA_SECTION(AC2_RFFTF32Coef,"RFFTdata4");



/****************************************************************************
	Private parameter definition 
****************************************************************************/

#define	SamplingCoef	((u32_t)CPU_TIMER_CLOCK_BASE * 10) / RFFT_SIZE
//#define	RealValueCoef	(f32_t)V_ACATS_FS / ((f32_t)Q12_ * 10 * 1.414)	//unit is 0.01VRMS

// VTHD from 0->18% need 8s integration time
#define FFT_Filter_A	(f32_t)0.1
#define FFT_Filter_B	(f32_t)0.9

/****************************************************************************
	Private macro definition
****************************************************************************/ 
 
/****************************************************************************
	Private enumeration definition
****************************************************************************/ 
 
/****************************************************************************
	Private structure definition 
****************************************************************************/
 
/****************************************************************************
	Private function prototype
****************************************************************************/ 

/*
// RAMLS0_6 : 462
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(FFT_Background_Process, ".TI.ramfunc");
#pragma CODE_SECTION(FFT_Timercallback, ".TI.ramfunc");
#endif
*/

/****************************************************************************
	Private variable declaration
****************************************************************************/
f32_t AC1_RFFTin1Buff[RFFT_SIZE];
f32_t AC1_RFFToutBuff[RFFT_SIZE];
f32_t AC1_RFFTmagBuff[RFFT_SIZE/2+1];
f32_t AC1_RFFTF32Coef[RFFT_SIZE];
	
f32_t AC2_RFFTin1Buff[RFFT_SIZE];
f32_t AC2_RFFToutBuff[RFFT_SIZE];
f32_t AC2_RFFTmagBuff[RFFT_SIZE/2+1];
f32_t AC2_RFFTF32Coef[RFFT_SIZE];

sFFTHandle_t tsFFT;


/***************************************************************************
*   brief  
*   note   
****************************************************************************/
static inline void RFFT_Calculate(RFFT_F32_STRUCT *rfft)
{
	RFFT_f32(rfft);		//Calculate real FFT
    RFFT_f32_mag(rfft);	//Calculate magnitude
}

/***************************************************************************
*   brief  fetch AC frequency and calculate interrupt period
*   note   
****************************************************************************/
static inline void FFT_GetIsrPeriod(sRFFT_t *fft)
{
	if (fft->eTag == FFT_Tag_AC1)
	{
		fft->u16ACFrequency = GET_MOMIAC_VAC1_FREQ_WF / 10;
	}
	else
	{
		fft->u16ACFrequency = GET_MOMIAC_VAC2_FREQ_WF / 10;
	}

	if (fft->u16ACFrequency == 0)
	{
		fft->u16VTHD = 0;
		fft->u16VTHD_WF = 0;
		fft->eStage = FFT_Stage_Finished;
	}
	else
	{
		fft->u16IsrPeriod = (u16_t)(tsFFT.u32SamplingCoef / (u32_t)fft->u16ACFrequency);
		fft->eStage = FFT_Stage_ClearReportBuff;
	}
}

/***************************************************************************
*   brief  Reset flag and report data
*   note   
****************************************************************************/
static inline void FFT_ClearReportBuff(sRFFT_t *fft)
{
	u16_t i;

	fft->u16SampleCNT = 0;
	fft->u32FFTOut_SUM = 0;

	for (i=0; i<Report_Amount; i++)
	{
		fft->u16FFTOut[i] = 0;
	}
	
	fft->eStage = FFT_Stage_ClearoutBuff;
}

/***************************************************************************
*   brief  Clean up output buffer
*   note   
****************************************************************************/
static inline void FFT_ClearoutBuff(sRFFT_t *fft)
{
	u16_t i;

	if (fft->eTag == FFT_Tag_AC1)
	{
		for (i=0; i < RFFT_SIZE; i++)
		{
			AC1_RFFToutBuff[i] = 0;
		}
	}
	else if (fft->eTag == FFT_Tag_AC2)
	{
		for (i=0; i < RFFT_SIZE; i++)
		{
			AC2_RFFToutBuff[i] = 0;
		}
	}

	fft->eStage = FFT_Stage_ClearmagBuff;
}

/***************************************************************************
*   brief  Clean up magnitude buffer
*   note   
****************************************************************************/
static inline void FFT_ClearmagBuff(sRFFT_t *fft)
{
	u16_t i;

	if (fft->eTag == FFT_Tag_AC1)
	{
		for (i=0; i < RFFT_SIZE/2; i++)
		{
			AC1_RFFTmagBuff[i] = 0;
		}
	}
	else if (fft->eTag == FFT_Tag_AC2)
	{
		for (i=0; i < RFFT_SIZE/2; i++)
		{
			AC2_RFFTmagBuff[i] = 0;
		}
	}

	fft->eStage = FFT_Stage_SetIsrPeripheral;
}

/***************************************************************************
*   brief  Setting timer peripheral
*   note   
****************************************************************************/
static inline void FFT_SetIsrPeripheral(sRFFT_t *fft)
{
	u32_t temp;
	
	if (fft->eTag == FFT_Tag_AC1)
	{
		temp = ((u32_t)CPU_TIMER_FREQUENCY_IN_MHZ * (u32_t)fft->u16IsrPeriod);
		tsFFT.nFlag.u16Bits.u2IsrWorking = 1;
		tsFFT.psInstance->PeriodInUSec = fft->u16IsrPeriod;	// Initialize timer period:
		tsFFT.psInstance->RegsAddr->PRD.all = temp - 1; 	//change PRD cpu timer
		tsFFT.psInstance->RegsAddr->TCR.bit.TSS = 0; 		//run cpu timer
		fft->eStage = FFT_Stage_FetchWaveform;
	}
	//AC2 start after AC1 finished
	else if (tsFFT.nFlag.u16Bits.u2IsrWorking == 0)
	{
		temp = ((u32_t)CPU_TIMER_FREQUENCY_IN_MHZ * (u32_t)fft->u16IsrPeriod);
		tsFFT.nFlag.u16Bits.u2IsrWorking = 2;
		tsFFT.psInstance->PeriodInUSec = fft->u16IsrPeriod; // Initialize timer period:
		tsFFT.psInstance->RegsAddr->PRD.all = temp - 1; 	//change PRD cpu timer
		tsFFT.psInstance->RegsAddr->TCR.bit.TSS = 0; 		//run cpu timer
		fft->eStage = FFT_Stage_FetchWaveform;
	}
}

/***************************************************************************
*   brief  fetch AC data from timer1 interrupt
*   note   waiting sampling finished at Timer1 call back function
****************************************************************************/
static inline void FFT_FetchWaveform(sRFFT_t *fft)
{
	if (fft->u16SampleCNT == RFFT_SIZE)
	{
		fft->u16SampleCNT = 0;
		tsFFT.nFlag.u16Bits.u2IsrWorking = 0;
		tsFFT.psInstance->RegsAddr->TCR.bit.TSS = 1; //stop cpu timer
		fft->eStage = FFT_Stage_CalcuFFT;
	}
}

/***************************************************************************
*   brief  Calculate RFFT
*   note   
****************************************************************************/
static inline void FFT_CalculateFFT(sRFFT_t *fft)
{
	RFFT_Calculate(&fft->rfft);
	fft->eStage = FFT_Stage_GetRealValue;
}

/***************************************************************************
*   brief  Calculate FFT Q11 to real value (unit is 0.01VRMS)
*   note   
****************************************************************************/
static inline void FFT_GetRealValue(sRFFT_t *fft)
{
	u32_t temp;
	
	if (fft->u16SampleCNT < Report_Amount)
	{
		temp = (u32_t)(fft->rfft.MagBuf[fft->u16SampleCNT] * fft->f32RealValueCoef);
		temp = temp >> (RFFT_STAGES - 1);
		fft->u16FFTOut[fft->u16SampleCNT] = (u16_t)temp;

		if (fft->u16SampleCNT > 1)
		{
			fft->u32FFTOut_SUM += (temp)*(temp);
		}
		
		fft->u16SampleCNT ++;
	}
	else
	{
		// Get VTHD
		fft->u16VTHD = (u16_t)((__sqrt((f32_t)fft->u32FFTOut_SUM) * 10000) / (f32_t)fft->u16FFTOut[1]);

		// Limit Max VTHD : 50.00% 
		if (fft->u16VTHD > 5000)
		{
			fft->u16VTHD = 5000;
		}

		// Filter VTHD
		fft->u16VTHD_WF = (u16_t)((f32_t)fft->u16VTHD * FFT_Filter_A + (f32_t)fft->u16VTHD_WF * FFT_Filter_B);
		fft->u16SampleCNT = 0;
		fft->eStage = FFT_Stage_Finished;
	}
}

/***************************************************************************
*   brief  Finish FFT process
*   note   
****************************************************************************/
static inline void FFT_Finished(sRFFT_t *fft)
{
	if (fft->eTag == FFT_Tag_AC1)
	{
		tsFFT.nFlag.u16Bits.u1AC1FFTDone = 1;
	}

	if (fft->eTag == FFT_Tag_AC2)
	{
		tsFFT.nFlag.u16Bits.u1AC2FFTDone = 1;
	}
}

/***************************************************************************
*   brief  FFT main handler
*   note 
*	1. Start doing FFT process when MFR page is 0xFF
*   2. clear RFFToutBuff and RFFTmagBuff
*	3. Fetch AC1 frequency and setting timer period
*	4. got AC1 input voltage Q11
*	5. Calu AC1 FFT
*	6. Fetch AC2 frequency and setting timer period
*	7. got AC2 input voltage Q11
*	8. Calu AC2 FFT
*	9. calu output real value for Pmbus used(unit is 0.01V RMS)
*	
*
****************************************************************************/
void FFT_Background_Process(void)
{
	u16_t i;

	if ((tsFFT.nFlag.u16Bits.u1ReciveRequest) &&
		(tsFFT.nFlag.u16Bits.u1InProcess == 0))
	{
		tsFFT.nFlag.u16All = 0;
		tsFFT.nFlag.u16Bits.u1InProcess = 1;
	}

	if (tsFFT.nFlag.u16Bits.u1InProcess == 0)
	{
		return;
	}

	if ((GET_MOMIAC_VAC1_DROP) || (GET_MOMIAC_VAC1_INPUTSTATUS != MoniAC_InputStatus_AC))
	{
		tsFFT.sRFFT[FFT_Tag_AC1].u16InputPresent = 0;
	}
	else
	{
		tsFFT.sRFFT[FFT_Tag_AC1].u16InputPresent = 1;
	}

	if ((GET_MOMIAC_VAC2_DROP) || (GET_MOMIAC_VAC2_INPUTSTATUS != MoniAC_InputStatus_AC))
	{
		tsFFT.sRFFT[FFT_Tag_AC2].u16InputPresent = 0;
	}
	else
	{
		tsFFT.sRFFT[FFT_Tag_AC2].u16InputPresent = 1;
	}

	for (i=0; i<FFT_Tag_Num; i++)
    {
    	if (tsFFT.sRFFT[i].u16InputPresent == 0)
    	{
    		tsFFT.sRFFT[i].u16VTHD = 0;
			tsFFT.sRFFT[i].u16VTHD_WF = 0;
			tsFFT.sRFFT[i].eStage = FFT_Stage_Finished;
    	} 
			
		switch (tsFFT.sRFFT[i].eStage)
		{
			case FFT_Stage_GetIsrPeriod:
				FFT_GetIsrPeriod(&tsFFT.sRFFT[i]);
				break;
			
			case FFT_Stage_ClearReportBuff:
				FFT_ClearReportBuff(&tsFFT.sRFFT[i]);
				break;
			
			case FFT_Stage_ClearoutBuff:
				FFT_ClearoutBuff(&tsFFT.sRFFT[i]);
				break;

			case FFT_Stage_ClearmagBuff:
				FFT_ClearmagBuff(&tsFFT.sRFFT[i]);
				break;

			case FFT_Stage_SetIsrPeripheral:
				FFT_SetIsrPeripheral(&tsFFT.sRFFT[i]);
				break;
			
			case FFT_Stage_FetchWaveform:
				FFT_FetchWaveform(&tsFFT.sRFFT[i]);
				break;

			case FFT_Stage_CalcuFFT:
				FFT_CalculateFFT(&tsFFT.sRFFT[i]);
				break;

			case FFT_Stage_GetRealValue:
				FFT_GetRealValue(&tsFFT.sRFFT[i]);
				break;

			case FFT_Stage_Finished:
				FFT_Finished(&tsFFT.sRFFT[i]);
				break;

			default:
				break;
		}
	}

	if ((tsFFT.nFlag.u16Bits.u1AC1FFTDone) &&
		(tsFFT.nFlag.u16Bits.u1AC2FFTDone))
	{
		tsFFT.nFlag.u16Bits.u1ReciveRequest = 0;
		tsFFT.nFlag.u16Bits.u1InProcess = 0;

		if (tsFFT.nFlag.u16Bits.u2IsrWorking != 0)
		{
			tsFFT.psInstance->RegsAddr->TCR.bit.TSS = 1; //stop cpu timer
		}
		
		for (i=0; i<FFT_Tag_Num; i++)
    	{
    		tsFFT.sRFFT[i].eStage = FFT_Stage_GetIsrPeriod;
		}
	}
}

/***************************************************************************
*   brief  Timer interrupt call back
*   note   Record AC waveform
****************************************************************************/
void FFT_Timercallback(void)
{
	if (tsFFT.nFlag.u16Bits.u2IsrWorking == 1)
	{
		if (tsFFT.sRFFT[FFT_Tag_AC1].u16SampleCNT < RFFT_SIZE)
		{
			AC1_RFFTin1Buff[tsFFT.sRFFT[FFT_Tag_AC1].u16SampleCNT] = (f32_t)GET_ADCFilter_ATS_VAC1_Sin;
			tsFFT.sRFFT[FFT_Tag_AC1].u16SampleCNT ++ ;
		}
	}
	else if (tsFFT.nFlag.u16Bits.u2IsrWorking == 2)
	{
		if (tsFFT.sRFFT[FFT_Tag_AC2].u16SampleCNT < RFFT_SIZE)
		{
			AC2_RFFTin1Buff[tsFFT.sRFFT[FFT_Tag_AC2].u16SampleCNT] = (f32_t)GET_ADCFilter_ATS_VAC2_Sin;
			tsFFT.sRFFT[FFT_Tag_AC2].u16SampleCNT ++ ;
		}
	}
}

/***************************************************************************
*   brief  Select Read harmonic Type (Read invidial rms harmonic or total harmonic) 
*   note : Read THD : (Total_RMS/1st_order)
           Read 3rd_order : (3rd_Order/1st_Order)
****************************************************************************/
void FFT_Read_Rarmonic(u8_t u8Value)
{
    if ((u8Value > 0) && (u8Value < Report_Amount))
    {
        tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic = (u16_t)(((f32_t)tsFFT.sRFFT[FFT_Tag_AC1].u16FFTOut[u8Value] / (f32_t)tsFFT.sRFFT[FFT_Tag_AC1].u16FFTOut[1]) * 10000); // Byte2~3 : S1 harmonic , Unit is 0.01%
        tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic = (u16_t)(((f32_t)tsFFT.sRFFT[FFT_Tag_AC2].u16FFTOut[u8Value] / (f32_t)tsFFT.sRFFT[FFT_Tag_AC2].u16FFTOut[1]) * 10000); // Byte4~5 : S2 harmonic , Unit is 0.01%
    }
    else
    {
        tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic = tsFFT.sRFFT[FFT_Tag_AC1].u16VTHD_WF;
        tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic = tsFFT.sRFFT[FFT_Tag_AC2].u16VTHD_WF;
    }
}

/***************************************************************************
*   brief  Select Read harmonic Type (Read invidial rms harmonic or total harmonic)
*   note : Read THD : (Total_RMS/1st_order)
           Read 3rd_order : (3rd_Order/1st_Order)
****************************************************************************/
void FFT_Read_Rarmonic_2(u8_t u8Value)
{
    if ((u8Value > 0) && (u8Value < Report_Amount))
    {
        tsFFT.u16Respond_ACK_2 = 0 + (u8Value << 8); // Byte0:ACK , Byte1:Harmonic order
        tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic_2 = (u16_t)(((f32_t)tsFFT.sRFFT[FFT_Tag_AC1].u16FFTOut[u8Value] / (f32_t)tsFFT.sRFFT[FFT_Tag_AC1].u16FFTOut[1]) * 10000); // Byte2~3 : S1 harmonic , Unit is 0.01%
        tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic_2 = (u16_t)(((f32_t)tsFFT.sRFFT[FFT_Tag_AC2].u16FFTOut[u8Value] / (f32_t)tsFFT.sRFFT[FFT_Tag_AC2].u16FFTOut[1]) * 10000); // Byte4~5 : S2 harmonic , Unit is 0.01%
    }
    else
    {
        if (u8Value == 0)
        {
            tsFFT.u16Respond_ACK_2 = 0;
        }
        else
        {
            tsFFT.u16Respond_ACK_2 = 1 + (u8Value << 8);
        }

        tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic_2 = tsFFT.sRFFT[FFT_Tag_AC1].u16VTHD_WF;
        tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic_2 = tsFFT.sRFFT[FFT_Tag_AC2].u16VTHD_WF;
    }
}

/***************************************************************************
*   brief  Pmbus call back funcion
*   note   Check PMbus request. if data is 0xFF, start doing FFT.
****************************************************************************/
void FFT_CheckRequest(u16_t u16MFRpage)
{
	if (u16MFRpage == 0xFF)
	{
		tsFFT.nFlag.u16Bits.u1ReciveRequest = 1;
	}
}

/***************************************************************************
*   brief  FFT 1s periodically process
*   note   	1. Input is AC
*			2. One of Input is present, calculate FT per 1s
****************************************************************************/
void FFT_1s_Periodically_Process(void)
{
	if ((GET_MOMIAC_VAC1_DROP == FALSE) || (GET_MOMIAC_VAC2_DROP == FALSE))
	{
		if (tsFFT.nFlag.u16Bits.u1InProcess == FALSE)
		{
			tsFFT.nFlag.u16Bits.u1ReciveRequest = 1;
		}	
	}

	/* For sensor data 0x18 */
    tsFFT.u16Respond_ACK   = 0;
	tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic = tsFFT.sRFFT[FFT_Tag_AC1].u16VTHD_WF;
	tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic = tsFFT.sRFFT[FFT_Tag_AC2].u16VTHD_WF;

    /* For sensor data 0x44 */
    tsFFT.u16Respond_ACK_2 = 0;
    tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic_2 = tsFFT.sRFFT[FFT_Tag_AC1].u16VTHD_WF;
    tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic_2 = tsFFT.sRFFT[FFT_Tag_AC2].u16VTHD_WF;
}

/***************************************************************************
*   brief  FFT Initialize
*   note   
****************************************************************************/
void FFT_Initialize(void)
{
	u16_t i;

	memset(&tsFFT, 0, sizeof(tsFFT));
	memset(&AC1_RFFTin1Buff, 0, sizeof(AC1_RFFTin1Buff));
	memset(&AC1_RFFToutBuff, 0, sizeof(AC1_RFFToutBuff));
	memset(&AC1_RFFTmagBuff, 0, sizeof(AC1_RFFTmagBuff));
	memset(&AC1_RFFTF32Coef, 0, sizeof(AC1_RFFTF32Coef));
	memset(&AC2_RFFTin1Buff, 0, sizeof(AC2_RFFTin1Buff));
	memset(&AC2_RFFToutBuff, 0, sizeof(AC2_RFFToutBuff));
	memset(&AC2_RFFTmagBuff, 0, sizeof(AC2_RFFTmagBuff));
	memset(&AC2_RFFTF32Coef, 0, sizeof(AC2_RFFTF32Coef));

	tsFFT.u32SamplingCoef = SamplingCoef;

	tsFFT.psInstance = &CpuTimer2;

	tsFFT.sRFFT[FFT_Tag_AC1].eTag = FFT_Tag_AC1;
	tsFFT.sRFFT[FFT_Tag_AC1].rfft.InBuf     = &AC1_RFFTin1Buff[0];  //Input buffer
    tsFFT.sRFFT[FFT_Tag_AC1].rfft.OutBuf    = &AC1_RFFToutBuff[0];  //Output buffer
    tsFFT.sRFFT[FFT_Tag_AC1].rfft.CosSinBuf = &AC1_RFFTF32Coef[0];  //Twiddle factor buffer
    tsFFT.sRFFT[FFT_Tag_AC1].rfft.MagBuf    = &AC1_RFFTmagBuff[0];  //Magnitude buffer
	tsFFT.sRFFT[FFT_Tag_AC1].f32RealValueCoef = GET_CALI_VS1_Gain / ((f32_t)Q12_ * 10 * 1.414);

	tsFFT.sRFFT[FFT_Tag_AC2].eTag = FFT_Tag_AC2;
	tsFFT.sRFFT[FFT_Tag_AC2].rfft.InBuf     = &AC2_RFFTin1Buff[0];  //Input buffer
    tsFFT.sRFFT[FFT_Tag_AC2].rfft.OutBuf    = &AC2_RFFToutBuff[0];  //Output buffer
    tsFFT.sRFFT[FFT_Tag_AC2].rfft.CosSinBuf = &AC2_RFFTF32Coef[0];  //Twiddle factor buffer
    tsFFT.sRFFT[FFT_Tag_AC2].rfft.MagBuf    = &AC2_RFFTmagBuff[0];  //Magnitude buffer
	tsFFT.sRFFT[FFT_Tag_AC2].f32RealValueCoef = GET_CALI_VS2_Gain / ((f32_t)Q12_ * 10 * 1.414);

	for (i=0; i<FFT_Tag_Num; i++)
    {
    	tsFFT.sRFFT[i].rfft.FFTSize   = RFFT_SIZE;
    	tsFFT.sRFFT[i].rfft.FFTStages = RFFT_STAGES;
		RFFT_f32_sincostable(&tsFFT.sRFFT[i].rfft);       //Calculate twiddle factor
    }
}


