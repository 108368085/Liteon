/****************************************************************************
 *	File	Handler_ATS.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/11/01 - 1st release
 ****************************************************************************/

#ifndef _HANDLER_ATS_H_
#define	_HANDLER_ATS_H_

#include "CONFIG_Define.h"
#include "SERV_SwitchDriver.h"
#include "Monitor_AC.h"
#include "Monitor_DC.h"
#include "SERV_LED.h"


/****************************************************************************
*	Public parameter definition
****************************************************************************/


/* Apply Source Parameter */
#define ATS_ApplySourceis1					0x01
#define	ATS_ApplySourceis2					0x02
#define SET_PREFER_SOURCE					ATS_ApplySourceis1

/* Manual Source Parameter */
#define MANUAL_SOURCE_Primary       		0x01
#define MANUAL_SOURCE_Secondary     		0x02
#define MANUAL_SOURCE_BBU           		0x03
#define MANUAL_SOURCE_Default				MANUAL_SOURCE_Primary

/* Load Priority, Single feed mode Parameter */
#define SIGNAL_INPUT_SOURCE      			0x01
#define DUAL_INPUT_SOURCE	    			0x02
#define DEFAULT_SINGLE_FEED_MODE    		DUAL_INPUT_SOURCE

/* Timer parameter */
#define DEFAULT_OBSERVE_DELAY_TIME          4       // 4s,	unit is 1s
#define MINIMUM_OBSERVE_DELAY_TIME          2       // 2s,  unit is 1s
#define MAXIMUM_OBSERVE_DELAY_TIME          5       // 5s,  unit is is

#define DEFAULT_OUTAGE_DELAY_TIME           90      // 90s, unit is 1s
#define MINIMUM_OUTAGE_DELAY_TIME           2       // 2s,  unit is 1s
#define MAXIMUM_OUTAGE_DELAY_TIME           90      // 90s, unit is 1s

#define DEFAULT_WALKIN_DELAY_TIME_LOW       1       // 1s,  unit is 1s
#define MINIMUM_WALKIN_DELAY_TIME_LOW       1       // 1s,  unit is 1s
#define MAXIMUM_WALKIN_DELAY_TIME_LOW       5       // 5s,  unit is 1s

#define DEFAULT_WALKIN_DELAY_TIME_HIGH      30      // 30s, unit is 1s
#define MINIMUM_WALKIN_DELAY_TIME_HIGH      12      // 12s, unit is 1s
#define MAXIMUM_WALKIN_DELAY_TIME_HIGH      60      // 60s, unit is 1s

#define DEFAULT_STABILIZATION_DELAY_TIME    300     // 300s,unit is 1s
#define MINIMUM_STABILIZATION_DELAY_TIME    2       // 2s,  unit is 1s
#define MAXIMUM_STABILIZATION_DELAY_TIME    600     // 600s,unit is 1s

#define DEFAULT_RETURN_DELAY_TIME    		0     	// 0s,unit is 1s


#define GET_ATS_PFCEnable_FLAG  			tsATS.nFlag.u16Bits.u1PFCEnable
#define GET_ATS_Bulk_Cali_MODE				tsATS.nFlag.u16Bits.u1BulkCalimode
#define GET_ATS_State						tsATS.eATSstate
#define GET_ATS_START_UP_FLAG 				tsATS.nFlag.u16Bits.u1StartUp

#define GET_APPLY_AC_VPEAK                  tsATS.ptApply->ptMoniAC->f32RealPeak
#define GET_APPLY_AC_FREQ                  	tsATS.ptApply->ptMoniAC->u16Freq_WF
#define GET_APPLY_DC_VPEAK 					(f32_t)tsATS.ptApply->ptMoniAC->u16RealInstant
#define GET_APPLY_INPUT_STATUS              tsATS.ptApply->ptMoniAC->nStatus.u16Bits.u2InputStatus
#define GET_APPLY_SwitchState               tsATS.ptApply->eSwitchState

#define GET_ATS_S1_PROT_FLAG 				tsATS.tsInput[ATS_InputTag_Input1].nFault.u16All
#define GET_ATS_S2_PROT_FLAG 				tsATS.tsInput[ATS_InputTag_Input2].nFault.u16All

#define GET_ATS_PRI_SRC_FLAG 				tsATS.ptSource[ATS_SourceTag_Primary]->nFlag.u16Bits.u1Valid // Used for ATS_PRI_SRC_Fail bit


// For Fault injection

#define SET_ATS_S1_RELAY_OPEN_Latch			tsATS.tsInput[ATS_InputTag_Input1].nFault.u16Bits.u1RealyOpen = 1
#define SET_ATS_S1_RELAY_OPEN_Clear			tsATS.tsInput[ATS_InputTag_Input1].nFault.u16Bits.u1RealyOpen = 0

#define SET_ATS_S2_RELAY_OPEN_Latch			tsATS.tsInput[ATS_InputTag_Input2].nFault.u16Bits.u1RealyOpen = 1
#define SET_ATS_S2_RELAY_OPEN_Clear			tsATS.tsInput[ATS_InputTag_Input2].nFault.u16Bits.u1RealyOpen = 0


// For System setting

#define SET_ATS_PREFER_SOURCE				tsATS.sContr.u8PreferSource_PSC
#define SET_ATS_SINGLE_FEED_MODE			tsATS.sContr.u8SINGLE_FEED_MODE
#define SET_ATS_OBSERVE_WINDOW				tsATS.sTimer.sConst.u8ObserveWindow
#define SET_ATS_OUTAGE_DELAY				tsATS.sTimer.sConst.u8OutageDelay
#define SET_ATS_WALK_IN_LOW					tsATS.sTimer.u8WalkinLow
#define SET_ATS_WALK_IN_HIGH				tsATS.sTimer.u8WalkinHigh
#define SET_ATS_STABILIZE_DELAY				tsATS.sTimer.sConst.u16StabilizationDelay
#define GET_ATS_WalkinTimeOut_ToD2D         tsATS.sTimer.u16WalkinTime_Out
#define GET_ATS_ForceD2DOn                  tsATS.sContr.u8Force_D2DOn

// For Relay fault count

#define SET_ATS_AC1_RealyOpen_FaultCNT		tsATS.tsInput[0].u8RelayOpen_FaultCNT = 0
#define SET_ATS_AC1_RealyShort_FaultCNT		tsATS.tsInput[0].u8RelayShort_FaultCNT = 0

#define SET_ATS_AC2_RealyOpen_FaultCNT		tsATS.tsInput[1].u8RelayOpen_FaultCNT = 0
#define SET_ATS_AC2_RealyShort_FaultCNT		tsATS.tsInput[1].u8RelayShort_FaultCNT = 0



/****************************************************************************
*	Public macro definition
****************************************************************************/

/****************************************************************************
*	Public enumeration definition 
****************************************************************************/

typedef enum
{
	ATS_State_Off = 0,		// ATS off
    ATS_State_Operating,	// Normal operating state
    ATS_State_Suspend,		// Ready to enter boot mode
}eATSMainState_t;


typedef enum
{
	ATS_InputTag_Input1 = 0,
	ATS_InputTag_Input2,
	ATS_InputTag_Num,
}eATS_Input_Tag_t;

typedef enum
{
	ATS_SourceTag_Primary = 0,
	ATS_SourceTag_Secondary,
	ATS_SourceTag_Num,
}eATS_Source_Tag_t;


typedef enum
{
	ATS_SwitchTag_ATSRelay = 0,
	ATS_SwitchTag_InrushRelay,
	ATS_SwitchTag_InrushIGBT,
	ATS_SwitchTag_Num,
}eATS_Switch_Tag_t;


typedef enum
{
    ATSStatus_Reset = 0,       	//ATS Input off
    ATSStatus_Switch,       	//ATS switching
    ATSStatus_Pri,             	//ATS Input is Primary
	ATSStatus_Sec,			   	//ATS Input is Secondary
	ATSStatus_BBU,			   	//ATS Input is BBU
}eATSStateMachine_t;


typedef enum
{
    ATSSwitch_StaticOff = 0,
	ATSSwitch_PreTurnOnATSRelay,
	ATSSwitch_ATSRelayOn,
	ATSSwitch_IGBTOn,
	ATSSwitch_PreTurnOnInrushRelay,
	ATSSwitch_StaticOn,
}eATSSwitchState_t;


typedef enum
{
	ATS_ITIC_Loss = 0,		// Input loss
    ATS_ITIC_Notusefull,	// < 155
    ATS_ITIC_UVP,			// 155 ~ 170
    ATS_ITIC_Normal,		// > 170
}eATS_ITIC_State_t;


/****************************************************************************
*	Public structure definition 
****************************************************************************/

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u2ATSEnable			: 2;        // 0:ATS disable, 1:Pri Enable, 2:Sec Enable, 3:BBU Enable
		u16_t u1PFCEnable			: 1;        // 0:PFC disable, 1:PFC Enable
		u16_t u1PFCFault			: 1;        // 0:PFC no fault, 1:PFC fault
		u16_t u1StartUp				: 1;        // 0:ATS cannot start up, 1:ATS could start up
		u16_t u1FirstOn				: 1;        // 0:ATS is not first turn on, 1:ATS is first turn on at Zero cross
		u16_t u1RideThrough			: 1;    	// 1:enable, 0:disable ride through
    	u16_t u1ExtendRideThrough	: 1; 		// 1:AC come back, 0:reset , no used

		u16_t u1WalkInRandomTime    : 1;        // 0: Reset walkin time, 1:Set walkin time(ready to return AC1)
		u16_t u1TimeStartCNT    	: 1;        // 1:AC2 return to AC1 start Count, 0: no any time count
		u16_t u1ReturnStartCNT    	: 1;		// 1:Return delay start count, 0: no any time count
		u16_t u1OutageStartCNT    	: 1;		// 1:Outage delay start count, 0: no any time count
		u16_t u1BulkCalimode	    : 1;        // 1:ATS into Bulk cap calibration mode shut down D2D, and PFC suspend, 0: ATS normal mode
		u16_t u1AC_Loss_Log			: 1;		// 1:already transmit AC Loss message, 0: has not transmitted AC Loss
		u16_t u1AC_Recovery_Log    	: 1;		// 1:already transmit AC recovery message, 0: has not transmitted AC recovery
		u16_t u1RideThrough_Action 	: 1;		// 1:Ridethrouth action need to reset, 0: no need to reset ridethrough count
	}u16Bits;
}nATSFlag_t;



typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1Valid				: 1;		// Input Source valid, , For LED
		u16_t u1Useful				: 1;		// Input Source not valid but Useful , For LED
		u16_t u1Standby				: 1;		// Input Source not valid/Useful, but within standby , For LED
		u16_t u2Health				: 2;		// 0:Input InValid, 1:StandBy, 2:Input useful, 3:Input Valid , For ATS state machine
		u16_t u1Apply				: 1;		// 0:ATS relay is not connected , 1:ATS relay is connected
		u16_t Reserved				: 10;
	}u16Bits;
}nATSManagerFlag_t;


typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1RealyOpen			: 1;		// ATS relay open fault
		u16_t u1RealyShort			: 1;		// ATS relay short fault
		u16_t Reserved				: 14;
	}u16Bits;
}nATSManagerFault_t;


typedef struct
{
	u32_t u32ObserveWindow;         // unit is 0.1ms
    u32_t u32StabilizationDelay;    // unit is 0.1ms , When ATS source is S2 now and S1 also valid keep 300s then source will do Walkin-time turn to S1
    u32_t u32OutageDelay;           // Default is 90s , unit is 0.1ms
    u32_t u32ReturnDelay;           // Default is 0s , unit is 0.1ms
}sATSDelayVar_t;

typedef struct
{
	u16_t u16StabilizationDelay;    // unit is 1s
	u8_t u8ObserveWindow;         	// unit is 1s
    u8_t u8OutageDelay;             // unit is 1s
    u8_t u8ReturnDelay;             // unit is 1s
}sATSDelayCon_t;

typedef struct
{
	eATS_Input_Tag_t eTag;			    // Input manager identifier 0:Input1 or 1:Input2
    nATSManagerFlag_t nFlag;          	// Identifier AC Flag
	nATSManagerFault_t nFault;      	// Componentfault
	eATSSwitchState_t eSwitchState;		// Current Switching state
	eATSSwitchState_t ePreSwitchState;	// Previously Switching state
	sSwitchDriver_t* ptSwitch[ATS_SwitchTag_Num];
	sMoniAC_t *ptMoniAC;				// AC monitor
	sLED_t *psACLED;				    // AC LED configure
	u16_t u16ElapsedTime;				// unit is 0.1ms
	
	// For ATS relay
    u16_t u16RelayShort_CNT;            // ATS relay short count
    u16_t u16RelayShort_FaultCNT_RecoveryCNT;     // ATS relay short fault count recovery count,  default is 1hr
    u8_t  u8RelayShort_RecoveryCNT;    	// ATS relay short recovery count, default is 10s
    u8_t  u8RelayShort_FaultCNT;       	// ATS relay short fault count, default is 3 times

	u16_t u16RelayOpen_CNT;             // ATS relay open count
	u16_t u16RelayOpen_FaultCNT_RecoveryCNT;     // ATS relay open fault count recovery count,  default is 1hr
    u8_t  u8RelayOpen_RecoveryCNT;     	// ATS relay open recovery count,  default is 10s
    u8_t  u8RelayOpen_FaultCNT;        	// ATS relay open fault count,  default is 3 times
}sATSManager_t;


typedef struct
{
    sATSDelayVar_t sVar;         	// varies
    sATSDelayCon_t sConst;       	// constant
    u32_t u32ATSSelect_CNT;         // unit is 0.1ms, For BBU emergency to S1 delay time
    u8_t  u8Get_WalkinTime;         // unit is 1s , Get WalkinTime
    u32_t u32WalkinTime;            // unit is 0.1ms
    u16_t u16WalkinTime_Out;        // unit is 100ms , Pass to D2D by ModBus , 10:means no walking time
    u16_t u16WalkinTime_Out_DefaultCNT; // unit is 100ms
    u32_t u32RandomTime_Range;      // unit is 1ms
    u32_t u32RideThroughTimeOut;    // unit is 0.1ms
    u32_t u32RideThroughCNT;    	// unit is 0.1ms
    u32_t u32Drop_Delay;    		// unit is 0.1ms
    u16_t u16InputReadyTime;		// unit is 0.1ms
    u16_t u16InputReadyDelay;		// unit is 0.1ms
	u16_t u16StartUp_Dealy;    		// unit is 1ms
    u8_t  u8WalkinLow;              // unit is 1s
    u8_t  u8WalkinHigh;             // unit is 1s
}sATSManagerTimer_t;

typedef struct
{
	u8_t  u8PreferSource;           // define prefer source is AC1 or AC2  (default is AC1)	
	u8_t  u8PreferSource_PSC;       // define prefer source is AC1 or AC2 by PSC (default is AC1)
	u8_t  u8ManuallySource;         // 0:Normal control, 1:manually control at AC1, 1:manually control at AC2
	u8_t  u8ManuallySource_PSC;     // 0:Normal control, 1:manually control at AC1, 1:manually control at AC2, by PSC
	u8_t  u8SINGLE_FEED_MODE;		// 0:Secondary Source LED DISABLED, 1:Secondary source LED Normal
	u8_t  u8Force_D2DOn;            // 0:D2D off, 1:D2D on
}sSysControl_t;


typedef struct
{
	eATSMainState_t eState;							// Current Main state
	eATSMainState_t ePreState;						// Previously Main state
	eATSStateMachine_t eATSstate;					// Current ATS state machine
	eATSStateMachine_t ePreATSstate;				// Previously ATS state machine
	eATS_ITIC_State_t eITICstate;					// ITIC state machine
	nATSFlag_t	nFlag;								// ATS control flag
	sSysControl_t sContr;							// ATS Control parameter from PSC
	sATSManagerTimer_t sTimer;						// ATS Control timer config
	sATSManager_t tsInput[ATS_InputTag_Num];		// Input manager reference to AC1 or AC2 (for report)
	sATSManager_t* ptSource[ATS_SourceTag_Num];		// Input manager reference to Primary or secondary source control by prefersource (for state machine)
	sATSManager_t* ptApply;							// Source reference is applying	
}sATS_t;



/****************************************************************************
*	Public export variable
****************************************************************************/
extern sATS_t tsATS;

/****************************************************************************
*	Public export function prototype
****************************************************************************/
extern void ATS_Initialize(void);
extern void ATS_Handler(void);
extern void ATS_1s_Periodically_Process(void);
extern void ATS_1ms_Periodically_Process(void);
extern void PSUPlugOut(void);
extern u16_t Is_Ready_to_Switch(void);
extern u16_t CheckApplyInput(void);
extern u16_t IS_InrushRelay_On(void);
extern void Update_StabilizationDelay(void);
extern void Update_ObserveWindow(void);
extern void Update_OutageDelay(void);
extern void Update_Random_Number_Range(void);
extern void ATS_100ms_Periodically_Process(void);


#endif	/* HANDLER_ATS_H_ */

