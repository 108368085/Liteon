/****************************************************************************
 *	File	SERV_FFT.c
 * 	Brief	Header file for RFFT calculation
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2019/05/29 - 1st release
 *  Modify: C:\ti\controlSUITE\libs\dsp\FPU\v131\examples\2833x_RFFT
 ****************************************************************************/

#ifndef _SERV_FFT_H_
#define _SERV_FFT_H_

#include "F28x_Project.h"
#include "CONFIG_Define.h"
#include "FPU.h"

/****************************************************************************
	Public parameter definition
****************************************************************************/

#define GET_FFT_VAC1			tsFFT.sRFFT[FFT_Tag_AC1].u16VTHD_WF
#define GET_FFT_VAC2			tsFFT.sRFFT[FFT_Tag_AC2].u16VTHD_WF

#define GET_READ_HARMONIC_ACK   tsFFT.u16Respond_ACK
#define GET_READ_HARMONIC_VAC1	tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic
#define GET_READ_HARMONIC_VAC2	tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic

#define GET_READ_HARMONIC_ACK_2   tsFFT.u16Respond_ACK_2
#define GET_READ_HARMONIC_VAC1_2  tsFFT.sRFFT[FFT_Tag_AC1].u16Read_Harmonic_2
#define GET_READ_HARMONIC_VAC2_2  tsFFT.sRFFT[FFT_Tag_AC2].u16Read_Harmonic_2

#define	RFFT_STAGES				7
#define	RFFT_SIZE				(1 << RFFT_STAGES) 
#define	Report_Amount			40+1

/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

typedef enum
{
	FFT_Tag_AC1 = 0,
	FFT_Tag_AC2,
	FFT_Tag_Num
}eFFTchannel_t;

typedef enum
{
	FFT_Stage_GetIsrPeriod = 0,
	FFT_Stage_ClearReportBuff,
	FFT_Stage_ClearoutBuff,
	FFT_Stage_ClearmagBuff,
	FFT_Stage_SetIsrPeripheral,
	FFT_Stage_FetchWaveform,
	FFT_Stage_CalcuFFT,
	FFT_Stage_GetRealValue,
	FFT_Stage_Finished
}eFFTStage_t;

/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1ReciveRequest	: 1;
		u16_t u1InProcess		: 1;
		u16_t u2IsrWorking		: 2;	//0:disable Timer1, 1:Isr for AC1, 2:Isr for AC2
		u16_t u1AC1FFTDone		: 1;
		u16_t u1AC2FFTDone		: 1;
		u16_t Reserved			: 10;
	}u16Bits;
}nFFTHandleFlag_t;

typedef struct
{
	eFFTchannel_t eTag;
	eFFTStage_t eStage;
	RFFT_F32_STRUCT rfft;
	u16_t u16InputPresent;
	u16_t u16ACFrequency;				// unit is 0.1Hz
	u16_t u16IsrPeriod;
	u16_t u16SampleCNT;					// max is 128
	u16_t u16FFTOut[Report_Amount];		// unit is 0.01V RMS
	u16_t u16VTHD;						// unit is 0.01%
	u16_t u16VTHD_WF;					// unit is 0.01%, with filter
	u16_t u16Read_Harmonic;				// either u16FFTOut or u16VTHD_WF to Canbus report
    u16_t u16Read_Harmonic_2;           // either u16FFTOut or u16VTHD_WF to Canbus report
	u32_t u32FFTOut_SUM;				// sum of u16FFTOut^2 (n=2,3,4,5...)
	f32_t f32RealValueCoef;				// unit is 0.01V RMS
}sRFFT_t;

typedef struct
{
    u16_t u16Respond_ACK;   // Byte0:ACK , Byte1:Harmonic order
    u16_t u16Respond_ACK_2; // Byte0:ACK , Byte1:Harmonic order
	nFFTHandleFlag_t nFlag;
	u32_t u32SamplingCoef;
	/* Instance handler */
    volatile struct CPUTIMER_VARS* psInstance;
	sRFFT_t sRFFT[FFT_Tag_Num];
}sFFTHandle_t;


/****************************************************************************
	Public export variable
****************************************************************************/

extern sFFTHandle_t tsFFT;

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void FFT_Initialize(void);
extern void FFT_Background_Process(void);
extern void FFT_Timercallback(void);
extern void FFT_1s_Periodically_Process(void);
extern void FFT_CheckRequest(u16_t u16MFRpage);		//ADToDo
extern void FFT_Read_Rarmonic(u8_t u8Value);
extern void FFT_Read_Rarmonic_2(u8_t u8Value);


#endif /* INCLUDE_USER_FFT_H_ */
