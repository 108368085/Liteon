/****************************************************************************
 *	File	Peripheral_SPI.h
 * 	Brief	Header file for Peripheral SPI module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/12/10 - 1st release
 ****************************************************************************/

#ifndef _PERIPHERAL_SPI_H_
#define _PERIPHERAL_SPI_H_

#include "CONFIG_Define.h"
#include "Peripheral.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/
#define USE_SPI_CHANNEL_A
//#define USE_SPI_CHANNEL_B
	
#ifdef  USE_SPI_CHANNEL_A
#define SPI_A_MASTER_MODE
#define SPI_A_SIMO_MUX_SEL		7
#define SPI_A_SOMI_MUX_SEL		7
#define SPI_A_CLK_MUX_SEL		7
#define SPI_A_STE_MUX_SEL		0
#define SPI_A_SIMO_PIN_NUM      GPIO_PIN_8
#define SPI_A_SOMI_PIN_NUM      GPIO_PIN_10
#define SPI_A_CLK_PIN_NUM      	GPIO_PIN_9
#define SPI_A_STE_PIN_NUM      	GPIO_PIN_11
#endif
	
#ifdef  USE_SPI_CHANNEL_B
//#define SPI_B_MASTER_MODE
#define SPI_B_SIMO_MUX_SEL		6
#define SPI_B_SOMI_MUX_SEL		6
#define SPI_B_CLK_MUX_SEL		6
#define SPI_B_STE_MUX_SEL		0
#define SPI_B_SIMO_PIN_NUM      GPIO_PIN_24
#define SPI_B_SOMI_PIN_NUM      GPIO_PIN_25
#define SPI_B_CLK_PIN_NUM      	GPIO_PIN_26
#define SPI_B_STE_PIN_NUM      	GPIO_PIN_27
#endif

/****************************************************************************
	Public macro definition
****************************************************************************/



/****************************************************************************
	Public enumeration definition 
****************************************************************************/

typedef enum ePeripheral_SPI_Channel
{

#ifdef USE_SPI_CHANNEL_A
    ePeriSPI_Channel_A,
#endif

#ifdef USE_SPI_CHANNEL_B
    ePeriSPI_Channel_B,
#endif

    ePeriSPI_Channel_Num,
}ePeripheral_SPI_Channel_t;

/** Master SPI transaction error */
typedef enum eMstSPI_Error_Enumeration
{
    MSPI_ERROR_NONE = 0,           			///< No Error
    MSPI_ERROR_BUS_ERROR,               	///< Bus error, misplaced start or stop signal
}eMSPI_Error_Enumeration_t;


/** Master SPI transaction state */
typedef enum eMstSPITransactionState
{
    MSPI_TRANSACTION_STATE_IDLE = 0,    	///< This transaction is idle
    MSPI_TRANSACTION_STATE_QUEUEING,    	///< This transaction is queuing for SPI Bus
    MSPI_TRANSACTION_STATE_TRANSACTING, 	///< This transaction is transacting
    MSPI_TRANSACTION_STATE_ACCOMPLISH,  	///< This transaction has accomplished
    MSPI_TRANSACTION_STATE_ERROR,       	///< This transaction triggered an error
}eMstSPITransactionState_t;


/** Master SPI Read and Write state */
typedef enum eSPIReadWriteState
{
	SPI_STATE_IDLE = 0,  	///< In idle state
    SPI_STATE_CHECKWIP,		///< Start in process, check EEPROM Write In Progress status
    SPI_STATE_OPCODE,    	///< Write opcode to EEPROM(Enable Write or Disable Write)
    SPI_STATE_CHECKWEL, 	///< check EEPROM Write Enable Latch status
    SPI_STATE_DATA,  		///< Data transaction
}eSPIReadWriteState_t;



/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1RWProcess				: 1;	// 0:Read process, 1:Write process
		u16_t u1EEPROMDisable			: 1;	// 0:Enable EEPROM Vcc, 1:Disable EEPROM Vcc
		u16_t uReserved					: 14;
	}u16Bits;
}nMstSPIFlag_t;


typedef struct sMstSPITransaction
{
    eMstSPITransactionState_t eState;
    u16_t u16SlaveAddress;
    u8_t  pu8MemoryAddress[4];
    u16_t u16MemoryAddressLength;
    u8_t* pu8TxBuff;
    u16_t u16TxIndex;
    u16_t u16TxLength;
    u8_t* pu8RxBuff;
    u16_t u16RxIndex;
    u16_t u16RxLength;
    u16_t u16ErrorCode;
    void (*pfFinishCallback)(struct sMstSPITransaction* psTransaction);
    struct sMstSPITransaction* psNext;
}sMstSPITransaction_t;

typedef struct sMstSPIHandler
{
	eSPIReadWriteState_t eState;
	eSPIReadWriteState_t ePreState;
	nMstSPIFlag_t nFlag;
	u16_t u16Step;
	u16_t u16RxTemp;
    sMstSPITransaction_t* psTransaction;
    u16_t u16BusIdleDelay;
	u16_t u16BusErrorDelay;
	u16_t u16DeviceResetDelay;
}sMstSPIHandler_t;


typedef struct sPeriSPI_Driver
{
    u16_t u16Port;		///< Which Port is used
    u16_t u16Role;    	///< This SPI channel is Master role or Slave role
    
    /* Instance handler */
    volatile struct SPI_REGS* psInstance;
    
    /* Master SPI Handler*/
    sMstSPIHandler_t sMasterHandler;
    
    /* Slave SPI Handler */
    //sSlvSPIHandler_t sSlaveHandler;
}sPeriSPI_Driver_t;
	

/****************************************************************************
	Public export variable
****************************************************************************/
extern sPeriSPI_Driver_t ptsPeriSPIDriver[ePeriSPI_Channel_Num];


/****************************************************************************
	Public export function prototype
****************************************************************************/
extern eMstSPITransactionState_t MstSPI_PushTransaction(u16_t u16Channel, sMstSPITransaction_t* psNewTransaction);
extern void PeriSPI_1ms_Periodically_Process(void);
extern void PeriSPI_Background_Process(void);
extern void PeriSPI_Initialize(void);
extern void PeriSPI_ResetBusIdleDelay(void);
extern void PeriSPI_Start(void);
extern void PeriSPI_Stop(void);


#endif
