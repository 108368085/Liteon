/*******************************************************************************
* file				CONFIG_Define.h
* brief				The file includes the function and data structure/variables
*					for this model
* note
* author			Adonis.wang
* version			01
* section History	2020/11/11 - 1st release
*******************************************************************************/
#ifndef _CONFIG_DEFINE_H_
#define _CONFIG_DEFINE_H_

#include "F28x_Project.h"

/****************************************************************************
    Public parameter definition
****************************************************************************/

#define TI_C28_PLATFORM

#ifndef TRUE
    #define TRUE                    1
#endif

#ifndef FALSE
    #define FALSE                   0
#endif

#ifndef ON
    #define ON                      1
#endif

#ifndef OFF
    #define OFF                     0
#endif

#ifndef HIGH
    #define HIGH                    1
#endif

#ifndef LOW
    #define LOW                     0
#endif

#ifndef NULL
    #define NULL                    0
#endif

#define U16_MAX_VALUE               0xFFFF
#define I16_MAX_POSITIVE_VALUE      (32767)
#define I16_MAX_NEGATIVE_VALUE      (-32768)


#ifndef AcceptPassword
    #define AcceptPassword          (0x55AA)
#endif

#ifndef ResetPassword
    #define ResetPassword           (0xD3E9)
#endif


//-----------------------Q FORMAT------------------------------------------
#define Q1_                 2
#define Q2_                 4
#define Q3_                 8
#define Q4_                 16
#define Q5_                 32
#define Q6_                 64
#define Q7_                 128
#define Q8_                 256
#define Q9_                 512
#define Q10_                1024
#define Q11_                2048
#define Q12_                4096
#define Q13_                8192
#define Q14_                16384
#define Q15_                32768
#define Q16_                65536
#define Q17_                131072
#define Q18_                262144
#define Q19_                524288
#define Q20_                1048576
#define Q21_                2097152
#define Q22_                4194304
#define Q23_                8388608
#define Q24_                16777216
#define Q25_                33554432
#define Q26_                67108864
#define Q27_                134217728
#define Q28_                268435456
#define Q29_                536870912
#define Q30_                1073741824
#define Q31_                2147483648
#define Q32_                4294967296

#define Q1_1				1
#define Q2_1				3
#define Q3_1				7
#define Q4_1				15
#define Q5_1				31
#define Q6_1				63
#define Q7_1				127
#define Q8_1				255
#define Q9_1				511
#define Q10_1				1023
#define Q11_1				2047
#define Q12_1				4095
#define Q13_1				8191
#define Q14_1				16383
#define Q15_1				32767
#define Q16_1				65535
#define Q17_1				131071
#define Q18_1				262143
#define Q19_1				524287
#define Q20_1				1048575
#define Q21_1				2097151
#define Q22_1				4194303
#define Q23_1				8388607
#define Q24_1				16777215
#define Q25_1				33554431
#define Q26_1				67108863
#define Q27_1				134217727
#define Q28_1				268435455
#define Q29_1				536870911
#define Q30_1				1073741823
#define Q31_1				2147483647
#define Q32_1				4294967295


/****************************************************************************
    Public macro definition
****************************************************************************/
#ifndef u8_t
typedef unsigned char   	u8_t;       // 8 bit unsigned data
#endif

#ifndef u16_t
typedef unsigned short  	u16_t;      // 16 bit unsigned data
#endif

#ifndef u32_t
typedef unsigned long   	u32_t;		// 32 bit unsigned data
#endif

#ifndef u64_t
typedef unsigned long long  u64_t;		// 64 bit unsigned data
#endif

#ifndef i8_t
typedef signed char     	i8_t;       // 8 bit signed data
#endif

#ifndef i16_t
typedef signed short    	i16_t;      // 16 bit signed data
#endif

#ifndef i32_t
typedef signed long     	i32_t;      // 32 bit signed data
#endif

#ifndef i64_t
typedef signed long long 	i64_t;      // 64 bit signed data
#endif

#ifndef f32_t
typedef float 				f32_t;      // 32 bit float, significant digit is 7
#endif

#ifndef f64_t
typedef long double  		f64_t;      // 64 bit float, significant digit is 16
#endif



#ifndef funcPtr
typedef void (*funcPtr)();             ///< function point
#endif



#ifndef __OffsetOf
    #define __OffsetOf(type, field)     ((u32_t)&(((type*) 0)-> field))
#endif

#ifndef __ContainerOf
    #define __ContainerOf(ptr, type, member)                                                    \
                (type *)((long)ptr - __OffsetOf(type, member))
#endif

#ifndef __LByteToWord   // LSB first
    #define __LByteToWord(pu8Data)      ((((u16_t)(pu8Data)[1]) << 8) + (pu8Data)[0])
#endif

#ifndef __MByteToWord   // MSB first
    #define __MByteToWord(pu8Data)      ((((u16_t)(pu8Data)[0]) << 8) + (pu8Data)[1])
#endif


#ifndef __LByteToDWord  // LSB first
    #define __LByteToDWord(pu8Data)             (((u32_t)(pu8Data[3]) << 24) + ((u32_t)(pu8Data[2]) << 16) + ((u32_t)(pu8Data[1]) << 8) + ((u32_t)(pu8Data[0])))
#endif

#ifndef __MByteToDWord  // MSB first
    #define __MByteToDWord(pu8Data)             (((u32_t)(pu8Data[0]) << 24) + ((u32_t)(pu8Data[1]) << 16) + ((u32_t)(pu8Data[2]) << 8) + ((u32_t)(pu8Data[3])))
#endif

#ifndef __WordToLByte   // LSB first
    #define __WordToLByte(pu8Dest, u16Data)     do{                                             \
                                                       *pu8Dest = (u8_t)(u16Data & 0xFF);       \
                                                       *(pu8Dest+1) = (u8_t)(u16Data>>8);       \
                                                  }while(0)
#endif

#ifndef __WordToMByte   // MSB first
    #define __WordToMByte(pu8Dest, u16Data)     do{                                             \
                                                       *pu8Dest = (u8_t)(u16Data >> 8);         \
                                                       *(pu8Dest+1) = (u8_t)(u16Data & 0xFF);   \
                                                  }while(0)
#endif

/**
 *  @brief  Convert u8_t array to two double word (32 bits + 32 bits) which the LSB will be put at first byte (for CAN)
 *  @note   {0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6, 0xG7, 0xH8} => A:0xD4C3B2A1, B:0xH8G7F6E5
 *  @param  pu8Dest: Pointer to u8_t array
 *  @param  u32Data_A, u32Data_B: 32-bits data
 *  @retval None
 */
#ifndef __LByteToTDWord  // LSB first
    #define __LByteToTDWord(pu8Data, u32Dest_A, u32Dest_B)    do{                               												\
			u32Dest_A = (((u32_t)(pu8Data[3]) << 24) + ((u32_t)(pu8Data[2]) << 16) + ((u32_t)(pu8Data[1]) << 8) + ((u32_t)(pu8Data[0])));		\
			u32Dest_B = (((u32_t)(pu8Data[7]) << 24) + ((u32_t)(pu8Data[6]) << 16) + ((u32_t)(pu8Data[5]) << 8) + ((u32_t)(pu8Data[4])));		\
                                                  				}while(0)
#endif

/**
 *  @brief  Convert two double word (32 bits + 32 bits) to u8_t array which the LSB will be put at first byte (for CAN)
 *  @note   A:0xA1B2C3D4, B:0xE5F6G7H8 => {0xD4, 0xC3, 0xB2, 0xA1, 0xH8, 0xG7, 0xF6, 0xE5}
 *  @param  pu8Dest: Pointer to u8_t array
 *  @param  u32Data_A, u32Data_B: 32-bits data
 *  @retval None
 */
#ifndef __TDWordToLByte  // LSB first
    #define __TDWordToLByte(pu8Dest, u32Data_A, u32Data_B)    do{                               	\
                                                        *pu8Dest 	 = (u8_t)(u32Data_A);         	\
                                                        *(pu8Dest+1) = (u8_t)(u32Data_A >> 8);    	\
                                                        *(pu8Dest+2) = (u8_t)(u32Data_A >> 16);   	\
                                                        *(pu8Dest+3) = (u8_t)(u32Data_A >> 24);   	\
                                                        *(pu8Dest+4) = (u8_t)(u32Data_B);   		\
                                                        *(pu8Dest+5) = (u8_t)(u32Data_B >> 8);   	\
                                                        *(pu8Dest+6) = (u8_t)(u32Data_B >> 16);   	\
                                                        *(pu8Dest+7) = (u8_t)(u32Data_B >> 24);   	\
                                                  				}while(0)
#endif


/**
 *  @brief  Convert double word (32 bits) to u8_t array which the LSB will be put at first byte
 *  @note   0xA1B2C3D4 => {0xD4, 0xC3, 0xB2, 0xA1}
 *  @param  pu8Dest: Pointer to u8_t array
 *  @param  u32Data: 32-bits data
 *  @retval None
 */
#ifndef __DWordToLByte  // LSB first
    #define __DWordToLByte(pu8Dest, u32Data)    do{                                             \
                                                        *pu8Dest = (u8_t)u32Data;               \
                                                        *(pu8Dest+1) = (u8_t)(u32Data >> 8);    \
                                                        *(pu8Dest+2) = (u8_t)(u32Data >> 16);   \
                                                        *(pu8Dest+3) = (u8_t)(u32Data >> 24);   \
                                                  }while(0)
#endif

/**
 *  @brief  Convert double word (32 bits) to u8_t array which the MSB will be put at first byte
 *  @note   0xA1B2C3D4 => {0xA1, 0xB2, 0xC3, 0xD4}
 *  @param  pu8Dest: Pointer to u8_t array
 *  @param  u32Data: 32-bits data
 *  @retval None
 */
#ifndef __DWordToMByte  // MSB first
    #define __DWordToMByte(pu8Dest, u32Data)    do{                                                 \
                                                        *pu8Dest = (u8_t)(u32Data >> 24);           \
                                                        *(pu8Dest+1) = (u8_t)(u32Data >> 16);       \
                                                        *(pu8Dest+2) = (u8_t)(u32Data >> 8);        \
                                                        *(pu8Dest+3) = (u8_t)(u32Data & 0x000000FF);\
                                                  }while(0)
#endif

/**
 *  @brief  Convert double word (32 bits) to u16_t array which the LSB will be put at first element
 *  @note   0xA1B2C3D4 => {0xC3D4, 0xA1B2}
 *  @param  pu16Dest: Pointer to u16_t array
 *  @param  u32Data: 32-bits data
 *  @retval None
 */
#ifndef __DWordToLWord  // LSB first
    #define __DWordToLWord(pu16Dest, u32Data)   do{                                                 \
                                                        *pu16Dest = (u16_t)(u32Data & 0xFFFF);      \
                                                        *(pu16Dest+1) = (u16_t)(u32Data >> 16);     \
                                                  }while(0)
#endif


/**
 *  @brief  Convert double word (32 bits) to u16_t array which the MSB will be put at first element
 *  @note   0xA1B2C3D4 => {0xA1B2, 0xC3D4}
 *  @param  pu16Dest: Pointer to u16_t array
 *  @param  u32Data: 32-bits data
 *  @retval None
 */
#ifndef __DWordToMWord  // LSB first
    #define __DWordToMWord(pu16Dest, u32Data)   do{                                                 \
                                                        *pu16Dest = (u16_t)(u32Data >> 16);         \
                                                        *(pu16Dest+1) = (u16_t)(u32Data & 0xFFFF);  \
                                                  }while(0)
#endif

/**
 *  @brief  Convert a u16_t array which LSB is put at the first word to double word (32 bits)
 *  @note   {0xC3D4, 0xA1B2} => 0xA1B2C3D4
 *  @param  pu16Src: Pointer to u16_t array
 *  @retval u32Data
 */
#ifndef __LWordToDWord  // LSB first
    #define __LWordToDWord(pu16Src)             ((u32_t)(pu16Src)[0] + ((u32_t)(pu16Src)[1] << 16))
#endif

/**
 *  @brief  Convert a u16_t array which MSB is put at the first word to double word (32 bits)
 *  @note   {0xA1B2, 0xC3D4}
 *  @param  pu16Src: Pointer to u16_t array
 *  @retval u32Data
 */
#ifndef __MWordToDWord  // MSB first
    #define __MWordToDWord(pu16Src)              (((u32_t)(pu16Src)[0] << 16) + (u32_t)(pu16Src)[1])
#endif



#ifndef __SwapEndian
    #define __SwapEndian(u16Src)    (((u16Src & 0xFF00)>>8) + ((u16Src & 0x00FF)<<8))
#endif   

#ifndef UNUSED
    #define UNUSED(x) ((void)(x))
#endif
                                                    


#ifndef __HeadElement
    #define __HeadElement(Array)       (Array[0])
#endif

#ifndef __TailElement
    #define __TailElement(Array)        (Array[__ElementCountOf(Array)-1])
#endif

#ifndef __ElementCountOf
    #define __ElementCountOf(array)     (sizeof(array)/sizeof(array[0]))
#endif

#ifndef __ElementIndexOf
    #define __ElementIndexOf(ptr, container, ElememtSize)  ((ptr - container) / sizeof(ElememtSize))
#endif


/****************************************************************************
    Public enumeration definition
****************************************************************************/

typedef enum eRequestResponse
{
    RequestDenied = 0,
    RequestFailed = RequestDenied,
    RequestAccepted,
    RequestProcessed = RequestAccepted,
    RequestProcessing,
}eRequestResponse_t;

/****************************************************************************
    Public structure definition
****************************************************************************/


/*******************************************************************************
* end of file
*******************************************************************************/

#endif
