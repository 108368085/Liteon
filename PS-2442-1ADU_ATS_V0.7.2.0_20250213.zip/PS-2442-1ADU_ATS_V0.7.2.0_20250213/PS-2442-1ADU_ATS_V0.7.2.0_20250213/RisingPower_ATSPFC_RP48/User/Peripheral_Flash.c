/** @file       Peripheral_Flash.c
 *  @brief      Configure and control Flash module
 *  @author     Adonis Wang
 *  @version    1.0
 *  @date       
 */
 
#include "F28x_Project.h"
#include "Peripheral.h"
#include "Peripheral_Flash.h"
#include <string.h>
#include "F021_F28004x_C28x.h"


/****************************************************************************
    Private parameter definition
****************************************************************************/
#define FLASH_SECTOR_NUM                32

// Sector length in number of 32bits
#define FlashSize_8KSector_u32length   	((u32_t)0x0800)	//SIZE: 4KWx16
#define FlashSize_16KSector_u32length   ((u32_t)0x1000)	//SIZE: 8KWx16
#define FlashSize_64KSector_u32length   ((u32_t)0x4000)	//SIZE: 32KWx16

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/
typedef struct sFlashSectorMap
{
    u32_t u32StartAddress;
    u32_t u32EndAddress;
    u32_t u32Size;              ///< length of region in 32-bit words to blank check
}sFlashSectorMap_t;

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 168
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(PeriFlash_Erase, ".TI.ramfunc");
#pragma CODE_SECTION(PeriFlash_Program, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declaration
****************************************************************************/


const sFlashSectorMap_t psFlashSectorMap[FLASH_SECTOR_NUM] =
{
    {FlashAddr_B0_S0_start,		FlashAddr_B0_S0_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S1_start,		FlashAddr_B0_S1_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S2_start,		FlashAddr_B0_S2_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S3_start,		FlashAddr_B0_S3_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S4_start,		FlashAddr_B0_S4_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S5_start,		FlashAddr_B0_S5_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S6_start,		FlashAddr_B0_S6_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S7_start,		FlashAddr_B0_S7_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S8_start,		FlashAddr_B0_S8_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S9_start,		FlashAddr_B0_S9_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S10_start,	FlashAddr_B0_S10_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S11_start,	FlashAddr_B0_S11_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S12_start,	FlashAddr_B0_S12_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S13_start,	FlashAddr_B0_S13_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S14_start,	FlashAddr_B0_S14_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B0_S15_start,	FlashAddr_B0_S15_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S0_start,		FlashAddr_B1_S0_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S1_start,		FlashAddr_B1_S1_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S2_start,		FlashAddr_B1_S2_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S3_start,		FlashAddr_B1_S3_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S4_start,		FlashAddr_B1_S4_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S5_start,		FlashAddr_B1_S5_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S6_start,		FlashAddr_B1_S6_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S7_start,		FlashAddr_B1_S7_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S8_start,		FlashAddr_B1_S8_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S9_start,		FlashAddr_B1_S9_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S10_start,	FlashAddr_B1_S10_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S11_start,	FlashAddr_B1_S11_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S12_start,	FlashAddr_B1_S12_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S13_start,	FlashAddr_B1_S13_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S14_start,	FlashAddr_B1_S14_End,	FlashSize_8KSector_u32length},
    {FlashAddr_B1_S15_start,	FlashAddr_B1_S15_End,	FlashSize_8KSector_u32length},
};


#pragma DATA_SECTION(pu16TemplateBuffer,"BufferDataSection");
u16_t pu16TemplateBuffer[8];

/**
 *  @brief  Initial Flash driver
 *  @retval FALSE: Initial operation failed
 *  @retval TRUE: Initial operation success
 */
u16_t PeriFlash_Initialize(void)
{
    Fapi_StatusType sReturnCheck;
    volatile Fapi_FlashStatusType sFlashStatus;
    /* 
     * This function is required to initialize the Flash API based on system
     * frequency before any other Flash API operation can be performed
     */
    EALLOW;
    sReturnCheck = Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 100);
    EDIS;
    
    if (sReturnCheck != Fapi_Status_Success)
    {
        return FALSE;
    }
     
    /*
     * Fapi_SetActiveFlashBack function sets the Flash bank adn FMC for further
     * Flash operations to be performed on the bank
     */
     
    EALLOW;
    sReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);
    EDIS;
    
    if (sReturnCheck != Fapi_Status_Success)
    {
        return FALSE;
    }
    
    return TRUE;
}


/**
 *  @brief  Erase Flash
 *  @param  u16EraseSector: Whose sectors need to erase
 *  @retval FALSE: Erase operation failed
 *  @retval TRUE: Erase operation success
 */
u16_t PeriFlash_Erase(u32_t u32SectorMask)
{

    Fapi_StatusType sReturnCheck;
    volatile Fapi_FlashStatusType sFlashStatus;
    Fapi_FlashStatusWordType sFlashStatusWord;
	u16_t i;
	u32_t SECTOR = 1;

	StopCpuTimer1();
	
    EALLOW;
    for (i=0; i<FLASH_SECTOR_NUM; i++)
    {
        if (u32SectorMask & (SECTOR << i))
        {

            // Issue an erase command to the Flash State Machine along with a user-provided sector address
            sReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector, (u32_t*)psFlashSectorMap[i].u32StartAddress);
            
            // Wait until the erase operation is over
            while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady);
            
            if (sReturnCheck != Fapi_Status_Success)
            {
                break;
            }
            

            //Read FMSTAT register contents to know the status of FSM
            //after erase command to see if there are any erase opreation related errors
            sFlashStatus = Fapi_getFsmStatus();
            if (sFlashStatus != 0)
            {
                break;
            }
            
            // Verify target sector is erased. The erase step itself does a verify as it goes.
            // This verify is a second verification that can be done.
            sReturnCheck = Fapi_doBlankCheck((u32_t*)psFlashSectorMap[i].u32StartAddress, psFlashSectorMap[i].u32Size, &sFlashStatusWord);
            if (sReturnCheck != Fapi_Status_Success)
            {
                break;
            }
            
        }
    }
    EDIS;

	StartCpuTimer1();
	
    if (i == FLASH_SECTOR_NUM)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }

}

/**
 *  @brief  Program Flash
 *  @note   The program address of flash "MUST" be erased before program
 *  @param  u32FlashAddress: Address of flash which is attempted to write
 *  @param  pu16ProgramData: Pointer to data buffer which is attempted to write to Flash
 *  @param  u32ProgramLength: How many words are attempted to write
 *  @retval FALSE
 *  @retval TRUE
 */
u16_t PeriFlash_Program(u32_t u32FlashAddress, u16_t* pu16ProgramData, u32_t u32ProgramLength)
{

    u16_t i;
    Fapi_StatusType sReturnCheck;
    volatile Fapi_FlashStatusType sFlashStatus;
    Fapi_FlashStatusWordType sFlashStatusWord;
    u32_t u32ProcessedWords = 0;

    EALLOW;
    
    for (i=0; i<u32ProgramLength; i+=8)
    {
        memset(pu16TemplateBuffer, 0xFFFF, sizeof(pu16TemplateBuffer));

        if ((u32ProgramLength - u32ProcessedWords) >= 8)
        {
            memcpy(pu16TemplateBuffer, (pu16ProgramData + i), 8);
        }
        else
        {
            memcpy(pu16TemplateBuffer, (pu16ProgramData + i), (u32ProgramLength - u32ProcessedWords));
        }


        /*
         *  Issue program command to write Flash 8 words each time
         *  Data not supplied is treated as all 0xFFFF.
         */
        sReturnCheck = Fapi_issueProgrammingCommand((u32_t*)(u32FlashAddress+i), (uint16*)pu16TemplateBuffer, 8, 0, 0, Fapi_AutoEccGeneration);
        
        // Wait until the Flash program operation is over
        while (Fapi_checkFsmForReady() == Fapi_Status_FsmBusy);
		
        if (sReturnCheck != Fapi_Status_Success)
        {
            break;
        }
        
        /*
         * Read FMSTAT register contents to know the status of FSM after
         * program command for debug
         */
        sFlashStatus = Fapi_getFsmStatus();
        
        if (sFlashStatus != 0)
        {
            break;
        }
        
        /*
         * Verify the values programmed. The Program step itself goes a verify as it goes.
         * This verify is a second verification that can be done.
         */
        sReturnCheck = Fapi_doVerify((u32_t*)(u32FlashAddress+i), 4, (u32_t*)pu16TemplateBuffer, &sFlashStatusWord);
    
        if (sReturnCheck != Fapi_Status_Success)
        {
            break;
        }

        u32ProcessedWords += 8;
    }
    EDIS;
    
    if (i<u32ProgramLength)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }

}
 
/**
 *  @brief  Read Flash
 *  @param  u32FlashAddress: Address of flash which is attempted to read
 *  @param  pu16ReadBuffer: Pointer to data buffer which is attempted to store
 *  @param  u32ReadLength: How many words are attempted to read
 *  @retval FALSE: Read operation failed
 *  @retval TRUE: Read operation success
 */
u16_t PeriFlash_Read(u32_t u32FlashAddress, u16_t* pu16ReadBuffer, u32_t u32ReadLength)
{
	u8_t i = 0;
	
	for (i=0; i<u32ReadLength; i++)
	{
		pu16ReadBuffer[i] = *((u16_t*)(u32FlashAddress + i));
	}

	return TRUE;
}

/**
 *  @brief  Verify Flash
 *  @param  u32FlashAddress: Address of flash which is attempted to verify
 *  @param  pu16VerifyData: Pointer to data buffer which is attempted to compare with data stored in Flash
 *  @param  u32VerifyLength: How many words are attempted to verify
 *  @retval FALSE: Verify operation failed or data mismatched
 *  @retval TRUE: Verify operation success
 */
u16_t PeriFlash_Verify(u32_t u32FlashAddress, u16_t* pu16VerifyData, u32_t u32VerifyLength)
{
    Fapi_StatusType sReturnCheck;
    Fapi_FlashStatusWordType sFlashStatusWord;
    
    EALLOW;
    sReturnCheck = Fapi_doVerify((u32_t*)u32FlashAddress, u32VerifyLength >> 1, (u32_t*)pu16VerifyData, &sFlashStatusWord);
    EDIS;
    
    if (sReturnCheck != Fapi_Status_Success)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}


/**
 *  @brief  Copy Flash
 *  @note   The destination address of flash "MUST" be erased before copy
 *  @param  u32DestinationAddress: Destination address
 *  @param  u32SourceAddress: Source address
 *  @param  u32CopyLength: How many words are attempted to copy
 *  @retval FALSE: Copy operation failed
 *  @retval TRUE: Copy operation success
 */
u16_t PeriFlash_Copy(u32_t u32DestinationAddress, u32_t u32SourceAddress, u32_t u32CopyLength)
{
    u16_t i;
    u32_t u32ProcessedLength = 0;
    u32_t u32CopyWords;
    u16_t pu16CopyBuffer[8];

    for (i=8; i<u32CopyLength; i+=8)
    {
        memset(pu16CopyBuffer, 0xFFFF, sizeof(pu16CopyBuffer));
        
        if ((u32CopyLength - u32ProcessedLength) >= 8)
        {
            u32CopyWords = 8;
        }
        else
        {
            u32CopyWords = (u32CopyLength - u32ProcessedLength);
        }


        if (PeriFlash_Read(u32SourceAddress + i, pu16CopyBuffer, u32CopyWords) == FALSE)
        {
            break;
        }
        
        if (PeriFlash_Program(u32DestinationAddress + i, pu16CopyBuffer, u32CopyWords) == FALSE)
        {
            break;
        }
    }
    
    if (i >= u32CopyLength)
    {
        u32CopyWords = 8;
        memset(pu16CopyBuffer, 0xFFFF, sizeof(pu16CopyBuffer));
        PeriFlash_Read(u32SourceAddress, pu16CopyBuffer, u32CopyWords);

		if (PeriFlash_Program(u32DestinationAddress, pu16CopyBuffer, u32CopyWords) == FALSE)
        {
            return FALSE;
        }
        else
        {
            return TRUE;
        }
    }
    else
    {
        return FALSE;
    }
}
