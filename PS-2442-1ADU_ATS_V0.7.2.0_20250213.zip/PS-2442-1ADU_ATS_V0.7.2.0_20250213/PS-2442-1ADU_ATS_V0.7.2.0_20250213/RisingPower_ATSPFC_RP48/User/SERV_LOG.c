/****************************************************************************
 *	File	SERV_LOG.c
 * 	Brief	Record/Report PSU all of log
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/12/25 - 1st Release
 ****************************************************************************/

#include <string.h>
#include <math.h>
#include "SERV_LOG.h"
#include "E2P_Data.h"
#include "E2P_BlackBox.h"
#include "E2P_Waveform.h"
#include "CONFIG_RisingPower.h"
#include "Monitor_AC.h"
#include "Monitor_DC.h"
#include "Monitor_TP.h"
#include "Handler_PFC.h"
#include "Peripheral.h"
#include "CANBus_Data.h"
#include "CANBus_Server.h"
#include "FLASH_IAP.h"




/****************************************************************************
    Private parameter definition
****************************************************************************/

// For Black box trigger event
#define INPUT_QUALITY_RECORDER_TRIGGER		0xBB
#define OUTPUT_QUALITY_RECORDER_TRIGGER     0x0E
#define STATUS_PFC_RECORDER_TRIGGER     	0x07
#define TEMPERATURE_RECORDER_TRIGGER        0xDD
#define STATUS_OTHER_RECORDER_TRIGGER       0x1F
#define STATUS_TRANSFER_RECORDER_TRIGGER    0x3FFF


/* Power Average fileter */
// Power_Filter_A + Power_Filter_B = 1
// 0.86s Integral time
#define Power_Filter_A						(f32_t)0.05
#define Power_Filter_B						(f32_t)0.95

#define Power_Derating_Filter_A				(f32_t)0.001
#define Power_Derating_Filter_B				(f32_t)0.999

// Composite fault count
#define ATS_Composite_Fault_CNT             120   	//120s, unit is 1s
#define PFC_Composite_Fault_CNT             30   	//30s, unit is 1s

// ATS Transfer count
#define ATS_Transfer_Waring_CNT				16800
#define ATS_Transfer_Fault_CNT				21000

// AC Power Cycle count
#define Default_powercycledelayCNT     		100 	//1s, unit is 10ms


#define Default_REQ_BBU_COUNT				0x05
#define Default_HEARTBEAT_TIMEOUT			0x05	//5s, unit is 1s

#define Default_CML_Recovery_TIME			10		//10s, unit is 1s

#define Default_FAULT_COUNT_LIMIT			3
#define Default_FAULT_DELAY					10		//10s, unit is 1s




/****************************************************************************
	Private macro definition
****************************************************************************/

#define FAULTINJECT_ACK			0x00
#define FAULTINJECT_NACK		0x01

#define Bits_00					0x01 
#define Bits_01					0x02 
#define Bits_02					0x04 
#define Bits_03					0x08 

#define Bits_04					0x10 
#define Bits_05					0x20 
#define Bits_06					0x40 
#define Bits_07					0x80 

#define Bits_08					0x0100 
#define Bits_09					0x0200 
#define Bits_10					0x0400 
#define Bits_11					0x0800

#define Bits_12					0x1000 
#define Bits_13					0x2000
#define Bits_14					0x4000
#define Bits_15					0x8000

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 1885->1164
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Log_Status_Transfer, ".TI.ramfunc");
#pragma CODE_SECTION(Log_Status_CML, ".TI.ramfunc");
#pragma CODE_SECTION(Log_Input_Power_Cal, ".TI.ramfunc");
#pragma CODE_SECTION(Log_Input_Meter, ".TI.ramfunc");
//#pragma CODE_SECTION(Log_Update_ATSwitchCNT, ".TI.ramfunc");
//#pragma CODE_SECTION(Log_Clear_Fault, ".TI.ramfunc");
//#pragma CODE_SECTION(Log_1hr_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(Log_1s_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(Log_10ms_Periodically_Process, ".TI.ramfunc");
#pragma CODE_SECTION(Log_1ms_Periodically_Process, ".TI.ramfunc");
#pragma CODE_SECTION(Log_10k_Instant_Process, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/

sLog_t tsLog;


/***************************************************************************
*   brief  Check BBU Status Word
*   note   1ms
****************************************************************************/
static inline void Log_BBU_Status_Word(void)
{
	u16_t i;
	u16_t u16Valid50CNT = 0;
	u16_t u16Valid20CNT = 0;
	u16_t u16Shelf_BBU_CNT = 0;  //  Maximum:6 , if any "BBU's SOC > 1%" then plus one
	
    for (i=0; i<SHELF_DEVICE_NUMBER; i++)
    {
    	if ((tsLog.nBBU_Status_Word[i].u16Bits.u1NOT_READY_TO_DISCHARGE == 0) &&
//			(tsLog.u32BBU_RSOC[i] >= 50) &&
			(tsLog.nBBU_Status_Word[i].u16Bits.u1SWITCH_SOC == 0) &&
			(tsLog.u8BBU_TIMEOUT[i] > 0))
    	{
    		u16Valid50CNT += 1;
			u16Valid20CNT += 1;
			u16Shelf_BBU_CNT += 1;
    	}
		else if ((tsLog.nBBU_Status_Word[i].u16Bits.u1NOT_READY_TO_DISCHARGE == 0) &&
//				 (tsLog.u32BBU_RSOC[i] >= 20) &&
		         (tsLog.nBBU_Status_Word[i].u16Bits.u1LOW_SOC == 0) &&
				 (tsLog.u8BBU_TIMEOUT[i] > 0))
		{
			u16Valid20CNT += 1;
			u16Shelf_BBU_CNT += 1;
		}
		else if ((tsLog.nBBU_Status_Word[i].u16Bits.u1NOT_READY_TO_DISCHARGE == 0) &&
                 (tsLog.u8BBU_TIMEOUT[i] > 0))
		{
		    u16Shelf_BBU_CNT += 1;
		}
    }

	tsLog.u8BBU_Valid_50_NUM = (u8_t)u16Valid50CNT;
	tsLog.u8BBU_Valid_20_NUM = (u8_t)u16Valid20CNT;
	tsLog.u8Shelf_BBU_NUM    = (u8_t)u16Shelf_BBU_CNT;
	
	if (tsLog.u8BBU_Valid_50_NUM >= tsLog.u8REQ_BBU_NUMBER)
	{
		tsLog.u16BBU_Valid = 2;	//BBU Valid
	}
	else if (tsLog.u8BBU_Valid_20_NUM >= tsLog.u8REQ_BBU_NUMBER)
	{
		tsLog.u16BBU_Valid = 1;	// SWITCH_THRESHOLD
	}
	else
	{
		tsLog.u16BBU_Valid = 0;	// EMERGENCY_THRESHOLD (SOC less than 20%)
	}

	// For BBU mode used
    if (tsLog.u8BBU_Valid_50_NUM >= SHELF_DEVICE_NUMBER)
    {
        tsLog.u16BBUMode_Valid = 2; //BBU Valid
    }
    else if (tsLog.u8BBU_Valid_20_NUM >= SHELF_DEVICE_NUMBER)
    {
        tsLog.u16BBUMode_Valid = 1; // SWITCH_THRESHOLD
    }
    else
    {
        tsLog.u16BBUMode_Valid = 0; // EMERGENCY_THRESHOLD (SOC less than 20%)
    }
}



/***************************************************************************
*   brief  Update Status Word
*   note   1ms
****************************************************************************/
static inline void Log_Status_Word(void)
{
    /* Bit 3 - CML */
	if (tsLog.nStatusCML.u8All)
	{
		tsLog.nStatusWord.u16Bits.u1CML = 1;
	}
	else
	{
		tsLog.nStatusWord.u16Bits.u1CML = 0;
	}

    /* Bit 4 - PERMANENT_FAILURE */
	if (tsLog.nComposite_failure.u8All ||
        tsLog.nStatusOther.u8Bits.u1RELAY_A_HW_FAIL ||
        tsLog.nStatusOther.u8Bits.u1RELAY_B_HW_FAIL ||
        tsLog.nStatusOther.u8Bits.u1RELAY_C_HW_FAIL)
	{
		tsLog.nStatusWord.u16Bits.u1ATS_PERMANENT_FAILURE = 1;
	}
	else
	{
		tsLog.nStatusWord.u16Bits.u1ATS_PERMANENT_FAILURE = 0;
	}

    /* Bit 5 - ATS_TEMPERATURE */
    if (tsLog.nStatusTEMP.u8All)
    {
        tsLog.nStatusWord.u16Bits.u1ATS_TEMPERATURE = 1;
    }
    else
    {
        tsLog.nStatusWord.u16Bits.u1ATS_TEMPERATURE = 0;
    }
    
    /* Bit 6 - ATS_PRI_SRC_Fail */
    if (GET_ATS_PRI_SRC_FLAG)
    {
    	tsLog.nStatusWord.u16Bits.u1ATS_PRI_SRC_Fail = 0; // Primary source is valid
    }
    else
    {
    	tsLog.nStatusWord.u16Bits.u1ATS_PRI_SRC_Fail = 1; // Primary source is invalid
    }

    /* Bit 7 - ATS_AUX_FAIL */
    if ((tsLog.nStatusOther.u8Bits.u1AUX_S1_FAIL == 1) ||
		(tsLog.nStatusOther.u8Bits.u1AUX_S2_FAIL == 1))
    {
        tsLog.nStatusWord.u16Bits.u1ATS_AUX_FAIL = 1;
    }
    else
    {
        tsLog.nStatusWord.u16Bits.u1ATS_AUX_FAIL = 0;
    }

    /* Bit 8 - Boot */
    tsLog.nStatusWord.u16Bits.u1BOOT = tsLog.nStatus_PFC2D2D.u16Bits.u1ATSInBootloader;

	/* Bit 9 - ATS_RELAY_C_FAIL */
	tsLog.nStatusWord.u16Bits.u1ATS_RELAY_C_FAIL = tsLog.nStatusOther.u8Bits.u1RELAY_C_HW_FAIL;

	
    /* Bit 10 - ATS_RELAY_B_FAIL */
	tsLog.nStatusWord.u16Bits.u1ATS_RELAY_B_FAIL = tsLog.nStatusOther.u8Bits.u1RELAY_B_HW_FAIL;

    
    /* Bit 11 - ATS_RELAY_A_FAIL */
	tsLog.nStatusWord.u16Bits.u1ATS_RELAY_A_FAIL = tsLog.nStatusOther.u8Bits.u1RELAY_A_HW_FAIL;

    
    /* Bit 12 - ATS_S2_INPUT */
    if (tsLog.nInputQuality[ATS_InputTag_Input2].u8All)
    {
        tsLog.nStatusWord.u16Bits.u1ATS_S2_INPUT = 1;
    }
    else
    {
        tsLog.nStatusWord.u16Bits.u1ATS_S2_INPUT = 0;
    }
    
    /* Bit 13 - ATS_S1_INPUT */
    if (tsLog.nInputQuality[ATS_InputTag_Input1].u8All)
    {
        tsLog.nStatusWord.u16Bits.u1ATS_S1_INPUT = 1;
    }
    else
    {
        tsLog.nStatusWord.u16Bits.u1ATS_S1_INPUT = 0;
    }
    
    /* Bit 14 - ATS_IOUT */	
    tsLog.nStatusWord.u16Bits.u1ATS_IOUT = tsLog.nOutputQuality.u8Bits.u1IIN_OCP;

    /* Bit 15 - ATS_VOUT */
    
}

/***************************************************************************
*   brief  Update Status input for D2D (Remove at next stage)
*   note   1ms
****************************************************************************/
static inline void Log_Status_Input(void)
{
	sMoniAC_t* ptMoni_AC = NULL;

	if (tsATS.ptApply != NULL)
	{
		ptMoni_AC = tsATS.ptApply->ptMoniAC;
	}
	
	if (ptMoni_AC != NULL)
	{
		/* Bit 0 - OPW */
		tsLog.nStatusInput.u16Bits.u1PIN_OPW = GET_MOMIAC_IPFC_OPW;

		/* Bit 1 - OPF */
		tsLog.nStatusInput.u16Bits.u1PIN_OPP = GET_MOMIAC_IPFC_OPP;

		/* Bit 2 - OCW */
		tsLog.nStatusInput.u16Bits.u1IIN_OCW = GET_MOMIAC_IPFC_OCW;

		/* Bit 3 - OCP */
		tsLog.nStatusInput.u16Bits.u1IIN_OCP = GET_MOMIAC_IPFC_OCP;

		/* Bit 4 - UVW */
		tsLog.nStatusInput.u16Bits.u1VIN_UVW = ptMoni_AC->nFlag.u16Bits.u1BrownoutWarning;

		/* Bit 5 - UVF */
		tsLog.nStatusInput.u16Bits.u1VIN_UVP = ptMoni_AC->nFlag.u16Bits.u1BrownoutProtect;
		
		/* Bit 6 - OVW */
		tsLog.nStatusInput.u16Bits.u1VIN_OVW = ptMoni_AC->nFlag.u16Bits.u1OverVoltageWarning;

		/* Bit 7 - OVP */
		tsLog.nStatusInput.u16Bits.u1VIN_OVP = ptMoni_AC->nFlag.u16Bits.u1OverVoltageProtect;	
	}
}

/***************************************************************************
*   brief  update Update transfer status when apply source change
*   note   
****************************************************************************/
void Log_Status_Transfer(eATSTransfer_State_t eNewState)
{
    tsLog.nStatusTransfer.u16All = 0;   //Reset

	if (eNewState == eATSTransfer_State_Off)
	{
		tsLog.u8NewBlackboxTrigger = 1;
	}
		
	if (tsATS.sContr.u8PreferSource == ATS_ApplySourceis1)
	{
		switch (eNewState)
    	{
        	case eATSTransfer_State_SPS:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S12 = 1;
            break;

        	case eATSTransfer_State_SSP:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S21 = 1;
            break;

			case eATSTransfer_State_SPB:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S1B = 1;
            break;

			case eATSTransfer_State_SSB:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S2B = 1;
            break;

			case eATSTransfer_State_SBP:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_BS1 = 1;
            break;

			case eATSTransfer_State_SBS:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_BS2 = 1;
            break;

        	default:
            break;
    	}
	}
	else
	{
		switch (eNewState)
    	{
        	case eATSTransfer_State_SPS:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S21 = 1;
            break;

        	case eATSTransfer_State_SSP:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S12 = 1;
            break;

			case eATSTransfer_State_SPB:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S2B = 1;
            break;

			case eATSTransfer_State_SSB:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_S1B = 1;
            break;

			case eATSTransfer_State_SBP:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_BS2 = 1;
            break;

			case eATSTransfer_State_SBS:
            	tsLog.nStatusTransfer.u16Bits.u1Transfer_BS1 = 1;
            break;

        	default:
            break;
    	}
	}
	
    if (eNewState >= eATSTransfer_State_MS1)
    {
    	tsLog.nStatusTransfer.u16Bits.u1TransferByManual = 1;
    }
        
    if (tsATS.ptApply != NULL)
    {
        if (tsATS.ptApply->ptMoniAC->nFlag.u16Bits.u1BrownoutProtect)
        {
            tsLog.nStatusTransfer.u16Bits.u1TransferByUnderVoltage = 1;
        }

        if (tsATS.ptApply->ptMoniAC->nFlag.u16Bits.u1OverVoltageProtect)
        {
            tsLog.nStatusTransfer.u16Bits.u1TransferByOverVoltage = 1;
        }

        if (tsATS.ptApply->ptMoniAC->nFlag.u16Bits.u1FreqError)
        {
            tsLog.nStatusTransfer.u16Bits.u1TransferByFreqError = 1;
        }

//		if (tsATS.ptApply->ptMoniAC->nFlag.u16Bits.u1HarmonicProtect)
//        {
//            tsLog.nStatusTransfer.u16Bits.u1TransferByHarmonics = 1;
//        }

        if ((tsATS.ptApply->nFault.u16All) ||
			(tsLog.nStatusTransfer.u16Bits.u1TransferByUnderVoltage) ||
			(tsLog.nStatusTransfer.u16Bits.u1TransferByOverVoltage) ||
			(tsLog.nStatusTransfer.u16Bits.u1TransferByFreqError) ||
			(tsLog.nStatusTransfer.u16Bits.u1TransferByHarmonics))
        {
            tsLog.nStatusTransfer.u16Bits.u1TransferByProtection = 1;
        }
    }

	/* Check new event triggered or not, XOR/AND */
	if (tsLog.nStatusTransfer.u16All & STATUS_TRANSFER_RECORDER_TRIGGER)
	{
		tsLog.u8NewBlackboxTrigger = 1;
	}
}

/***************************************************************************
*   brief  Update status ATS source
*   note   1ms
****************************************************************************/
static inline void Log_Status_ATS_Source(void)
{
    /* Bit 1 - S2 Available */
    if (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Valid)
    {
        tsLog.nStatusATSource.u8Bits.u1Available_S2 = 1;
    }
    else
    {
        tsLog.nStatusATSource.u8Bits.u1Available_S2 = 0;
    }

    /* Bit 2 - S1 Available */
    if (tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Valid)
    {
        tsLog.nStatusATSource.u8Bits.u1Available_S1 = 1;
    }
    else
    {
        tsLog.nStatusATSource.u8Bits.u1Available_S1 = 0;
    }

	/* Bit 6 - Current Source S2 */
	/* Bit 7 - Current Source S1 */
    // When AC loss , update "u1CurrentSource" immediately
    if (tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Apply && GET_MOMIAC_VAC1_INPUTSTATUS != MoniAC_InputStatus_Loss)
    {
        tsLog.nStatusATSource.u8Bits.u1CurrentSource_S1 = 1;
        tsLog.nStatusATSource.u8Bits.u1CurrentSource_S2 = 0;
    }
    else if (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Apply && GET_MOMIAC_VAC2_INPUTSTATUS != MoniAC_InputStatus_Loss)
    {
        tsLog.nStatusATSource.u8Bits.u1CurrentSource_S1 = 0;
        tsLog.nStatusATSource.u8Bits.u1CurrentSource_S2 = 1;
    }
    else
    {
        tsLog.nStatusATSource.u8Bits.u1CurrentSource_S1 = 0;
        tsLog.nStatusATSource.u8Bits.u1CurrentSource_S2 = 0;
    }
}

/***************************************************************************
*  @brief  Update Input Qualities
*  @retval FALSE: There are no new event asserted
*  @retval TRUE: There are new event asserted
****************************************************************************/
static inline u16_t Log_Status_InputQualities(void)
{
    u16_t i;
    u8_t pu8PreviousValue[ATS_InputTag_Num];
    u16_t u16NewEventTrigger = FALSE;

    for (i=0; i<ATS_InputTag_Num; i++)
    {
        pu8PreviousValue[i] =  tsLog.nInputQuality[i].u8All;

        /* Bit 0 - RELAY_#_HARMONIC_FAULT */
        tsLog.nInputQuality[i].u8Bits.u1VIN_OHP = tsMoniAC[i].nFlag.u16Bits.u1HarmonicProtect;

		/* Bit 1 - RELAY_#_HARMONIC_WARNING */
		tsLog.nInputQuality[i].u8Bits.u1VIN_OHW = tsMoniAC[i].nFlag.u16Bits.u1HarmonicWarning;
		      
        /* Bit 2 - RELAY_#_FREQ_WARNING */
        tsLog.nInputQuality[i].u8Bits.u1VIN_OFW = tsMoniAC[i].nFlag.u16Bits.u1FreqWarning;

        /* Bit 3 - RELAY_#_FREQ_FAULT */
        tsLog.nInputQuality[i].u8Bits.u1VIN_OFP = tsMoniAC[i].nFlag.u16Bits.u1FreqError;

        /* Bit 4 - RELAY_#_UV_FAULT */
        tsLog.nInputQuality[i].u8Bits.u1VIN_UVP = tsMoniAC[i].nFlag.u16Bits.u1BrownoutProtect;

        /* Bit 5 - RELAY_#_UV_WARNING */
        tsLog.nInputQuality[i].u8Bits.u1VIN_UVW = tsMoniAC[i].nFlag.u16Bits.u1BrownoutWarning;

        /* Bit 6 - RELAY_#_OV_WARNING */
        tsLog.nInputQuality[i].u8Bits.u1VIN_OVW = tsMoniAC[i].nFlag.u16Bits.u1OverVoltageWarning;

        /* Bit 7 - REALY_#_OV_FAULT */
        tsLog.nInputQuality[i].u8Bits.u1VIN_OVP = tsMoniAC[i].nFlag.u16Bits.u1OverVoltageProtect;

        /* Check new event triggered or not, XOR/AND */
        if ((pu8PreviousValue[i] ^ tsLog.nInputQuality[i].u8All) & 
            tsLog.nInputQuality[i].u8All & INPUT_QUALITY_RECORDER_TRIGGER)
        {
            u16NewEventTrigger |= TRUE;
        }
    }

    return u16NewEventTrigger;
}

/***************************************************************************
*  @brief  Update Output Quality
*  @retval FALSE: There are no new event asserted
*  @retval TRUE: There are new event asserted
****************************************************************************/
static inline u16_t Log_Status_OutputQuality(void)
{
    u8_t u8PreviousValue;
    u16_t u16NewEventTrigger = FALSE;

	u8PreviousValue = tsLog.nOutputQuality.u8All;

	/* Bit 0 - PFC OPW */
	tsLog.nOutputQuality.u8Bits.u1PIN_OPW = GET_MOMIAC_IPFC_OPW;
	
	/* Bit 1 - PFC OPP */
	tsLog.nOutputQuality.u8Bits.u1PIN_OPP = GET_MOMIAC_IPFC_OPP;

	/* Bit 2 - PFC OCW */
	tsLog.nOutputQuality.u8Bits.u1IIN_OCW = GET_MOMIAC_IPFC_OCW;

	/* Bit 3 - PFC OCP */
	tsLog.nOutputQuality.u8Bits.u1IIN_OCP = GET_MOMIAC_IPFC_OCP;
	
	
	/* Check new event triggered or not, XOR/AND */
	if ((u8PreviousValue ^ tsLog.nOutputQuality.u8All) & 
		tsLog.nOutputQuality.u8All & OUTPUT_QUALITY_RECORDER_TRIGGER)
	{
		u16NewEventTrigger = TRUE;
	}

    return u16NewEventTrigger;
}

/***************************************************************************
*  @brief  Update Temperature Status
*  @retval FALSE: There are no new event asserted
*  @retval TRUE: There are new event asserted
****************************************************************************/
static inline u16_t Log_Status_Temperature(void)
{
    u8_t u8PreviousValue;
    u16_t u16NewEventTrigger = FALSE;

    u8PreviousValue = tsLog.nStatusTEMP.u8All;

	/* Bit 1 - ATS UTP */
    tsLog.nStatusTEMP.u8Bits.u1ATS_UTP = GET_MOMITP_ATS_UTP;

	/* Bit 9 - ATS UTW */
    tsLog.nStatusTEMP.u8Bits.u1ATS_UTW = GET_MOMITP_ATS_UTW;	

	/* Bit 25 - ATS OTW */
	tsLog.nStatusTEMP.u8Bits.u1ATS_OTW = GET_MOMITP_ATS_OTW;

	/* Bit 17 - ATS OTP */
    tsLog.nStatusTEMP.u8Bits.u1ATS_OTP = GET_MOMITP_ATS_OTP;

    /* Bit 0 - Inlet UTP */
    tsLog.nStatusTEMP.u8Bits.u1Inlet_UTP = GET_MOMITP_INLET_UTP;

    /* Bit 8 - Inlet UTW */
    tsLog.nStatusTEMP.u8Bits.u1Inlet_UTW = GET_MOMITP_INLET_UTW;

    /* Bit 24 - Inlet OTW */
    tsLog.nStatusTEMP.u8Bits.u1Inlet_OTW = GET_MOMITP_INLET_OTW;

    /* Bit 16 - Inlet OTP */
    tsLog.nStatusTEMP.u8Bits.u1Inlet_OTP = GET_MOMITP_INLET_OTP;

    /* Check new event triggered or not, XOR/AND */
    if ((u8PreviousValue ^ tsLog.nStatusTEMP.u8All) & 
        tsLog.nStatusTEMP.u8All & TEMPERATURE_RECORDER_TRIGGER)
    {
        u16NewEventTrigger = TRUE;
    }

    return u16NewEventTrigger;
}

/***************************************************************************
*   brief  Update Status Other, aux power fault
*   note   1ms
****************************************************************************/
static inline u16_t Log_Status_Other(void)
{
	u8_t u8PreviousValue;
    u16_t u16NewEventTrigger = FALSE;

	u8PreviousValue = tsLog.nStatusOther.u8All;
	
    /* Bit 0 - Auxiliary power supply S1 failed */
    if (GET_MOMIDC_VAUX1_OVP || GET_MOMIDC_VAUX1_UVP)
    {
        tsLog.nStatusOther.u8Bits.u1AUX_S1_FAIL = 1;
    }
    else
    {
        tsLog.nStatusOther.u8Bits.u1AUX_S1_FAIL = 0;
    }

    /* Bit 1 - Auxiliary power supply S2 failed */
    if (GET_MOMIDC_VAUX2_OVP || GET_MOMIDC_VAUX2_UVP)
    {
        tsLog.nStatusOther.u8Bits.u1AUX_S2_FAIL = 1;
    }
    else
    {
        tsLog.nStatusOther.u8Bits.u1AUX_S2_FAIL = 0;
    }

	/* Bit 2 - ATS S1 RELAY HW FAIL */
	if ((tsATS.tsInput[ATS_InputTag_Input1].nFault.u16Bits.u1RealyOpen) ||
		(tsATS.tsInput[ATS_InputTag_Input1].nFault.u16Bits.u1RealyShort))
	{
		tsLog.nStatusOther.u8Bits.u1RELAY_A_HW_FAIL = 1;
	}
	else
	{
		tsLog.nStatusOther.u8Bits.u1RELAY_A_HW_FAIL = 0;
	}

	/* Bit 3 - ATS S2 RELAY HW FAIL */
	if ((tsATS.tsInput[ATS_InputTag_Input2].nFault.u16Bits.u1RealyOpen) ||
		(tsATS.tsInput[ATS_InputTag_Input2].nFault.u16Bits.u1RealyShort))
	{
		tsLog.nStatusOther.u8Bits.u1RELAY_B_HW_FAIL = 1;
	}
	else
	{
		tsLog.nStatusOther.u8Bits.u1RELAY_B_HW_FAIL = 0;
	}

	/* Bit 4 - PFC Inrush RELAY HW FAIL */
	tsLog.nStatusOther.u8Bits.u1RELAY_C_HW_FAIL = GET_PFC_RELAY_FAULT;

	/* Bit 5 - ATS TRANSFER COUNT FAULT */
	/* Bit 6 - ATS TRANSFER COUNT WARNING */
	if (tsLog.u8ATSwitchCNT_Latch == 0)
	{
		if (tsLog.u32TotATSwitchCNT > ATS_Transfer_Fault_CNT)
		{
			tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_FAIL = 1;
			tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_WARNING = 1;
		}
		else if (tsLog.u32TotATSwitchCNT > ATS_Transfer_Waring_CNT)
		{
			tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_FAIL = 0;
			tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_WARNING = 1;
		}
		else
		{
			tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_FAIL = 0;
			tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_WARNING = 0;
		}
	}

	/* Check new event triggered or not, XOR/AND */
    if ((u8PreviousValue ^ tsLog.nStatusOther.u8All) & 
        tsLog.nStatusOther.u8All & STATUS_OTHER_RECORDER_TRIGGER)
    {
        u16NewEventTrigger = TRUE;
    }

    return u16NewEventTrigger;
}

/***************************************************************************
*   brief  Update PFC Status (Liteon MFR)
*   note   1ms
****************************************************************************/
static inline u16_t Log_Status_PFC(void)
{
	u16_t u16PreviousValue;
    u16_t u16NewEventTrigger = FALSE;

	u16PreviousValue = tsLog.nStatusPFC.u16All;
	
    /* Bit 0 - PFC PTC FAULT */
	tsLog.nStatusPFC.u16Bits.u1PTCFault = GET_PFC_PTC_FAULT;
    
    /* Bit 1 - PFC Softstart FAULT */
    tsLog.nStatusPFC.u16Bits.u1SoftStartFault = GET_PFC_SS_FAULT;

    /* Bit 2 - PFC OV Protect */
	tsLog.nStatusPFC.u16Bits.u1Vbulk_OV = GET_MOMIDC_VBULK_OVP;
	
    /* Bit 3 - PFC UV Protect */
    tsLog.nStatusPFC.u16Bits.u1Vbulk_UV = GET_MOMIDC_VBULK_UVP;

	/* Bit 4 - ATS Valid */
	if (tsLog.nStatusATSource.u8Bits.u1Available_S1 || 
		tsLog.nStatusATSource.u8Bits.u1Available_S2)
	{
		tsLog.nStatusPFC.u16Bits.u1ATS_Valid = 1;
	}
	else
	{
		tsLog.nStatusPFC.u16Bits.u1ATS_Valid = 0;
	}
	
	/* Bit 5 - ATS Enable */
	if (tsATS.ptApply != NULL)
	{
		tsLog.nStatusPFC.u16Bits.u1ATS_Enable = 1;
	}
	else
	{
		tsLog.nStatusPFC.u16Bits.u1ATS_Enable = 0;
	}
    
	/* Bit 6 - PFC Enable */
    tsLog.nStatusPFC.u16Bits.u1PFC_Enable = GET_PFC_ENABLE;
		
    /* Bit 7 - D2D Enable */
    tsLog.nStatusPFC.u16Bits.u1D2D_Enable = GET_GPIO_D2D_EN;


	/* Bit 8 - BBU Valid */
	tsLog.nStatusPFC.u16Bits.u2BBU_Valid = tsLog.u16BBU_Valid;

	/* Bit 10 - BBU Enable */
	if (GET_ATS_State == ATSStatus_BBU)
	{
		tsLog.nStatusPFC.u16Bits.u1BBU_Enable = 1;
	}
	else
	{
		tsLog.nStatusPFC.u16Bits.u1BBU_Enable = 0;
	}

	/* Bit 11 - PFC Fault */
	tsLog.nStatusPFC.u16Bits.u1PFC_Fault = GET_PFC_FAULT;

    /* Bit 12 - PFC Fault */
    tsLog.nStatusPFC.u16Bits.u1Vbulk_OVW = GET_MOMIDC_VBULK_OVW;

    /* Bit 13 - PFC Fault */
    tsLog.nStatusPFC.u16Bits.u1Vbulk_UVW = GET_MOMIDC_VBULK_UVW;

	/* Check new event triggered or not, XOR/AND */
	if ((u16PreviousValue ^ tsLog.nStatusPFC.u16All) & 
		tsLog.nStatusPFC.u16All & STATUS_PFC_RECORDER_TRIGGER)
	{
		u16NewEventTrigger = TRUE;
	}
			
	return u16NewEventTrigger;
}

/***************************************************************************
*   brief  Update Status CML
*   note   u8Bits: Which bits are attempted to assert
****************************************************************************/
void Log_Status_CML(u8_t u8Bits)
{

	if (u8Bits != NULL)
	{
		tsLog.nStatusCML.u8All |= u8Bits;
	}
	else
	{
		/* Bit 0 - INTERNAL_COMM_FAULT */
		if (tsLog.u16D2DAliveFlag)
		{
			tsLog.nStatusCML.u8Bits.u1INTERNAL_COMM_FAULT = 0;
		}
        else if (tsLog.u32UnixTimeStamp >= 10) // 10 means 10s , Avoid causing "u1INTERNAL_COMM_FAULT" when turning on PSU for the first time
        {
			tsLog.nStatusCML.u8Bits.u1INTERNAL_COMM_FAULT = 1;
		}
	}

	if (tsLog.u8PreCML != tsLog.nStatusCML.u8All)
	{
		tsLog.u8PreCML = tsLog.nStatusCML.u8All;
		tsLog.u16CMLRecoveryCNT = tsLog.u8Fault_Delay;
	}
	

	/* Bit 1 - INTERNAL_COMM_WARNING */

	/* Bit 2 - MEMORY_UTILIZATION_FAULT */

	/* Bit 3 - CPU_UTILIZATION_FAULT */

	/* Bit 4 - MESSAGE_FAILURES_FAULT */

	/* Bit 5 - CHECKSUM_FAIL */

	/* Bit 6 - INVALID_DATA */

	/* Bit 7 - INVALID_COMM */

}

/***************************************************************************
*   brief  Update Status input
*   note   1ms
****************************************************************************/
static inline void Log_Status_PFCtoD2D(void)
{
	// Bit 0 - ATSInBootloader
	if (GET_IAP_LED_INDICATOR_CNT > 0)
	{
		tsLog.nStatus_PFC2D2D.u16Bits.u1ATSInBootloader = 1;
	}
	else
	{
		tsLog.nStatus_PFC2D2D.u16Bits.u1ATSInBootloader = 0; // Clear Bootloader LED blinking
	}
	
	// Bit 1 - ATS Fault
    if (tsLog.nStatusWord.u16Bits.u1ATS_PERMANENT_FAILURE)
    {
        tsLog.nStatus_PFC2D2D.u16Bits.u1ATS_Fault = 1;
    }
    else
    {
        tsLog.nStatus_PFC2D2D.u16Bits.u1ATS_Fault = 0;
    }

	/* Bit 2 - PFC Fault */
    if (tsLog.nComposite_failure.u8Bits.u1PFC_Composite_failure)
    {
        tsLog.nStatus_PFC2D2D.u16Bits.u1PFC_Fault = 1;
    }
    else
    {
        tsLog.nStatus_PFC2D2D.u16Bits.u1PFC_Fault = 0;
    }


	/* Bit 4 - Temp_PFC_UTP */
	tsLog.nStatus_PFC2D2D.u16Bits.u1Temp_PFC_UTP = GET_MOMITP_PFC_UTP;
	
	/* Bit 5 - Temp_PFC_UTW */
	tsLog.nStatus_PFC2D2D.u16Bits.u1Temp_PFC_UTW = GET_MOMITP_PFC_UTW;

	/* Bit 6 - Temp_PFC_OTW */
	tsLog.nStatus_PFC2D2D.u16Bits.u1Temp_PFC_OTW = GET_MOMITP_PFC_OTW;

	/* Bit 7 - Temp_PFC_OTP */
	tsLog.nStatus_PFC2D2D.u16Bits.u1Temp_PFC_OTP = GET_MOMITP_PFC_OTP;

	/* Bit 8 - D2D Enable */
	tsLog.nStatus_PFC2D2D.u16Bits.u1D2D_Enable = GET_GPIO_D2D_EN;

	// Bit 9 - Vbulk OVP
	tsLog.nStatus_PFC2D2D.u16Bits.u1VBULK_OVP = GET_MOMIDC_VBULK_OVP;

	// Bit 10 - Vbulk UVP , this bit create in PFC operate mode

	// Bit 11 - Temp_Inlet_OTP
	tsLog.nStatus_PFC2D2D.u16Bits.u1Temp_Inlet_OTP = GET_MOMITP_INLET_OTP;

	// Bit 12 - Temp_ATS_OTP
	tsLog.nStatus_PFC2D2D.u16Bits.u1Temp_ATS_OTP = GET_MOMITP_ATS_OTP;
	
    /* Bit 13 - Vbulk OVW */
    if (GET_MOMIDC_VBULK_OVW)
    {
        tsLog.nStatus_PFC2D2D.u16Bits.u1VBULK_OVW = TRUE;
    }
    else
    {
         tsLog.nStatus_PFC2D2D.u16Bits.u1VBULK_OVW = FALSE;
    }

    // Bit 14 - Vbulk UVW , this bit create in PFC operate mode
}

/***************************************************************************
*   brief  Update Temporary Fault and Permanent Fault
*   note   1ms in while loop
****************************************************************************/
static inline void Log_Temporary_Permanent_Fault(void)
{
    /* Update Temporary Fault */
    if (GET_MOMITP_ATS_UTP ||
        GET_MOMITP_ATS_OTP ||
        GET_MOMITP_INLET_UTP ||
        GET_MOMITP_INLET_OTP ||
        GET_MOMITP_PFC_UTP ||
        GET_MOMITP_PFC_OTP ||
        tsLog.nStatusWord.u16Bits.u1ATS_AUX_FAIL ||
        tsLog.nStatusWord.u16Bits.u1ATS_IOUT ||
        tsLog.nStatusPFC.u16Bits.u1Vbulk_OV ||
        tsLog.nStatusPFC.u16Bits.u1PTCFault ||
        tsLog.nStatusPFC.u16Bits.u1SoftStartFault)
    {
        tsLog.u16Temporary_Fault = 1;
    }
    else

    {
        tsLog.u16Temporary_Fault = 0;
    }

    /* Update Permanent Fault */
    if (tsLog.nComposite_failure.u8Bits.u1ATS_Composite_failure || tsLog.nComposite_failure.u8Bits.u1PFC_Composite_failure)
    {
        tsLog.u16Permanent_Fault = 1;
    }
    else
    {
        tsLog.u16Permanent_Fault = 0;
    }
}

/***************************************************************************
*   brief  Update LED Status to D2D by ModBus
*   note   10ms in while loop
****************************************************************************/
static void LED_Status_PFCtoD2D(void)
{
    u16_t u16Combine_LedStatus = 0;

    // S1 mode
    if (tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Valid == TRUE)
    {
        if (tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Apply == TRUE)
        {
            u16Combine_LedStatus += LED_S1_SOLID_GREEN;
        }
        else
        {
            u16Combine_LedStatus += LED_S1_SOLID_GREEN;
            u16Combine_LedStatus += LED_S1_BLINKING_GREEN;
        }
    }
    else if ((tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u2Health) ||
            (GET_MOMIAC_VAC1_FRP) ||
            (GET_MOMIAC_VAC1_OVP))
    {
        if ((SET_ATS_SINGLE_FEED_MODE == SIGNAL_INPUT_SOURCE) &&
            (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Valid == TRUE))
        {
            // avoid S2 valid and S1 invalid output orange when single source mode , so LED must output "off"
        }
        else
        {
            u16Combine_LedStatus += LED_S1_SOLID_ORANGE;
        }
    }

    // S2 mode
    if (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Valid == TRUE)
    {
        if (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Apply == TRUE)
        {
            u16Combine_LedStatus += LED_S2_SOLID_GREEN;
        }
        else
        {
            u16Combine_LedStatus += LED_S2_SOLID_GREEN;
            u16Combine_LedStatus += LED_S2_BLINKING_GREEN;
        }
    }
    else if ((tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u2Health) ||
            (GET_MOMIAC_VAC2_FRP) ||
            (GET_MOMIAC_VAC2_OVP))
    {
        if ((SET_ATS_SINGLE_FEED_MODE == SIGNAL_INPUT_SOURCE) &&
            (tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Valid == TRUE))
        {
            // avoid S1 valid and S2 invalid output orange when single source mode , so LED must output "off"
        }
        else
        {
            u16Combine_LedStatus += LED_S2_SOLID_ORANGE;
        }
    }

    if (GET_PFC_BootMode)
    {
        u16Combine_LedStatus += LED_BootMode;
    }

    if (tsLog.u16Temporary_Fault)
    {
        u16Combine_LedStatus += LED_TemporaryFault;
    }

    if (tsLog.u16Permanent_Fault)
    {
        u16Combine_LedStatus += LED_PermanentFault;
    }

    tsLog.nLED_StatustoD2D.u16All = u16Combine_LedStatus;
}

/***************************************************************************
*   brief  Update status Transition
*   note   1ms
****************************************************************************/
static inline void Log_Status_Transition(void)
{
	/* Bit 0 - BBU Valid*/
    if (tsLog.u16BBU_Valid == 0)
    {
        tsLog.nStatus_Transition.u8Bits.u1BBUValid = 0;
    }
    else
    {
        tsLog.nStatus_Transition.u8Bits.u1BBUValid = 1;
    }

    /* Bit 1 - S2 Available */
    if (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Valid)
    {
        tsLog.nStatus_Transition.u8Bits.u1Available_S2 = 1;
    }
    else
    {
        tsLog.nStatus_Transition.u8Bits.u1Available_S2 = 0;
    }

    /* Bit 2 - S1 Available */
    if (tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Valid)
    {
        tsLog.nStatus_Transition.u8Bits.u1Available_S1 = 1;
    }
    else
    {
        tsLog.nStatus_Transition.u8Bits.u1Available_S1 = 0;
    }

	/* Bit 3 - Current Source S2 */
	/* Bit 4 - Current Source S1 */
	if (tsATS.tsInput[ATS_InputTag_Input1].nFlag.u16Bits.u1Apply)
	{
		tsLog.nStatus_Transition.u8Bits.u1CurrentSource_S1 = 1;
		tsLog.nStatus_Transition.u8Bits.u1CurrentSource_S2 = 0;
	}
	else if (tsATS.tsInput[ATS_InputTag_Input2].nFlag.u16Bits.u1Apply)
	{
		tsLog.nStatus_Transition.u8Bits.u1CurrentSource_S1 = 0;
		tsLog.nStatus_Transition.u8Bits.u1CurrentSource_S2 = 1;
	}
	else
	{
		tsLog.nStatus_Transition.u8Bits.u1CurrentSource_S1 = 0;
		tsLog.nStatus_Transition.u8Bits.u1CurrentSource_S2 = 0;
	}
}

/***************************************************************************
*   brief  Update Composite failure per 1s
*   note   
****************************************************************************/
static inline void Log_Composite_failure(void)
{
    // For ATS Composite failure
    if ((tsLog.nStatusATSource.u8Bits.u1Available_S1 || tsLog.nStatusATSource.u8Bits.u1Available_S2) &&
        ((tsLog.nStatusATSource.u8Bits.u1CurrentSource_S1 == 0) && (tsLog.nStatusATSource.u8Bits.u1CurrentSource_S2 == 0)))
    {
    	if (tsLog.u16CompositeFault_ATSCounter < ATS_Composite_Fault_CNT)
    	{
    		tsLog.u16CompositeFault_ATSCounter ++;
    	}
        else
        {
        	tsLog.nComposite_failure.u8Bits.u1ATS_Composite_failure = 1;
        }
    }
    else
    {
        tsLog.u16CompositeFault_ATSCounter = 0;
        tsLog.nComposite_failure.u8Bits.u1ATS_Composite_failure = 0;
    }

    // For PFC Composite failure
    if (GET_PFC_ENABLE && (GET_MOMIDC_VBULK_GOOD == FALSE))
    {
		if (tsLog.u16CompositeFault_PFCCounter < PFC_Composite_Fault_CNT)
		{
			tsLog.u16CompositeFault_PFCCounter ++;
		}
		else
		{
			tsLog.nComposite_failure.u8Bits.u1PFC_Composite_failure = 1;
		}
    }
    else
    {
        tsLog.u16CompositeFault_PFCCounter = 0;
        tsLog.nComposite_failure.u8Bits.u1PFC_Composite_failure = 0;
    }
}

/***************************************************************************
*   brief  Update Power on count per 1s
*   note   
****************************************************************************/
static inline void Log_PowerOnTime(void)
{
	if (tsLog.u32UnixTimeStamp < Q32_1)
	{
		tsLog.u32UnixTimeStamp += 1;
	}

	if (tsLog.u32PowerOnTime < Q32_1)
	{
		tsLog.u32PowerOnTime += 1;
	}
	
	if (tsLog.u32TotPowerOnTime < Q32_1)
	{
		tsLog.u32TotPowerOnTime += 1;
	}
}

/***************************************************************************
*   brief  Check D2D Alive per 1s
*   note   
****************************************************************************/
static inline void CheckD2DAlive(void)
{
	if (tsLog.u16D2DAlivePreCNT != tsLog.u16D2DAliveCNT)
	{
		tsLog.u16D2DAlivePreCNT = tsLog.u16D2DAliveCNT;
		tsLog.u16D2DAliveFlag = 1;
	}
	else
	{
		tsLog.u16D2DAliveFlag = 0;
	}
}

/***************************************************************************
*   brief  Check BBU and D2D device time out per 1s
*   note   
****************************************************************************/
static inline void Device_Time_Out(void)
{
	u16_t i;
	
    for (i=0; i<SHELF_DEVICE_NUMBER; i++)
    {
    	if (tsLog.u8BBU_TIMEOUT[i] > 0)
    	{
    		tsLog.u8BBU_TIMEOUT[i] -= 1;
    	}

		if (tsLog.u8D2D_TIMEOUT[i] > 0)
    	{
    		tsLog.u8D2D_TIMEOUT[i] -= 1;
    	}
	}
}

/***************************************************************************
*   brief  CML recovery time per 1s
*   note
****************************************************************************/
static inline void CML_Recovery_Time(void)
{
	if (tsLog.u16CMLRecoveryCNT > 0)
	{
		tsLog.u16CMLRecoveryCNT --;
	}
	else
	{
		tsLog.nStatusCML.u8All = 0;
		tsLog.u8PreCML = 0;
	}
}

/***************************************************************************
*   brief  Fetch D2D Max Power per 1s
*   note
****************************************************************************/
static inline void Fetch_D2D_Max_Power(void)
{
	u16_t i;
	u32_t u32Power_Out_Linear11 = 0;
	u16_t u16Power_Out_Linear11 = 0;
	u32_t u32Power_Out_Real = 0;
	u32_t u32Power_Out_Max = 0;
	
    for (i=0; i<SHELF_DEVICE_NUMBER; i++)
    {
    	if (tsLog.u8D2D_TIMEOUT[i] > 0)
    	{
    		u32Power_Out_Linear11 = tsLog.u32D2D_ReadPower[i] & 0xFFFF0000;
			u16Power_Out_Linear11 = u32Power_Out_Linear11 >> 16;
			u32Power_Out_Real = (u32_t)Literal_To_Real(u16Power_Out_Linear11, 1);

			if (u32Power_Out_Real > u32Power_Out_Max)
    		{
    			u32Power_Out_Max = u32Power_Out_Real;
    		} 		
    	}
    }
	tsLog.u16D2D_MaxPower = (u16_t)u32Power_Out_Max;
}

/***************************************************************************
*   brief  Bootloader time out per 1s
*   note
****************************************************************************/
static inline void Bootloader_Time_Out(void)
{
	if (GET_IAP_LED_INDICATOR_CNT > 0)
	{
		if (GET_IAP_LED_INDICATOR_CNT < IAP_LED_Time_Out)
		{
			GET_IAP_LED_INDICATOR_CNT ++;
		}
		else
		{
			GET_IAP_LED_INDICATOR_CNT = 0;
			GET_IAP_PROGRAM_STAGE = eProgram_IDLE;
	        GET_STATUS_BOOTLOADER = 0; // Clear STATUS_BOOTLOADER flag when bootloader 30mins is time out
		}
	}
}

/***************************************************************************
*   brief  Calculate input current
*   note   To calibration input current by specific offset at different input voltage condition
****************************************************************************/
static u16_t Log_Input_Current_Cal(void)
{
	u16_t u16Iin_orginal;
	u16_t u16Iin;	// unit is 0.001A
	u16_t u16Vin;	// unit is 0.1V

	u16Iin = GET_MOMIAC_IPFC_REALRMS_WF;
	u16Iin_orginal = GET_MOMIAC_IPFC_REALRMS_WF;
	
    if (tsATS.ptApply->eTag == ATS_InputTag_Input1)
    {
        u16Vin = GET_MOMIAC_VAC1_REALRMS_WF;
    }
    else
    {
        u16Vin = GET_MOMIAC_VAC2_REALRMS_WF;
    }

	if (u16Iin > 200) // For avoid variable overflow
	{
	    if(GET_APPLY_INPUT_STATUS == MoniAC_InputStatus_DC)    // DC input
	    {
	        // Vin > 425V
	        if(u16Vin >= 4250)
	        {
	            u16Iin = (u16_t)((f32_t)u16Iin_orginal * 0.97) + 95;

	        }
	        // 285V < Vin < 425V
	        else if(u16Vin >= 2850)
	        {
	            if (u16Iin_orginal > 145)
	            {
	                u16Iin = u16Iin_orginal - 145;
	            }
	        }
	        // Vin < 285V
	        else
	        {
	            if (u16Iin_orginal > 180)
	            {
	                u16Iin = (u16_t)((f32_t)u16Iin_orginal * 1.02) - 180;
	            }
	        }
	    }
	    else    // AC input
	    {
	        // Vin > 290V
	        if (u16Iin_orginal < 2000)
	        {
	            ;
	        }
	        else if (u16Vin > 2900)
	        {
	            if (u16Iin_orginal < 4000)
	            {
                    u16Iin = u16Iin_orginal - 10;
	            }
                else if (u16Iin_orginal < 5000)
                {
                    u16Iin = u16Iin_orginal - 50;
                }
	            else if (u16Iin_orginal < 7500)
	            {
	                u16Iin = u16Iin_orginal - 70;
	            }
	            else if (u16Iin_orginal < 11500)
	            {
	                u16Iin = u16Iin_orginal - 100;
	            }
	            else
	            {
                    u16Iin = u16Iin_orginal - 200;
	            }
	        }
	        // 265V < Vin < 290V
	        else if (u16Vin > 2650)
	        {
                if (u16Iin_orginal < 5000)
                {
                    u16Iin = u16Iin_orginal - 195;
                }
                else if (u16Iin_orginal < 5500)
                {
                    u16Iin = u16Iin_orginal - 175;
                }
                else if (u16Iin_orginal < 7000)
	            {
	                u16Iin = u16Iin_orginal - 160;
	            }
                else
                {
                    u16Iin = u16Iin_orginal - 150;
                }
	        }
            // 235V < Vin < 265V
            else if (u16Vin > 2350)
            {
                u16Iin = u16Iin_orginal - 100;
            }
	        // 225V < Vin < 235V
	        else if (u16Vin > 2250)
	        {
	            if (u16Iin < 6000)
	            {
	                u16Iin = u16Iin_orginal - 90;
	            }
	            else
	            {
	                u16Iin = u16Iin_orginal - 60;
	            }

	        }
	        // 215V < Vin < 225V
	        else if (u16Vin > 2150)
	        {
	            if (u16Iin < 6500)
	            {
	                u16Iin = u16Iin_orginal - 70;
	            }
	            else
	            {
	                u16Iin = u16Iin_orginal - 50;
	            }
	        }
	        // 190V < Vin < 215V
	        else if (u16Vin > 1900)
	        {
	            if (u16Iin < 9000)
	            {
	                u16Iin = u16Iin_orginal - 40;
	            }
	            else
	            {
                    u16Iin = u16Iin_orginal;
	            }
	        }
	        // Vin < 190V
	        else
	        {
	            if (u16Iin < 6500)
	            {
	                u16Iin = u16Iin_orginal + 10;
	            }
	            else
	            {
	                u16Iin = u16Iin_orginal + 100;
	            }
	        }
	    }
	}

	return u16Iin;
}


/***************************************************************************
*   brief  Calculate input power
*   note   To calibration input power by specific PF at different Load condition
****************************************************************************/
static u16_t Log_Input_Power_Cal(u16_t u16Vin, u16_t u16Iin)
{
	u16_t u16Pin;
	u16Pin = (u16_t)(((u32_t)u16Vin * (u32_t)u16Iin) / 10000);	// Unit is 1W (0.1V*0.001A)

	if (u16Pin < 150)
	{
        u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.2);
	}
    else if (u16Pin < 400)  // <600W PF:0.98~0.95
    {
        if (u16Vin > 2700 && u16Pin < 220) // > 270Vac
        {
            u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.2);
        }
        else
        {
            u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.5);
        }
    }
	else if (u16Pin < 600)	// <600W PF:0.98~0.95
	{
		if (u16Vin < 2150) // < 215Vac
		{
			u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.98);
		}
		else
		{
			u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.95);
		}
	}
	else if (u16Pin < 1000)		// 600W~999W PF:0.98
	{
	    if (u16Vin > 3000)
	    {
	        u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.965);
	    }
	    else if (u16Vin > 2150) // > 215Vac
        {
            u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.98);
        }
	}
	else if (u16Pin < 1500)		// 1000W~1500W PF:0.99
	{
        if (u16Vin > 3000 && u16Pin < 1200)
        {
            u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.965);
        }
        else if (u16Vin > 2650) // > 265Vac
        {
            u16Pin = (u16_t)((f32_t)u16Pin * (f32_t)0.99);
        }
	}

	return u16Pin;
}

/***************************************************************************
*   brief  Update input parameter
*   note   10ms Periodically process
****************************************************************************/
static void Log_Input_Meter(void)
{
	if (tsATS.ptApply != NULL)
	{
		tsLog.u16InputCurrent = Log_Input_Current_Cal();

		if (tsATS.ptApply->eTag == ATS_InputTag_Input1)
		{
			tsLog.u16InputVoltage = GET_MOMIAC_VAC1_REALRMS_WF;
			tsLog.u16InputVoltage_WOF = GET_MOMIAC_VAC1_REALRMS;
			tsLog.u16InputFrequency = GET_MOMIAC_VAC1_FREQ_WF;
			tsLog.u16InputCurrent_S1 = tsLog.u16InputCurrent;
			tsLog.u16InputCurrent_S2 = 0;
			tsLog.u16InputPower = Log_Input_Power_Cal(tsLog.u16InputVoltage, tsLog.u16InputCurrent);
			tsLog.u16InputPower_S1 = tsLog.u16InputPower;
			tsLog.u16InputPower_S2 = 0;
			tsLog.u16InputPower_AVG = tsLog.u16InputPower_AVG_S1;
			tsLog.u16InputPower_Max = tsLog.u16InputPower_Max_S1;

			if (tsLog.nStatus_D2D2PFC.u16Bits.u1D2D_STB_OK)
			{
				// For secondary AC1 or AC2 rising time issue
				SET_GPIO_AC1_ON;
				SET_GPIO_AC2_OFF;
			}
		}
		else if (tsATS.ptApply->eTag == ATS_InputTag_Input2)
		{
			tsLog.u16InputVoltage = GET_MOMIAC_VAC2_REALRMS_WF;
			tsLog.u16InputVoltage_WOF = GET_MOMIAC_VAC2_REALRMS;
			tsLog.u16InputFrequency = GET_MOMIAC_VAC2_FREQ_WF;
			tsLog.u16InputCurrent_S2 = tsLog.u16InputCurrent;
			tsLog.u16InputCurrent_S1 = 0;
			tsLog.u16InputPower = Log_Input_Power_Cal(tsLog.u16InputVoltage, tsLog.u16InputCurrent);
			tsLog.u16InputPower_S2 = tsLog.u16InputPower;
			tsLog.u16InputPower_S1 = 0;
			tsLog.u16InputPower_AVG = tsLog.u16InputPower_AVG_S2;
			tsLog.u16InputPower_Max = tsLog.u16InputPower_Max_S2;

			if (tsLog.nStatus_D2D2PFC.u16Bits.u1D2D_STB_OK)
			{
				SET_GPIO_AC2_ON;
				SET_GPIO_AC1_OFF;
			}
		}	
	}
	else
	{
		tsLog.u16InputVoltage = 0;
		tsLog.u16InputVoltage_WOF = 0;
		tsLog.u16InputCurrent = 0;
		tsLog.u16InputCurrent_S1 = 0;
		tsLog.u16InputCurrent_S2 = 0;
		tsLog.u16InputFrequency = 0;
		tsLog.u16InputPower = 0;
		tsLog.u16InputPower_S1 = 0;
		tsLog.u16InputPower_S2 = 0;
		tsLog.u16InputPower_AVG = 0;
		tsLog.u16InputPower_Max = 0;

		if (tsLog.nStatus_D2D2PFC.u16Bits.u1D2D_STB_OK)
		{
			SET_GPIO_AC1_OFF;
			SET_GPIO_AC2_OFF;
		}
	}

	tsLog.u16InputPower_AVG_S1 = (u16_t)((f32_t)tsLog.u16InputPower_S1 * Power_Filter_A + (f32_t)tsLog.u16InputPower_AVG_S1 * Power_Filter_B);
	tsLog.u16InputPower_AVG_S2 = (u16_t)((f32_t)tsLog.u16InputPower_S2 * Power_Filter_A + (f32_t)tsLog.u16InputPower_AVG_S2 * Power_Filter_B);

	if (tsLog.u16InputPower_S1 > tsLog.u16InputPower_Max_S1)
	{
		tsLog.u16InputPower_Max_S1 = tsLog.u16InputPower_S1;
	}

	if (tsLog.u16InputPower_S2 > tsLog.u16InputPower_Max_S2)
	{
		tsLog.u16InputPower_Max_S2 = tsLog.u16InputPower_S2;
	}
}

/***************************************************************************
*   brief  Update input Power derating
*   note   10ms Periodically process
****************************************************************************/
static void Log_Input_Power_Derating(void)
{
	// 277 @ 4.4KW
	if (tsLog.u16InputVoltage_WOF > 2370)
	{
		tsLog.u16InputPower_Derating = 4400;
	}
	// 230 @ 4.2KW
	else if (tsLog.u16InputVoltage_WOF > 2270)
	{
		if ((tsLog.u16InputPower_Derating > 4300) &&
			(tsLog.u16InputVoltage_WOF > 2330))
		{
			tsLog.u16InputPower_Derating = 4400;
		}
		else
		{
			tsLog.u16InputPower_Derating = 4200;
		}
	}
	// 220 @ 4.1KW
	else if (tsLog.u16InputVoltage_WOF > 2170)
	{
		if ((tsLog.u16InputPower_Derating > 4000) &&
			(tsLog.u16InputVoltage_WOF > 2230))
		{
			tsLog.u16InputPower_Derating = 4200;
		}
		else
		{
			tsLog.u16InputPower_Derating = 4100;
		}
	}
	// 208 @ 3.8KW
	else if (tsLog.u16InputVoltage_WOF > 2050)
	{
		if ((tsLog.u16InputPower_Derating > 3900) &&
			(tsLog.u16InputVoltage_WOF > 2130))
		{
			tsLog.u16InputPower_Derating = 4100;
		}
		else
		{
			tsLog.u16InputPower_Derating = 3800;
		}
	}
	// 200 @ 3.7KW
	//else if (tsLog.u16InputVoltage_WOF > 1950)
	else
	{
		if ((tsLog.u16InputPower_Derating > 3600) &&
			(tsLog.u16InputVoltage_WOF > 2030))
		{
			tsLog.u16InputPower_Derating = 3800;
		}
		else
		{
			tsLog.u16InputPower_Derating = 3500;
		}
	}
	// 180 @ 3.0KW
	/*
	else
	{
		if ((tsLog.u16InputPower_Derating > 3000) &&
			(tsLog.u16InputVoltage_WOF > 1900))
		{
			tsLog.u16InputPower_Derating = 3500;
		}
		else
		{
			tsLog.u16InputPower_Derating = 3000;
		}
	}
	*/

	if (GET_ATS_State == ATSStatus_Reset)
	{
		tsLog.u16InputPower_Derating = 0;
	}

	// Increase fast
	if (tsLog.u16InputPower_Derating > tsLog.u16InputPower_Derating_WF)
	{
		tsLog.u16InputPower_Derating_WF = tsLog.u16InputPower_Derating;
	}
	else
	{
		// decrease slowly
		tsLog.u16InputPower_Derating_WF = (u16_t)((f32_t)tsLog.u16InputPower_Derating * Power_Derating_Filter_A + (f32_t)tsLog.u16InputPower_Derating_WF * Power_Derating_Filter_B);
	
		if (tsLog.u16InputPower_Derating_WF <= (tsLog.u16InputPower_Derating + 10))
		{
			tsLog.u16InputPower_Derating_WF = tsLog.u16InputPower_Derating;
		}
	}
}

/***************************************************************************
*   brief  Update VBulk OVP & UVP count
*   note   1. Set CanBus_Server to send protection count (NMT 0xF7)
*          2. Update per 10ms
****************************************************************************/
static void Log_VBulk_Protect_CNT(void)
{
    if (tsLog.u32VBulk_Protect_CNT != (GET_MOMIDC_VBULK_OVP_Count + (GET_MOMIDC_VBULK_UVP_Count << 8)))
    {
        tsLog.u32VBulk_Protect_CNT = (GET_MOMIDC_VBULK_OVP_Count + (GET_MOMIDC_VBULK_UVP_Count << 8));
        SET_CANBUS_SERVER_Tx_VBulk_Protect; // Notice server to transmit VBulk protect count
    }
}

/***************************************************************************
*   brief  Update Flip count
*   note   This function should be called when ATS transfer energy source
****************************************************************************/
void Log_Update_ATSwitchCNT(void)
{
	if (tsLog.u32ATSwitchCNT < Q32_1)
	{
		tsLog.u32ATSwitchCNT += 1;
	}
		
	if (tsLog.u32TotATSwitchCNT < Q32_1)
	{
		tsLog.u32TotATSwitchCNT += 1;
	}

    if (pu16E2pDataInRam[E2pDataIndex_Manufacture_Password] == AcceptPassword)
    {
        u16_t pu16PushData[2];
        __DWordToLWord(pu16PushData, tsLog.u32TotATSwitchCNT);
        // Push Low word of Total Flip Count
        E2pData_PushData(E2pDataIndex_TotATSwitchCNT, pu16PushData[0]);
        // Push High word of Total Flip Count
        E2pData_PushData(E2pDataIndex_TotATSwitchCNT+1, pu16PushData[1]);

		__DWordToLWord(pu16PushData, tsLog.u32TotPowerOnTime);
		// Push Low word of Total Flip Count
		E2pData_PushData(E2pDataIndex_TotPowerOnTime, pu16PushData[0]);
		// Push High word of Total Flip Count
		E2pData_PushData(E2pDataIndex_TotPowerOnTime+1, pu16PushData[1]);
    }
}

/***************************************************************************
*   brief  Clear status fault by PSC
*   note   
****************************************************************************/
void Log_Clear_Fault(void)
{
	switch (tsLog.u8ClearFault)
	{
		case 0x00:	// Clear all
		
			GET_MOMIAC_VAC1_FLAG = GET_MOMIAC_VAC1_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_VAC2_FLAG = GET_MOMIAC_VAC2_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_VPFC_FLAG = GET_MOMIAC_VPFC_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_IPFC_FLAG = GET_MOMIAC_IPFC_FLAG & MOMIAC_CLEAR_FAULT;

			GET_MOMIDC_VBULK_FLAG = GET_MOMIDC_VBULK_FLAG & MOMIDC_CLEAR_FAULT;
			GET_MOMIDC_VAUX1_FLAG = GET_MOMIDC_VAUX1_FLAG & MOMIDC_CLEAR_FAULT;
			GET_MOMIDC_VAUX2_FLAG = GET_MOMIDC_VAUX2_FLAG & MOMIDC_CLEAR_FAULT;		
			CLEAR_MOMIDC_VBULK_OVP;

			GET_MOMITP_ATS_FLAG = 0;
			GET_MOMITP_PFC_FLAG = 0;
			GET_MOMITP_D2D_FLAG = 0;
			GET_MOMITP_INLET_FLAG = 0;

			GET_STATUS_BOOTLOADER = 0;
			GET_ATS_S1_PROT_FLAG = 0;
			GET_ATS_S2_PROT_FLAG = 0;
			GET_PFC_PROT_FLAG = 0;
			
			SET_ATS_AC1_RealyOpen_FaultCNT;
			SET_ATS_AC1_RealyShort_FaultCNT;
			SET_ATS_AC2_RealyOpen_FaultCNT;
			SET_ATS_AC2_RealyShort_FaultCNT;

			tsLog.nStatusCML.u8All = 0;
			tsLog.nStatusTransfer.u16All = 0;
			tsLog.u8ATSwitchCNT_Latch = 0;
			tsLog.u16CompositeFault_ATSCounter = 0;
			tsLog.u16CompositeFault_PFCCounter = 0;
			tsLog.nComposite_failure.u8All = 0;

			// For fault inject clear Trigger Type

			SET_MOMIAC_VAC1_DROP_Clear;
			SET_MOMIAC_VAC1_UVP_Clear;
			SET_MOMIAC_VAC1_UVW_Clear;
			SET_MOMIAC_VAC1_OVW_Clear;
			SET_MOMIAC_VAC1_OVP_Clear;
			SET_MOMIAC_VAC1_HAW_Clear;
			SET_MOMIAC_VAC1_HAP_Disable;
			SET_MOMIAC_VAC1_FRW_Clear;
			SET_MOMIAC_VAC1_FRP_Clear;

			SET_MOMIAC_VAC2_DROP_Clear;
			SET_MOMIAC_VAC2_UVP_Clear;
			SET_MOMIAC_VAC2_UVW_Clear;
			SET_MOMIAC_VAC2_OVW_Clear;
			SET_MOMIAC_VAC2_OVP_Clear;
			SET_MOMIAC_VAC2_HAW_Clear;
			SET_MOMIAC_VAC2_HAP_Disable;
			SET_MOMIAC_VAC2_FRW_Clear;
			SET_MOMIAC_VAC2_FRP_Clear;
		
			SET_MOMIAC_IPFC_OCW_Clear;
			SET_MOMIAC_IPFC_OCP_Clear;
			SET_MOMIAC_IPFC_OPW_Clear;
			SET_MOMIAC_IPFC_OPP_Clear;
	
			SET_MOMITP_ATS_UTP_Disable;
			SET_MOMITP_ATS_UTW_Disable;
			SET_MOMITP_ATS_OTW_Clear;
			SET_MOMITP_ATS_OTP_Clear;
			
			SET_MOMITP_INLET_UTP_Clear;
			SET_MOMITP_INLET_UTW_Clear;
			SET_MOMITP_INLET_OTW_Clear;
			SET_MOMITP_INLET_OTP_Clear;

			SET_MOMITP_PFC_UTP_Disable;
			SET_MOMITP_PFC_UTW_Disable;
			SET_MOMITP_PFC_OTW_Clear;
			SET_MOMITP_PFC_OTP_Clear;
			
			SET_MOMITP_D2D_UTP_Disable;
			SET_MOMITP_D2D_UTW_Disable;
			SET_MOMITP_D2D_OTW_Clear;
			SET_MOMITP_D2D_OTP_Clear;

			SET_MOMIDC_VAUX1_OVP_Clear;
			SET_MOMIDC_VAUX2_OVP_Clear;
			break;

		case CANBUS_CMD_STATUS_WORD:

			GET_MOMIAC_VAC1_FLAG = GET_MOMIAC_VAC1_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_VAC2_FLAG = GET_MOMIAC_VAC2_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_VPFC_FLAG = GET_MOMIAC_VPFC_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_IPFC_FLAG = GET_MOMIAC_IPFC_FLAG & MOMIAC_CLEAR_FAULT;

			GET_MOMIDC_VAUX1_FLAG = GET_MOMIDC_VAUX1_FLAG & MOMIDC_CLEAR_FAULT;
			GET_MOMIDC_VAUX2_FLAG = GET_MOMIDC_VAUX2_FLAG & MOMIDC_CLEAR_FAULT;

			GET_MOMITP_ATS_FLAG = 0;
			GET_MOMITP_PFC_FLAG = 0;
			GET_MOMITP_D2D_FLAG = 0;
			GET_MOMITP_INLET_FLAG = 0;

			GET_ATS_S1_PROT_FLAG = 0;
			GET_ATS_S2_PROT_FLAG = 0;
			GET_PFC_PROT_FLAG = 0;

			SET_ATS_AC1_RealyOpen_FaultCNT;
			SET_ATS_AC1_RealyShort_FaultCNT;
			SET_ATS_AC2_RealyOpen_FaultCNT;
			SET_ATS_AC2_RealyShort_FaultCNT;
			
			tsLog.nStatusCML.u8All = 0;
			tsLog.u16CompositeFault_ATSCounter = 0;
			tsLog.u16CompositeFault_PFCCounter = 0;
			tsLog.nComposite_failure.u8All = 0;
			break;

		case CANBUS_CMD_STATUS_INPUT:

			GET_MOMIAC_VAC1_FLAG = GET_MOMIAC_VAC1_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_VAC2_FLAG = GET_MOMIAC_VAC2_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_VPFC_FLAG = GET_MOMIAC_VPFC_FLAG & MOMIAC_CLEAR_FAULT;
			GET_MOMIAC_IPFC_FLAG = GET_MOMIAC_IPFC_FLAG & MOMIAC_CLEAR_FAULT;

			SET_MOMIAC_VAC1_DROP_Clear;
			SET_MOMIAC_VAC1_UVP_Clear;
			SET_MOMIAC_VAC1_UVW_Clear;
			SET_MOMIAC_VAC1_OVW_Clear;
			SET_MOMIAC_VAC1_OVP_Clear;
			SET_MOMIAC_VAC1_HAW_Clear;
			SET_MOMIAC_VAC1_HAP_Disable;
			SET_MOMIAC_VAC1_FRW_Clear;
			SET_MOMIAC_VAC1_FRP_Clear;

			SET_MOMIAC_VAC2_DROP_Clear;
			SET_MOMIAC_VAC2_UVP_Clear;
			SET_MOMIAC_VAC2_UVW_Clear;
			SET_MOMIAC_VAC2_OVW_Clear;
			SET_MOMIAC_VAC2_OVP_Clear;
			SET_MOMIAC_VAC2_HAW_Clear;
			SET_MOMIAC_VAC2_HAP_Disable;
			SET_MOMIAC_VAC2_FRW_Clear;
			SET_MOMIAC_VAC2_FRP_Clear;

			SET_MOMIAC_IPFC_OCW_Clear;
			SET_MOMIAC_IPFC_OCP_Clear;
			SET_MOMIAC_IPFC_OPW_Clear;
			SET_MOMIAC_IPFC_OPP_Clear;
			break;

		case CANBUS_CMD_STATUS_TRANSFER:
				
			tsLog.nStatusTransfer.u16All = 0;	
			break;

		case CANBUS_CMD_STATUS_TEMP:

			GET_MOMITP_ATS_FLAG = 0;
			GET_MOMITP_PFC_FLAG = 0;
			GET_MOMITP_D2D_FLAG = 0;
			GET_MOMITP_INLET_FLAG = 0;
			
			SET_MOMITP_ATS_UTP_Disable;
			SET_MOMITP_ATS_UTW_Disable;
			SET_MOMITP_ATS_OTW_Clear;
			SET_MOMITP_ATS_OTP_Clear;
			SET_MOMITP_INLET_UTP_Clear;
			SET_MOMITP_INLET_UTW_Clear;
			SET_MOMITP_INLET_OTW_Clear;
			SET_MOMITP_INLET_OTP_Clear;
			SET_MOMITP_PFC_UTP_Disable;
			SET_MOMITP_PFC_UTW_Disable;
			SET_MOMITP_PFC_OTW_Clear;
			SET_MOMITP_PFC_OTP_Clear;
			SET_MOMITP_D2D_UTP_Disable;
			SET_MOMITP_D2D_UTW_Disable;
			SET_MOMITP_D2D_OTW_Clear;
			SET_MOMITP_D2D_OTP_Clear;
			break;

		case CANBUS_CMD_STATUS_OTHER:

			GET_MOMIDC_VAUX1_FLAG = GET_MOMIDC_VAUX1_FLAG & MOMIDC_CLEAR_FAULT;
			GET_MOMIDC_VAUX2_FLAG = GET_MOMIDC_VAUX2_FLAG & MOMIDC_CLEAR_FAULT;	
			SET_MOMIDC_VAUX1_OVP_Clear;
			SET_MOMIDC_VAUX2_OVP_Clear;

			GET_ATS_S1_PROT_FLAG = 0;
			GET_ATS_S2_PROT_FLAG = 0;
			GET_PFC_PROT_FLAG = 0;
			SET_ATS_AC1_RealyOpen_FaultCNT;
			SET_ATS_AC1_RealyShort_FaultCNT;
			SET_ATS_AC2_RealyOpen_FaultCNT;
			SET_ATS_AC2_RealyShort_FaultCNT;
			tsLog.u8ATSwitchCNT_Latch = 0;
			break;

		case CANBUS_CMD_STATUS_CML:
				
			tsLog.nStatusCML.u8All = 0;
			break;

		
		case CANBUS_CMD_STATUS_BOOTLOADER:
			
			GET_STATUS_BOOTLOADER = 0;
			break;
		
		default:
			break;
	}
}

/***************************************************************************
*   brief  Fault Injection function
*   note   
****************************************************************************/
void Log_EDIT_Status_Input(u8_t Value1, u8_t Value2, u8_t Value3)
{
	if (Value1 & Bits_00)
	{
		GET_MOMIAC_VAC1_HAP = 1;
		SET_MOMIAC_VAC1_HAP_Latch;
	}

	if (Value1 & Bits_01)
	{
		GET_MOMIAC_VAC1_HAW = 1;
		SET_MOMIAC_VAC1_HAW_Latch;
	}

	if (Value1 & Bits_02)
	{
		GET_MOMIAC_VAC1_FRW = 1;
		SET_MOMIAC_VAC1_FRW_Latch;
	}

	if (Value1 & Bits_03)
	{
		GET_MOMIAC_VAC1_FRP = 1;
		SET_MOMIAC_VAC1_FRP_Latch;
	}

	if (Value1 & Bits_04)
	{
		GET_MOMIAC_VAC1_UVP = 1;
		GET_MOMIAC_VAC1_DROP = 1;
		SET_MOMIAC_VAC1_UVP_Latch;
		SET_MOMIAC_VAC1_DROP_Latch;
	}

	if (Value1 & Bits_05)
	{
		GET_MOMIAC_VAC1_UVW = 1;
		SET_MOMIAC_VAC1_UVW_Latch;
	}

	if (Value1 & Bits_06)
	{
		GET_MOMIAC_VAC1_OVW = 1;
		SET_MOMIAC_VAC1_OVW_Latch;
	}

	if (Value1 & Bits_07)
	{
		GET_MOMIAC_VAC1_OVP = 1;
		SET_MOMIAC_VAC1_OVP_Latch;
	}


	if (Value2 & Bits_00)
	{
		GET_MOMIAC_VAC2_HAP = 1;
		SET_MOMIAC_VAC2_HAP_Latch;
	}

	if (Value2 & Bits_01)
	{
		GET_MOMIAC_VAC2_HAW = 1;
		SET_MOMIAC_VAC2_HAW_Latch;
	}

	if (Value2 & Bits_02)
	{
		GET_MOMIAC_VAC2_FRW = 1;
		SET_MOMIAC_VAC2_FRW_Latch;
	}

	if (Value2 & Bits_03)
	{
		GET_MOMIAC_VAC2_FRP = 1;
		SET_MOMIAC_VAC2_FRP_Latch;
	}

	if (Value2 & Bits_04)
	{
		GET_MOMIAC_VAC2_UVP = 1;
		GET_MOMIAC_VAC2_DROP = 1;
		SET_MOMIAC_VAC2_UVP_Latch;
		SET_MOMIAC_VAC2_DROP_Latch;
	}

	if (Value2 & Bits_05)
	{
		GET_MOMIAC_VAC2_UVW = 1;
		SET_MOMIAC_VAC2_UVW_Latch;
	}

	if (Value2 & Bits_06)
	{
		GET_MOMIAC_VAC2_OVW = 1;
		SET_MOMIAC_VAC2_OVW_Latch;
	}

	if (Value2 & Bits_07)
	{
		GET_MOMIAC_VAC2_OVP = 1;
		SET_MOMIAC_VAC2_OVP_Latch;
	}

	if (Value3 & Bits_00)
	{
		GET_MOMIAC_IPFC_OPW = 1;
		SET_MOMIAC_IPFC_OPW_Latch;
	}
	
	if (Value3 & Bits_01)
	{
		GET_MOMIAC_IPFC_OPP = 1;
		SET_MOMIAC_IPFC_OPP_Latch;
	}

	if (Value3 & Bits_02)
	{
		GET_MOMIAC_IPFC_OCW = 1;
		SET_MOMIAC_IPFC_OCW_Latch;
	}

	if (Value3 & Bits_03)
	{
		GET_MOMIAC_IPFC_OCP = 1;
		SET_MOMIAC_IPFC_OCP_Latch;
	}

}

/***************************************************************************
*   brief  Fault Injection function
*   note   
****************************************************************************/
void Log_EDIT_Status_Temp(u8_t Value)
{
	if (Value & Bits_00)
	{
		GET_MOMITP_ATS_UTP = 1;
		SET_MOMITP_ATS_UTP_Latch;
	}

	if (Value & Bits_01)
	{
		GET_MOMITP_ATS_UTW = 1;
		SET_MOMITP_ATS_UTW_Latch;
	}

	if (Value & Bits_02)
	{
		GET_MOMITP_ATS_OTW = 1;
		SET_MOMITP_ATS_OTW_Latch;
	}

	if (Value & Bits_03)
	{
		GET_MOMITP_ATS_OTP = 1;
		SET_MOMITP_ATS_OTP_Latch;
	}

	if (Value & Bits_04)
	{
		GET_MOMITP_INLET_UTP = 1;
		SET_MOMITP_INLET_UTP_Latch;
	}

	if (Value & Bits_05)
	{
		GET_MOMITP_INLET_UTW = 1;
		SET_MOMITP_INLET_UTW_Latch;
	}

	if (Value & Bits_06)
	{
		GET_MOMITP_INLET_OTW = 1;
		SET_MOMITP_INLET_OTW_Latch;
	}

	if (Value & Bits_07)
	{
		GET_MOMITP_INLET_OTP = 1;
		SET_MOMITP_INLET_OTP_Latch;
	}
}

/***************************************************************************
*   brief  Fault Injection function
*   note   byte 0 : 0 Disable temp fault injection
*                   1 Change Inlet temperature
*					2 Change ATS temperature
*					3 Change PFC temperature
*					4 Change D2D temperature
*          byte 1-2: Linear 11 target temperature
****************************************************************************/
void Log_EDIT_Temp(u8_t Value1 , i16_t Value2)
{
	if(Value1)
	{
		if(Value1 == 1)
		{
			GET_MOMITP_INLET_FIJ = TRUE;
			GET_MOMITP_INLET_Temper = Value2;
			GET_MOMITP_INLET_Temper_P = (u16_t)(GET_MOMITP_INLET_Temper + 400);
		}
		else if(Value1 == 2)
		{
			GET_MOMITP_ATS_FIJ = TRUE;
			GET_MOMITP_ATS_Temper = Value2;
			GET_MOMITP_ATS_Temper_P = (u16_t)(GET_MOMITP_ATS_Temper + 400);
		}
		else if(Value1 == 3)
		{
			GET_MOMITP_PFC_FIJ = TRUE;
			GET_MOMITP_PFC_Temper = Value2;
			GET_MOMITP_PFC_Temper_P = (u16_t)(GET_MOMITP_PFC_Temper + 400);
		}
		else if(Value1 == 4)
		{
			GET_MOMITP_D2D_FIJ = TRUE;
			GET_MOMITP_D2D_Temper = Value2;
			GET_MOMITP_D2D_Temper_P = (u16_t)(GET_MOMITP_D2D_Temper + 400);
		}
	}
	else
	{
		GET_MOMITP_INLET_FIJ = FALSE;
		GET_MOMITP_ATS_FIJ = FALSE;
		GET_MOMITP_PFC_FIJ = FALSE;
		GET_MOMITP_D2D_FIJ = FALSE;
	}
}

/***************************************************************************
*   brief  Fault Injection function
*   note   
****************************************************************************/
void Log_EDIT_Status_Other(u8_t Value)
{
	if (Value & Bits_00)
	{
		GET_MOMIDC_VAUX1_OVP = 1;
		SET_MOMIDC_VAUX1_OVP_Latch;
	}

	if (Value & Bits_01)
	{
		GET_MOMIDC_VAUX2_OVP = 1;
		SET_MOMIDC_VAUX2_OVP_Latch;
	}

	if (Value & Bits_02)
	{
		SET_ATS_S1_RELAY_OPEN_Latch;
	}

	if (Value & Bits_03)
	{
		SET_ATS_S2_RELAY_OPEN_Latch;
	}

	if (Value & Bits_04)
	{
		SET_PFC_RELAY_FAULT_Latch;
	}

	if (Value & Bits_05)
	{
		tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_FAIL = 1;
		tsLog.u8ATSwitchCNT_Latch = 1;
	}

	if (Value & Bits_06)
	{
		tsLog.nStatusOther.u8Bits.u1RELAY_COUNT_WARNING = 1;
		tsLog.u8ATSwitchCNT_Latch = 1;
	}
}

/***************************************************************************
*   brief  VBulk Fault Injection function
*   note   byte 0 : 0 Disable VBULK fault injection
*                   1 VBulk OVP
*                   2 VBulk UVP
****************************************************************************/
void Log_EDIT_VBULK_Protection(u8_t Value)
{
    if (Value == 0)
    {
        // Clear VBulk fault inject
        SET_MOMIDC_VBULK_FIJ = 0;
        SET_MOMIDC_VBULK_OVP_Clear;
        SET_MOMIDC_VBULK_UVP_Clear;
        GET_MOMIDC_VBULK_OVP = 0;
        GET_MOMIDC_VBULK_UVP = 0;
    }
    else
    {
        SET_MOMIDC_VBULK_FIJ = 1;

        // VBulk OVP fault inject
        if (Value == 1)
        {
            GET_MOMIDC_VBULK_OVP = 1;
            GET_MOMIDC_VBULK_OVP_Count ++;
            SET_MOMIDC_VBULK_OVP_Latch;
        }
        else if (Value == 2)
        {
            // VBulk UVP fault inject
            GET_MOMIDC_VBULK_UVP = 1;
            GET_MOMIDC_VBULK_UVP_Count ++;
            SET_MOMIDC_VBULK_UVP_Latch;
        }
    }
}

/***************************************************************************
*   brief  Internal debugger function
*   note   
****************************************************************************/
void Log_Internal_debugger(void)
{
	if (tsLog.nInternal_Debugger.u8Bits.u1ENABLE_WATCHDOG_RESET)
	{
		// enter watchdog bad key and reset immediately
		EALLOW;
		WdRegs.WDCR.all = 0;	// bad key
		EDIS;
	}

	if (tsLog.nInternal_Debugger.u8Bits.u1TEMP_DISABLE == TRUE)
	{
		MoniTP_Set_TriggerType(TRUE);
	}
	else
	{
		MoniTP_Set_TriggerType(FALSE);
	}
}

/***************************************************************************
*   brief  check time stamp shift
*   note   
****************************************************************************/
void Log_TimeStamp_Shift(u32_t u32Time)
{
	if (u32Time > tsLog.u32UnixTimeStamp)
	{
		tsLog.u32UnixTimeStamp_Shift = u32Time - tsLog.u32UnixTimeStamp;
	}
	
	tsLog.u32UnixTimeStamp = u32Time;
}

/***************************************************************************
*   brief  Log 1hr Periodically process
*   note   
****************************************************************************/
void Log_1hr_Periodically_Process(void)
{
	tsLog.u16InputPower_Max_S1 = tsLog.u16InputPower_AVG_S1;
	tsLog.u16InputPower_Max_S2 = tsLog.u16InputPower_AVG_S2;
}

/***************************************************************************
*   brief  Log 1s Periodically process
*   note   update unix time and working time
****************************************************************************/
void Log_1s_Periodically_Process(void)
{
	Log_Composite_failure();
	Log_PowerOnTime();
	CheckD2DAlive();
	Device_Time_Out();
	CML_Recovery_Time();
	Fetch_D2D_Max_Power();
	Bootloader_Time_Out();
}

/***************************************************************************
*   brief  Log_10ms_Periodically_Process
*   note   from ATS.c
****************************************************************************/
void Log_10ms_Periodically_Process(void)
{
	Log_Input_Meter();
	Log_Input_Power_Derating();
	Log_VBulk_Protect_CNT();    // Record VBulk protect count

    // For Modbus
    LED_Status_PFCtoD2D();

	// PFC alive count
	if (tsLog.u16PFCAliveCNT == Q16_1)
	{
		tsLog.u16PFCAliveCNT = 0;
	}
	else
	{
		tsLog.u16PFCAliveCNT ++;
	}

    // AC Power cycle count
    if ((tsATS.eATSstate == ATSStatus_Pri) ||
        (tsATS.eATSstate == ATSStatus_Sec) ||
        (tsLog.u8Shelf_BBU_NUM))
    {
        if (tsLog.u16powercycledelayCNT < Default_powercycledelayCNT)
        {
            tsLog.u16powercycledelayCNT ++;
        }
        else
        {
            tsLog.nStatus_PFC2D2D.u16Bits.u1ACPowerCycle = 1;
        }
    }
    else if (tsATS.eATSstate == ATSStatus_Reset)
    {
        tsLog.u16powercycledelayCNT = 0;
        tsLog.nStatus_PFC2D2D.u16Bits.u1ACPowerCycle = 0;
    }

	// Clear all fault while PSU in factory mode and PS from Off to On and D2D is alive
    // This function is no used!!!  Because D2D take away u1FAMode and u1PSON bit
	if ((tsLog.nStatus_D2D2PFC.u16Bits.u1FAMode == TRUE) &&
		(tsLog.u16PrePSON == FALSE) &&
		(tsLog.u16D2DAliveFlag == TRUE))
	{
		tsLog.u8ClearFault = 0;
		Log_Clear_Fault();
	}

//	tsLog.u16PrePSON = tsLog.nStatus_D2D2PFC.u16Bits.u1PSON;

}

/***************************************************************************
*   brief  Log_1ms_Periodically_Process
*   note   update all of flag for report
****************************************************************************/
void Log_1ms_Periodically_Process(void)
{	 
    u16_t u16NewEventTrigger = FALSE;

	// For CAN
    u16NewEventTrigger |= Log_Status_InputQualities();
    u16NewEventTrigger |= Log_Status_OutputQuality();
	u16NewEventTrigger |= Log_Status_Temperature();
	u16NewEventTrigger |= Log_Status_Other();
	u16NewEventTrigger |= Log_Status_PFC();
	Log_Status_ATS_Source();
	Log_Status_CML(NULL);
    Log_Status_Word();
    Log_Temporary_Permanent_Fault();

	// For Modbus
	Log_Status_Input();
	Log_Status_PFCtoD2D();
	Log_Status_Transition();

	// For Black box
    if ((tsATS.nFlag.u16Bits.u1StartUp == TRUE) &&
		((u16NewEventTrigger == TRUE) || (tsLog.u8NewBlackboxTrigger == TRUE)))
    {
    	tsLog.u8NewBlackboxTrigger = 0;
		BlackBox_StartRecord();
    }

	// For BBU status word
	Log_BBU_Status_Word();
	
	// ATS Device Fail
	if (tsLog.u16PreDeviceFault != tsLog.u16Permanent_Fault)
	{
		if ((tsLog.u16PreDeviceFault == 0) &&
			(tsLog.u16Permanent_Fault))
		{
			SET_CANBUS_SERVER_BC_ATSPSU_FAIL;
		}
		
		tsLog.u16PreDeviceFault = tsLog.u16Permanent_Fault;
	}
}

/***************************************************************************
*   brief  Log 10kHz instant process
*   note   update instant value for waveform capture
****************************************************************************/
void Log_10k_Instant_Process(void)
{

#ifdef EnablePSKILL

	// ATS relay off, Vbulk below 100V or PSkill = 1 into this function
	if ((GET_GPIO_PS_KILL == 1) && 
		(tsLog.u16D2DAliveFlag) && 
		(tsLog.nStatus_D2D2PFC.u16Bits.u1D2D_STB_OK))
	{
		PSUPlugOut();
		CANBusServer_Disable_Push_Data(); // don't send AC loss during PS kill
		
		// For fault injection, from latch to autorecovery.
		SET_MOMIAC_VAC1_HAP_Disable;
		SET_MOMIAC_VAC1_FRP_Clear;
		SET_MOMIAC_VAC1_OVP_Clear;
		SET_MOMIAC_VAC1_UVP_Clear;
		SET_MOMIAC_VAC1_DROP_Clear;
		
		SET_MOMIAC_VAC2_HAP_Disable;
		SET_MOMIAC_VAC2_FRP_Clear;
		SET_MOMIAC_VAC2_OVP_Clear;
		SET_MOMIAC_VAC2_UVP_Clear;
		SET_MOMIAC_VAC2_DROP_Clear;

		SET_MOMIAC_IPFC_OCP_Clear;
		SET_MOMITP_INLET_UTP_Clear;
		SET_MOMITP_INLET_OTP_Clear;
		SET_MOMITP_ATS_OTP_Clear;
		SET_MOMITP_PFC_OTP_Clear;
		SET_MOMITP_D2D_OTP_Clear;
	}
		
#endif

    /* Update waveform channel source */
    tsLog.u8InstantValue_VS1 = (u8_t)(GET_MOMIAC_VAC1_REALINSTANT / 20);
    tsLog.u8InstantValue_VS2 = (u8_t)(GET_MOMIAC_VAC2_REALINSTANT / 20);

    if ((tsATS.ptApply != NULL) && (tsATS.ptApply->eSwitchState > ATSSwitch_PreTurnOnATSRelay))
    {
    	tsLog.u8InstantValue_VAC = (u8_t)(GET_MOMIAC_VPFC_REALINSTANT / 20);
        tsLog.u8InstantValue_IAC = (u8_t)(GET_MOMIAC_IPFC_REALINSTANT * 8 / 100);
    }
    else
    {
        tsLog.u8InstantValue_VAC = 0;
        tsLog.u8InstantValue_IAC = 0;
    }

	tsLog.u16InstantValue_VS1_VS2 = (u16_t)tsLog.u8InstantValue_VS1 + (((u16_t)tsLog.u8InstantValue_VS2) << 8);
	tsLog.u16InstantValue_VAC_IAC = (u16_t)tsLog.u8InstantValue_VAC + (((u16_t)tsLog.u8InstantValue_IAC) << 8);
}

/***************************************************************************
*   brief  Log Initialize
*   note   Only be executed when MCU power on
****************************************************************************/
void Log_Initialize(void)
{
	memset(&tsLog, 0, sizeof(tsLog));

	tsLog.u16NominalVoltage = 277;
	tsLog.u16PreMainACValid = 3;
	tsLog.u8COMPATIBILITY_NUMBER = 0x10;
	tsLog.u8REQ_BBU_NUMBER = Default_REQ_BBU_COUNT;
	tsLog.u8HEARTBEAT_TIMEOUT = Default_HEARTBEAT_TIMEOUT;
	tsLog.u8Fault_Count_Limit = Default_FAULT_COUNT_LIMIT;
	tsLog.u8Fault_Delay = Default_FAULT_DELAY;

	/* Initial and configure waveform channel */
    sWaveformProbeConfig_t sProbeConfig;
    sProbeConfig.pu16Source[0] = &tsLog.u16InstantValue_VS1_VS2;
    sProbeConfig.pu16Source[1] = &tsLog.u16InstantValue_VAC_IAC;
    Waveform_ConfigureProbe(sProbeConfig);

    if (pu16E2pDataInRam[E2pDataIndex_Manufacture_Password] == AcceptPassword)
    {
		tsLog.u32TotATSwitchCNT = __LWordToDWord(&pu16E2pDataInRam[E2pDataIndex_TotATSwitchCNT]);
        tsLog.u32TotPowerOnTime = __LWordToDWord(&pu16E2pDataInRam[E2pDataIndex_TotPowerOnTime]);
	}

}


