/****************************************************************************
 *	File	Handler_PFC.c
 * 	Brief	Interleaved PFC state machine
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/09 - 1st release
 ****************************************************************************/

#include <string.h>
#include <math.h>
#include "Handler_PFC.h"
#include "Handler_ATS.h"
#include "Peripheral.h"
#include "SERV_ADCFilter.h"
#include "Monitor_DC.h"
#include "Monitor_TP.h"
#include "CONFIG_RisingPower.h"
#include "Peripheral.h"
#include "SERV_LOG.h"
#include "SERV_Calibration.h"
#include "CANBus_Server.h"




/****************************************************************************
*	Private parameter definition 
****************************************************************************/

/* PFC PTC Config */
#define PTC_SustainedTime				1000		// 100ms, unit is 0.1ms
#define PTC_TimeOut						30000		// 3s, unit is 0.1ms
#define PTC_FaultRecoveryTime			10			// 10s, unit is 1s
#define PTC_Target_differ_Voltage		70 			// 70V
//#define PTC_Target_differ_Voltage_Q15	(u16_t)((((f32_t)PTC_Target_differ_Voltage*1000) / (f32_t)V_BUS_FS)*Q15_+0.5)

/* PFC Softstart Config */
#define SS_Rising_Time					13000		// 1.3s, unit is 0.1ms
#define SS_Rising_Timeup				20000		// 2s, unit is 0.1ms
#define SS_FaultRecoveryTime			10			// 10s, unit is 1s
#define Default_PFCRelayCNT				60			// 10min, unit is 10s


/* PFC VBulk Ref Voltage Config */
#define VBulk_Gain_V					(f32_t)1.414  //AC RMS to Peak
#define VBulk_Gain_V_DC					(f32_t)1	  //DC RMS to Peak
#define VBulk_Gain_I					(f32_t)3.2
#define VBulk_Gain_P					(f32_t)0.0238 // 1/42
//#define VBulk_Gain_V_Q15				((VBulk_Gain_V*100*Q15_) / (f32_t)V_BUS_FS)
//#define VBulk_Gain_VDC_Q15			((VBulk_Gain_V_DC*100*Q15_) / (f32_t)V_BUS_FS)
//#define VBulk_Gain_I_Q15				((VBulk_Gain_I*100*Q15_) / (f32_t)V_BUS_FS)
//#define VBulk_Gain_P_Q15				((VBulk_Gain_P*1000*Q15_) / (f32_t)V_BUS_FS)

#define VBulk_5V                        5UL         // unit is 1V
#define VBulk_10V						10UL		// unit is 1V
#define VBulk_20V						20UL		// unit is 1V
#define VBulk_35V						35UL		// unit is 1V
#define VBulk_470V                      470UL       // unit is 1V
#define VBulk_short_Limit				100UL		// unit is 1V, detect Vbulk short fault

//#define VBulk_10V_Q15					(u16_t)(((f32_t)(VBulk_10V*1000) / (f32_t)V_BUS_FS)*Q15_)
//#define VBulk_20V_Q15					(u16_t)(((f32_t)(VBulk_20V*1000) / (f32_t)V_BUS_FS)*Q15_)
//#define VBulk_35V_Q15					(u16_t)(((f32_t)(VBulk_35V*1000) / (f32_t)V_BUS_FS)*Q15_)
//#define VBulk_Q15short_Limit			(u16_t)(((f32_t)(VBulk_short_Limit*1000) / (f32_t)V_BUS_FS)*Q15_)

#define VBulk_Compensation				0UL			// -3V, unit is 1V, For compensation Vbulk voltage while Load on
#define VBulk_Limit_MIN					439UL		// unit is 1V
#define VBulk_Limit_L					435UL		// unit is 1V
#define VBulk_Limit_M					435UL		// unit is 1V
#define VBulk_420V                      420UL       // unit is 1V
#define VBulk_438V                      438UL       // unit is 1V
#define VBulk_439V                      439UL       // unit is 1V
#define VBulk_442V						442UL		// unit is 1V
#define VBulk_Limit_H					455UL		// unit is 1V
#define VBulk_Limit_MAX					460UL		// unit is 1V
#define VBulk_SlewRate                  435UL       // unit is 1V
//#define VBulk_Q15Limit_MIN			(u16_t)(((f32_t)((VBulk_Limit_MIN - VBulk_Compensation)*1000) / (f32_t)V_BUS_FS)*Q15_)
//#define VBulk_Q15Limit_L				(u16_t)(((f32_t)((VBulk_Limit_L - VBulk_Compensation)*1000) / (f32_t)V_BUS_FS)*Q15_)
//#define VBulk_Q15Limit_M				(u16_t)(((f32_t)((VBulk_Limit_M - VBulk_Compensation)*1000) / (f32_t)V_BUS_FS)*Q15_)
//#define VBulk_Q15Limit_H				(u16_t)(((f32_t)((VBulk_Limit_H - VBulk_Compensation)*1000) / (f32_t)V_BUS_FS)*Q15_)
//#define VBulk_Q15Limit_MAX			(u16_t)(((f32_t)((VBulk_Limit_MAX - VBulk_Compensation)*1000) / (f32_t)V_BUS_FS)*Q15_)

#define VacLevel_L 						2800 		//280V, unit is 0.1V
#define VacLevel_H 						2900 		//290V, unit is 0.1V

/* Base on 4.2KW */
#define Pin_80Load 						3360 		//3360W, unit is 1W
#define Pin_75Load 						3150 		//3150W, unit is 1W
#define Pin_67Load 						2814 		//2814W, unit is 1W
#define Pin_66Load						2800 		//2800W, unit is 1W
#define Pin_62Load 						2604 		//2604W, unit is 1W
#define Pin_50Load						2100 		//2100W, unit is 1W
#define Pin_40Load						1680 		//1680W, unit is 1W
#define Pin_16Load						700 		//700W, unit is 1W
#define Pin_12Load						500 		//500W, unit is 1W
#define Pin_10Load						420 		//420W, unit is 1W

/* Base on 4.4KW */
#define Pin_80Load_48V                  3520        //3520W, unit is 1W
#define Pin_75Load_48V                  3300        //3300W, unit is 1W
#define Pin_45Load_48V                  1980        //1980W, unit is 1W
#define Pin_40Load_48V                  1760        //1760W, unit is 1W


/* PFC PI Controller Config */
#define PI_V_Integral_Poslimit			(f32_t)(Q30_-1)
#define PI_V_Integral_Neglimit			(f32_t)(0)
#define PI_I_Integral_Poslimit			(f32_t)(Q30_-1)
#define PI_I_Integral_Neglimit			(f32_t)(0)			//-Q27_ for ZC current spike

#define PI_V_PIOut_Poslimit				(f32_t)(Q16_-1)
#define PI_V_PIOut_Neglimit				(f32_t)(0)
#define PI_I_PIOut_Poslimit				(f32_t)(Q16_-1)
#define PI_I_PIOut_Neglimit				(f32_t)(0)

//#define PI_V_ERROR_THRESHOLD_H 		(u16_t)(((f32_t)20000/V_BUS_FS)*Q15_+0.5) 	//20V
//#define PI_V_ERROR_THRESHOLD_L 		(u16_t)(((f32_t)15000/V_BUS_FS)*Q15_+0.5)  	//15V
//#define PI_I_RMS_THRESHOLD_H 			(u16_t)(((f32_t)10000/I_AC_FS)*Q15_+0.5) 	//10A
//#define PI_I_RMS_THRESHOLD_L 			(u16_t)(((f32_t)5000/I_AC_FS)*Q15_+0.5)  	//5A

#define PI_V_Voltagescale 				(f32_t)(Q15_) 								//Q15
#define PI_I_Voltagescale 				(f32_t)(Q15_) 								//Q15
#define PI_V_TS							((f32_t)Q20_/CPU_TIMER_10KHz_FREQUENCY)		//Q20 1/vbus loop sample frequency
#define PI_I_TS							((f32_t)Q20_/EPWM7_FREQ)					//Q20 1/iac loop sample frequency

#define PI_V_KP_SS						(u32_t)((f32_t)1*PI_V_Voltagescale+0.5)		//Q15
#define PI_V_KP_L						(u32_t)((f32_t)1*PI_V_Voltagescale+0.5)		//Q15 , Value:32768
#define PI_V_KP_H						(u32_t)((f32_t)3*PI_V_Voltagescale+0.5) 	//Q15 , Value:32768*3
#define PI_V_KI_SS						((f32_t)300)  								//Q15
#define PI_V_KI_L						((f32_t)1500)  								//Q15
#define PI_V_KI_H						((f32_t)400)  								//Q15
#define PI_V_KITS_SS					(u32_t)(PI_V_TS*PI_V_KI_SS)					//Q20 , Value:7864
#define PI_V_KITS_L						(u32_t)(PI_V_TS*PI_V_KI_L)					//Q20 , Value:39321
#define PI_V_KITS_H						(u32_t)(PI_V_TS*PI_V_KI_H)					//Q20 , Value:10485


#ifdef Enable20AHallSensor
	
#define PI_I_KP_L						((u32_t)5000)								//Q15
#define PI_I_KP_H						((u32_t)28000) 								//Q15
#define PI_I_KI_L						((f32_t)1000) 								//Q15
#define PI_I_KI_H						((f32_t)2000)  								//Q15
#define PI_I_KITS_L						(u32_t)(PI_I_TS*PI_I_KI_L)					//Q20
#define PI_I_KITS_H						(u32_t)(PI_I_TS*PI_I_KI_H)					//Q20


#else

#define PI_I_KP_L						((u32_t)10000)								//Q15
#define PI_I_KP_H						((u32_t)40000) 								//Q15
#define PI_I_KI_L						((f32_t)2000) 								//Q15
#define PI_I_KI_H						((f32_t)4000)  								//Q15
#define PI_I_KITS_L						(u32_t)(PI_I_TS*PI_I_KI_L)					//Q20
#define PI_I_KITS_H						(u32_t)(PI_I_TS*PI_I_KI_H)					//Q20

#endif


/* PFC PI Current loop Control Parameter */

#define PI_V_Out_10_L					2200	//Iin=2A
#define PI_V_Out_10_M                   2400    //Iin=2.1A
#define PI_V_Out_10_H					2700	//Iin=2.5A
#define PI_V_Out_20_LL                  3700    //Iin=3.7A
#define PI_V_Out_20_L					3900	//Iin=3.8A
#define PI_V_Out_20_H					4200	//Iin=3.9A
#define PI_V_Out_25                     4500    //Iin=4.3A
#define PI_V_Out_30						4900	//Iin=4.8A
#define PI_V_Out_35						5800	//Iin=5.9A
#define PI_V_Out_40						6400	//Iin=6.4A
#define PI_V_Out_45                     7500    //Iin=7.5A
#define PI_V_Out_50						8000	//Iin=8.1A
#define PI_V_Out_60						9500	//Iin=9.8A
#define PI_V_Out_70						11000	//Iin=11.2A
#define PI_V_Out_80						12600	//Iin=12.8A
#define PI_V_Out_83                     12800   //Iin=13.4A
#define PI_V_Out_85                     13300   //Iin=14.7A
#define PI_V_Out_90						14000	//Iin=15.0A
#define PI_V_Out_93                     14500   //Iin=15.2A
#define PI_V_Out_95                     15000   //Iin=15.5A
#define PI_V_Out_100					17100	//Iin=18A
#define PI_V_Out_110_L                  21000   //Iin=22A
#define PI_V_Out_110_H					23000	//Iin=24A


#define PI_I_KP_10						(u32_t)40000
#define PI_I_KP_20						(u32_t)50000
#define PI_I_KP_30						(u32_t)50000
#define PI_I_KP_40						(u32_t)50000
#define PI_I_KP_50						(u32_t)50000
#define PI_I_KP_60						(u32_t)50000
#define PI_I_KP_70						(u32_t)50000
#define PI_I_KP_80						(u32_t)50000
#define PI_I_KP_90						(u32_t)40000
#define PI_I_KP_100						(u32_t)20000

#define PI_I_KI_10						(u32_t)60000
#define PI_I_KI_20						(u32_t)100000
#define PI_I_KI_30						(u32_t)100000
#define PI_I_KI_40						(u32_t)100000
#define PI_I_KI_50						(u32_t)100000
#define PI_I_KI_60						(u32_t)100000
#define PI_I_KI_70						(u32_t)100000
#define PI_I_KI_80						(u32_t)100000
#define PI_I_KI_90						(u32_t)100000
#define PI_I_KI_100						(u32_t)100000

#define PI_DFFS_10						(u32_t)1600
#define PI_DFFS_20						(u32_t)2000
#define PI_DFFS_30						(u32_t)1000
#define PI_DFFS_40						(u32_t)1000
#define PI_DFFS_50						(u32_t)1000
#define PI_DFFS_60						(u32_t)1000
#define PI_DFFS_70						(u32_t)1000
#define PI_DFFS_80						(u32_t)1000
#define PI_DFFS_90						(u32_t)1000
#define PI_DFFS_100						(u32_t)1000


/* PFC Cuurent loop Controller Config */
#define	Duty_feedward_Poslimit			(f32_t)(Q16_-1)	//Q16-1
#define	Duty_feedward_Neglimit			(f32_t)(0)
//#define	Duty_feedward_Gain				((f32_t)(1.08))	//1.03 > 1 backward, <1 forward
#define Duty_feedward_shift				(1500)			//1500
#define SoftStart_Change_Phase          (7000)         // For SoftStart Change Phase , unit is 0.001V
#define Prevent_Over_SoftStart          (20000)        // For Prevent over softStart Change Phase , unit is 0.001V
#define Normal_Change_Phase             (0000)         // For Normal Change Phase    , unit is 0.001V
//#define Duty_feedward_Currentadjust	(i32_t)(((f32_t)4500/I_AC_FS)*Q16_+0.5) 	//4.5A single phase peak current

//#define Vacpeak_10V_THRESHOLD 		(u16_t)(((f32_t)10000/V_ACPFC_FS)*Q15_+0.5) //10V
//#define Vacpeak_20V_THRESHOLD 		(u16_t)(((f32_t)20000/V_ACPFC_FS)*Q15_+0.5) //20V
//#define Vacpeak_THRESHOLD_H 			Q15_
//#define Vacpeak_THRESHOLD_L			(u16_t)(((f32_t)160000/V_ACPFC_FS)*Q15_*1.414)	//160V
//#define Iacpeak_Poslimit				(i16_t)(((f32_t)17000/I_AC_FS)*Q15_+0.5) 	//17A single phase, 34A total current
//#define Iacpeak_Lightload_L			(i32_t)(((f32_t)8000/I_AC_FS)*Q15_+0.5) 	//8A single phase peak current
//#define Iacpeak_Lightload_H			(i32_t)(((f32_t)9000/I_AC_FS)*Q15_+0.5) 	//9A single phase peak current


/* PFC voltage protection Config */
#define UV_FaultRecoveryTime			3		// 3s, unit is 1s
#define OV_FaultRecoveryTime			10		// 10s, unit is 1s

/* X-cap compensation Config */
#define Xcap							(f32_t)6	// Unit is uF
#define PIx2_           				(f32_t)6.2831853
//#define XcapCom         				((f32_t)PIx2_*Gain_ACPFC_to_I_AC*Xcap)


/* Totem Pole phase control Config */
//#define Phasechange_V_Pos_Hystersis		(i16_t)(((f32_t)10000/V_ACPFC_FS)*Q15_) 	//10V


/* PWM Duty limit */
#define PWM_Enable_COUNT       			5
#define PWM_Duty_Poslimit				62914	//62500 ->96%
#define PWM_Duty_Neglimit				2621	//3000 -> 4%


/* PFC enable from Suspend to operation delay time */

#define Enable_PFC_Delay_Time			20		// 20ms, unit is 0.1ms
#define BBU_Mode_Off_Delay_Time			600		// 60ms, unit is 0.1ms
#define Suspend_Delay_Time				270		// 27ms + 3ms drop out is 30ms, unit is 0.1ms, align with delta
#define VPFC_PEAK_Ready_Delay           2000    // 200ms, unit is 0.1ms

/* PFC Vbulk level to D2D */
#define VBulk435Level                   9929
#define VBulk442Level                   29789
#define VBulk455Level                   49648

/* PI control parameters adjust by CANBUS*/
#define CONTROL_Increase				0x10
#define CONTROL_Decrease				0x01

#define Mask_Vbulk_UV_Fault_Flag  		0x40EF


/****************************************************************************
*	Private macro definition
****************************************************************************/ 

/****************************************************************************
*	Private enumeration definition
****************************************************************************/ 
enum
{
	ePFC_Polarity_DeadZone,
	ePFC_Polarity_Positive,
	ePFC_Polarity_Negative,
};

/****************************************************************************
*	Private structure definition 
****************************************************************************/

/****************************************************************************
*	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 2057 -> 2010
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Dynamic_Current_PIGain, ".TI.ramfunc");
#pragma CODE_SECTION(Get_VBulk_Vref_Q15, ".TI.ramfunc");
#pragma CODE_SECTION(PI_CONTROLLER, ".TI.ramfunc");
#pragma CODE_SECTION(PFC_Voltage_Loop_Handler, ".TI.ramfunc");
#pragma CODE_SECTION(PFC_Current_Loop_Handler, ".TI.ramfunc");
#pragma CODE_SECTION(PFC_Handler, ".TI.ramfunc");
//#pragma CODE_SECTION(PFC_1ms_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(PFC_1s_Periodically_Process, ".TI.ramfunc");

#endif


/****************************************************************************
*	Private variable declaration
****************************************************************************/
sPFC_t tsPFC;



/****************************************************************************
*	Brief	dynamic current loop PG gain base on voltage loop PIout
*	Note	voltage loop PIout higher(power rise) then current loop KP smaller
*	        return : KP : Q15 , KI : Q20
*
*			change PFC KPKI check list:
*			1. PF and iTHD
*			2. 3%VTHD inject, check iTHD < 5%
*			3. Input impendence performance
*			4. Harmonic order when 2 PSUs in parallel
****************************************************************************/
static void Dynamic_Current_PIGain(void)
{
	u32_t u32CurrKP;
	u32_t u32CurrKI;

#ifdef Enable20AHallSensor
	
	u32CurrKP = (u32_t)__fsat((i32_t)tsPFC.sCURR_PI.u32KP_H - (tsPFC.sVOLT_PI.i32PIout >> 1), tsPFC.sCURR_PI.u32KP_H, tsPFC.sCURR_PI.u32KP_L);
	u32CurrKI = (u32_t)__fsat((i32_t)tsPFC.sCURR_PI.u32KITS_H - (tsPFC.sVOLT_PI.i32PIout >> 1), tsPFC.sCURR_PI.u32KITS_H, tsPFC.sCURR_PI.u32KITS_L);

#else

	//u32CurrKP = (u32_t)__fsat(((i32_t)tsPFC.sCURR_PI.u32KP_H - tsPFC.sVOLT_PI.i32PIout), tsPFC.sCURR_PI.u32KP_H, tsPFC.sCURR_PI.u32KP_L);
	//u32CurrKI = (u32_t)__fsat(((i32_t)tsPFC.sCURR_PI.u32KITS_L + tsPFC.sVOLT_PI.i32PIout), tsPFC.sCURR_PI.u32KITS_H, tsPFC.sCURR_PI.u32KITS_L);

	u32CurrKP = tsPFC.sCURR_PI.u32KP_H;			// For PI debug
	u32CurrKI = tsPFC.sCURR_PI.u32KITS_L;			// For PI debug

	// With Hysteresis
	if ((CheckApplyInput()) &&
        (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_AC) &&
        (tsPFC.sPFCRara.u16VinRMS > 1950) &&
        (tsPFC.sPFCRara.u16VinRMS < 2830) &&
        (tsATS.ptApply->ptMoniAC->u16Harmonic_WF > 270) &&
        (tsATS.ptApply->ptMoniAC->u16Harmonic_WF < 550) &&
        (tsPFC.sVOLT_PI.i32PIout > 14000))
    {
        // VTHD : 2.7% ~ 5.5%
        tsPFC.sConPara.u32DynamicKPKILevel = 95;
        u32CurrKP = 51000;
        u32CurrKI = 120000;
        tsPFC.sConfigPara.u32Duty_feedward_shift = 1500;
        tsPFC.sConfigPara.f32Duty_feedward_Gain = 1;
    }
    else if (tsPFC.sVOLT_PI.i32PIout > PI_V_Out_110_H)
    {
		// > 110%load
        tsPFC.sConPara.u32DynamicKPKILevel = 110;
        u32CurrKP = PI_I_KP_100;
        u32CurrKI = PI_I_KI_100;
        tsPFC.sConfigPara.u32Duty_feedward_shift = PI_DFFS_100;
        tsPFC.sConfigPara.f32Duty_feedward_Gain = 1;
    }
    else if (tsPFC.sVOLT_PI.i32PIout > PI_V_Out_85)
    {
        if ((tsPFC.sVOLT_PI.i32PIout > PI_V_Out_110_L) &&
            (tsPFC.sConPara.u32DynamicKPKILevel >= 110))
        {
            // For overload hysteresis
            tsPFC.sConPara.u32DynamicKPKILevel = 110;
            u32CurrKP = 30000;
            u32CurrKI = 80000;
            tsPFC.sConfigPara.u32Duty_feedward_shift = PI_DFFS_100;
            tsPFC.sConfigPara.f32Duty_feedward_Gain = 1;
        }
        else
        {
            // 90%load ~ 100%load , Shelf Level:>=90%load
            /* 20240513 change dbg */
            tsPFC.sConPara.u32DynamicKPKILevel = 90;
            u32CurrKP = 33000;
            u32CurrKI = 100000;
            tsPFC.sConfigPara.u32Duty_feedward_shift = 1600;
            tsPFC.sConfigPara.f32Duty_feedward_Gain = 0.94;
        }
    }
    else if (tsPFC.sVOLT_PI.i32PIout > PI_V_Out_35)
    {
        if ((tsPFC.sVOLT_PI.i32PIout > PI_V_Out_83) &&
            (tsPFC.sConPara.u32DynamicKPKILevel >= 90))
        {
            // For full load hysteresis
            /* 20240513 change dbg */
            tsPFC.sConPara.u32DynamicKPKILevel = 90;
            u32CurrKP = 33000;
            u32CurrKI = 100000;
            tsPFC.sConfigPara.u32Duty_feedward_shift = 1600;
            tsPFC.sConfigPara.f32Duty_feedward_Gain = 0.94;
        }
        else
        {
        	// 30%load ~ 80%load
            tsPFC.sConPara.u32DynamicKPKILevel = 50;
            u32CurrKP = 35000;
            u32CurrKI = 80000;
            tsPFC.sConfigPara.u32Duty_feedward_shift = 1500; // PI_DFFS_30
            tsPFC.sConfigPara.f32Duty_feedward_Gain = 1;
        }
    }
    else
    {
        if ((tsPFC.sVOLT_PI.i32PIout > PI_V_Out_25) &&
            (tsPFC.sConPara.u32DynamicKPKILevel >= 50))
        {
            tsPFC.sConPara.u32DynamicKPKILevel = 50; // For Harmonic : Only Duty feed 1500
            u32CurrKP = 35000;
            u32CurrKI = 80000;
            tsPFC.sConfigPara.u32Duty_feedward_shift = 1500; // PI_DFFS_30
            tsPFC.sConfigPara.f32Duty_feedward_Gain = 1;
        }
        else
        {
 			// 0%load ~ 25%load
 			// Vac < 235Vac
		  	tsPFC.sConPara.u32DynamicKPKILevel = 20;
            u32CurrKP = 40000;
            u32CurrKI = 120000;
            tsPFC.sConfigPara.u32Duty_feedward_shift = 1000;
            tsPFC.sConfigPara.f32Duty_feedward_Gain = 1.02;

			// For Improve iTHD
			if ((tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_AC) &&
            	(tsPFC.sPFCRara.u16VinRMS >= 2550) &&
            	(tsPFC.sPFCRara.u16VinRMS <= 2950))
        	{
			    if (tsPFC.sVOLT_PI.i32PIout > 1900)
			    {
	                // 235ac < Vac< 295ac
	                tsPFC.sConPara.u32DynamicKPKILevel = 25;
	                u32CurrKP = 40000;
	                u32CurrKI = 130000;
	                tsPFC.sConfigPara.u32Duty_feedward_shift = 1300;
	                tsPFC.sConfigPara.f32Duty_feedward_Gain = 1.02;
			    }
			    else
			    {
			        // For 5%load harmonic solution , 20250122 Added
	                tsPFC.sConPara.u32DynamicKPKILevel = 5;
	                u32CurrKP = 60000;
	                u32CurrKI = 30000;
	                tsPFC.sConfigPara.u32Duty_feedward_shift = 1000;
	                tsPFC.sConfigPara.f32Duty_feedward_Gain = 1;
			    }
        	}
			else if ((tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_AC) &&
            	 	 (tsPFC.sPFCRara.u16VinRMS > 2950))
			{
				// Vac > 295
				tsPFC.sConPara.u32DynamicKPKILevel = 30;
            	u32CurrKP = PI_I_KP_10; // 30000 improve 305 iTHD , PI_I_KP_10
            	u32CurrKI = PI_I_KI_10; // 60000 , PI_I_KI_10
            	tsPFC.sConfigPara.u32Duty_feedward_shift = PI_DFFS_10; // 1500 , PI_DFFS_10
            	tsPFC.sConfigPara.f32Duty_feedward_Gain = 1; // 0.92 , 1
			}
        }
    }

#endif

	// if PFC at light load condition, using single PFC
	if (tsPFC.nSFlag.u16Bits.u1SinglePFC)
	{
		// ADToDo: special KP KI value for single PFC
		tsPFC.sCURR_PI.u32KP = u32CurrKP;
		tsPFC.sCURR2_PI.u32KP = u32CurrKP;
		tsPFC.sCURR_PI.u32KITS = u32CurrKI;
		tsPFC.sCURR2_PI.u32KITS = u32CurrKI;
	}
	else
	{
		tsPFC.sCURR_PI.u32KP = u32CurrKP;
		tsPFC.sCURR2_PI.u32KP = u32CurrKP;
		tsPFC.sCURR_PI.u32KITS = u32CurrKI;
		tsPFC.sCURR2_PI.u32KITS = u32CurrKI;
	}
}

/****************************************************************************
*   Brief   Pull up 3.3V if Vbulk voltage > 470V
*   Note    1. Used without filter Vbulk sense
*           2. If Vbulk voltage > 470V then pull up 3.3V to notify D2D
****************************************************************************/
static void DET_ITIC_Vbulk(void)
{
    if (GET_MOMIAC_VAC1_ITIC || GET_MOMIAC_VAC1_ITIC || (tsPFC.sPFCRara.u16Vbulk_DET_NOF_Q15 > tsPFC.sConfigPara.u16VBulk_470V_Q15))
    {
        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, 65535); // Pull up 3.3V
    }
}

/****************************************************************************
*	Brief	Get Vbulk voltage reference
*	Note	Input is current original Vref, return is Vbulk ref (Q15 type)
*			Vref = V*kv+I*ki
****************************************************************************/
static u16_t Get_VBulk_Vref_Q15(u16_t CurrentVref)
{
	u16_t u16Vref = CurrentVref;
	u16_t u16Vinpeak_Q15 = (*tsPFC.sPFCRara.pu16Vin_nnn_Q12) << 3;	// instant Vpfc peak value
	u16_t u16Vinpeak_busscale_Q15 = (u16_t)((f32_t)u16Vinpeak_Q15 * tsPFC.sConfigPara.f32PFC_to_BUS);
	u16_t u16Vinpeak_Add5V_Q15 = u16Vinpeak_busscale_Q15 + tsPFC.sConfigPara.u16VBulk_5V_Q15;
	u16_t u16SelectPower;

	/* Select Power to adjudge VBulk */
#ifdef WithD2D
	u16SelectPower = GET_LOG_D2DMAXPOWER; // With D2D
#else
	u16SelectPower = GET_LOG_POWER;       // Only PFC
#endif
		
	if (u16Vinpeak_Add5V_Q15 > u16Vref) //dbg
	{
		u16Vref = (u16_t)__fsat(u16Vinpeak_Add5V_Q15, tsPFC.sConfigPara.u16VBulkRef_Limit_MAX_Q15, tsPFC.sConfigPara.u16VBulkRef_Limit_MIN_Q15);

		if (tsPFC.eState == PFC_State_Operating)
		{
			// change Vref immediately when Vpeak > Vref
			tsPFC.sVOLT_PI.i32Ref = (i32_t)u16Vref;
			tsPFC.sConPara.u16VrefLoadLevel = 5;
		}
	}
	else
	{
		tsPFC.sPFCRara.u16VinRMS = GET_MOMIAC_VPFC_REALRMS;

#ifdef EnableDynamicVbulk

		// normal operating abjust Vref min limtit by output power
		// min limit base on worst case hold up time
		// Vacpeak + 20V
		// Vref range : 420V~450V
		// 420 + (4200 - 2800) * 0.0238 = 453.32V

		f32_t f32Vref;		// unit is Vbulk Q15
		u16_t u16VrefBuff;
		f32_t f32VinTemp;
		u16_t u16VBulkRef_Min_Limit_Q15 = tsPFC.sConfigPara.u16VBulkRef_Limit_MIN_Q15;

		if (tsPFC.eState == PFC_State_Operating)
		{
			if (GET_LOG_D2DMAXPOWER > Pin_66Load)
			{
				u16VrefBuff = tsPFC.sConfigPara.u16VBulkRef_Limit_MIN_Q15 + (u16_t)(((f32_t)(GET_LOG_D2DMAXPOWER - Pin_66Load)) * tsPFC.sConfigPara.f32DynamicBulkPG);
				u16VBulkRef_Min_Limit_Q15 = __fsat(u16VrefBuff, (tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15 - 1), tsPFC.sConfigPara.u16VBulkRef_Limit_MIN_Q15);
			}
		}

		// softstart only abjust Vref by input volage
		if (GET_LOG_VAC_WOF > (GET_LOG_VAC + 50))	//+5V
		{
			// Vin update immediately when Vin rise rapidly
			f32VinTemp = (f32_t)GET_LOG_VAC_WOF;
		}
		else
		{
			// unit is 0.1V
			f32VinTemp = (f32_t)GET_LOG_VAC;
		}
	
		if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_DC)
		{
			// Vref = Vdc + 20V
			f32Vref = (f32VinTemp * tsPFC.sConfigPara.f32DynamicBulkVG_DC) + (f32_t)tsPFC.sConfigPara.u16VBulk_20V_Q15;
		}
		else
		{
			// Vref = Vpeak + 20V
			f32Vref = (f32VinTemp * tsPFC.sConfigPara.f32DynamicBulkVG) + (f32_t)tsPFC.sConfigPara.u16VBulk_20V_Q15;
		}

		u16Vref = (u16_t)__fsat(f32Vref, tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15, u16VBulkRef_Min_Limit_Q15);
	
#else

		if (tsPFC.sPFCRara.u16VinRMS < VacLevel_L)
		{
			tsPFC.sConPara.u16VrefVinLevel = 1;
		}
		else if (tsPFC.sPFCRara.u16VinRMS > VacLevel_H)
		{
			tsPFC.sConPara.u16VrefVinLevel = 2;
		}

		if (GET_D2P_DYNAMIC)
		{
		    // For D2D dynamic load used
            u16Vref = tsPFC.sConfigPara.u16VBulkRef_438V_Q15;
            tsPFC.sConPara.u16VrefLoadLevel = 3;
            PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk442Level);
		}
		else if (tsPFC.sConPara.u16VrefVinLevel == 1)
        {
            if (tsPFC.eState == PFC_State_Operating)
            {

                /****************************************************************************
                *   Note   1. VBulk 455V : power > 80%load , back 75%load to 445V
                *          2. VBulk 442V : power > 45%load , back 40%load to 435V
                *          3. VBulk 435V : Default
                ****************************************************************************/
                if (u16SelectPower > Pin_80Load_48V)
                {
                    u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15;
                    tsPFC.sConPara.u16VrefLoadLevel = 4;
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk455Level);
                }
                else if (u16SelectPower > Pin_45Load_48V) //Pin_67Load
                {
                    if ((u16SelectPower > Pin_75Load_48V) &&
                        (tsPFC.sConPara.u16VrefLoadLevel >= 4))
                    {
                        u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15;
                        tsPFC.sConPara.u16VrefLoadLevel = 4;
                        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk455Level);
                    }
                    else
                    {
                        u16Vref = tsPFC.sConfigPara.u16VBulkRef_442V_Q15;
                        tsPFC.sConPara.u16VrefLoadLevel = 3;
                        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk442Level);
                    }
                }
                else if (u16SelectPower > Pin_16Load)
                {
                    if ((u16SelectPower > Pin_40Load_48V) && // Pin_62Load
                        (tsPFC.sConPara.u16VrefLoadLevel >= 3))
                    {
                        u16Vref = tsPFC.sConfigPara.u16VBulkRef_442V_Q15;
                        tsPFC.sConPara.u16VrefLoadLevel = 3;
                        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk442Level);
                    }
                    else
                    {
                        u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_L_Q15;
                        tsPFC.sConPara.u16VrefLoadLevel = 2;
                        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk435Level);
                    }
                }
                else
                {
                    if ((u16SelectPower > Pin_12Load) &&
                        (tsPFC.sConPara.u16VrefLoadLevel >= 2))
                    {
                        u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_L_Q15;
                        tsPFC.sConPara.u16VrefLoadLevel = 2;
                        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk435Level);
                    }
                    else
                    {
                        u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_L_Q15;
                        tsPFC.sConPara.u16VrefLoadLevel = 1;
                        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk435Level);
                    }
                }
            }
            else
            {
                u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_L_Q15;
                tsPFC.sConPara.u16VrefLoadLevel = 2;
                PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk435Level);
            }
        }
        else
        {
            // Vac>290V
            if (tsPFC.eState == PFC_State_Operating)
            {
                if (u16SelectPower > Pin_80Load_48V)
                {
                    u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15;
                    tsPFC.sConPara.u16VrefLoadLevel = 4;
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk455Level);
                }
                else if ((u16SelectPower > Pin_75Load_48V) &&
                         (tsPFC.sConPara.u16VrefLoadLevel >= 4))
                {
                    u16Vref = tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15;
                    tsPFC.sConPara.u16VrefLoadLevel = 4;
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk455Level);
                }
                else
                {
                    u16Vref = tsPFC.sConfigPara.u16VBulkRef_439V_Q15;
                    tsPFC.sConPara.u16VrefLoadLevel = 3;
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk435Level);
                }
            }
            else
            {
                u16Vref = tsPFC.sConfigPara.u16VBulkRef_442V_Q15;
                tsPFC.sConPara.u16VrefLoadLevel = 3;
                PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk435Level);
            }
        }
#endif 

#ifdef WithD2D
		if (GET_LOG_D2D_OK == 0)
		{
			u16Vref = tsPFC.sConfigPara.u16VBulkRef_442V_Q15;
			tsPFC.sConPara.u16VrefLoadLevel = 2;
			tsPFC.sConPara.u16VrefVinLevel = 2;
            PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, VBulk442Level);
		}
#endif

	}

	DET_ITIC_Vbulk();
	return u16Vref;
}

/****************************************************************************
*	Brief	X-cap compensation
*	Note	X-cap compensations i=2 pi f vp C cos, spend time is 5us
****************************************************************************/

static inline void Xcap_compensation(void)
{
#ifdef EnableXcapCompensate

	f32_t 	f32Rad = 0;
	f32_t	f32Phase = 0;
	f32_t 	dValue = 0;	//Q15

	if (tsPFC.nSFlag.u16Bits.u1Vin_Polarity)
	{
		f32Phase = (f32_t)GET_MOMIAC_VPFC_PHASE;
	}
	else
	{
		f32Phase = (f32_t)(GET_MOMIAC_VPFC_PHASE + GET_MOMIAC_VPFC_HALFPERIOD);
	}
	
	f32Rad = (PIx2_*(f32_t)tsPFC.sPFCRara.u16VinFreq * f32Phase) / 100000;	//10kHz,Freq is 0.1Hz
	dValue = (tsPFC.sConfigPara.f32XcapCompensate * ((f32_t)tsPFC.sPFCRara.u16VinFreq) * ((f32_t)tsPFC.sPFCRara.u16Vinpeak_Q15) * cos(f32Rad)) / ((f32_t)10000000); //uF,Freq is 0.1Hz
	tsPFC.sConPara.i32IXcapCompensate = (i32_t)dValue;

#endif 
}


/****************************************************************************
*	Brief	PI controller
*	Note	1. return i32PIout(Q16 type)
*	        2. In current loop(40KHz)
****************************************************************************/
static void PI_CONTROLLER(sPI_Parameter_t* tsPI, i32_t i32Duty_feed)
{
	i32_t PI_OUT = 0;
	i32_t BUF = 0;
	i32_t Integral = 0;

	//tsPI->i32Error = 0;

	//Q15
	BUF = (tsPI->i32Error + tsPI->i32ErrorPre) >> 1;

	//(q20*q15)/q5=Q30
    tsPI->i32Integral = (((i32_t)tsPI->u32KITS * BUF) >> 5) + tsPI->i32IntegralPre;
	
	//Integral limit:-Q30~Q30-1.
	tsPI->i32Integral = (i32_t)__fsat((f32_t)tsPI->i32Integral, tsPI->f32Integral_Poslimit, tsPI->f32Integral_Neglimit);

	//update previously data
    tsPI->i32IntegralPre = tsPI->i32Integral;
	tsPI->i32ErrorPre = tsPI->i32Error;

	//Integral with gain
	Integral = ((tsPI->i32Integral >> 14) * tsPI->i32IntegralGain) >> 12;

	//q15*q15>>14=q16
	if (tsPI->i32Ref == 0)
	{
		// for no load solution
   		PI_OUT = (i32_t)(((i32_t)tsPI->u32KP * tsPI->i32Error) >>14) + Integral;  
	}
	else
	{		
    	PI_OUT = (i32_t)(((i32_t)tsPI->u32KP * tsPI->i32Error) >>14) + Integral + i32Duty_feed;  
	}
	
	tsPI->i32PIout = (i32_t)(__fsat((f32_t)PI_OUT, tsPI->f32PIout_Poslimit, tsPI->f32PIout_Neglimit));
}


/****************************************************************************
*	Brief	PFC voltage control Reset
*	Note	at 10KHz Timer0 interrupt
****************************************************************************/
static inline void PFC_Voltage_Loop_Reset(void)
{
	if (tsPFC.ePreVoltState != tsPFC.eVoltState)
	{
		tsPFC.ePreVoltState = tsPFC.eVoltState;
		tsPFC.sVOLT_PI.i32ErrorPre = 0;
		tsPFC.sVOLT_PI.i32IntegralPre = 0;
	}
}

/****************************************************************************
*	Brief	PFC voltage control operating
*	Note	at 10KHz Timer0 interrupt
****************************************************************************/
static inline void PFC_Voltage_Loop_Operating(void)
{
	u32_t u32ErrorTempabs;
	
	if (tsPFC.eState == PFC_State_Operating)
	{
		// Monitor Input voltage to adjust Vbulk reference
		tsPFC.sPFCRara.u16Vbulk_Target_Q15 = (i32_t)(Get_VBulk_Vref_Q15((u16_t)tsPFC.sVOLT_PI.i32Ref));
		
		tsPFC.sVOLT_PI.i32Error = tsPFC.sVOLT_PI.i32Ref - (i32_t)tsPFC.sPFCRara.u16Vbulk_DET_Q15;

		// limit Error when Vbulk_DET feedback circuit fault happen
		if (tsPFC.sPFCRara.u16Vbulk_DET_Q15 < tsPFC.sConfigPara.u16VBulkshort_Limit_L_Q15)
		{
			tsPFC.sVOLT_PI.i32Error = tsPFC.sConfigPara.u16VBulk_20V_Q15;
		}
		
		u32ErrorTempabs = labs(tsPFC.sVOLT_PI.i32Error);

		//for overshoot protection
		if ((u32ErrorTempabs > tsPFC.sConfigPara.u16VBulk_35V_Q15) &&
			(tsPFC.sVOLT_PI.i32Error < 0))
		{
			tsPFC.sVOLT_PI.i32IntegralPre = 0;
		}

		// Select Voltage PI Gain , Note : When first Verror>20V
		if ((u32ErrorTempabs > tsPFC.sVOLT_PI.u16AdjustGain_H) &&
			(tsPFC.nSFlag.u16Bits.u1VoltagePIFast == FALSE))
		{
			// Error > 20V
			tsPFC.sVOLT_PI.u32KP = tsPFC.sVOLT_PI.u32KP_H;     // P 32768*3 * 1.7
			tsPFC.sVOLT_PI.u32KITS = tsPFC.sVOLT_PI.u32KITS_H; // I 10485   * 0.7
			tsPFC.nSFlag.u16Bits.u1VoltagePIFast = TRUE;
		}
		else if ((u32ErrorTempabs < tsPFC.sVOLT_PI.u16AdjustGain_L) &&
				 (tsPFC.nSFlag.u16Bits.u1VoltagePIFast == TRUE))
		{
			// Error < 15V
			tsPFC.sVOLT_PI.u32KP = tsPFC.sVOLT_PI.u32KP_L;     // KP_L = 32678
			tsPFC.sVOLT_PI.u32KITS = tsPFC.sVOLT_PI.u32KITS_L; // 157286
			tsPFC.nSFlag.u16Bits.u1VoltagePIFast = FALSE;
		}

		// Voltage KP adjust
		if (tsPFC.nSFlag.u16Bits.u1VoltagePIFast == FALSE)
		{
			tsPFC.sVOLT_PI.u32KP = tsPFC.sVOLT_PI.u32KP_L + (u32ErrorTempabs << 6);
		}
	
		// DC input mode
		if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status != MoniAC_InputStatus_AC)
		{
			// DC mode Voltage control every 1kHz
			if (tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_1K == TRUE)
			{
				tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_1K = FALSE;
				PI_CONTROLLER(&tsPFC.sVOLT_PI, 0);
				Dynamic_Current_PIGain();
			}
		}
		// AC input mode
		else
		{
			// Fast Voltage control every 10kHz	
			if (tsPFC.nSFlag.u16Bits.u1VoltagePIFast == TRUE)
			{			
				PI_CONTROLLER(&tsPFC.sVOLT_PI, 0);
				Dynamic_Current_PIGain();
			}
			// Slow Voltage control every half ac cycle
			else if (tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_AC == TRUE)
			{
				PI_CONTROLLER(&tsPFC.sVOLT_PI, 0);
				Dynamic_Current_PIGain();
			}

			tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_AC = FALSE;
			
			Xcap_compensation();
		}
	}
	else if (tsPFC.eState == PFC_State_Softstart)
	{
		tsPFC.sVOLT_PI.i32Error = tsPFC.sVOLT_PI.i32Ref - (i32_t)tsPFC.sPFCRara.u16Vbulk_DET_Q15;
		PI_CONTROLLER(&tsPFC.sVOLT_PI, 0);
	}
	else if (tsPFC.eState == PFC_State_Vbulk_SlewRate)
	{
        tsPFC.sVOLT_PI.i32Error = tsPFC.sVOLT_PI.i32Ref - (i32_t)tsPFC.sPFCRara.u16Vbulk_DET_Q15;
        u32ErrorTempabs = labs(tsPFC.sVOLT_PI.i32Error);

        if ((u32ErrorTempabs > tsPFC.sVOLT_PI.u16AdjustGain_H) &&
            (tsPFC.nSFlag.u16Bits.u1VoltagePIFast == FALSE))
        {
            // Error > 20V
            tsPFC.sVOLT_PI.u32KP = tsPFC.sVOLT_PI.u32KP_H; //* 1.5;
            tsPFC.sVOLT_PI.u32KITS = tsPFC.sVOLT_PI.u32KITS_H; //* 0.6;
            tsPFC.nSFlag.u16Bits.u1VoltagePIFast = TRUE;
        }
        else if ((u32ErrorTempabs < tsPFC.sVOLT_PI.u16AdjustGain_L) &&
                 (tsPFC.nSFlag.u16Bits.u1VoltagePIFast == TRUE))
        {
            // Error < 15V
            tsPFC.sVOLT_PI.u32KP = tsPFC.sVOLT_PI.u32KP_L + (u32ErrorTempabs << 6);
            tsPFC.sVOLT_PI.u32KITS = tsPFC.sVOLT_PI.u32KITS_L;
            tsPFC.nSFlag.u16Bits.u1VoltagePIFast = FALSE;
        }

        // Fast Voltage control every 10kHz
        if (tsPFC.nSFlag.u16Bits.u1VoltagePIFast == TRUE)
        {
            PI_CONTROLLER(&tsPFC.sVOLT_PI, 0);
            Dynamic_Current_PIGain();
        }
        // Slow Voltage control every half ac cycle
        else if (tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_AC == TRUE)
        {
            PI_CONTROLLER(&tsPFC.sVOLT_PI, 0);
            Dynamic_Current_PIGain();
        }

        tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_AC = FALSE;
	}

	if (tsPFC.ePreVoltState != tsPFC.eVoltState)
	{
		tsPFC.ePreVoltState = tsPFC.eVoltState;
		tsPFC.eCurrState = PFC_CURR_State_Operating;
	}
}

/****************************************************************************
*	Brief	PFC Current control Reset
*	Note	
****************************************************************************/
static inline void PFC_Current_Loop_Reset(void)
{
	if (tsPFC.ePreCurrState != tsPFC.eCurrState)
	{
		PeriEPwm_PFC_Disable();
		tsPFC.ePreCurrState = tsPFC.eCurrState;
		tsPFC.sCURR_PI.i32ErrorPre = 0;
		tsPFC.sCURR_PI.i32IntegralPre = 0;
		tsPFC.sCURR2_PI.i32ErrorPre = 0;
		tsPFC.sCURR2_PI.i32IntegralPre = 0;
		tsPFC.nSFlag.u16Bits.u1SinglePFC = 0;
		tsPFC.sConPara.i32IXcapCompensate = 0;
	}

	// clear CBC protect flag
	if (tsPFC.nPFlag.u16Bits.u1PFC_phase_A_CBC)
	{
		tsPFC.nPFlag.u16Bits.u1PFC_phase_A_CBC = 0;
		PeriPWM_PFC_A_CBC_Clear();
	}
	
	if (tsPFC.nPFlag.u16Bits.u1PFC_phase_B_CBC)
	{
		tsPFC.nPFlag.u16Bits.u1PFC_phase_B_CBC = 0;
		PeriPWM_PFC_B_CBC_Clear();
	}
}

/****************************************************************************
*   Brief   PFC Variable frequency control
*   Note    For High frequency
****************************************************************************/
static inline void PFC_Variable_Frequency_High(void)
{
    EPwm7Regs.TBPRD = tsPFC.sConfigPara.u16HighFreq;
    EPwm8Regs.TBPRD = tsPFC.sConfigPara.u16HighFreq;
    PWM_Period[ePeriEPwm_Tag_PFC_A] = tsPFC.sConfigPara.u16HighFreq;
    PWM_Period[ePeriEPwm_Tag_PFC_B] = tsPFC.sConfigPara.u16HighFreq;
    EPwm7Regs.DBRED.bit.DBRED = PWM_DeadBand_240;       // 240ns = 24*0.01us, RED = DBRED*TBCLK
    EPwm7Regs.DBFED.bit.DBFED = PWM_DeadBand_240;
    EPwm8Regs.DBRED.bit.DBRED = PWM_DeadBand_240;
    EPwm8Regs.DBFED.bit.DBFED = PWM_DeadBand_240;
}

/****************************************************************************
*   Brief   PFC Variable frequency control
*   Note    For Low frequency
****************************************************************************/
static inline void PFC_Variable_Frequency_Low(void)
{
//    if (tsPFC.sConfigPara.u16LowFreq == EPWM_39KHz)
//    {
//        tsPFC.sConfigPara.u16LowFreq = EPWM_41KHz;
//    }
//    else
//    {
//        tsPFC.sConfigPara.u16LowFreq = EPWM_39KHz;
//    }

    EPwm7Regs.TBPRD = tsPFC.sConfigPara.u16LowFreq;
    EPwm8Regs.TBPRD = tsPFC.sConfigPara.u16LowFreq;
    PWM_Period[ePeriEPwm_Tag_PFC_A] = tsPFC.sConfigPara.u16LowFreq;
    PWM_Period[ePeriEPwm_Tag_PFC_B] = tsPFC.sConfigPara.u16LowFreq;
    EPwm7Regs.DBRED.bit.DBRED = PWM_DeadBand_300;       // 300ns = 30*0.01us, RED = DBRED*TBCLK
    EPwm7Regs.DBFED.bit.DBFED = PWM_DeadBand_300;
    EPwm8Regs.DBRED.bit.DBRED = PWM_DeadBand_300;
    EPwm8Regs.DBFED.bit.DBFED = PWM_DeadBand_300;
}

/****************************************************************************
*   Brief   PFC Variable frequency control
*   Note   1. 50KHz : power > 350W  ,  back 250W to 40KHz
*          2. 40KHz : power > 1000W ,  back 850W to 50KHz
****************************************************************************/
static inline void PFC_Variable_Frequency_Control(void)
{
    if (tsPFC.eState == PFC_State_Operating)
    {
        if (GET_LOG_POWER > 1000)
        {
            PFC_Variable_Frequency_Low();
            tsPFC.sConPara.u16FrequencyLevel = 0;
        }
        else if ((GET_LOG_POWER > 850) &&
                (tsPFC.sConPara.u16FrequencyLevel == 0))
        {
            PFC_Variable_Frequency_Low();
            tsPFC.sConPara.u16FrequencyLevel = 0;
        }
        else if (GET_LOG_POWER >= 350)
        {
            PFC_Variable_Frequency_High();
            tsPFC.sConPara.u16FrequencyLevel = 1;
        }
        else
        {
            if ((GET_LOG_POWER > 250) &&
               (tsPFC.sConPara.u16FrequencyLevel == 1))
            {
                PFC_Variable_Frequency_High();
                tsPFC.sConPara.u16FrequencyLevel = 1;
            }
            else
            {
                PFC_Variable_Frequency_Low();
                tsPFC.sConPara.u16FrequencyLevel = 0;
            }
        }
    }
}

/****************************************************************************
*   Brief   Single phase inductor OCP
****************************************************************************/
static inline void PFC_SinglePhase_OCP(void)
{
    if (((*tsPFC.sPFCRara.pu16IinA_nnn_Q12 << 3) > tsPFC.sConfigPara.u32Iac_Sense_OCP) ||
        ((*tsPFC.sPFCRara.pu16IinB_nnn_Q12 << 3) > tsPFC.sConfigPara.u32Iac_Sense_OCP))
    {
        tsPFC.nPFlag.u16Bits.u1SinglePhase_OCP = TRUE;
    }
}

/****************************************************************************
*	Brief	PFC Current control operating
*
*	Note	1. AVG current control
*	        2. In Positive SoftStart will disable PWM7A(PWM8A) and PWM7B(PWM8B) output 50% duty ,
*	           In Negative SoftStart will disable PWM7B(PWM8B) and PWM7A(PWM8A) output 50% duty
*	        3. DeadZone will disable all PWM
*	        4. SoftStart pattern is 50% duty
*	        5. PWM trigger ADC EOC(End of conversion) interrupt at 40KHz
*	        6. Gate_A is PWM7A(pin51), Gate_B is PWM7B(pin50), Gate_C is PWM8A(pin96), Gate_C is PWM8B(pin95)
****************************************************************************/
static inline void PFC_Current_Loop_Operating(void)
{
	u16_t u16PFC_Vac_mwave_Q15;			// Vac m Wave Q15 type
	i16_t i16PFC_Vac_swave_Q15;			// Vac sin Wave Q15 type
	f32_t f32Vac_busFS_Q31;				// Vac m Wave base on Vbulk HW gain	
	f32_t f32DutyFeedForward_Q16;		// Sin wave compensation
	f32_t f32DutyFeedForward_Gain;		// 
	i32_t i32DutyFeedForward_Q16;		// Sin wave compensation
	u16_t u16Vinpeak_Q15;				// PFC Input Voltage peak value
	f32_t f32VBulk_Q15;					// PFC Bulk-cap Voltage value
	f32_t f32RealInput;					// Standardization Real m Wave 0~1
	i32_t i32Iac_instant_A_Q15;			// PFC chock phase A Instant average current
	i32_t i32Iac_instant_B_Q15;			// PFC chock phase B Instant average current
	u16_t u16Duty_A;					// PFC phase A Current PI out
	u16_t u16Duty_B;					// PFC phase B Current PI out

	u16PFC_Vac_mwave_Q15 = (*tsPFC.sPFCRara.pu16Vin_nnn_Q12) << 3;				//Q15 m wave volatage
	i16PFC_Vac_swave_Q15 = (*tsPFC.sPFCRara.pi16Vin_sin_Q12) << 3;				//Q15 sin wave volatage
	i32Iac_instant_A_Q15 = ((i32_t)(*tsPFC.sPFCRara.pu16IinA_nnn_Q12)) << 3;	//Q15 phase A m wave current
	i32Iac_instant_B_Q15 = ((i32_t)(*tsPFC.sPFCRara.pu16IinB_nnn_Q12)) << 3;	//Q15 phase B m wave current
	f32VBulk_Q15 = (f32_t)tsPFC.sVOLT_PI.i32Ref;								//Q15 Vbulk target value

	if (tsPFC.ePreCurrState != tsPFC.eCurrState)
	{
		tsPFC.nSFlag.u16Bits.u2PFC_Polarity = ePFC_Polarity_DeadZone;
		tsPFC.ePreCurrState = tsPFC.eCurrState;
	}

	// Disable PWM if ITIC occur, turn on PWM at next zero cross
    if (GET_MOMIAC_VAC1_ITIC || GET_MOMIAC_VAC2_ITIC)
    {
        tsPFC.sCURR_PI.i32IntegralGain = 0;
        tsPFC.sCURR2_PI.i32IntegralGain = 0;
        PeriEPwm_PFC_Disable();
        return;
    }

	//
	// Step 0: clear PI control while trigger CBC protection
	//
	if (tsPFC.nPFlag.u16Bits.u1PFC_phase_A_CBC)
	{
		tsPFC.sConPara.u16SoftStartIref = 0;
		tsPFC.sCURR_PI.i32ErrorPre = 0;
		tsPFC.sCURR_PI.i32IntegralPre = 0;
		tsPFC.nPFlag.u16Bits.u1PFC_phase_A_CBC = 0;
		PeriPWM_PFC_A_CBC_Clear();
	}
	
	if (tsPFC.nPFlag.u16Bits.u1PFC_phase_B_CBC)
	{
		tsPFC.sConPara.u16SoftStartIref = 0;
		tsPFC.sCURR2_PI.i32ErrorPre = 0;
		tsPFC.sCURR2_PI.i32IntegralPre = 0;
		tsPFC.nPFlag.u16Bits.u1PFC_phase_B_CBC = 0;
		PeriPWM_PFC_B_CBC_Clear();
	}
	
	//
	// Step 1: Get Vin peak value and V bulk-cap value
	//
	// DC input mode
	if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_DC)
	{
		f32DutyFeedForward_Gain = 1;
		u16Vinpeak_Q15 = u16PFC_Vac_mwave_Q15;	
	}
	// AC input mode
	else
	{
		f32DutyFeedForward_Gain = tsPFC.sConfigPara.f32Duty_feedward_Gain;
		u16Vinpeak_Q15 = tsPFC.sPFCRara.u16Vinpeak_Q15;
	}

	//
	// Step 2 : Get DutyFeedforward.
	//
	// Larger DutyFeedForward can make the peak current fall forward
	// Smaller DutyFeedForward can make the peak current fall backward
	// Low line dutyfeed small, high line dutyfeed large	
	f32Vac_busFS_Q31 = (f32_t)(((u32_t)u16PFC_Vac_mwave_Q15) << 16) * tsPFC.sConfigPara.f32PFC_to_BUS + 0.5;		//Q31=Q15*Q16 turn to Vbulk scale
	f32DutyFeedForward_Q16 = (f32Vac_busFS_Q31 * f32DutyFeedForward_Gain) / f32VBulk_Q15;			//Q16 = Q31/Q15, standardization base on Vbulk


	//
	//Step 3 : Get Real input voltage value
	//
	//Find Vac peak -> limit -> Standardization
	if (u16PFC_Vac_mwave_Q15 > (u16Vinpeak_Q15 + tsPFC.sConfigPara.u16Vacpeak_10V_THRESHOLD_Q15))
	{
		u16Vinpeak_Q15 = u16PFC_Vac_mwave_Q15;	// instant update	
	}
	
	u16Vinpeak_Q15 = __fsat(u16Vinpeak_Q15, tsPFC.sConfigPara.u16Vacpeak_THRESHOLD_H_Q15, tsPFC.sConfigPara.u16Vacpeak_THRESHOLD_L_Q15);
	f32RealInput = (f32_t)u16PFC_Vac_mwave_Q15 / (f32_t)u16Vinpeak_Q15;	//standardization base on Vac_pfc_peak

	//
	//Step 4 : Get current loop Ref parameter , Current PI Vref = Voltage PI out x Real input
	//	
	tsPFC.sCURR_PI.i32Ref = (i32_t)((f32_t)tsPFC.sVOLT_PI.i32PIout * f32RealInput); //Q16
	tsPFC.sCURR_PI.i32Ref = (i32_t)(tsPFC.sCURR_PI.i32Ref * tsPFC.sConPara.u16SoftStartIref) >> 12;
	tsPFC.sCURR_PI.i32Ref = __fsat((tsPFC.sCURR_PI.i32Ref >> 1), tsPFC.sConfigPara.i16Iacpeak_Poslimit, tsPFC.sConfigPara.i16Iacpeak_Neglimit); //Q15

	// PFC softstart I ref, 1.6ms
	if (tsPFC.sConPara.u16SoftStartIref >= Q12_)
	{
		tsPFC.sConPara.u16SoftStartIref = Q12_;
	}
	else
	{
		tsPFC.sConPara.u16SoftStartIref += tsPFC.sConPara.u16Const_SoftStartIref;
	}

	// if PFC at light load condition, using single PFC
	if (tsPFC.nSFlag.u16Bits.u1SinglePFC)
	{
		tsPFC.sCURR_PI.i32Ref = tsPFC.sCURR_PI.i32Ref << 1;
		tsPFC.sCURR2_PI.i32Ref = 0;
	}
	else
	{
		tsPFC.sCURR2_PI.i32Ref = tsPFC.sCURR_PI.i32Ref;
	}

	//i16PhaseChange_V_Pos_Q15
	//Step 5 : Totem Pole PFC phase control
	//	
	if (i16PFC_Vac_swave_Q15 > tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Pos_Q15) //i16PhaseChange_V_Pos_Q15
	{
		if (tsPFC.nSFlag.u16Bits.u2PFC_Polarity != ePFC_Polarity_Positive)
		{
			PeriEPwm_PFC_Disable();
			PeriPWM_PFC_Pos_Polarity();
			tsPFC.nSFlag.u16Bits.u2PFC_Polarity = ePFC_Polarity_Positive;
			tsPFC.sConPara.u16SyncRectifierTurnOnDelay = tsPFC.sConPara.u16Const_SyncRectifierTurnOnDelay;
			tsPFC.sConPara.u16PWMEnableCNT = PWM_Enable_COUNT;
			tsPFC.sConPara.u16SoftStart_Duty_Control = 0;
		}
		else
		{
			// integral soft start 3.2ms for ZC current spike
			if (tsPFC.sCURR_PI.i32IntegralGain >= Q12_)
			{
				tsPFC.sCURR_PI.i32IntegralGain = Q12_;
				tsPFC.sCURR2_PI.i32IntegralGain = Q12_;
			}
			else
			{
				tsPFC.sCURR_PI.i32IntegralGain += tsPFC.sCURR_PI.u32Const_IntegralGain; // Q5_
				tsPFC.sCURR2_PI.i32IntegralGain += tsPFC.sCURR_PI.u32Const_IntegralGain;
			}
			
			//
			//Step 6 : Add Xcap compensate in duty feed forward
			//
			if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_AC)
			{

#ifdef EnableXcapCompensate
			
				if (tsPFC.sVOLT_PI.i32PIout < tsPFC.sConfigPara.i32Xcap_Currentadjust)
				{
					f32DutyFeedForward_Q16 = f32DutyFeedForward_Q16 + (f32_t)tsPFC.sConfigPara.u32Duty_feedward_shift;
				}
				else
				{
					f32DutyFeedForward_Q16 = f32DutyFeedForward_Q16 + (f32_t)tsPFC.sConPara.i32IXcapCompensate;
				}
#else
				f32DutyFeedForward_Q16 = f32DutyFeedForward_Q16 + (f32_t)tsPFC.sConfigPara.u32Duty_feedward_shift;
#endif
			}

			// Duty feedforward limit
			f32DutyFeedForward_Q16 = __fsat(f32DutyFeedForward_Q16, Duty_feedward_Poslimit, Duty_feedward_Neglimit);
			i32DutyFeedForward_Q16 = (i32_t)f32DutyFeedForward_Q16;

			// Duty feed forward invert, big value at zero cross
			i32DutyFeedForward_Q16 = Q16_ - i32DutyFeedForward_Q16;


			//
			//Step 7 : Get current loop PI Error , Current PI Error = Current PI Vref + Ixcap - Iac(Q15)
			//
		
			if ( *tsPFC.sPFCRara.pi16IinA_sin_Q12 < 0)
			{
				tsPFC.sCURR_PI.i32Error = tsPFC.sCURR_PI.i32Ref + i32Iac_instant_A_Q15;	
			}
			else
			{
				tsPFC.sCURR_PI.i32Error = tsPFC.sCURR_PI.i32Ref - i32Iac_instant_A_Q15;
			}
			
			if ( *tsPFC.sPFCRara.pi16IinB_sin_Q12 < 0)
			{
				tsPFC.sCURR2_PI.i32Error = tsPFC.sCURR2_PI.i32Ref + i32Iac_instant_B_Q15;	
			}
			else
			{
				tsPFC.sCURR2_PI.i32Error = tsPFC.sCURR2_PI.i32Ref - i32Iac_instant_B_Q15;
			}


			//
			//Step 8 : Current loop PI Calculation
			//
			PI_CONTROLLER(&tsPFC.sCURR_PI, i32DutyFeedForward_Q16);
			PI_CONTROLLER(&tsPFC.sCURR2_PI, i32DutyFeedForward_Q16);
				
            // After Zero Cross, Totem pole softstart patent
            if (tsPFC.sConPara.u16SyncRectifierTurnOnDelay > 0)
            {
//              PeriPWM_PFC_DB_Enable(); // for enable two arms

//                u16Duty_A = (u16_t)__fsat(((tsPFC.sCURR_PI.i32PIout) / tsPFC.sConPara.u16SyncRectifierTurnOnDelay), PWM_Duty_Poslimit, PWM_Duty_Neglimit);
//                u16Duty_B = (u16_t)__fsat(((tsPFC.sCURR2_PI.i32PIout) / tsPFC.sConPara.u16SyncRectifierTurnOnDelay), PWM_Duty_Poslimit, PWM_Duty_Neglimit);
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, (Q16_-u16Duty_A));
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, (Q16_-u16Duty_B));

                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, Q15_);
                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, Q15_);

//                tsPFC.sConPara.u16SoftStart_Duty_Control += Q14_;
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, tsPFC.sConPara.u16SoftStart_Duty_Control);
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, tsPFC.sConPara.u16SoftStart_Duty_Control);

                tsPFC.sConPara.u16SyncRectifierTurnOnDelay -= 1;

                // Remove softstat when input is dc source
                if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status != MoniAC_InputStatus_AC)
                {
                    tsPFC.sConPara.u16SyncRectifierTurnOnDelay = 0;
                }
            }
            // Totem pole Normal working
            else
            {
                if (i16PFC_Vac_swave_Q15 < tsPFC.sConfigPara.i16PhaseChange_V_Pos_Q15)
                {
                    u16Duty_A = (u16_t)__fsat(tsPFC.sCURR_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    u16Duty_B = (u16_t)__fsat(tsPFC.sCURR2_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, u16Duty_A);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, u16Duty_B);
                }
                else
                {
                    PeriPWM_PFC_DB_Enable();

                    //Step 8 :Limit compensator output, and PI control transfer to PWM module
                    u16Duty_A = (u16_t)__fsat(tsPFC.sCURR_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    u16Duty_B = (u16_t)__fsat(tsPFC.sCURR2_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, u16Duty_A);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, u16Duty_B);
                }
            }

			/* Prevent PWM not enable */
			if (tsPFC.sConPara.u16PWMEnableCNT > 0)
			{
				if (tsPFC.nSFlag.u16Bits.u1SinglePFC)
				{
					PeriEPwm_PFC_PhaseA_Enable();
				}
                else if (tsPFC.sConPara.u16PWMEnableCNT <= 4)
                {
                    PeriEPwm_PFC_Enable();
                }
				tsPFC.sConPara.u16PWMEnableCNT -= 1;
			}
		}		
	}
	else if (i16PFC_Vac_swave_Q15 < tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Neg_Q15)
	{
		if (tsPFC.nSFlag.u16Bits.u2PFC_Polarity != ePFC_Polarity_Negative)
		{
			PeriEPwm_PFC_Disable();
			PeriPWM_PFC_Neg_Polarity();
			tsPFC.nSFlag.u16Bits.u2PFC_Polarity = ePFC_Polarity_Negative;
			tsPFC.sConPara.u16SyncRectifierTurnOnDelay = tsPFC.sConPara.u16Const_SyncRectifierTurnOnDelay;
			tsPFC.sConPara.u16PWMEnableCNT = PWM_Enable_COUNT;
			tsPFC.sConPara.u16SoftStart_Duty_Control = 0;
		}
		else
		{
			// integral soft start 3.2ms for ZC current spike
			if (tsPFC.sCURR_PI.i32IntegralGain >= Q12_)
			{
				tsPFC.sCURR_PI.i32IntegralGain = Q12_;
				tsPFC.sCURR2_PI.i32IntegralGain = Q12_;
			}
			else
			{
				tsPFC.sCURR_PI.i32IntegralGain += tsPFC.sCURR_PI.u32Const_IntegralGain;
				tsPFC.sCURR2_PI.i32IntegralGain += tsPFC.sCURR_PI.u32Const_IntegralGain;
			}

			//
			//Step 6 : Add Xcap compensate in duty feed forward
			//
			if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_AC)
			{

#ifdef EnableXcapCompensate
			
				if (tsPFC.sVOLT_PI.i32PIout < tsPFC.sConfigPara.i32Xcap_Currentadjust)
				{
					f32DutyFeedForward_Q16 = f32DutyFeedForward_Q16 + (f32_t)tsPFC.sConfigPara.u32Duty_feedward_shift;
				}
				else
				{
					f32DutyFeedForward_Q16 = f32DutyFeedForward_Q16 - (f32_t)tsPFC.sConPara.i32IXcapCompensate;
				}
#else
				f32DutyFeedForward_Q16 = f32DutyFeedForward_Q16 + (f32_t)tsPFC.sConfigPara.u32Duty_feedward_shift;
#endif
			}

			// Duty feedforward limit
			f32DutyFeedForward_Q16 = __fsat(f32DutyFeedForward_Q16, Duty_feedward_Poslimit, Duty_feedward_Neglimit);
			i32DutyFeedForward_Q16 = (i32_t)f32DutyFeedForward_Q16;

			// Duty feed forward invert, big value at zero cross
			i32DutyFeedForward_Q16 = Q16_ - i32DutyFeedForward_Q16;


			//
			//Step 7 : Get current loop PI Error , Current PI Error = Current PI Vref + Ixcap - Iac(Q15)
			//
		
			if ( *tsPFC.sPFCRara.pi16IinA_sin_Q12 > 0)
			{
				tsPFC.sCURR_PI.i32Error = tsPFC.sCURR_PI.i32Ref + i32Iac_instant_A_Q15;	
			}
			else
			{
				tsPFC.sCURR_PI.i32Error = tsPFC.sCURR_PI.i32Ref - i32Iac_instant_A_Q15;
			}
			
			if ( *tsPFC.sPFCRara.pi16IinB_sin_Q12 > 0)
			{
				tsPFC.sCURR2_PI.i32Error = tsPFC.sCURR2_PI.i32Ref + i32Iac_instant_B_Q15;	
			}
			else
			{
				tsPFC.sCURR2_PI.i32Error = tsPFC.sCURR2_PI.i32Ref - i32Iac_instant_B_Q15;
			}
		
			//
			//Step 8 : Current loop PI Calculation
			//
			PI_CONTROLLER(&tsPFC.sCURR_PI, i32DutyFeedForward_Q16);
			PI_CONTROLLER(&tsPFC.sCURR2_PI, i32DutyFeedForward_Q16);
			
            // After Zero Cross, Totem pole softstart patent
            if (tsPFC.sConPara.u16SyncRectifierTurnOnDelay > 0)
            {
//              PeriPWM_PFC_DB_Enable(); // for enable two arms

//                u16Duty_A = (u16_t)__fsat(((tsPFC.sCURR_PI.i32PIout) / tsPFC.sConPara.u16SyncRectifierTurnOnDelay), PWM_Duty_Poslimit, PWM_Duty_Neglimit);
//                u16Duty_B = (u16_t)__fsat(((tsPFC.sCURR2_PI.i32PIout) / tsPFC.sConPara.u16SyncRectifierTurnOnDelay), PWM_Duty_Poslimit, PWM_Duty_Neglimit);
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, (u16Duty_A));
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, (u16Duty_B));

                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, Q15_);
                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, Q15_);

//                tsPFC.sConPara.u16SoftStart_Duty_Control += Q14_;
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, tsPFC.sConPara.u16SoftStart_Duty_Control);
//                PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, tsPFC.sConPara.u16SoftStart_Duty_Control);

                tsPFC.sConPara.u16SyncRectifierTurnOnDelay -= 1;

                // Remove softstat when input is dc source
                if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status != MoniAC_InputStatus_AC)
                {
                    tsPFC.sConPara.u16SyncRectifierTurnOnDelay = 0;
                }
            }
            // Totem pole Normal working
            else
            {
                if (i16PFC_Vac_swave_Q15 > tsPFC.sConfigPara.i16PhaseChange_V_Neg_Q15)
                {
                    u16Duty_A = (u16_t)__fsat(tsPFC.sCURR_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    u16Duty_B = (u16_t)__fsat(tsPFC.sCURR2_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, u16Duty_A);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, u16Duty_B);
                }
                else
                {
                    PeriPWM_PFC_DB_Enable();

                    //Step 8 :Limit compensator output, and PI control transfer to PWM module
                    u16Duty_A = (u16_t)__fsat(tsPFC.sCURR_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    u16Duty_B = (u16_t)__fsat(tsPFC.sCURR2_PI.i32PIout, PWM_Duty_Poslimit, PWM_Duty_Neglimit);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_A, u16Duty_A);
                    PeriEPwm_SetDuty(ePeriEPwm_Tag_PFC_B, u16Duty_B);
                }
            }

			/* Prevent PWM not enable */
			if (tsPFC.sConPara.u16PWMEnableCNT > 0)
			{
				if (tsPFC.nSFlag.u16Bits.u1SinglePFC)
				{
					PeriEPwm_PFC_PhaseA_Enable();
				}
                else if (tsPFC.sConPara.u16PWMEnableCNT <= 4)
                {
                    PeriEPwm_PFC_Enable();
                }
				tsPFC.sConPara.u16PWMEnableCNT -= 1;
			}
		}
	}
	else
	{
		if (tsPFC.nSFlag.u16Bits.u2PFC_Polarity != ePFC_Polarity_DeadZone)
		{
			tsPFC.nSFlag.u16Bits.u2PFC_Polarity = ePFC_Polarity_DeadZone;
			PeriEPwm_PFC_Disable();
//			tsPFC.sCURR_PI.i32ErrorPre = 0;
//			tsPFC.sCURR_PI.i32IntegralPre = 0;
//			tsPFC.sCURR2_PI.i32ErrorPre = 0;
//			tsPFC.sCURR2_PI.i32IntegralPre = 0;
			tsPFC.sCURR_PI.i32IntegralGain = 0;
			tsPFC.sCURR2_PI.i32IntegralGain = 0;

#ifdef EnableSinglePFC

			// if PFC at light load condition, using single PFC
			if (tsPFC.sVOLT_PI.i32PIout < tsPFC.sConfigPara.i32Iacpeak_Lightload_L)
			{
				tsPFC.nSFlag.u16Bits.u1SinglePFC = 1;
			}
			else if (tsPFC.sVOLT_PI.i32PIout > tsPFC.sConfigPara.i32Iacpeak_Lightload_H)
			{
				tsPFC.nSFlag.u16Bits.u1SinglePFC = 0;
			}
#endif

#ifdef PFC_Frequency_Conversion
			PFC_Variable_Frequency_Control();
#endif
		}
	}

	// Detect Single Phase OCP
//	PFC_SinglePhase_OCP();

	/* Current Loop parameters */
//	PeriDacA_SetValue(abs(tsPFC.sCURR_PI.i32Ref)>>3);
//	PeriDacB_SetValue(abs(tsPFC.sCURR_PI.i32PIout)>>4);
//	PeriDacB_SetValue(i32Iac_instant_A_Q15>>3);
//	PeriDacB_SetValue(tsPFC.sCURR_PI.i32Integral>>18);
//	PeriDacB_SetValue(*tsPFC.sPFCRara.pu16IinA_nnn_Q12);
//	PeriDacB_SetValue(u16Duty_A >> 4);

	/* Voltage Loop parameters */
//	PeriDacA_SetValue(abs(tsPFC.sVOLT_PI.i32Ref)>>3);
//    PeriDacB_SetValue(abs(tsPFC.sVOLT_PI.i32PIout)>>4);
//	PeriDacB_SetValue(tsPFC.sVOLT_PI.i32PIout>>4);
//	PeriDacB_SetValue((tsPFC.sConPara.i32IXcapCompensate>>4) + Q11_);

}


/****************************************************************************
*	Brief	PFC voltage control loop
*	Note	10kHz, update per zero cross
****************************************************************************/
void PFC_Voltage_Loop_Handler(void)
{
	switch (tsPFC.eVoltState)
	{
		case PFC_VOLT_State_Reset:
			PFC_Voltage_Loop_Reset();
		break;

		case PFC_VOLT_State_Operating:
			PFC_Voltage_Loop_Operating();
		break;
				
		default:
		break;
	}
}

/****************************************************************************
*	Brief	PFC current control loop
*	Note	PWM clock
****************************************************************************/
void PFC_Current_Loop_Handler(void)
{
	switch (tsPFC.eCurrState)
	{
		case PFC_CURR_State_Reset:
			PFC_Current_Loop_Reset();
		break;

		case PFC_CURR_State_Operating:
			PFC_Current_Loop_Operating();	
		break;
				
		default:
		break;
	}
}

/****************************************************************************
*	Brief	Uptate PFC contol parameter
*	Note	In Timer0 10kHz ISR
*	Monitor Input source is DC or AC
****************************************************************************/
static inline void Monitor_PFC_Control_Parameter(void)
{
	tsPFC.nSFlag.u16Bits.u1PFC_Enable = GET_ATS_PFCEnable_FLAG;
	tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status = GET_MOMIAC_VPFC_INPUTSTATUS;
	tsPFC.nPFlag.u16Bits.u1Vbulk_OV = GET_MOMIDC_VBULK_OVP;
	tsPFC.nPFlag.u16Bits.u1Vbulk_UV = GET_MOMIDC_VBULK_UVP;
	tsPFC.nPFlag.u16Bits.u1Inlet_UTP = GET_MOMITP_INLET_UTP;
	tsPFC.nPFlag.u16Bits.u1Inlet_OTP = GET_MOMITP_INLET_OTP;
	tsPFC.nPFlag.u16Bits.u1PFC_UTP = GET_MOMITP_PFC_UTP;
	tsPFC.nPFlag.u16Bits.u1PFC_OTP = GET_MOMITP_PFC_OTP;
	tsPFC.nPFlag.u16Bits.u1ATS_UTP = GET_MOMITP_ATS_UTP;
	tsPFC.nPFlag.u16Bits.u1ATS_OTP = GET_MOMITP_ATS_OTP;
	tsPFC.nPFlag.u16Bits.u1PFC_OCP = GET_MOMIAC_IPFC_OCP;
	tsPFC.sPFCRara.u16Vbulk_DET_Q15 = (*tsPFC.sPFCRara.pu16Vbulk_DET_Q12) << 3;
    tsPFC.sPFCRara.u16Vbulk_DET_NOF_Q15 = (*GET_ADCFilter_DC_VBulk_DET_NOF) << 3;

	// AC only
	if (tsPFC.nSFlag.u16Bits.u1Vin_Polarity != GET_MOMIAC_VPFC_POLARITY)		
	{
		tsPFC.nSFlag.u16Bits.u1Vin_Polarity = GET_MOMIAC_VPFC_POLARITY;

		if (tsPFC.eState >= PFC_State_PTC)
		{
			if (CheckApplyInput())
			{
				if ((tsPFC.eState == PFC_State_Operating) &&
					(tsPFC.nSFlag.u16Bits.u1PFC_Vpeak_Ready == TRUE))
				{			
					tsPFC.sPFCRara.u16Vinpeak_Q15 = (u16_t)(((GET_MOMIAC_VPFC_PEAK * 100) / tsPFC.sConfigPara.f32PFC_FS)*Q15_);
					tsPFC.sPFCRara.u16VinFreq = GET_MOMIAC_VPFC_FREQ_WF / 10;
				}
				else
				{			
					tsPFC.sPFCRara.u16Vinpeak_Q15 = (u16_t)(((GET_APPLY_AC_VPEAK * 100) / tsPFC.sConfigPara.f32PFC_FS)*Q15_);
					tsPFC.sPFCRara.u16VinFreq = GET_APPLY_AC_FREQ / 10;
				}
			}
			else
			{
				tsPFC.sPFCRara.u16Vinpeak_Q15 = (u16_t)(((GET_MOMIAC_VPFC_PEAK * 100) / tsPFC.sConfigPara.f32PFC_FS)*Q15_);
				tsPFC.sPFCRara.u16VinFreq = GET_MOMIAC_VPFC_FREQ_WF / 10;
			}

			tsPFC.sPFCRara.u16Vbulk_DET_ZC_Q15 = tsPFC.sPFCRara.u16Vbulk_DET_Q15;
		}


		if (tsPFC.eVoltState == PFC_VOLT_State_Operating)
		{
            tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_AC = TRUE;
		}		
	}
}

/****************************************************************************
*	Brief	check PFC Bulk OV or UV Fault
*	Note	1. If Bulk UV is true , state will keep goto PTC state
*	        2. at 10KHz Timer0 interrupt
*	        3. Remove OTP because is to allow the PFC to continue working to prevent PTC resistor damage
*	        4. OTP will disable D2D , But ATS and PFC keep working
****************************************************************************/
static inline void Check_PFC_Fault(void)
{
	if ((tsPFC.nPFlag.u16Bits.u1Vbulk_OV == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1Vbulk_UV == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1Inlet_UTP == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1Inlet_OTP == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1PFC_UTP == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1PFC_OTP == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1ATS_UTP == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1ATS_OTP == TRUE) ||
		(tsPFC.nPFlag.u16Bits.u1PFC_OCP == TRUE) ||
//		(tsPFC.nPFlag.u16Bits.u1SinglePhase_OCP == TRUE) ||
		(tsPFC.nPFlag.u16Bits.u1PFC_Relay_Fail == TRUE))
	{
		tsPFC.eState = PFC_State_Off;
	}

	if (tsPFC.nPFlag.u16All & Mask_Vbulk_UV_Fault_Flag)
	{
		tsPFC.nSFlag.u16Bits.u1PFC_Fault = TRUE;
	}
	else
	{
		tsPFC.nSFlag.u16Bits.u1PFC_Fault = FALSE;
	}
}

/****************************************************************************
*	Brief	check PFC Relay fault
*	Note	1. PTC or softstart retry fault over 60 times, trigger PFC relay fault
*	        2. at 10KHz Timer0 interrupt
****************************************************************************/
static void Check_PFC_Relay_Fault(u16_t u16Action)
{
	if (u16Action == TRUE)
	{
		if (tsPFC.sConPara.u16PFCRelayFaultCNT < Default_PFCRelayCNT)
		{
			tsPFC.sConPara.u16PFCRelayFaultCNT ++;
		}
		else if (tsPFC.sConPara.u16PFCRelayFaultCNT == Default_PFCRelayCNT)
		{
			tsPFC.nPFlag.u16Bits.u1PFC_Relay_Fail = 1;
		}
	}
	else if (u16Action == FALSE)
	{
		tsPFC.sConPara.u16PFCRelayFaultCNT = 0;
		tsPFC.nPFlag.u16Bits.u1PFC_Relay_Fail = 0;
	}
}

/****************************************************************************
*	Brief	PFC state off
*	Note	1. default or fault or waiting PFC enable signal
*	        2. In Timer0 10kHz ISR
****************************************************************************/
static inline void PFC_OFF(void)
{
	if (tsPFC.ePreState != tsPFC.eState)
	{
		tsPFC.eVoltState = PFC_VOLT_State_Reset;
		tsPFC.eCurrState = PFC_CURR_State_Reset;
		SetSwitchState(tsPFC.psPFCRelay, SwitchDriver_State_OFF);
		SetSwitchState(tsPFC.psPFCIGBT, SwitchDriver_State_OFF);
		tsPFC.nSFlag.u16Bits.u1InrushIGBTOn = FALSE;
		tsPFC.nSFlag.u16Bits.u1InrushRealyOn = FALSE;
		tsPFC.nSFlag.u16Bits.u1PFC_OK = FALSE; // For enable D2D flag
		tsPFC.ePreState = tsPFC.eState;
        PeriEPwm_SetDuty(ePeriEPwm_Tag_VBulkToD2D, 0);
	}

	if ((tsPFC.nSFlag.u16Bits.u1PFC_Enable == TRUE) &&
		(tsPFC.nSFlag.u16Bits.u1PFC_Fault == FALSE))
	{
		// PFC On when PFC enable and no PFC fault except Vbulk UVP
		tsPFC.eState = PFC_State_PTC;
	}
}

/****************************************************************************
*	Brief	PFC state PTC charge bulk
*	Note	1. waiting PTC charge bulk-cap to target voltage(Vpeak -70V)
*	        2. If PTC charge VBulk over time than 3s , then turn off PFC and recovery wait 10s
*	        3. at 10KHz Timer0 interrupt
****************************************************************************/
static inline void PFC_PTC(void)
{
	u16_t u16Vacpeaktobus, u16VbulkTarget;
	u16_t u16Vinpeak_Q15 = 0;
	
	if (tsPFC.ePreState != tsPFC.eState)
	{
		tsPFC.sConPara.u16PTC_ChargeTime_CNT = 0;
		tsPFC.sConPara.u16PTC_SustainedTime_CNT = 0;
		tsPFC.ePreState = tsPFC.eState;
	}

	if (CheckApplyInput())
	{
		if (GET_APPLY_INPUT_STATUS == MoniAC_InputStatus_AC)
		{
			u16Vinpeak_Q15 = (u16_t)(((GET_APPLY_AC_VPEAK * 100) / tsPFC.sConfigPara.f32PFC_FS)*Q15_);
		}
		else
		{
			u16Vinpeak_Q15 = (u16_t)(((GET_APPLY_DC_VPEAK * 100) / tsPFC.sConfigPara.f32PFC_FS)*Q15_);
		}
	}

	// Got Vbulk target voltage
	u16Vacpeaktobus = (u16_t)((f32_t)u16Vinpeak_Q15 * tsPFC.sConfigPara.f32PFC_to_BUS); //PFC to bus
	
	if (u16Vacpeaktobus > tsPFC.sConfigPara.u16PTC_Target_differ_Voltage)
	{
		u16VbulkTarget = u16Vacpeaktobus - tsPFC.sConfigPara.u16PTC_Target_differ_Voltage;
	}
	else
	{
		//Input Voltage fault, do not power on
		u16VbulkTarget = Q15_;
	}

	if (tsPFC.sPFCRara.u16Vbulk_DET_Q15 > u16VbulkTarget)
	{
		tsPFC.sConPara.u16PTC_SustainedTime_CNT++;
		
		if (tsPFC.sConPara.u16PTC_SustainedTime_CNT > PTC_SustainedTime)
		{
			tsPFC.eState = PFC_State_IGBTOn;
		}	
	}
	else
	{
		tsPFC.sConPara.u16PTC_SustainedTime_CNT = 0;
	}

	tsPFC.sConPara.u16PTC_ChargeTime_CNT ++;
	
	/* If PTC charge VBulk over time than 3s , then turn off PFC and recovery wait 10s */
	if (tsPFC.sConPara.u16PTC_ChargeTime_CNT > PTC_TimeOut)
	{
		tsPFC.nPFlag.u16Bits.u1PTC_Fault = TRUE;
		tsPFC.sConPara.u16PTC_Fault_Recovery_CNT = PTC_FaultRecoveryTime;
		Check_PFC_Relay_Fault(TRUE);
		tsPFC.eState = PFC_State_Off;
	}

	if (tsPFC.nSFlag.u16Bits.u1PFC_Enable == FALSE)
	{
		tsPFC.eState = PFC_State_Off;
	}
}

/****************************************************************************
*	Brief	PFC state inrush IGBT turn on
*	Note	1. waiting for zero cross turn on timing
*	        2. When Bulk-cap voltage large then VPeak-70V , MCU will turn on IGBT at zero cross
*	        3. In Timer0 10kHz ISR
****************************************************************************/
static inline void PFC_IGBTOn(void)
{
	if (tsPFC.ePreState != tsPFC.eState)
	{
		tsPFC.ePreState = tsPFC.eState;
	}

	if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_AC)
	{
		//IGBT turn on timing
		if (SwitchTiming(MoniAC_SwitchZC, MoniAC_Tag_VPFC))
		{
			SetSwitchState(tsPFC.psPFCIGBT, SwitchDriver_State_TurnOn);
			tsPFC.eState = PFC_State_Softstart;
		}
	}
	else
	{
		//IGBT turn on immediately
		SetSwitchState(tsPFC.psPFCIGBT, SwitchDriver_State_TurnOn);
		tsPFC.eState = PFC_State_Softstart;
	}

	if (tsPFC.nSFlag.u16Bits.u1PFC_Enable == FALSE)
	{
		tsPFC.eState = PFC_State_Off;
	}
}

/****************************************************************************
*	Brief	PFC state Vbulk softstart
*	Note	1. start control PFC PWM and softstart Vbulk to Vref
*			2. total softstart time keep 1.3s, per Xms rising 1 count
*			3. Input Bulk-cap voltage large than input peak voltage , MCU will turn on inrush Relay at zero cross
*			4. If softstart time-up over 2s , PFC state enter state off and recovery wait 10s
*			5. when state goto normal working , IGBT will turn-off
*			6. In Timer0 10kHz ISR
****************************************************************************/
static inline void PFC_Softstart(void)
{	
	// Initial and Calculation rising step voltage
	if (tsPFC.ePreState != tsPFC.eState)
	{
		tsPFC.sConPara.u16SoftStartIref = Q12_;
		tsPFC.nSFlag.u16Bits.u1InrushIGBTOn = TRUE;
		tsPFC.sConPara.u16SS_RisingTime_CNT = 0;
		tsPFC.ePreState = tsPFC.eState;
		tsPFC.eVoltState = PFC_VOLT_State_Operating; // Enable Voltage loop
		tsPFC.sPFCRara.u16Vbulk_Ref_Q15 = Get_VBulk_Vref_Q15(tsPFC.sConfigPara.u16VBulkRef_442V_Q15); // VBulk target is 442V when first power on

		/* Calculate VBulk RisingStep */
		if (tsPFC.sPFCRara.u16Vbulk_Ref_Q15 > tsPFC.sPFCRara.u16Vbulk_DET_Q15)
		{
			tsPFC.sConPara.u16SS_RisingStep_Volt = (u16_t)(((f32_t)(tsPFC.sPFCRara.u16Vbulk_Ref_Q15 - tsPFC.sPFCRara.u16Vbulk_DET_Q15))/SS_Rising_Time)+1;
		}
		else
		{
			tsPFC.sConPara.u16SS_RisingStep_Volt = 1;
		}
		
		/* Limit VBulk reference */
		tsPFC.sVOLT_PI.i32Ref = (i32_t)(tsPFC.sPFCRara.u16Vbulk_DET_Q15 + tsPFC.sConfigPara.u16PTC_Target_differ_Voltage);

		if (tsPFC.sVOLT_PI.i32Ref > tsPFC.sPFCRara.u16Vbulk_Ref_Q15)
		{
			tsPFC.sVOLT_PI.i32Ref = (i32_t)tsPFC.sPFCRara.u16Vbulk_Ref_Q15;
		}
		
		/* Assign KP and KI */
		tsPFC.sVOLT_PI.u32KP = tsPFC.sVOLT_PI.u32KP_SS;     //32768
		tsPFC.sVOLT_PI.u32KITS = tsPFC.sVOLT_PI.u32KITS_SS; //0
		tsPFC.sCURR_PI.u32KP = tsPFC.sCURR_PI.u32KP_H;      //40000
		tsPFC.sCURR_PI.u32KITS = tsPFC.sCURR_PI.u32KITS_H;  //104857
		tsPFC.sCURR2_PI.u32KP = tsPFC.sCURR2_PI.u32KP_H;
		tsPFC.sCURR2_PI.u32KITS = tsPFC.sCURR2_PI.u32KITS_H;
		tsPFC.sConfigPara.u32Duty_feedward_shift = Duty_feedward_shift;
		tsPFC.nSFlag.u16Bits.u1VoltagePIFast = FALSE;
	}

	// If Bulk-cap voltage large than input peak voltage , MCU will turn on inrush Relay at zero cross
	if (tsPFC.nSFlag.u16Bits.u1InrushRealyOn == FALSE)
	{
		if (IS_InrushRelay_On()) // Check Bulk-cap voltage large than input peak voltage
		{
			if (tsPFC.nSFlag.u16Bits.u2PFC_Vin_Status == MoniAC_InputStatus_AC)
			{
				//Inrush relay turn on at zero cross
				if (SwitchTiming(MoniAC_RelayONZC, MoniAC_Tag_VPFC))
				{
					SetSwitchState(tsPFC.psPFCRelay, SwitchDriver_State_TurnOn);
					tsPFC.nSFlag.u16Bits.u1InrushRealyOn = TRUE;
				}
			}
			else // If input is DC , Inrush relay turn on immediately
			{
				//Inrush relay turn on immediately
				SetSwitchState(tsPFC.psPFCRelay, SwitchDriver_State_TurnOn);
				tsPFC.nSFlag.u16Bits.u1InrushRealyOn = TRUE;
			}
		}
	}

	// Monitor Input voltage to adjust Vbulk reference
	tsPFC.sPFCRara.u16Vbulk_Ref_Q15 = Get_VBulk_Vref_Q15(tsPFC.sPFCRara.u16Vbulk_Ref_Q15);

	// Softstart
	tsPFC.sConPara.u16SS_RisingTime_CNT ++;
	
	/* VBulk RisingStep */
	if (tsPFC.sVOLT_PI.i32Ref < tsPFC.sPFCRara.u16Vbulk_Ref_Q15)
	{
		tsPFC.sVOLT_PI.i32Ref += tsPFC.sConPara.u16SS_RisingStep_Volt;
		tsPFC.sPFCRara.u16Vbulk_Target_Q15 = (u16_t)tsPFC.sVOLT_PI.i32Ref;
	}
	/*else if ((tsPFC.sPFCRara.u16Vbulk_DET_Q15 < tsPFC.sPFCRara.u16Vbulk_Ref_Q15) &&
			 (tsPFC.sConPara.u16SS_RisingTime_CNT > SS_Rising_Time))
	{
		tsPFC.sVOLT_PI.i32Ref += tsPFC.sConPara.u16SS_RisingStep_Volt;
		tsPFC.sPFCRara.u16Vbulk_Target_Q15 = (u16_t)tsPFC.sVOLT_PI.i32Ref;
	}*/
    else if ((tsPFC.sConPara.u16SS_RisingTime_CNT > SS_Rising_Time) &&
             (tsPFC.sPFCRara.u16Vbulk_DET_Q15 >= tsPFC.sConfigPara.u16VBulkRef_420V_Q15) &&
             (tsPFC.nSFlag.u16Bits.u1InrushRealyOn == TRUE))
    {
		Check_PFC_Relay_Fault(FALSE);
		tsPFC.sVOLT_PI.u32KP = tsPFC.sVOLT_PI.u32KP_L;
		tsPFC.sVOLT_PI.u32KITS = tsPFC.sVOLT_PI.u32KITS_L;
		tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_AC = FALSE;
		tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_1K = FALSE;
		SetSwitchState(tsPFC.psPFCIGBT, SwitchDriver_State_OFF);
		SetSwitchState(tsPFC.psPFCRelay, SwitchDriver_State_StaticON);
		tsPFC.eState = PFC_State_Operating;
		CHECK_MOMIDC_VBULK_UVP;
	}
			
	// VBulk Softstart fault CNT
	if (tsPFC.sConPara.u16SS_RisingTime_CNT > SS_Rising_Timeup)
	{
		tsPFC.nPFlag.u16Bits.u1SoftStart_Fail = TRUE;
		tsPFC.sConPara.u16SS_Fault_Recovery_CNT = SS_FaultRecoveryTime;
		Check_PFC_Relay_Fault(TRUE);
		tsPFC.eState = PFC_State_Off;
	}

	if (tsPFC.nSFlag.u16Bits.u1PFC_Enable == FALSE)
	{
		tsPFC.eState = PFC_State_Off;
	}
}

/****************************************************************************
*	Brief	PFC state normal operating
*	Note	1. keep Vbulk at Vref level
*	        2. If get PFC_Disable , turn-off PI controller(Disable PWM)
*	        3. In Timer0 10kHz ISR
****************************************************************************/
static inline void PFC_Operating(void)
{
	if (tsPFC.ePreState != tsPFC.eState)
	{
		tsPFC.nSFlag.u16Bits.u1PFC_OK = TRUE; // For enable D2D flag
		tsPFC.nSFlag.u16Bits.u1PFC_Vpeak_Ready = FALSE;
		tsPFC.sPFCRara.u16VPFC_Peak_Ready_CNT = VPFC_PEAK_Ready_Delay;
		tsPFC.ePreState = tsPFC.eState;
	}

	// Vbulk change slowly function at operation
	// 50V = 322.8ms (65ms/10V)
	if (tsPFC.sPFCRara.u16Vbulk_Target_Q15 != tsPFC.sVOLT_PI.i32Ref)
	{
		if (tsPFC.sPFCRara.u16Vbulk_Target_Q15 > tsPFC.sVOLT_PI.i32Ref)
		{
			tsPFC.sVOLT_PI.i32Ref += 1;
		}
		else
		{
			tsPFC.sVOLT_PI.i32Ref -= 1;
		}
	}

	if (tsPFC.nSFlag.u16Bits.u1PFC_Vpeak_Ready == FALSE)
	{
		if (tsPFC.sPFCRara.u16VPFC_Peak_Ready_CNT > 0)
		{
			tsPFC.sPFCRara.u16VPFC_Peak_Ready_CNT --;
		}
		else
		{
			tsPFC.nSFlag.u16Bits.u1PFC_Vpeak_Ready = TRUE;
		}
	}
	
	// Disable Voltage loop and Current loop
	if (tsPFC.nSFlag.u16Bits.u1PFC_Enable == FALSE)
	{
		tsPFC.nSFlag.u16Bits.u1PFC_Vpeak_Ready = FALSE;
		tsPFC.eState = PFC_State_Suspend;
		tsPFC.eVoltState = PFC_VOLT_State_Reset;
		tsPFC.eCurrState = PFC_CURR_State_Reset;
	}

	// Detect Vbulk UVP
	if (tsPFC.nPFlag.u16Bits.u1Vbulk_UV == TRUE)
	{
	    SET_LOG_VBulkUVP = TRUE;
		tsPFC.nSFlag.u16Bits.u1PFC_Vpeak_Ready = FALSE;
		tsPFC.eState = PFC_State_Off;
	}
	else
	{
	    SET_LOG_VBulkUVP = FALSE;
	}

    // Detect Vbulk UVW
    if (GET_MOMIDC_VBULK_UVW == TRUE)
    {
        SET_LOG_VBulkUVW = TRUE;
    }
    else
    {
        SET_LOG_VBulkUVW = FALSE;
    }
}

/****************************************************************************
*	Brief	PFC state suspend
*	Note	1. when AC loss goto suspend mode, waiting AC recovery (until VBulk not OK or 27ms)
*	        2. If in VBulk Cali_mode , PFC will stay here until calibration completed
*	        3. at 10KHz Timer0 interrupt
****************************************************************************/
static inline void PFC_Suspend(void)
{
	if (tsPFC.ePreState != tsPFC.eState)
	{
		tsPFC.sConPara.u16Suspend_CNT = Suspend_Delay_Time;					//27ms
		tsPFC.sConPara.u16EnablePFCDelay = Enable_PFC_Delay_Time;			//2ms
		tsPFC.sConPara.u16BBUMode_Turnoff_CNT = BBU_Mode_Off_Delay_Time;	//60ms
		tsPFC.ePreState = tsPFC.eState;
	}
	
	if ((tsPFC.nSFlag.u16Bits.u1PFC_Enable == TRUE) &&
		(CheckApplyInput()))
	{
        // 1. Wait 2ms When ATS transfer then turn on PFC
        // 2. Remove wait 2ms when AC drop
		if ((tsPFC.sConPara.u16EnablePFCDelay == 0) ||
            (GET_APPLY_SwitchState == ATSSwitch_StaticOn))
		{
			if (GET_APPLY_INPUT_STATUS == MoniAC_InputStatus_AC)
			{
				tsPFC.sPFCRara.u16Vinpeak_Q15 = (u16_t)(((GET_APPLY_AC_VPEAK * 100) / tsPFC.sConfigPara.f32PFC_FS)*Q15_);
			}
			else
			{
				tsPFC.sPFCRara.u16Vinpeak_Q15 = (u16_t)(((GET_APPLY_DC_VPEAK * 100) / tsPFC.sConfigPara.f32PFC_FS)*Q15_);
			}
			
			tsPFC.sConPara.u16SoftStartIref = 0;
			tsPFC.sPFCRara.u16Vbulk_DET_ZC_Q15 = tsPFC.sPFCRara.u16Vbulk_DET_Q15;
			tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_AC = TRUE;
			tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_1K = TRUE;
            tsPFC.nSFlag.u16Bits.u1PFC_Vbulk_SlewRate  = TRUE;
            tsPFC.sPFCRara.u16Vbulk_Target_Q15 = (i32_t)(Get_VBulk_Vref_Q15((u16_t)tsPFC.sVOLT_PI.i32Ref));
            tsPFC.sVOLT_PI.i32Ref = tsPFC.sConfigPara.u16VBulkRef_SlewRate_Q15;
			tsPFC.eState = PFC_State_Vbulk_SlewRate;
			tsPFC.eVoltState = PFC_VOLT_State_Operating;
		}
		else
		{
			tsPFC.sConPara.u16EnablePFCDelay -= 1;
		}
	}
	else
	{
		tsPFC.sConPara.u16EnablePFCDelay = Enable_PFC_Delay_Time;

		if (GET_ATS_State == ATSStatus_BBU)
		{
			if (tsPFC.sConPara.u16BBUMode_Turnoff_CNT > 0)
			{
				tsPFC.sConPara.u16BBUMode_Turnoff_CNT --;
			}
			else
			{
				tsPFC.eState = PFC_State_Off;
			}
		}

		// Turn off PFC When AC invalid during 27ms
		if (tsPFC.sConPara.u16Suspend_CNT > 0)
		{
			tsPFC.sConPara.u16Suspend_CNT --;
		}
		// If ATS in bulk cap calibration mode, PFC stay at suspend mode
		else if (GET_ATS_Bulk_Cali_MODE == FALSE)
		{
			tsPFC.eState = PFC_State_Off;
		}
	}

	if (tsPFC.nPFlag.u16Bits.u1Vbulk_UV == TRUE)
	{
		tsPFC.eState = PFC_State_Off;
	}
}

/****************************************************************************
*   Brief   PFC state slew rage
*   Note    1. Vbulk slew rate when AC drop then recover AC
****************************************************************************/
static inline void PFC_SlewRate(void)
{
    if (tsPFC.sPFCRara.u16Vbulk_Target_Q15 != tsPFC.sVOLT_PI.i32Ref)
    {
        if (tsPFC.sPFCRara.u16Vbulk_Target_Q15 > tsPFC.sVOLT_PI.i32Ref)
        {
            tsPFC.sVOLT_PI.i32Ref += 3;
        }
        else if (tsPFC.sPFCRara.u16Vbulk_Target_Q15 < tsPFC.sVOLT_PI.i32Ref)
        {
            tsPFC.sVOLT_PI.i32Ref -= 1;
        }
    }
    else
    {
        tsPFC.eState = PFC_State_Operating;
    }
}

/****************************************************************************
*   Brief   D2D Enable check
*   Note    1. Detect VBulk UVW & UVP
****************************************************************************/
static inline void Detect_Vbulk_UV(void)
{
    if ((tsPFC.eState == PFC_State_Operating) ||
        (tsPFC.eState == PFC_State_Vbulk_SlewRate))
    {
        // Detect Vbulk UVP
        if (tsPFC.nPFlag.u16Bits.u1Vbulk_UV == TRUE)
        {
            SET_LOG_VBulkUVP = TRUE;
            tsPFC.nSFlag.u16Bits.u1PFC_Vpeak_Ready = FALSE;
            tsPFC.eState = PFC_State_Off;
        }
        else
        {
            SET_LOG_VBulkUVP = FALSE;
        }

        // Detect Vbulk UVW
        if (GET_MOMIDC_VBULK_UVW == TRUE)
        {
            SET_LOG_VBulkUVW = TRUE;
        }
        else
        {
            SET_LOG_VBulkUVW = FALSE;
        }
    }
}

/****************************************************************************
*	Brief	D2D Enable check
*	Note    1. when vbulk not in calibration mode and PFC flag is true , turn-on D2D
*	        2. at timer0 10KHz interrupt
****************************************************************************/
static inline void Enable_D2D(void)
{
    if ((tsPFC.nSFlag.u16Bits.u1PFC_OK) &&
        (GET_ATS_Bulk_Cali_MODE == FALSE) &&
        (tsPFC.nPFlag.u16Bits.u1Inlet_UTP == FALSE) &&
        (tsPFC.nPFlag.u16Bits.u1Inlet_OTP == FALSE) &&
        (tsPFC.nPFlag.u16Bits.u1PFC_OTP == FALSE) &&
        //(tsPFC.nPFlag.u16Bits.u1PFC_UTP == FALSE) &&
        //(tsPFC.nPFlag.u16Bits.u1ATS_UTP == FALSE) &&
        (tsPFC.nPFlag.u16Bits.u1ATS_OTP == FALSE) &&
        (GET_LOG_PSU_REQ_OK == TRUE || GET_ATS_ForceD2DOn == TRUE))
    {
        SET_GPIO_D2D_EN;
    }
    else
    {
        SET_GPIO_D2D_DIS;
    }
}

/****************************************************************************
*	Brief	Interleaved PFC state machine
*	Note	In Timer0 10kHz ISR
****************************************************************************/
void PFC_Handler(void)
{
	Monitor_PFC_Control_Parameter();
	Check_PFC_Fault();
	
	switch (tsPFC.eState)
	{
		case PFC_State_Off:
			PFC_OFF();
		break;
	
		case PFC_State_PTC:
			PFC_PTC();
		break;
		
		case PFC_State_IGBTOn:
			PFC_IGBTOn();
		break;

		case PFC_State_Softstart:
			PFC_Softstart();
		break;
		
		case PFC_State_Operating:
			PFC_Operating();
		break;
		
		case PFC_State_Suspend:
			PFC_Suspend();
		break;
		
        case PFC_State_Vbulk_SlewRate:
            PFC_SlewRate();
        break;

		default:
		break;
	}

	Detect_Vbulk_UV();
	Enable_D2D();
}

/***************************************************************************
*   brief  Adjust PI control Value
*   note   
****************************************************************************/
void PFC_PI_V_KP(u8_t u8Action)
{
	if (u8Action == CONTROL_Decrease && GET_PFC_V_KP >= 1000)
	{
		GET_PFC_V_KP -= 100;
		tsPFC.sVOLT_PI.u32KP_H -= 1000; // For error > 20V
	}
	else if (u8Action == CONTROL_Increase)
	{
		GET_PFC_V_KP += 100;
        tsPFC.sVOLT_PI.u32KP_H += 1000; // For error > 20V
	}
}

/***************************************************************************
*   brief  Adjust PI control Value
*   note   
****************************************************************************/
void PFC_PI_V_KI(u8_t u8Action)
{
	if (u8Action == CONTROL_Decrease && GET_PFC_V_KI >= 1000)
	{
		GET_PFC_V_KI -= 100;
        tsPFC.sVOLT_PI.u32KITS_H -= 1000; // For error > 20V
	}
	else if (u8Action == CONTROL_Increase)
	{
		GET_PFC_V_KI += 100;
        tsPFC.sVOLT_PI.u32KITS_H += 1000; // For error > 20V
	}
}

/***************************************************************************
*   brief  Adjust PI control Value
*   note   
****************************************************************************/
void PFC_PI_I_KP(u8_t u8Action)
{
	if (u8Action == CONTROL_Decrease && GET_PFC_I_KP >= 1000)
	{
		GET_PFC_I_KP -= 1000;
	}
	else if (u8Action == CONTROL_Increase)
	{
		GET_PFC_I_KP += 1000;
	}
}

/***************************************************************************
*   brief  Adjust PI control Value
*   note   
****************************************************************************/
void PFC_PI_I_KI(u8_t u8Action)
{
	if (u8Action == CONTROL_Decrease && GET_PFC_I_KI >= 1000)
	{
		GET_PFC_I_KI -= 1000;
	}
	else if (u8Action == CONTROL_Increase)
	{
		GET_PFC_I_KI += 1000;
	}
}

/***************************************************************************
*   brief  Adjust PI control Value
*   note   
****************************************************************************/
void PFC_PI_Duty_Feed_Gain(u8_t u8Action)
{
	if (u8Action == CONTROL_Decrease)
	{
	    tsPFC.sConfigPara.f32Duty_feedward_Gain -= 0.01 ;
	}
	else if (u8Action == CONTROL_Increase)
	{
	    tsPFC.sConfigPara.f32Duty_feedward_Gain += 0.01;
	}
	GET_PFC_FEEDWARD_GAIN = tsPFC.sConfigPara.f32Duty_feedward_Gain * 100;
}

/***************************************************************************
*   brief  Adjust SoftStart count at zero cross
*   note
****************************************************************************/
void PFC_SoftStart_Count(u8_t u8Action)
{
    if (u8Action == CONTROL_Decrease && tsPFC.sConPara.u16Const_SyncRectifierTurnOnDelay > 0)
    {
        tsPFC.sConPara.u16Const_SyncRectifierTurnOnDelay -= 1;
    }
    else if (u8Action == CONTROL_Increase)
    {
        tsPFC.sConPara.u16Const_SyncRectifierTurnOnDelay += 1;
    }
}

/***************************************************************************
*   brief  Adjust normal phase change, unit is 0.5V
*   note
****************************************************************************/
void PFC_Normal_Change_Phase(u8_t u8Action)
{
    if (u8Action == CONTROL_Decrease)
    {
        tsPFC.sConfigPara.i16PhaseChange_V_Pos_Q15 -= (i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        tsPFC.sConfigPara.i16PhaseChange_V_Neg_Q15 -= -(i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        GET_PFC_Normal_Phase -= 500;
    }
    else if (u8Action == CONTROL_Increase)
    {
        tsPFC.sConfigPara.i16PhaseChange_V_Pos_Q15 += (i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        tsPFC.sConfigPara.i16PhaseChange_V_Neg_Q15 += -(i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        GET_PFC_Normal_Phase += 500;
    }
}

/***************************************************************************
*   brief  Adjust SoftStart phase change, unit is 0.5V
*   note
****************************************************************************/
void PFC_SoftStart_Change_Phase(u8_t u8Action)
{
    if (u8Action == CONTROL_Decrease)
    {
        tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Pos_Q15 -= (i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Neg_Q15 -= -(i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        GET_PFC_SoftStart_Phase -= 500;
    }
    else if (u8Action == CONTROL_Increase)
    {
        tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Pos_Q15 += (i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Neg_Q15 += -(i16_t)(((f32_t)500 / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
        GET_PFC_SoftStart_Phase += 500;
    }
}

/***************************************************************************
*   brief  Adjust Iref integral gain
*   note
****************************************************************************/
void PFC_Adjust_Iref_IntegralGain(u8_t u8Action)
{
    if (u8Action == CONTROL_Decrease && tsPFC.sCURR_PI.u32Const_IntegralGain > 0)
    {
        tsPFC.sCURR_PI.u32Const_IntegralGain -= 1;
    }
    else if (u8Action == CONTROL_Increase)
    {
        tsPFC.sCURR_PI.u32Const_IntegralGain += 1;
    }
}

/***************************************************************************
*   brief  Adjust SoftStart Iref integral gain
*   note
****************************************************************************/
void PFC_Adjust_Iref_Gain(u8_t u8Action)
{
    if (u8Action == CONTROL_Decrease && tsPFC.sConPara.u16Const_SoftStartIref > 0)
    {
        tsPFC.sConPara.u16Const_SoftStartIref -= 1;
    }
    else if (u8Action == CONTROL_Increase)
    {
        tsPFC.sConPara.u16Const_SoftStartIref += 1;
    }
}

/***************************************************************************
*   brief  Adjust Duty feed shift
*   note
****************************************************************************/
void PFC_PI_Duty_Feed_Shift(u8_t u8Action)
{
	if (u8Action == CONTROL_Decrease && GET_PFC_DUTY_FEED_SHIFT > 0)
	{
		GET_PFC_DUTY_FEED_SHIFT -= 100 ;
	}
	else if (u8Action == CONTROL_Increase)
	{
		GET_PFC_DUTY_FEED_SHIFT += 100;
	}
}

/***************************************************************************
*   brief  Adjust Vbulk ref, unit is 0.1V
*   note   
****************************************************************************/
void PFC_VBULK_Adjust(u8_t u8Action)
{
	if (u8Action == CONTROL_Decrease)
	{
		GET_PFC_VBULK_M -= 6;
		GET_PFC_VBULK_L    = GET_PFC_VBULK_M;
		GET_PFC_VBULK_H    = GET_PFC_VBULK_M;
		GET_PFC_VBULK_LL   = GET_PFC_VBULK_M;
		GET_PFC_VBULK_442V = GET_PFC_VBULK_M;
	}
	else if (u8Action == CONTROL_Increase)
	{
		GET_PFC_VBULK_M += 6;
		GET_PFC_VBULK_L    = GET_PFC_VBULK_M;
		GET_PFC_VBULK_H    = GET_PFC_VBULK_M;
		GET_PFC_VBULK_LL   = GET_PFC_VBULK_M;
        GET_PFC_VBULK_442V = GET_PFC_VBULK_M;
	}
}

/***************************************************************************
*   brief  PFC 1ms periodically process
*   note   
****************************************************************************/
void PFC_1ms_Periodically_Process(void)
{
	// Voltage loop period for DC input
	tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_1K = TRUE;

	// Vbulk change slowly function at operation
	// 50V = 3228ms (65ms/1V)

//	if ((tsPFC.sPFCRara.u16Vbulk_Target_Q15 != tsPFC.sVOLT_PI.i32Ref) &&
//		(tsPFC.eState == PFC_State_Operating))
//	{
//		if (tsPFC.sPFCRara.u16Vbulk_Target_Q15 > tsPFC.sVOLT_PI.i32Ref)
//		{
//			tsPFC.sVOLT_PI.i32Ref += 1;
//		}
//		else
//		{
//			tsPFC.sVOLT_PI.i32Ref -= 1;
//		}
//	}
}

/***************************************************************************
*   brief  PFC 10ms periodically process
*   note
****************************************************************************/
void PFC_10ms_Periodically_Process(void)
{
    // Voltage loop period for DC input
//    tsPFC.nSFlag.u16Bits.u1VoltagePIRequest_1K = TRUE;

    // Vbulk change slowly function at operation
    // 50V = 32280ms (650ms/1V)

//    if ((tsPFC.sPFCRara.u16Vbulk_Target_Q15 != tsPFC.sVOLT_PI.i32Ref) &&
//        (tsPFC.eState == PFC_State_Operating))
//    {
//        if (tsPFC.sPFCRara.u16Vbulk_Target_Q15 > tsPFC.sVOLT_PI.i32Ref)
//        {
//            tsPFC.sVOLT_PI.i32Ref += 1;
//        }
//        else
//        {
//            tsPFC.sVOLT_PI.i32Ref -= 1;
//        }
//    }
}

/***************************************************************************
*   brief  PFC 1s periodically process
*   note   Fault recovery
****************************************************************************/
void PFC_1s_Periodically_Process(void)
{
	if (tsPFC.nPFlag.u16Bits.u1PTC_Fault == TRUE)
	{
		if (tsPFC.sConPara.u16PTC_Fault_Recovery_CNT > 0)
		{
			tsPFC.sConPara.u16PTC_Fault_Recovery_CNT--;
		}		
		else
		{
			tsPFC.nPFlag.u16Bits.u1PTC_Fault = FALSE;
		}
	}

	if (tsPFC.nPFlag.u16Bits.u1SoftStart_Fail == TRUE)
	{
		if (tsPFC.sConPara.u16SS_Fault_Recovery_CNT > 0)
		{
			tsPFC.sConPara.u16SS_Fault_Recovery_CNT--;
		}		
		else
		{
			tsPFC.nPFlag.u16Bits.u1SoftStart_Fail = FALSE;
		}
	}
/*
	if (tsPFC.nPFlag.u16Bits.u1Vbulk_UV == TRUE)
	{
		if (tsPFC.sConPara.u16UV_Fault_Recovery_CNT < UV_FaultRecoveryTime)
		{
			tsPFC.sConPara.u16UV_Fault_Recovery_CNT++;
		}				
		else
		{
			CLEAR_MOMIDC_VBULK_UVP;
			tsPFC.sConPara.u16UV_Fault_Recovery_CNT = 0;
		}
	}
	else
	{
		tsPFC.sConPara.u16UV_Fault_Recovery_CNT = 0;
	}
*/
	if (tsPFC.nPFlag.u16Bits.u1Vbulk_OV == TRUE)
	{
		if (tsPFC.sConPara.u16OV_Fault_Recovery_CNT < OV_FaultRecoveryTime)
		{
			tsPFC.sConPara.u16OV_Fault_Recovery_CNT++;
		}				
		else
		{
			CLEAR_MOMIDC_VBULK_OVP;
			tsPFC.sConPara.u16OV_Fault_Recovery_CNT = 0;
		}			
	}
	else
	{
		tsPFC.sConPara.u16OV_Fault_Recovery_CNT = 0;
	}
}

/***************************************************************************
*   brief  PFC Initialize
*   note   Only be executed when MCU power on
****************************************************************************/
void PFC_Initialize(void)
{
	memset(&tsPFC, 0, sizeof(tsPFC));
	tsPFC.eState = PFC_State_Off;
	tsPFC.eVoltState = PFC_VOLT_State_Reset;
	tsPFC.eCurrState = PFC_CURR_State_Reset;

	/* Feed back sense */
	tsPFC.sPFCRara.pu16Vin_nnn_Q12 = &GET_ADCFilter_PFC_VAC_nnn;
	tsPFC.sPFCRara.pi16Vin_sin_Q12 = &GET_ADCFilter_PFC_VAC_Sin;
	tsPFC.sPFCRara.pu16IinA_nnn_Q12 = &GET_ADCFilter_PFC_IAC_A_nnn;
	tsPFC.sPFCRara.pu16IinB_nnn_Q12 = &GET_ADCFilter_PFC_IAC_B_nnn;
	tsPFC.sPFCRara.pi16IinA_sin_Q12 = &GET_ADCFilter_PFC_IAC_A_Sin;
	tsPFC.sPFCRara.pi16IinB_sin_Q12 = &GET_ADCFilter_PFC_IAC_B_Sin;
	tsPFC.sPFCRara.pu16Vbulk_DET_Q12 = &GET_ADCFilter_DC_VBulk_DET;

    /* Hardware Gain */
	tsPFC.sConfigPara.f32BUS_FS = V_BUS_FS;
	tsPFC.sConfigPara.f32PFC_FS = V_ACPFC_FS;
	tsPFC.sConfigPara.f32IAC_FS = I_AC_FS;
	tsPFC.sConfigPara.f32PFC_to_BUS = tsPFC.sConfigPara.f32PFC_FS / tsPFC.sConfigPara.f32BUS_FS;
	
	tsPFC.sConfigPara.u16VBulkRef_Limit_MAX_Q15 = (u16_t)(((f32_t)((VBulk_Limit_MAX - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulkRef_Limit_H_Q15 = (u16_t)(((f32_t)((VBulk_Limit_H - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulkRef_Limit_M_Q15 = (u16_t)(((f32_t)((VBulk_Limit_M - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulkRef_Limit_L_Q15 = (u16_t)(((f32_t)((VBulk_Limit_L - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
    tsPFC.sConfigPara.u16VBulkRef_SlewRate_Q15 = (u16_t)(((f32_t)((VBulk_SlewRate - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
    tsPFC.sConfigPara.u16VBulkRef_420V_Q15 = (u16_t)(((f32_t)((VBulk_420V - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulkRef_438V_Q15 = (u16_t)(((f32_t)((VBulk_438V - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
    tsPFC.sConfigPara.u16VBulkRef_439V_Q15 = (u16_t)(((f32_t)((VBulk_439V - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
    tsPFC.sConfigPara.u16VBulkRef_442V_Q15 = (u16_t)(((f32_t)((VBulk_442V - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
    tsPFC.sConfigPara.u16VBulk_470V_Q15 = (u16_t)(((f32_t)(VBulk_470V * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulkRef_Limit_MIN_Q15 = (u16_t)(((f32_t)((VBulk_Limit_MIN - VBulk_Compensation) * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16PTC_Target_differ_Voltage = (u16_t)((((f32_t)PTC_Target_differ_Voltage * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_ + 0.5);
	tsPFC.sConfigPara.u16VBulkshort_Limit_L_Q15 = (u16_t)(((f32_t)(VBulk_short_Limit * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
    tsPFC.sConfigPara.u16VBulk_5V_Q15 = (u16_t)(((f32_t)(VBulk_5V * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulk_10V_Q15 = (u16_t)(((f32_t)(VBulk_10V * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulk_20V_Q15 = (u16_t)(((f32_t)(VBulk_20V * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.u16VBulk_35V_Q15 = (u16_t)(((f32_t)(VBulk_35V * 1000) / tsPFC.sConfigPara.f32BUS_FS) * Q15_);
	tsPFC.sConfigPara.f32DynamicBulkVG = ((VBulk_Gain_V * 100 * Q15_) / tsPFC.sConfigPara.f32BUS_FS);
	tsPFC.sConfigPara.f32DynamicBulkVG_DC = ((VBulk_Gain_V_DC * 100 * Q15_) / tsPFC.sConfigPara.f32BUS_FS);
	tsPFC.sConfigPara.f32DynamicBulkIG = ((VBulk_Gain_I * 100 * Q15_) / tsPFC.sConfigPara.f32BUS_FS);
	tsPFC.sConfigPara.f32DynamicBulkPG = ((VBulk_Gain_P * 1000 * Q15_) / tsPFC.sConfigPara.f32BUS_FS);
	tsPFC.sConfigPara.u16Vacpeak_10V_THRESHOLD_Q15 = (u16_t)(((f32_t)10000 / tsPFC.sConfigPara.f32PFC_FS) * Q15_ + 0.5);
	tsPFC.sConfigPara.u16Vacpeak_20V_THRESHOLD_Q15 = (u16_t)(((f32_t)20000 / tsPFC.sConfigPara.f32PFC_FS) * Q15_ + 0.5);
	tsPFC.sConfigPara.u16Vacpeak_THRESHOLD_H_Q15 = Q15_;
	tsPFC.sConfigPara.u16Vacpeak_THRESHOLD_L_Q15 = (u16_t)(((f32_t)160000 / tsPFC.sConfigPara.f32PFC_FS) * Q15_ * 1.414); // 160V
	tsPFC.sConfigPara.i16Iacpeak_Poslimit = (i16_t)(((f32_t)18000 / tsPFC.sConfigPara.f32IAC_FS) * Q15_ + 0.5); 	//25A single phase, 50A total current
	tsPFC.sConfigPara.i16Iacpeak_Neglimit = 0;
	tsPFC.sConfigPara.i32Iacpeak_Lightload_L = (i32_t)(((f32_t)8000 / tsPFC.sConfigPara.f32IAC_FS) * Q15_ + 0.5); 	//8A single phase peak current
	tsPFC.sConfigPara.i32Iacpeak_Lightload_H = (i32_t)(((f32_t)9000 / tsPFC.sConfigPara.f32IAC_FS) * Q15_ + 0.5); 	//9A single phase peak current
    tsPFC.sConfigPara.u32Iac_Sense_OCP       = (i32_t)(((f32_t)40000 / tsPFC.sConfigPara.f32IAC_FS) * Q15_ + 0.5);  //40A single phase peak current
	tsPFC.sConfigPara.i32Xcap_Currentadjust  = (i32_t)(((f32_t)4500 / tsPFC.sConfigPara.f32IAC_FS) * Q16_ + 0.5);	// 4.5A
	tsPFC.sConfigPara.f32XcapCompensate = ((f32_t)PIx2_ * (tsPFC.sConfigPara.f32PFC_FS / tsPFC.sConfigPara.f32IAC_FS) * Xcap);
	tsPFC.sConfigPara.i16PhaseChange_V_Pos_Q15 = (i16_t)(((f32_t)Normal_Change_Phase / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
	tsPFC.sConfigPara.i16PhaseChange_V_Neg_Q15 = -(i16_t)(((f32_t)Normal_Change_Phase / tsPFC.sConfigPara.f32PFC_FS) * Q15_);

	/* CanBus Control Parameter */
	tsPFC.sConPara.u16Const_SoftStartIref = Q6_; //Q6_
	tsPFC.sConPara.u16SoftStart_Duty_Control = 0;
	tsPFC.sConPara.u16Const_SyncRectifierTurnOnDelay = 0;  // For adjust SoftStart count
    tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Pos_Q15 = (i16_t)(((f32_t)SoftStart_Change_Phase / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
    tsPFC.sConfigPara.i16PhaseChange_SoftStart_V_Neg_Q15 = -(i16_t)(((f32_t)SoftStart_Change_Phase / tsPFC.sConfigPara.f32PFC_FS) * Q15_);
    tsPFC.sConPara.u16Report_Normal_Phase_Change = Normal_Change_Phase;       // For report normal    Change Phase , 7V , unit is 0.001V
    tsPFC.sConPara.u16Report_SoftStart_Phase_Change = SoftStart_Change_Phase; // For report SoftStart Change Phase , 5V  , unit is 0.001V
    tsPFC.sCURR_PI.u32Const_IntegralGain = 26; // Q5_ , for RP12:30 , RP48:28
	tsPFC.sConfigPara.u32Duty_feedward_shift = Duty_feedward_shift;
	tsPFC.sConfigPara.f32Duty_feedward_Gain = 1;

    /* Voltage loop Parameter */
	tsPFC.sVOLT_PI.eType = PFC_VOLTAGE_LOOP;
	tsPFC.sVOLT_PI.i32IntegralGain = Q12_;
	tsPFC.sVOLT_PI.f32Integral_Poslimit = PI_V_Integral_Poslimit;
	tsPFC.sVOLT_PI.f32Integral_Neglimit = PI_V_Integral_Neglimit;
	tsPFC.sVOLT_PI.f32PIout_Poslimit = PI_V_PIOut_Poslimit;
	tsPFC.sVOLT_PI.f32PIout_Neglimit = PI_V_PIOut_Neglimit;
	tsPFC.sVOLT_PI.u16AdjustGain_H = (u16_t)(((f32_t)20000 / tsPFC.sConfigPara.f32BUS_FS) * Q15_ + 0.5); // 20V
	tsPFC.sVOLT_PI.u16AdjustGain_L = (u16_t)(((f32_t)15000 / tsPFC.sConfigPara.f32BUS_FS) * Q15_ + 0.5); // 15V
	tsPFC.sVOLT_PI.u32KP_SS = PI_V_KP_SS; // 32768
	tsPFC.sVOLT_PI.u32KP_H = PI_V_KP_H * 1.7;
	tsPFC.sVOLT_PI.u32KP_L = PI_V_KP_L;
	tsPFC.sVOLT_PI.u32KITS_H = PI_V_KITS_H * 0.7;
	tsPFC.sVOLT_PI.u32KITS_L = PI_V_KITS_L;

    /* Current loop-1 Parameter */
	tsPFC.sCURR_PI.eType = PFC_CURRENT_LOOP_1;
	tsPFC.sCURR_PI.i32IntegralGain = Q12_;
	tsPFC.sCURR_PI.f32Integral_Poslimit = PI_I_Integral_Poslimit;
	tsPFC.sCURR_PI.f32Integral_Neglimit = PI_I_Integral_Neglimit;
	tsPFC.sCURR_PI.f32PIout_Poslimit = PI_I_PIOut_Poslimit;
	tsPFC.sCURR_PI.f32PIout_Neglimit = PI_I_PIOut_Neglimit;
	tsPFC.sCURR_PI.u16AdjustGain_H = (u16_t)(((f32_t)10000 / tsPFC.sConfigPara.f32IAC_FS) * Q15_ + 0.5); 	// 10A
	tsPFC.sCURR_PI.u16AdjustGain_L = (u16_t)(((f32_t)5000 / tsPFC.sConfigPara.f32IAC_FS) * Q15_ + 0.5);		// 5A
	tsPFC.sCURR_PI.u32KP_H = PI_I_KP_H; //40000
	tsPFC.sCURR_PI.u32KP_L = PI_I_KP_L;
	tsPFC.sCURR_PI.u32KITS_H = PI_I_KITS_H; //104857
	tsPFC.sCURR_PI.u32KITS_L = PI_I_KITS_L;

    /* Current loop-2 Parameter */
    tsPFC.sCURR2_PI.eType = PFC_CURRENT_LOOP_2;
	tsPFC.sCURR2_PI.i32IntegralGain = Q12_;
	tsPFC.sCURR2_PI.f32Integral_Poslimit = PI_I_Integral_Poslimit;
	tsPFC.sCURR2_PI.f32Integral_Neglimit = PI_I_Integral_Neglimit;
	tsPFC.sCURR2_PI.f32PIout_Poslimit = PI_I_PIOut_Poslimit;
	tsPFC.sCURR2_PI.f32PIout_Neglimit = PI_I_PIOut_Neglimit;
	tsPFC.sCURR2_PI.u16AdjustGain_H = tsPFC.sCURR_PI.u16AdjustGain_H;
	tsPFC.sCURR2_PI.u16AdjustGain_L = tsPFC.sCURR_PI.u16AdjustGain_L;
	tsPFC.sCURR2_PI.u32KP_H = PI_I_KP_H;
	tsPFC.sCURR2_PI.u32KP_L = PI_I_KP_L;
	tsPFC.sCURR2_PI.u32KITS_H = PI_I_KITS_H;
	tsPFC.sCURR2_PI.u32KITS_L = PI_I_KITS_L;

	/* Variable Frequency */
	tsPFC.sConfigPara.u16LowFreq = EPWM_40KHz;
	tsPFC.sConfigPara.u16HighFreq = EPWM_50KHz;

	tsPFC.psPFCRelay = GetSwitchDriverRef(SwitchDriver_Tag_PFC_Relay);
	tsPFC.psPFCIGBT = GetSwitchDriverRef(SwitchDriver_Tag_PFC_IGBT);
}


/****************************************************************************
*	End of Function
****************************************************************************/
