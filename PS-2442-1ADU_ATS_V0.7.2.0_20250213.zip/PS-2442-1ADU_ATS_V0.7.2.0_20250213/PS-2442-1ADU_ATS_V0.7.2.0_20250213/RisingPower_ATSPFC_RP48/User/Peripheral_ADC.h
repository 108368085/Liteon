/****************************************************************************
 *	File	Peripheral_ADC.h
 * 	Brief	Header file for Peripheral ADC module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

 
#ifndef _PERIPHERAL_ADC_H_
#define _PERIPHERAL_ADC_H_

#include "CONFIG_Define.h"

/****************************************************************************
    Public parameter definition
****************************************************************************/

#define GET_ADC_I_PFC_B			ADCResult[ADC_I_PFC_B]
#define GET_ADC_V_PFC_N			ADCResult[ADC_V_PFC_N]
#define GET_ADC_V_AC1_L			ADCResult[ADC_V_AC1_L]
#define GET_ADC_V_AC2_N			ADCResult[ADC_V_AC2_N]
#define GET_ADC_T_INLET			ADCResult[ADC_T_INLET]
#define GET_ADC_T_ATS			ADCResult[ADC_T_ATS]

#define GET_ADC_I_PFC_A			ADCResult[ADC_I_PFC_A]
#define GET_ADC_V_PFC_L			ADCResult[ADC_V_PFC_L]
#define GET_ADC_V_AC1_N			ADCResult[ADC_V_AC1_N]
#define GET_ADC_V_AC2_L			ADCResult[ADC_V_AC2_L]
#define GET_ADC_T_PFC			ADCResult[ADC_T_PFC]
#define GET_ADC_T_D2D			ADCResult[ADC_T_D2D]


#define GET_ADC_V_PFC_OVP1		ADCResult[ADC_V_PFC_OVP1]
#define GET_ADC_V_PFC_DET		ADCResult[ADC_V_PFC_DET]
#define GET_ADC_V_PFC_OVP2		ADCResult[ADC_V_PFC_OVP2]
#define GET_ADC_V_AUX1			ADCResult[ADC_V_AUX1]
#define GET_ADC_V_AUX2			ADCResult[ADC_V_AUX2]


/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/
typedef enum
{
	ADC_I_PFC_B = 0,
	ADC_V_PFC_N,
	ADC_V_AC1_L,
	ADC_V_AC2_N,
	ADC_T_INLET,
	ADC_T_ATS,
	
	ADC_I_PFC_A,
	ADC_V_PFC_L,
	ADC_V_AC1_N,
	ADC_V_AC2_L,
	ADC_T_PFC,
	ADC_T_D2D,
	
	ADC_V_PFC_OVP1,
	ADC_V_PFC_DET,
	ADC_V_PFC_OVP2,
	ADC_V_AUX1,
	ADC_V_AUX2,

	ADC_Tag_Num
}eADCTag_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/
extern u16_t ADCResult[ADC_Tag_Num];


/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void PeriAdc_Initialize(void);
extern void PeriAdc_Start(void);
extern void PeriAdc_Stop(void);

#endif 
