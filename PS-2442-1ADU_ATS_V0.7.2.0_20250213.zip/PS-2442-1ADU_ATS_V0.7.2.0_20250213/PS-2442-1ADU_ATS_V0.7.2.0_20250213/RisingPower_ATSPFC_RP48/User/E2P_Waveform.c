/** @file       E2P_Waveform.c
 *  @brief      Record 4 channel data(Vac1,Vac2,Vpfc,Ipfc) to achieve waveform feature
 *  @Note		Waveform data format is u16_t, (Vac2Vac1), (IpfcVpfc).
 *  @author     Adonis Wang
 *  @version    2.0
 *  @date       
 */

#include "E2P_Waveform.h"
#include "E2P_BlackBox.h"
#include <string.h>

/****************************************************************************
	Private parameter definition 
****************************************************************************/

#define HalfWaveformSampleQuantities        (WaveformSampleQuantities >> 1)


/****************************************************************************
	Private macro definition
****************************************************************************/ 

/****************************************************************************
	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/ 

/*
// RAMLS0_6 : 224
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(Waveform_10k_Instant_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(Waveform_Record, ".TI.ramfunc");
//#pragma CODE_SECTION(Waveform_StartCapture, ".TI.ramfunc");
#endif
*/

/****************************************************************************
	Private variable declaration
****************************************************************************/
sWaveformMonitor_t tsWaveformMonitor;
sWaveformRecorder_t tsWaveformRecorder;


/**
 *  @brief  Sample data of each channel and rolling waveform window
 *  @Note	
 */
static inline void Waveform_Probe(void)
{
    u16_t i;
	u16_t u16Record_Front_Index;
    
    /* Update channel logs of rolling window */
    for (i=0; i<WaveformSampleChannels; i++)
    {
        tsWaveformMonitor.psLogs[tsWaveformMonitor.u16RollingIndex].u16Value[i] = *tsWaveformMonitor.sConfig.pu16Source[i];
    }

    if ((tsWaveformRecorder.nFlag.u16Bits.u1BlackBox_Recording) ||
		(tsWaveformRecorder.nFlag.u16Bits.u1Capture_Recording))
    {
		u16Record_Front_Index = (tsWaveformRecorder.u16RecordIndex - HalfWaveformSampleQuantities) * WaveformSampleChannels * 2;
	
        for (i=0; i<WaveformSampleChannels; i++)
        {
			// Copy previous waveform at (WaveformSampleDuration/2) ago
			if (tsWaveformMonitor.u16RollingIndex < HalfWaveformSampleQuantities)
			{
				__WordToLByte((tsWaveformRecorder.sConfig.pu8Destination + u16Record_Front_Index + (i * 2)), tsWaveformMonitor.psLogs[HalfWaveformSampleQuantities + tsWaveformMonitor.u16RollingIndex].u16Value[i]);
			}
			else
			{
				__WordToLByte((tsWaveformRecorder.sConfig.pu8Destination + u16Record_Front_Index + (i * 2)), tsWaveformMonitor.psLogs[tsWaveformMonitor.u16RollingIndex - HalfWaveformSampleQuantities].u16Value[i]);
			}
	
            // Copy Current waveform
            __WordToLByte((tsWaveformRecorder.sConfig.pu8Destination + (tsWaveformRecorder.u16RecordIndex * WaveformSampleChannels * 2) + (i * 2)), tsWaveformMonitor.psLogs[tsWaveformMonitor.u16RollingIndex].u16Value[i]);
        }
        	
		tsWaveformRecorder.u16RecordIndex += 1;
		
        // Once if record accomplished, terminate record process and publish it
        if (tsWaveformRecorder.u16RecordIndex == WaveformSampleQuantities)
        {
        	if (tsWaveformRecorder.nFlag.u16Bits.u1BlackBox_Recording)
        	{
        		tsWaveformRecorder.nFlag.u16Bits.u1BlackBox_Recording = 0;
				BlackBox_Waveform_Callback();
        	}
			else if (tsWaveformRecorder.nFlag.u16Bits.u1Capture_Recording)
			{
				tsWaveformRecorder.nFlag.u16Bits.u1Capture_Recording = 0;
				SET_BLACKBOX_WAVEFORM_CAPTURE_1;
			}
        }
    }
      
    tsWaveformMonitor.u16RollingIndex += 1;
    
    if (tsWaveformMonitor.u16RollingIndex == WaveformSampleQuantities)
    {
        tsWaveformMonitor.u16RollingIndex = 0;
    }
}

/**
 *  @brief  waveform capture for 10kHz instant process
 *  @retval None
 */
void Waveform_10k_Instant_Process(void)
{
	Waveform_Probe();
}

/**
 *  @brief  Record Waveform
 *  @retval None
 */
void Waveform_Record(void)
{ 
    if (tsWaveformRecorder.nFlag.u16Bits.u1BlackBox_Recording == 0)
    {
        tsWaveformRecorder.u16RecordIndex = HalfWaveformSampleQuantities;
        tsWaveformRecorder.nFlag.u16Bits.u1BlackBox_Recording = 1;
		SET_BLACKBOX_WAVEFORM_CAPTURE_0;

		// Blackbox waveform priority higher than waveform capture
		if (tsWaveformRecorder.nFlag.u16Bits.u1Capture_Recording == 1)
		{
			tsWaveformRecorder.nFlag.u16Bits.u1Capture_Recording = 0;
		}
    }
}

/**
 *  @brief  Start waceform capture, triggerd by can bus
 *  @retval None
 */
void Waveform_StartCapture(void)
{
	if (tsWaveformRecorder.nFlag.u16Bits.u1BlackBox_Recording == 0)
	{
		tsWaveformRecorder.u16RecordIndex = HalfWaveformSampleQuantities;
		tsWaveformRecorder.nFlag.u16Bits.u1Capture_Recording = 1;
		SET_BLACKBOX_WAVEFORM_CAPTURE_0;
	}
}

/**
 *  @brief  Configure probe attributes
 *  @param  sProbeConfig: Waveform Probe attributes which is attempted to configure
 *  @retval None
 */
void Waveform_ConfigureProbe(sWaveformProbeConfig_t sProbeConfig)
{
    tsWaveformMonitor.sConfig = sProbeConfig;
}

/**
 *  @brief  Configure probe attributes
 *  @param  sProbeConfig: Waveform Probe attributes which is attempted to configure
 *  @retval None
 */
void Waveform_Address_Setting(sWaveformRecorderConfig_t sRecorderConfig)
{
    tsWaveformRecorder.sConfig = sRecorderConfig;
}

/**
 *  @brief  Initial waveform module
 *  @retval None
 */
void Waveform_Initialize(void)
{
    memset(&tsWaveformMonitor, 0, sizeof(tsWaveformMonitor));
    memset(&tsWaveformRecorder, 0, sizeof(tsWaveformRecorder));
}

