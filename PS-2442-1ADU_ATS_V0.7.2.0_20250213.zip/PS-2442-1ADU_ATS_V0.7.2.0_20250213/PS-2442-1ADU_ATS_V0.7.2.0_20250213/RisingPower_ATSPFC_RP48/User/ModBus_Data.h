/** @file       ModBus_Data.h
 *  @author     Ollie Chen
 *  @brief      Header file for ModBus Server Data
 *  @version    1.0
 *  @date       2017-10-25
 */

#ifndef _MODBUS_DATA_H_
#define _MODBUS_DATA_H_

#include "CONFIG_Define.h"
#include "SERV_GuardVar.h"


/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/
/**
    @brief  Enumerate the ModBus data register type
*/
typedef enum
{
	eMBusData_Type_Coil,
	eMBusData_Type_Input,
	eMBusData_Type_Specific,
	eMBusData_Type_Holding,
}eMBusDataType_t;

/****************************************************************************
*   Public structure definition
****************************************************************************/
/**
    @brief  Structure definition of Coil register 
*/
typedef struct sCoilRegNode
{
	u16_t 	u16StartAddr;
	u16_t	u16EndAddr;
	u16_t 	u16StartBit;
	u16_t	u16EndBit;
	u16_t* 	pu16Reg;
}sCoilRegNode_t;

/**
    @brief  Structure definition of Input register
*/
typedef struct sInputRegNode
{
	u16_t 	u16StartAddr;
	u16_t	u16EndAddr;
	u16_t*	pu16Reg;
}sInputRegNode_t;

/**
    @brief  Structure definition of Holding register
*/
typedef struct sHoldingRegNode
{
	u16_t 	u16StartAddr;
	u16_t	u16EndAddr;
	sGuardVarList_t* psGuardVarList;
}sHoldingRegNode_t;

/****************************************************************************
	Public export variable 
****************************************************************************/

/****************************************************************************
*   public function prototype
****************************************************************************/
extern sCoilRegNode_t* MBusData_SearchCoilRegNode(u16_t u16Address);
extern sInputRegNode_t* MBusData_SearchInputRegNode(u16_t u16Address);
extern sHoldingRegNode_t* MBusData_SearchHoldingRegNode(u16_t u16Address);
extern void MBusData_Initialize(void);
#endif
