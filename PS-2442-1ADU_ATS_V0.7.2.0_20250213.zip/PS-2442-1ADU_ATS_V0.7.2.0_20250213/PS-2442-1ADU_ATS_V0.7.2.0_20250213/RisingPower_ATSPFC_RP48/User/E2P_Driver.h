/****************************************************************************
 *	File	E2P_Driver.h
 * 	Brief	Header file for EEPROM driver
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/12/25 - Modify from Ollie Chen
 ****************************************************************************/

#ifndef _E2P_DRIVER_H_
#define _E2P_DRIVER_H_

#include "CONFIG_Define.h"

/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/
typedef enum eE2p_Tag
{
    E2p_Tag_1,
    E2p_Tag_Num,
}eE2p_Tag_t;

typedef enum eE2pDriverState
{
    E2P_STATE_IDLE,         ///< EEPROM is idle and accepted for next operation
    E2P_STATE_BUSY,         ///< EEPROM is busy
    E2P_STATE_READY,        ///< EEPROM finished an operation and wait for a confirmation to reset
    E2P_STATE_ERROR,        ///< EEPROM triggered an operate error and wait for reset
}eE2pDriverState_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef struct sE2pDriverInfo
{
    u16_t u16Tag;
    u32_t u32MemorySize;
    u16_t u16PageSize;
    u16_t (*pfMemoryWrite)(struct sE2pDriverInfo* psE2pDrvInfo, u32_t u32RegAddr, u16_t u16WrLen, u8_t* pu8WrBuff);
    u16_t (*pfMemoryRead)(struct sE2pDriverInfo* psE2pDrvInfo, u32_t u32RegAddr, u16_t u16RdLen, u8_t* pu8RdBuff);
    eE2pDriverState_t (*pfGetDriverState)(struct sE2pDriverInfo* psE2pDrvInfo);
    void (*pfResetDriver)(struct sE2pDriverInfo* psE2pDrvInfo);
}sE2pDriverInfo_t;

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void E2pDrv_Initialize(void);
extern sE2pDriverInfo_t* E2pDrv_GetDriverInformation(u16_t u16Tag);

#endif
