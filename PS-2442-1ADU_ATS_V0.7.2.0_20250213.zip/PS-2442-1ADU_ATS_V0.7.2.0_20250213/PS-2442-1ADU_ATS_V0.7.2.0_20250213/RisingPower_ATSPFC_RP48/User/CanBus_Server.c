/****************************************************************************
 *	File	CanBus_Server.c
 * 	Brief	CanBus Server Application
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 *	 History 2021/05/13 - 1st release
 ****************************************************************************/

#include <string.h>
#include "CANBus_Server.h"
#include "CANBus_Data.h"
#include "SERV_CRC.h"
#include "SERV_LOG.h"
#include "E2P_BlackBox.h"
#include "FLASH_CommonRam.h"



/****************************************************************************
	Private parameter definition
****************************************************************************/
#define GET_A_CommType			0x1F000000
#define GET_BB_Address			0x00FF0000
#define GET_CC_Command			0x0000FF00
#define GET_DD_ExtCommand		0x000000FF

#define Shift_A_CommType		24
#define Shift_BB_Address		16
#define Shift_CC_Command		8

#define Polling_Time			48	// 48ms(1s/sensor number), unit is 1ms
									// 48 -> 1008ms
									// 47 -> 987ms

// specify filter
#define Fetch_Slot_Number		0x0000000F
#define Filter_Slot_Number		0xFFFFFFF0
#define Filter_Slot_Number_D2D	0xFFF0FFF0
#define Filter_TargetAddress	0x00FF0000
#define Fetch_TargetAddress_C0	0x00C00000
#define Fetch_TargetAddress_00	0x00000000
#define ID_BBU_DeviceFail		0x000002D0
#define ID_BBU_Heartbeat		0x010001D0
#define ID_BBU_RSOC				0x03A031D0
#define ID_D2D_ReadPower		0x03A013B0
#define ID_PSC_HeartBeat        0x010001A0





/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 542 -> 314
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(CANBusServer_Stuff_RealTime_Payload, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Clear_Data, ".TI.ramfunc");
#pragma CODE_SECTION(CANBusServer_BBU_Listen_Handler, ".TI.ramfunc");
#pragma CODE_SECTION(CANBusServer_PushTransaction, ".TI.ramfunc");
#pragma CODE_SECTION(CANBusServer_Write_Handler, ".TI.ramfunc");
#pragma CODE_SECTION(CANBusServer_Rx_Callback, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Tx_Callback, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Variable_Data, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Push_CANBUS_Data, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Broadcast, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Polling_SensorData, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_1s_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_1ms_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Tx_Handler, ".TI.ramfunc");
//#pragma CODE_SECTION(CANBusServer_Background_Process, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declare
****************************************************************************/

/****************************************************************************
	Public variable declare
****************************************************************************/
sCANBusServer_t tsCANBusServer;


/**
 *  @brief  Fill payload to Tx Buffer
 *  @param  pu8Dest
 *  @param  pu8Src
 *  @param  u8Length
 *  @retval None
 */
static inline void CANBusServer_Stuff_RealTime_Payload(u8_t* pu8Dest, u8_t* pu8Src, u8_t u8Len, u8_t u8Array)
{
    if (tsCANBusServer.u8DataComposition == eMEMORY_COMPOSITION_SEQUENTIAL)
    {
        while (u8Len)
        {
            memcpy(pu8Dest, pu8Src, 1);
            u8Len -= 1;
            pu8Dest += 1;
            pu8Src += 1;
        }
    }
    else if (tsCANBusServer.u8DataComposition == eMEMORY_COMPOSITION_CASCADE)
    {
        while (u8Len)
        {
            // More than two bytes of data
        	if (u8Len >= 2)
            {
            	if (u8Array == 1)
            	{
            	    // Source data is 8bit
            		*pu8Dest = (u8_t)((*pu8Src) & 0x00FF);
					*(pu8Dest+1) = (u8_t)((*(pu8Src+1)) & 0x00FF);
					pu8Src += 1;
            	}
				else
				{
				    // Source data is 16bit
					__WordToLByte(pu8Dest, *((u16_t*)pu8Src));
				}          
                u8Len -= 2;
                pu8Dest += 2;
                pu8Src += 1;
            }
        	// Only one byte of data
            else
            {
                memcpy(pu8Dest, pu8Src, 1);
                u8Len -= 1;
                pu8Dest += 1;
                pu8Src += 1;
            }
        }
    }
}

/**
 *  @brief  Stuff history payload to transmitter Buffer
 *  @param  pu8Dest: Pointer to transmitter buffer
 *  @param  pu8Src: Pointer to source of history
 *  @param  u8Length: payload length
 *  @retval None
 */

/*
static void CANBusServer_Stuff_History_Payload(u8_t* pu8Dest, u8_t* pu8Src, u8_t u8Len)
{
    memcpy(pu8Dest, pu8Src, u8Len);
}
*/

/**
 *  @brief  CANBus clear data
 *  @retval None
 */
static inline void CANBusServer_Clear_Data(sCANDataFrame_t* psCANDataFrame)
{
	u16_t i;
	
	for (i=0; i<CAN_BUFF_SIZE; i++)
	{
		psCANDataFrame->pu8Data[i] = 0;
	}
}

/**
 *  @brief  CANBus push transaction
 *  @retval None
 */
static void CANBusServer_PushTransaction(sCANBusPageData_t* psPageData, u8_t TargetAddress)
{   
	u32_t u32ID_A;	// comm type
	u32_t u32ID_BB;	// target address
	u32_t u32ID_CC;	// comm
	u32_t u32ID_DD;	// ext comm
	u8_t  u8Datalength; // push data length
	
	// Canbus Tx Buffer full-condition 1
	if ((tsCANBusServer.u16PushIndex == (CANBUS_SERVER_TX_BUFF-1)) &&
		(tsCANBusServer.u16WriteIndex == 0))
	{
		return;
	}

	// Canbus Tx Buffer full-condition 2
	if ((tsCANBusServer.u16PushIndex + 1) == tsCANBusServer.u16WriteIndex)
	{
		return;
	}

	// Claer data
	CANBusServer_Clear_Data(&tsCANBusServer.sTxData[tsCANBusServer.u16PushIndex]);
	u8Datalength = 0;

	// Push Transaction
	u32ID_A = (u32_t)tsCANBusServer.psCmd->u8Command_Type;
	u32ID_BB = (u32_t)TargetAddress;
	u32ID_CC = (u32_t)tsCANBusServer.psCmd->u8Command;
	u32ID_DD = tsCANBusServer.u32DeviceAddressNumber;
	tsCANBusServer.sTxData[tsCANBusServer.u16PushIndex].u32ID = (u32ID_A << Shift_A_CommType) | (u32ID_BB << Shift_BB_Address) | (u32ID_CC << Shift_CC_Command) | u32ID_DD;
	
	// one page or multi page data
	while (psPageData)
	{	
		CANBusServer_Stuff_RealTime_Payload(&tsCANBusServer.sTxData[tsCANBusServer.u16PushIndex].pu8Data[u8Datalength], psPageData->pu8ReadBuff, psPageData->u8Length, psPageData->u8Array);
		u8Datalength += psPageData->u8Length;

		if (tsCANBusServer.psCmd->u8Page == CANBUS_Multi_PAGE)
		{
			psPageData = psPageData->psNext;
		}
		else
		{
			psPageData = NULL;
		}
	}
	
	tsCANBusServer.sTxData[tsCANBusServer.u16PushIndex].u16Length = (u16_t)u8Datalength;
	tsCANBusServer.u16PushIndex += 1;

	if (tsCANBusServer.u16PushIndex == CANBUS_SERVER_TX_BUFF)
	{
		tsCANBusServer.u16PushIndex = 0;
	}
}

/**
 *  @brief  CANBus Listen BBU status word
 *  @retval None
 */
static void CANBusServer_BBU_Listen_Handler(sCANDataFrame_t* psDataFrame)
{
	u16_t u16Slot_Number;

	u16Slot_Number = (u16_t)(psDataFrame->u32ID & Fetch_Slot_Number);

	if ((u16Slot_Number > 0) && (u16Slot_Number < 7))
	{
		if (((psDataFrame->u32ID & Filter_Slot_Number) == ID_BBU_DeviceFail) ||
			((psDataFrame->u32ID & Filter_Slot_Number) == ID_BBU_Heartbeat))
		{			
			tsLog.nBBU_Status_Word[u16Slot_Number - 1].u16All = __LByteToWord(psDataFrame->pu8Data);
		}
		else if ((psDataFrame->u32ID & Filter_Slot_Number) == ID_BBU_RSOC)
		{			
			tsLog.u32BBU_RSOC[u16Slot_Number - 1] = __LByteToDWord(psDataFrame->pu8Data);
		}
	
		tsLog.u8BBU_TIMEOUT[u16Slot_Number - 1] = SET_LOG_HEARTBEAT_TIMEOUT;
	}
}

/**
 *  @brief  CANBus Listen D2D Read Power
 *  @retval None
 */
static void CANBusServer_D2D_Listen_ReadPower(sCANDataFrame_t* psDataFrame)
{
	u16_t u16Slot_Number;

	u16Slot_Number = (u16_t)(psDataFrame->u32ID & Fetch_Slot_Number);

	if ((u16Slot_Number > 0) && (u16Slot_Number < 7))
	{
		tsLog.u32D2D_ReadPower[u16Slot_Number - 1] = __LByteToDWord(psDataFrame->pu8Data);
		tsLog.u8D2D_TIMEOUT[u16Slot_Number - 1] = SET_LOG_HEARTBEAT_TIMEOUT;
	}
}

/**
 *  @brief  CANBus Write Handler
 *  @retval None
 */
static void CANBusServer_Write_Handler(sCANBusPageData_t* psPageData, sCANDataFrame_t* psDataFrame)
{
    /* Build guard variable write request message */
    /*  In PMBus, due to each command is mapping to each guard variable node, so...
     *  The offset of Access request is 0 
     *  The length of Access request is Write Length
     */

	u16_t u16WriteIndex;
    sGuardVarAccessRequest_t sAccessRequest;

	u16WriteIndex = 0;
    sAccessRequest.u16Offset = 0;


	sCANBusPageData_t* psPageDatabuff = psPageData;

	// check data length
	if (psDataFrame->u16Length > tsCANBusServer.psCmd->u8WriteLength)
	{
		Log_Status_CML(STATUS_CML_BIT_INVALID_DATA);
	}

	// Check data validity
	while (psPageData)
	{
		sAccessRequest.pu8Data = &psDataFrame->pu8Data[0 + u16WriteIndex];
    	sAccessRequest.u16Length = psPageData->u8Length;
	
    	if (GuardVarList_CheckRequest(psPageData->psWriteBuff, sAccessRequest) == RequestDenied)
        {
        	Log_Status_CML(STATUS_CML_BIT_INVALID_DATA);
       		return;
        }
		
        // If the requested page is all page, we need to get to next page data structure
        if (tsCANBusServer.psCmd->u8Page == CANBUS_Multi_PAGE)
        {
        	u16WriteIndex += psPageData->u8Length;
        	psPageData = psPageData->psNext;
        }
        else
        {
         	psPageData = NULL;
        }
	}
        
    // After checked validity of data with all requested page, return to first element
    psPageData = psPageDatabuff;
	u16WriteIndex = 0;

    // Write data
    while (psPageData)
    {
    	sAccessRequest.pu8Data = &psDataFrame->pu8Data[0 + u16WriteIndex];
    	sAccessRequest.u16Length = psPageData->u8Length;
		
        GuardVarList_WriteRequest(psPageData->psWriteBuff, sAccessRequest);
            
        if (tsCANBusServer.psCmd->u8Page == CANBUS_Multi_PAGE)
        {
        	u16WriteIndex += psPageData->u8Length;
            psPageData = psPageData->psNext;
        }
        else
        {
            psPageData = NULL;
        }
    }
}

/**
 *  @brief  CANBus Server Rx call back from peripheral can module
 *	@Note	Parse Rx Frame
 *  @retval None
 */
void CANBusServer_Rx_Callback(sCANDataFrame_t* psDataFrame)
{
	// Listen BBU devicefail and heartbeat
	if (((psDataFrame->u32ID & Filter_Slot_Number) == ID_BBU_DeviceFail) ||
		((psDataFrame->u32ID & Filter_Slot_Number) == ID_BBU_Heartbeat) ||
		((psDataFrame->u32ID & Filter_Slot_Number) == ID_BBU_RSOC))
	{
		CANBusServer_BBU_Listen_Handler(psDataFrame);
	}
	// Listen D2D Read Poewr
	else if ((psDataFrame->u32ID & Filter_Slot_Number_D2D) == ID_D2D_ReadPower)

	{
		CANBusServer_D2D_Listen_ReadPower(psDataFrame);
	}
    else if (psDataFrame->u32ID == ID_PSC_HeartBeat)
    {
    // Listen PSC heart beat and change Unix_TimeStamp
      Log_TimeStamp_Shift(__LByteToDWord(psDataFrame->pu8Data));
    }
	// Listen target Address, only accept 0xC0~0xC6, 0x00
	else if (((psDataFrame->u32ID & Filter_TargetAddress) == Fetch_TargetAddress_00) ||
			 ((psDataFrame->u32ID & Filter_TargetAddress) == Fetch_TargetAddress_C0) ||
			 ((psDataFrame->u32ID & Filter_TargetAddress) == tsCANBusServer.u32DeviceAddressNumber_Shift))
	{		
		// Step2: check Command
		tsCANBusServer.u8ID_A_CommType = (u8_t)((psDataFrame->u32ID & GET_A_CommType) >> Shift_A_CommType);
		tsCANBusServer.u8ID_BB_Address = (u8_t)((psDataFrame->u32ID & GET_BB_Address) >> Shift_BB_Address);
		tsCANBusServer.u8ID_CC_Command = (u8_t)((psDataFrame->u32ID & GET_CC_Command) >> Shift_CC_Command);
		tsCANBusServer.u8ID_DD_ExtCommand = (u8_t)(psDataFrame->u32ID & GET_DD_ExtCommand);

    	tsCANBusServer.psCmd = CANBusData_GetCommandStructure(tsCANBusServer.u8ID_A_CommType, tsCANBusServer.u8ID_CC_Command);

		if (tsCANBusServer.psCmd == NULL)
		{
			Log_Status_CML(STATUS_CML_BIT_INVALID_COMMAND);
			return;
		}
	
		// Step3: Got pageData
    	sCANBusPageData_t* psPageData = tsCANBusServer.psCmd->psData;
    
		if (psPageData)
    	{
    		// Step4: select Read/Write/RW/special
    		if (tsCANBusServer.psCmd->u8Protocol == CANBUS_Protocol_Read)
			{
				CANBusServer_PushTransaction(psPageData, CAN_System_Address);
			}
			else if (tsCANBusServer.psCmd->u8Protocol == CANBUS_Protocol_Write)
			{
				CANBusServer_Write_Handler(psPageData, psDataFrame);
			}
			else if (tsCANBusServer.psCmd->u8Protocol == CANBUS_Protocol_WandR)
			{
				// Write data first and then push data (ack)
				CANBusServer_Write_Handler(psPageData, psDataFrame);
				CANBusServer_PushTransaction(psPageData, CAN_System_Address);
			}
			else if (tsCANBusServer.psCmd->u8Protocol == CANBUS_Protocol_WorR)
			{
				// Read
				if (psDataFrame->u16Length == 0)
				{
					CANBusServer_PushTransaction(psPageData, CAN_System_Address);
				}
				// Write
				else
				{
					CANBusServer_Write_Handler(psPageData, psDataFrame);
				}
			}
   		}
	}
}

/**
 *  @brief  CANBus Server Tx call back when Tx transmit finished
 *  @retval None
 */
void CANBusServer_Tx_Callback(void)
{
	if (tsCANBusServer.u16EmergencyAccept)
	{
		tsCANBusServer.u16EmergencyRequest = 0;
		tsCANBusServer.u16EmergencyAccept = 0;
	}
	else
	{
		tsCANBusServer.u16WriteIndex += 1;
	
		if (tsCANBusServer.u16WriteIndex == CANBUS_SERVER_TX_BUFF)
		{
			tsCANBusServer.u16WriteIndex = 0;
		}
	}
}

/**
 *  @brief  CANBus Server Push Variable data
 *  @note	Callback from Canbus Data
 */
void CANBusServer_Variable_Data(u8_t u8COMMAND, u8_t* pu8data)
{
	u8_t u8Length;
	u8_t u8CommandCode = pu8data[0];
	sCANBusCmdStr_t* psCmdbuff = CANBusData_GetCommandStructure(CANBUS_COMMTYPE_VARIABLE, u8CommandCode);

	if (psCmdbuff != NULL)
	{
		GET_LOG_VARIABLE[0] = 0; // ACK
		GET_LOG_VARIABLE[1] = u8CommandCode;
		
		// Write
		if (u8COMMAND == CANBUS_CMD_SET_VARIABLE)
		{
			sCANDataFrame_t sDataFramebuff;
			sDataFramebuff.u16Length = psCmdbuff->u8WriteLength;

			if (sDataFramebuff.u16Length == 1)
			{
				sDataFramebuff.pu8Data[0] = pu8data[1];
			}
			else if (sDataFramebuff.u16Length == 2)
			{
				sDataFramebuff.pu8Data[0] = pu8data[1];
				sDataFramebuff.pu8Data[1] = pu8data[2];
			}
			else if (sDataFramebuff.u16Length == 4)
			{
				sDataFramebuff.pu8Data[0] = pu8data[1];
				sDataFramebuff.pu8Data[1] = pu8data[2];
				sDataFramebuff.pu8Data[2] = pu8data[3];
				sDataFramebuff.pu8Data[3] = pu8data[4];
			}
			
			CANBusServer_Write_Handler(psCmdbuff->psData, &sDataFramebuff);
		}

		// Read
		if ((u8CommandCode == CANBUS_CMD_STABILIZATION_DELAY) ||
		    (u8CommandCode == CANBUS_CMD_NOMINAL_VOLTAGE))
		{
			__WordToLByte(&GET_LOG_VARIABLE[2], *((u16_t*)psCmdbuff->psData->pu8ReadBuff));
			u8Length = 4;
		}
		else if (u8CommandCode == CANBUS_CMD_BMC_UNIX_TIMESTAMP)
		{
			__DWordToLByte(&GET_LOG_VARIABLE[2], *((u32_t*)psCmdbuff->psData->pu8ReadBuff));
			u8Length = 6;
		}
		else
		{
			GET_LOG_VARIABLE[2] = *(psCmdbuff->psData->pu8ReadBuff);
			u8Length = 3;
		}
	}
	else
	{
		// Return NACK if target variable provided is not defined for the target device
		GET_LOG_VARIABLE[0] = 1; //NACK
		u8Length = 1;
	}

	tsCANBusServer.psCmd->psData->u8Length = u8Length;
}

/**
 *  @brief  CANBus Server Push Data to Transaction
 *  @note
 */
void CANBusServer_Push_CANBUS_Data(u8_t u8CommandType, u8_t u8CommandCode, u8_t u8TargetAddress)
{
	tsCANBusServer.psCmd = CANBusData_GetCommandStructure(u8CommandType, u8CommandCode);
	sCANBusPageData_t* psPageData = tsCANBusServer.psCmd->psData;
	CANBusServer_PushTransaction(psPageData, u8TargetAddress);
}

/**
 *  @brief  CANBus Server Push Data to Transaction for emergency
 *  @note   Priority transmission of urgent data
 */
static void CANBusServer_Push_Emergency_Data(u8_t u8CommandType, u8_t u8CommandCode, u8_t u8TargetAddress)
{
	u32_t u32ID_A;	// comm type
	u32_t u32ID_BB;	// target address
	u32_t u32ID_CC;	// comm
	u32_t u32ID_DD;	// ext comm
	u8_t  u8Datalength = 0; // push data length

	tsCANBusServer.psCmd = CANBusData_GetCommandStructure(u8CommandType, u8CommandCode);
	sCANBusPageData_t* psPageData = tsCANBusServer.psCmd->psData;

	// Claer data
	CANBusServer_Clear_Data(&tsCANBusServer.sTxDataEmergency);

	// Push Transaction
	u32ID_A = (u32_t)tsCANBusServer.psCmd->u8Command_Type;
	u32ID_BB = (u32_t)u8TargetAddress;
	u32ID_CC = (u32_t)tsCANBusServer.psCmd->u8Command;
	u32ID_DD = tsCANBusServer.u32DeviceAddressNumber;
	tsCANBusServer.sTxDataEmergency.u32ID = (u32ID_A << Shift_A_CommType) | (u32ID_BB << Shift_BB_Address) | (u32ID_CC << Shift_CC_Command) | u32ID_DD;
	
	// one page or multi page data
	while (psPageData)
	{	
		CANBusServer_Stuff_RealTime_Payload(&tsCANBusServer.sTxDataEmergency.pu8Data[u8Datalength], psPageData->pu8ReadBuff, psPageData->u8Length, psPageData->u8Array);
		u8Datalength += psPageData->u8Length;

		if (tsCANBusServer.psCmd->u8Page == CANBUS_Multi_PAGE)
		{
			psPageData = psPageData->psNext;
		}
		else
		{
			psPageData = NULL;
		}
	}
	
	tsCANBusServer.sTxDataEmergency.u16Length = (u16_t)u8Datalength;
	tsCANBusServer.u16EmergencyRequest = 1;
}

/**
 *  @brief  CANBus Server broadcast
 *  @retval None
 */
static inline void CANBusServer_Broadcast(void)
{
	if (tsCANBusServer.nBroadcast.u16All)
	{
		if (tsCANBusServer.nBroadcast.u16Bits.u1AC_LOSS)
		{
			CANBusServer_Push_Emergency_Data(CANBUS_COMMTYPE_EMERGENCY, CANBUS_CMD_AC_LOSS, CAN_Broadcast_Address);
			tsCANBusServer.nBroadcast.u16Bits.u1AC_LOSS = 0;
		}

		if (tsCANBusServer.nBroadcast.u16Bits.u1AC_RECOVER)
		{
			CANBusServer_Push_Emergency_Data(CANBUS_COMMTYPE_EMERGENCY, CANBUS_CMD_AC_RECOVER, CAN_Broadcast_Address);
			tsCANBusServer.nBroadcast.u16Bits.u1AC_RECOVER = 0;
		}

		if (tsCANBusServer.nBroadcast.u16Bits.u1ATSPSU_FAIL)
		{
			CANBusServer_Push_Emergency_Data(CANBUS_COMMTYPE_EMERGENCY, CANBUS_CMD_DEVICE_FAIL, CAN_Broadcast_Address);
			tsCANBusServer.nBroadcast.u16Bits.u1ATSPSU_FAIL = 0;
		}

		if (tsCANBusServer.nBroadcast.u16Bits.u1HEARTBEAT)
		{
			CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_NMT, CANBUS_CMD_HEARTBEAT, CAN_Broadcast_Address);
			tsCANBusServer.nBroadcast.u16Bits.u1HEARTBEAT = 0;
		}

		if (tsCANBusServer.nBroadcast.u16Bits.u1COMPATIBILITY)
		{
			CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_NMT, CANBUS_CMD_COMPATIBILITY_NUMBER, CAN_Broadcast_Address);
			tsCANBusServer.nBroadcast.u16Bits.u1COMPATIBILITY = 0;
		}
	}

	/* //Reserved this function
	if (tsCANBusServer.nTransmit.u16Bits.u1VBulk_Protect)
	{
        CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_NMT, CANBUS_CMD_FAULT_RECOVERY, CAN_System_Address);
        tsCANBusServer.nTransmit.u16Bits.u1VBulk_Protect = 0;
	}*/
}

/**
 *  @brief  CANBus Server polling sensor data
 *  @retval
 *  @note   Fixed time transmission
 */
static inline void CANBusServer_Polling_SensorData(void)
{
	CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_SENSOR_DATA, pu8SensorData[tsCANBusServer.u16PollingData], CAN_System_Address);

	tsCANBusServer.u16PollingData ++;

	if (tsCANBusServer.u16PollingData >= eCANBUS_SENSOR_Num)
	{
		tsCANBusServer.u16PollingData = 0;
	}
}

/**
 *  @brief  CANBus Server periodically process
 *  @retval None
 */
void CANBusServer_1s_Periodically_Process(void)
{
	tsCANBusServer.u32DeviceAddressNumber = (u32_t)tsCANBusServer.u8DeviceAddress + (u32_t)tsCANBusServer.u16DeviceAddress_Number;
	tsCANBusServer.u32DeviceAddressNumber_Shift = tsCANBusServer.u32DeviceAddressNumber << Shift_BB_Address;

    if ((GET_LOG_D2DAliveFlag || tsLog.u8D2D_TIMEOUT[tsCANBusServer.u16DeviceAddress_Number - 1]) &&
        (GET_LOG_CANBUS_SILENCE == 0))
    {
		SET_CANBUS_SERVER_BC_HEARTBEAT;
		SET_CANBUS_SERVER_BC_COMPATIBILITY;
	}
}

/**
 *  @brief  CANBus Server Periodically Process
 *  @note   Polling each sensor data per 25ms
 */
void CANBusServer_1ms_Periodically_Process(void)
{
	if (tsCANBusServer.u16PollingTime >= Polling_Time)
	{
		tsCANBusServer.u16PollingTime = 1;

		if ((GET_LOG_D2DAliveFlag || tsLog.u8D2D_TIMEOUT[tsCANBusServer.u16DeviceAddress_Number - 1]) &&
			(GET_LOG_CANBUS_SILENCE == 0))
		{
			CANBusServer_Polling_SensorData();
		}
	}
	else
	{
		tsCANBusServer.u16PollingTime ++;
	}
}

/**
 *  @brief  CANBus Tx handler in while loop
 *  @retval None
 */
static inline void CANBusServer_Tx_Handler(void)
{
	if (PeriCAN_IsTxIDLE() == TRUE)
	{
		if (tsCANBusServer.u16EmergencyRequest)
		{
			tsCANBusServer.u16EmergencyAccept = 1;
			PeriCAN_TxRequest(&tsCANBusServer.sTxDataEmergency);
		}
		else if (tsCANBusServer.u16PushIndex != tsCANBusServer.u16WriteIndex)
		{
			PeriCAN_TxRequest(&tsCANBusServer.sTxData[tsCANBusServer.u16WriteIndex]);
		}
	}
}

/**
 *  @brief  Peripheral - CANBus Server Background Process
 *  @retval While loop
 */
void CANBusServer_Background_Process(void)
{
	CANBusServer_Broadcast();
	CANBusServer_Tx_Handler();
}

/**
 *  @brief  clear push and write index
 *  @Note 	Disable push data during PS kill(PSU plug out)
 */
void CANBusServer_Disable_Push_Data(void)
{
	tsCANBusServer.nBroadcast.u16All = 0;
	tsCANBusServer.u16EmergencyRequest = 0;
//	tsCANBusServer.u16PushIndex = 0;
//	tsCANBusServer.u16WriteIndex = 0;
}

/**
 *  @brief  Initial CANBus Server
 *  @retval None
 */
void CANBusServer_Initialize(void)
{
	memset(&tsCANBusServer, 0, sizeof(tsCANBusServer));

	tsCANBusServer.u8DataComposition = eMEMORY_COMPOSITION_CASCADE;
	tsCANBusServer.u8WriteProtect = DEFAULT_WRITE_PROTECT;

	tsCANBusServer.u8DeviceAddress = CAN_ATS_Device_Address;
	tsCANBusServer.u16DeviceAddress_Number = 1;
	tsCANBusServer.u32DeviceAddressNumber = (u32_t)tsCANBusServer.u8DeviceAddress + (u32_t)tsCANBusServer.u16DeviceAddress_Number;
	tsCANBusServer.u32DeviceAddressNumber_Shift = tsCANBusServer.u32DeviceAddressNumber << Shift_BB_Address;
	tsCANBusServer.u16PollingTime = 1;
	tsCANBusServer.u16PollingData = 0;

}
 
