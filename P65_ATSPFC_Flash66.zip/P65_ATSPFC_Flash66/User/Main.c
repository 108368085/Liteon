/****************************************************************************
 *	File	Main.c
 *	Brief	WMW2.0 Application Entry
 *	Note
 *	Author	Adonis Wang
 *	Ver 	01
 *	History 2020/10/29 - 1st release
 *	History modify from kroran project by ollie chen
 *
 *  Debug	PeriDacB_SetValue(PERI_DAC_1V0)
 *	Debug	SET_GPIO_DEBUG1_H
 ****************************************************************************/


/* Include all head files of related peripheral */
#include "f28x_project.h"
#include "Peripheral.h"
#include "CONFIG_Define.h"
#include "device.h"
#include <string.h>

/* Include all head files of related service */
#include "SysTime.h"


/****************************************************************************
	Private parameter definition 
****************************************************************************/ 

/****************************************************************************
	Private macro definition
****************************************************************************/ 

/****************************************************************************
	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/ 

/****************************************************************************
	Private variable declaration
****************************************************************************/ 

/****************************************************************************
*	Brief	Main entry
*	Note	
****************************************************************************/
void main(void)
{

    /* Initialize System Control: PLL, WatchDog, Enable peripheral Clocks */
//	InitSysCtrl();

    Device_init();

    /* Clear all interrupts */
    DINT;

	/*
     * Initialize the PIE/CPU control register to their default state.
     * The default state  is all PIE/CPU interrupts disabled and flags are cleared
     */
    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;

	/*
	 * Initialize the PIE vector table with pointers to the shell Interrupt Service Routines (ISR).
     * This will populate the entire table, even if the interrupt is not used in this example
     */
    InitPieVectTable();

	/* Initialize Peripherals */
    Peripheral_Initialize();


    /* Enable Pie interrupts */
    EnableInterrupts();

    /* Enable global interrupts and higher priority real-time debug events */
    EINT;   // Enable Global interrupt INTM
    ERTM;   // Enable Global real-time interrupt DBGM
    
    
    /* Initial Service */
	Service_Initialize();

	/* Enable Watch Dog */
#ifdef EnableWatchDog	
	ServiceDog();
	EALLOW;
	WdRegs.WDCR.all = 0x002F;	//840ms reset
	EDIS;	
#endif

    /* Enable Peripheral */
    Peripheral_Start();
//    PeriDacA_SetValue(PERI_DAC_3V3);
//    PeriDacC_SetValue(PERI_DAC_3V3);

    while (1)
    {
#ifdef EnableWatchDog
		ServiceDog();
#endif
        SysTime();
    }
}
