/****************************************************************************
 *	File	Peripheral_CAN.c
 * 	Brief	Configure and control CAN module on TI 28004x platform
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/12/10 - 1st release
 ****************************************************************************/

/****************************************************************************
*	Included Files
****************************************************************************/
#include <CONFIG_RisingPower.h>
#include "F28x_Project.h"
#include "sw_prioritized_isr_levels.h"
#include "driverlib.h"
#include "device.h"
#include "Peripheral_CAN.h"
#include <string.h>
#include "CANBus_Server.h"

#ifdef Enable_DCAN


/****************************************************************************
    Private parameter definition
****************************************************************************/
#define CAN_Bit_Rate_1M     1000000UL	//1MHz
#define CAN_Bit_Rate_125K   125000UL    //125KHz
#define CAN_Bit_Time		10
#define TX_MSG_OBJ_ID 		21
#define RX_MSG_OBJ_ID		1
#define RX_MSG_MID_ID		5
#define RX_MSG_EOB_ID		7	//5


//*****************************************************************************
//
// The following are defines for the bit fields in the CAN_IF1CMD register
//
//*****************************************************************************
#define CAN_IFxCMD_MSG_NUM_S      (u32_t)0U
#define CAN_IFxCMD_MSG_NUM_M      (u32_t)0xFFU        // OBJ Message Number
#define CAN_IFxCMD_DMAACTIVE      (u32_t)0x4000U      // DMA Status
#define CAN_IFxCMD_BUSY           (u32_t)0x8000U      // Busy Flag
#define CAN_IFxCMD_DATA_B         (u32_t)0x10000U     // Access Data Bytes 4-7
#define CAN_IFxCMD_DATA_A         (u32_t)0x20000U     // Access Data Bytes 0-3
#define CAN_IFxCMD_TXRQST         (u32_t)0x40000U     // Access Transmission Request
#define CAN_IFxCMD_CLRINTPND      (u32_t)0x80000U     // Clear Interrupt Pending Bit
#define CAN_IFxCMD_CONTROL        (u32_t)0x100000U    // Access Control Bits
#define CAN_IFxCMD_ARB            (u32_t)0x200000U    // Access Arbitration Bits
#define CAN_IFxCMD_MASK           (u32_t)0x400000U    // Access Mask Bits
#define CAN_IFxCMD_DIR            (u32_t)0x800000U    // Write/Read Direction, 1:Write; 0:Read

//*****************************************************************************
//
// The following are defines for the bit fields in the CAN_IF1MSK register
// Enable for acceptance filtering
//
//*****************************************************************************
#define CAN_IFxMSK_MSK_C          (u32_t)0x00F80000U  // Identifier Mask
#define CAN_IFxMSK_MSK_A          (u32_t)0x1EFF00F8U  // Identifier Mask
#define CAN_IFxMSK_MSK_S          (u32_t)0U			  // No filter ID
#define CAN_IFxMSK_MSK_M          (u32_t)0x1FFFFFFFU  // Identifier Mask, 0:don't care(mask), 1:care
#define CAN_IFxMSK_MDIR           (u32_t)0x40000000U  // Mask Message Direction
#define CAN_IFxMSK_MXTD           (u32_t)0x80000000U  // Mask Extended Identifier

//*****************************************************************************
//
// The following are defines for the bit fields in the CAN_IF1ARB register
//
//*****************************************************************************
#define CAN_IFxARB_ID_C           (u32_t)0x1FC7FFFFU  // Message ID only accept target is 0xC0~0xC7
#define CAN_IFxARB_ID_A           (u32_t)0x0100FFD7U  // Message ID only accept Broadcast from BBU, 0x0X00XXDX
#define CAN_IFxARB_ID_S           (u32_t)0U			  // Message ID only accept 0x00000000
#define CAN_IFxARB_ID_M           (u32_t)0x1FFFFFFFU  // Message Identifier, accept all
#define CAN_IFxARB_DIR            (u32_t)0x20000000U  // Message Direction, 1:transmit; 0:receive
#define CAN_IFxARB_XTD            (u32_t)0x40000000U  // Extended Identifier
#define CAN_IFxARB_MSGVAL         (u32_t)0x80000000U  // Message Valid

//*****************************************************************************
//
// The following are defines for the bit fields in the CAN_IF1MCTL register
//
//*****************************************************************************
#define CAN_IFxMCTL_DLC_S         (u32_t)0U
#define CAN_IFxMCTL_DLC_M         (u32_t)0xFU         // Data length code
#define CAN_IFxMCTL_EOB           (u32_t)0x80U        // End of Block
#define CAN_IFxMCTL_TXRQST        (u32_t)0x100U       // Transmit message is requested and is not yet done
#define CAN_IFxMCTL_RMTEN         (u32_t)0x200U       // Remote Enable
#define CAN_IFxMCTL_RXIE          (u32_t)0x400U       // Receive Interrupt Enable
#define CAN_IFxMCTL_TXIE          (u32_t)0x800U       // Transmit Interrupt Enable
#define CAN_IFxMCTL_UMASK         (u32_t)0x1000U      // Use Acceptance Mask
#define CAN_IFxMCTL_INTPND        (u32_t)0x2000U      // Interrupt Pending
#define CAN_IFxMCTL_MSGLST        (u32_t)0x4000U      // Message Lost
#define CAN_IFxMCTL_NEWDAT        (u32_t)0x8000U      // New Data

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

typedef enum ePeriCAN_Port
{
    ePeriCAN_Port_A = 0,
    ePeriCAN_Port_B,
}ePeriCAN_Port_t;

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/


// RAMLS0_6 : 337 -> 318
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(PeriCAN_TxRequest, ".TI.ramfunc");
//#pragma CODE_SECTION(PeriCAN_1ms_Periodically_Process, ".TI.ramfunc");
#pragma CODE_SECTION(PeriCAN_Background_Process, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/
sPeriCAN_Driver_t ptsPeriCANDriver[ePeriCAN_Channel_Num];


/**
 *  @brief  CAN_A0 interrupt
 *  @retval None
 */
/*
#ifdef USE_CAN_CHANNEL_A
__interrupt void PeriCAN_Channel_A0_Interrupt_Handler(void)
{
    // Branch mechanism code Start
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER9.all;   // Store IER
    IER |= M_INT9;
    IER &= MINT9;                                           // Set "global" priority
    PieCtrlRegs.PIEIER9.all &= MG9_5;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");
    EINT;
    
    // User code Start
	u32_t Status_INT, Status_ES;
	
	Status_INT = ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_INT.all;

	// Simply read and discard the status to clear the interrupt.
	Status_ES = ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_ES.all;

    //
    // If the cause is a controller status interrupt, then get the status
    //
    if (Status_INT == CAN_INT_INT0ID_STATUS)
    {	
        // Check to see if an error occurred.
        if(((Status_ES  & 0x7) != CAN_STATUS_LEC_MSK) &&
           ((Status_ES  & 0x7) != CAN_STATUS_LEC_NONE))
        {
            // Set a flag to indicate some errors may have occurred.
        }
    }

	if(Status_ES & CAN_STATUS_RXOK)
	{
		ptsPeriCANDriver[ePeriCAN_Channel_A].nFlag.u16Bits.u1RxOK = TRUE;
	}

	if(Status_ES & CAN_STATUS_TXOK)
	{
		ptsPeriCANDriver[ePeriCAN_Channel_A].nFlag.u16Bits.u1TxOK = TRUE;
	}



    //
    // Clear the global interrupt flag for the CAN interrupt line
    //
    ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_GLB_INT_CLR.bit.INT0_FLG_CLR = 1;
    
    // User code End
    
    DINT;
    PieCtrlRegs.PIEIER9.all = TempPIEIER;                   // Restore IER
    
}
#endif
*/


/**
 *  @brief  CAN Module reset
 *  @retval None
 */

/*
static void CAN_Module_Reset(sPeriCAN_Driver_t* psDriver)
{
	

	// Initialize the CAN controllers
	CAN_initModule(CANA_BASE);

	psDriver->psInstance->CAN_CTL.bit.ABO = 1;

	// Set up the CAN bus bit rate,and bit Time
	CAN_setBitRate(CANA_BASE, SYS_CLK_OUT, CAN_Bit_Rate, CAN_Bit_Time);

    // Start CAN module A and B operations
    CAN_startModule(CANA_BASE);



	// Place CAN controller in init state, regardless of previous state.
	psDriver->psInstance->CAN_CTL.bit.Init = 1;

    // Force module to reset state
    //
    EALLOW;
    psDriver->psInstance->CAN_CTL.bit.SWR = 1;
    EDIS;

    //
    // Delay for 14 cycles
    //
    SysCtl_delay(1U);

	// Clear Init
	psDriver->psInstance->CAN_CTL.bit.Init = 0;
}
*/


/**
 *  @brief  Read message object
 *  @retval None
 */
static inline void PeriCAN_ReadMessage(sPeriCAN_Driver_t* psDriver)
{
	u16_t i;
	
	psDriver->sRxCANHandler.sDataFrame.u32ID = psDriver->psInstance->CAN_IF1ARB.bit.ID;

	psDriver->sRxCANHandler.sDataFrame.u16Length = psDriver->psInstance->CAN_IF1MCTL.bit.DLC;

	psDriver->sRxCANHandler.sDataFrame.pu8Data[0] = (u8_t)psDriver->psInstance->CAN_IF1DATA.bit.Data_0;
	psDriver->sRxCANHandler.sDataFrame.pu8Data[1] = (u8_t)psDriver->psInstance->CAN_IF1DATA.bit.Data_1;
	psDriver->sRxCANHandler.sDataFrame.pu8Data[2] = (u8_t)psDriver->psInstance->CAN_IF1DATA.bit.Data_2;
	psDriver->sRxCANHandler.sDataFrame.pu8Data[3] = (u8_t)psDriver->psInstance->CAN_IF1DATA.bit.Data_3;
	psDriver->sRxCANHandler.sDataFrame.pu8Data[4] = (u8_t)psDriver->psInstance->CAN_IF1DATB.bit.Data_4;
	psDriver->sRxCANHandler.sDataFrame.pu8Data[5] = (u8_t)psDriver->psInstance->CAN_IF1DATB.bit.Data_5;
	psDriver->sRxCANHandler.sDataFrame.pu8Data[6] = (u8_t)psDriver->psInstance->CAN_IF1DATB.bit.Data_6;
	psDriver->sRxCANHandler.sDataFrame.pu8Data[7] = (u8_t)psDriver->psInstance->CAN_IF1DATB.bit.Data_7;

	// save number of length byte data and reset extra data
	for (i = psDriver->sRxCANHandler.sDataFrame.u16Length; i < 8; i++)
	{
		psDriver->sRxCANHandler.sDataFrame.pu8Data[i] = 0;
	}
}

/**
 *  @brief  Send message object
 *  @retval None
 */
static inline void PeriCAN_SendMessage(sPeriCAN_Driver_t* psDriver)
{
	u16_t i;
	u32_t DATA_A = 0;
	u32_t DATA_B = 0;	
	u8_t* pu8Data = &psDriver->sTxCANHandler.psDataFrame->pu8Data[0];
	u32_t ID = psDriver->sTxCANHandler.psDataFrame->u32ID;
	u16_t Lengh = psDriver->sTxCANHandler.psDataFrame->u16Length;
	
	for (i = 0; i < Lengh; i++)
	{
		if (i < 4)
		{
			DATA_A += ((u32_t)pu8Data[i] << (i*8));
		}
		else
		{
			DATA_B += ((u32_t)pu8Data[i] << ((i-4)*8));
		}
	}


	psDriver->psInstance->CAN_IF2DATA.all = DATA_A; // Data 0 is the first, and Data 7 is the last byte to be transmitted or received
	psDriver->psInstance->CAN_IF2DATB.all = DATA_B;	
	psDriver->psInstance->CAN_IF2ARB.all  = CAN_IFxARB_DIR | CAN_IFxARB_XTD | CAN_IFxARB_MSGVAL | ID; // Message Identifier
	psDriver->psInstance->CAN_IF2MCTL.all = CAN_IFxMCTL_EOB | Lengh;
	psDriver->psInstance->CAN_IF2CMD.all  = CAN_IFxCMD_DIR | CAN_IFxCMD_ARB | CAN_IFxCMD_CONTROL | CAN_IFxCMD_TXRQST | CAN_IFxCMD_DATA_A | CAN_IFxCMD_DATA_B | (u32_t)TX_MSG_OBJ_ID;
}

/**
 *  @brief  Monitor can register to check CAN module error, status, and interrupt register
 *  @Note 	Two option for user choose, ISR got status or while loop monitor status
 *  @retval None
 */
static inline void Monitor_CAN_Reg(sPeriCAN_Driver_t* psDriver)
{

	// Simply read and discard the status to clear the interrupt.
	psDriver->nESReg.u16All = (u16_t)psDriver->psInstance->CAN_ES.all;

	psDriver->nERRCReg.u16All = (u16_t)psDriver->psInstance->CAN_ERRC.all;

    // Check to see if an error occurred.
    if ((psDriver->nESReg.u16Bits.u3LEC != CAN_STATUS_LEC_MSK) &&
        (psDriver->nESReg.u16Bits.u3LEC != CAN_STATUS_LEC_NONE))
    {
    	// Set a flag to indicate some errors may have occurred.
    	if (psDriver->u16CANerrorFlag < Q15_)
    	{
    		psDriver->u16CANerrorFlag ++; 
    	} 
    }

	// This bit will be set independent of the result of acceptance filtering
	// Any ID get will assert RxOK, but only filter data could assert the NewDat flag
	if (psDriver->nESReg.u16Bits.u1RxOK)
	{
		psDriver->nFlag.u16Bits.u1RxOK = TRUE;
	}

	if (psDriver->nESReg.u16Bits.u1TxOK)
	{
		psDriver->nFlag.u16Bits.u1TxOK = TRUE;
	}
}

/**
 *  @brief  CAN Rx Handler
 *  @retval None
 */
static inline void CAN_Rx_Handler(sPeriCAN_Driver_t* psDriver)
{
	if ((psDriver->nFlag.u16Bits.u1RxOK == TRUE) &&
		(psDriver->nFlag.u16Bits.u1CANError == FALSE))
	{
		psDriver->nFlag.u16Bits.u1RxOK = FALSE;	

		for (psDriver->sRxCANHandler.u32FIFOIndex = RX_MSG_OBJ_ID; psDriver->sRxCANHandler.u32FIFOIndex <= RX_MSG_EOB_ID; psDriver->sRxCANHandler.u32FIFOIndex++)
		{
			while (psDriver->psInstance->CAN_IF1CMD.bit.Busy == TRUE)
			{
			}

			psDriver->psInstance->CAN_IF1CMD.all = CAN_IFxCMD_ARB | CAN_IFxCMD_CONTROL | CAN_IFxCMD_DATA_A | CAN_IFxCMD_DATA_B | CAN_IFxCMD_TXRQST | psDriver->sRxCANHandler.u32FIFOIndex;
			
			while (psDriver->psInstance->CAN_IF1CMD.bit.Busy == TRUE)
			{
			}

			if (psDriver->psInstance->CAN_IF1MCTL.bit.NewDat)
			{
				PeriCAN_ReadMessage(psDriver);
				CANBusServer_Rx_Callback(&psDriver->sRxCANHandler.sDataFrame);
			}	
		}
	}
}

/**
 *  @brief  CAN Tx Handler
 *  @retval None
 */
static inline void CAN_Tx_Handler(sPeriCAN_Driver_t* psDriver)
{
	switch (psDriver->sTxCANHandler.eState)
	{
		case CAN_STATE_IDLE:
		{
			if ((psDriver->nFlag.u16Bits.u1TxRequest == TRUE) &&
				(psDriver->nFlag.u16Bits.u1CANError == FALSE))
			{
				psDriver->nFlag.u16Bits.u1TxTransacting = TRUE;
				psDriver->nFlag.u16Bits.u1TxRequest = FALSE;
				psDriver->sTxCANHandler.u16BusErrorDelay = 0;
				
				while (psDriver->psInstance->CAN_IF2CMD.bit.Busy == TRUE)
				{
				}

				// IFx Write data to mailbox
				PeriCAN_SendMessage(psDriver);
				psDriver->nFlag.u16Bits.u1TxOK = FALSE;
				psDriver->sTxCANHandler.eState = CAN_STATE_ACCOMPLISH;						
			}
		}
		break;
				
		case CAN_STATE_ACCOMPLISH:
		{
			if (psDriver->nFlag.u16Bits.u1TxOK == TRUE)
			{
				psDriver->nFlag.u16Bits.u1TxTransacting = FALSE;
				psDriver->sTxCANHandler.eState = CAN_STATE_IDLE;
				CANBusServer_Tx_Callback();
			}
		}
		break;

		case CAN_STATE_ERROR:
		{
			psDriver->nFlag.u16Bits.u1TxTransacting = FALSE;
			psDriver->sTxCANHandler.eState = CAN_STATE_IDLE;
		}
		break;
		
		default:
		break;
	}
}

/**
 *  @brief  CAN main handler
 *  @retval None
 */
static inline void CAN_Handler(sPeriCAN_Driver_t* psDriver)
{
	Monitor_CAN_Reg(psDriver);
	CAN_Rx_Handler(psDriver);
	CAN_Tx_Handler(psDriver);
}

/**
 *  @brief  Check Can bus Tx Idel
 *  @retval 
 */
u16_t PeriCAN_IsTxIDLE(void)
{
	if (ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.eState == CAN_STATE_IDLE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/**
 *  @brief  Canbus server request to send data
 *  @retval 
 */
void PeriCAN_TxRequest(sCANDataFrame_t* psDataFrame_Src)
{
	if (ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.eState == CAN_STATE_IDLE)
	{
		ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.psDataFrame = psDataFrame_Src;
		ptsPeriCANDriver[ePeriCAN_Channel_A].nFlag.u16Bits.u1TxRequest = TRUE;
	}
}

/**
 *  @brief  Peripheral - CAN 1ms periodically Process
 *  @retval While loop
 */
void PeriCAN_1ms_Periodically_Process(void)
{
	if (ptsPeriCANDriver[ePeriCAN_Channel_A].nFlag.u16Bits.u1TxTransacting)
	{
		if (ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.u16BusErrorDelay < PERI_CAN_Tx_BusErrorDelay)
		{
			ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.u16BusErrorDelay ++;
		}
		else
		{
			//CAN_Module_Reset(&ptsPeriCANDriver[ePeriCAN_Channel_A]);
			ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.eState = CAN_STATE_ERROR;
		}
	}
}

/**
 *  @brief  Peripheral - CAN Background Process
 *  @retval While loop
 */
void PeriCAN_Background_Process(void)
{
	CAN_Handler(&ptsPeriCANDriver[ePeriCAN_Channel_A]);
}


/**
 *  @brief  Start Peripheral CAN
 *  @retval None
 */
void PeriCAN_Start(void)
{

#ifdef USE_CAN_CHANNEL_A
    CAN_startModule(CANA_BASE);
#endif

#ifdef USE_CAN_CHANNEL_B
    CAN_startModule(CANB_BASE);
#endif

}

/**
 *  @brief  Stop Peripheral CAN
 *  @retval None
 */
void PeriCAN_Stop(void)
{

#ifdef USE_CAN_CHANNEL_A
		ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_CTL.bit.Init = 1;
#endif
	
#ifdef USE_CAN_CHANNEL_B
		ptsPeriCANDriver[ePeriCAN_Channel_B].psInstance->CAN_CTL.bit.Init = 1;
#endif

}

/**
 *  @brief  Initialize Rx message object
 *  @retval None
 */
static inline void PeriCAN_Setup_RxMessageObject(sPeriCAN_Driver_t* psDriver, u16_t ID)
{

	while (psDriver->psInstance->CAN_IF1CMD.bit.Busy == TRUE)
	{
	}

	psDriver->psInstance->CAN_IF1MSK.all  = CAN_IFxMSK_MXTD | CAN_IFxMSK_MDIR | CAN_IFxMSK_MSK_S;
	psDriver->psInstance->CAN_IF1ARB.all  = CAN_IFxARB_XTD | CAN_IFxARB_MSGVAL | CAN_IFxARB_ID_M;

	if (ID == RX_MSG_EOB_ID)
	{
		psDriver->psInstance->CAN_IF1MCTL.all = CAN_IFxMCTL_UMASK | CAN_IFxMCTL_EOB;
	}
	else
	{
		psDriver->psInstance->CAN_IF1MCTL.all = CAN_IFxMCTL_UMASK;
	}
	
	psDriver->psInstance->CAN_IF1CMD.all  = CAN_IFxCMD_DIR | CAN_IFxCMD_MASK | CAN_IFxCMD_ARB | CAN_IFxCMD_CONTROL | (u32_t)ID;
}


/**
 *  @brief  Initial CAN A module
 *  @retval None
 */
 
#ifdef USE_CAN_CHANNEL_A
static inline void CAN_A_Initialize(void)
{
	u16_t i;
	
    ptsPeriCANDriver[ePeriCAN_Channel_A].u16Port = ePeriCAN_Port_A;
    ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance = &CanaRegs;

	// Initialize GPIO and configure GPIO pins for CANTX/CANRX on module A and B
	GPIO_setPinConfig(GPIO_70_CANA_RX);
	GPIO_setPinConfig(GPIO_71_CANA_TX);

	// Initialize the CAN controllers
	CAN_initModule(CANA_BASE);

	// The Auto-Bus-On feature is enabled
	ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_CTL.bit.ABO = 1;

	// Set up the CAN bus bit rate to 1MHz,and bit Time to 10
	// bitRate is the desired bit rate (bits/sec)
	// bitTime is the number of time quanta per bit required for desired
	// bit time (Tq) and must be in the range from 8 to 25
	CAN_setBitRate(CANA_BASE, SYS_CLK_OUT, CAN_Bit_Rate_1M, CAN_Bit_Time);

/*
    // Enable CAN_A interrupts items
    ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_CTL.bit.IE0 = 1;
	ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_CTL.bit.SIE = 1;
	ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_CTL.bit.EIE = 1;

	EALLOW;

	// Re-mapped ISR functions in PIE vector table
	PieVectTable.CANA0_INT = &PeriCAN_Channel_A0_Interrupt_Handler;
		
	// Enable CPU INT9 which is connected to CAN INT
	PieCtrlRegs.PIEIER9.bit.INTx5 = 1;
	IER |= M_INT9;

	EDIS;

	// CAN Global interrupt Enable function
	ptsPeriCANDriver[ePeriCAN_Channel_A].psInstance->CAN_GLB_INT_EN.bit.GLBINT0_EN = 1;
*/

	// Initialize the receive message object used for receiving CAN messages
	for (i=RX_MSG_OBJ_ID; i<=RX_MSG_EOB_ID; i++)
    {
		PeriCAN_Setup_RxMessageObject(&ptsPeriCANDriver[ePeriCAN_Channel_A], i);
	}

}
#endif


/**
 *  @brief  Initial CAN module
 *  @retval None
 */
void PeriCAN_Initialize(void)
{
	u16_t i;
	
	for (i=0; i<ePeriCAN_Channel_Num; i++)
	{
		memset(&ptsPeriCANDriver[i], 0, sizeof(ptsPeriCANDriver[i]));
	}

#ifdef USE_CAN_CHANNEL_A
	CAN_A_Initialize();
#endif
	
#ifdef USE_CAN_CHANNEL_B
	CAN_B_Initialize();
#endif

}

#endif /* Enable_DCAN */


