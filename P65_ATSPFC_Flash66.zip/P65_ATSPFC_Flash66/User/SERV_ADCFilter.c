/****************************************************************************
 *	File	SERV_ADCFilter.c
 * 	Brief	ADC Signals Filter Process
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/29 - 1st release
 ****************************************************************************/
#include <CONFIG_RisingPower.h>
#include "SERV_ADCFilter.h"
#include "SERV_LOG.h"
#include "Peripheral.h"
#include <string.h>
#include <math.h>
#include <CLA_Control_PFC.h>


/****************************************************************************
	Private parameter definition 
****************************************************************************/
//#define Samplingfrequency_PWM   	(f32_t)EPWM7_FREQ
//#define Samplingfrequency_10k  		(f32_t)CPU_TIMER_10KHz_FREQUENCY
//#define Samplingfrequency_1k  		(f32_t)CPU_TIMER_1KHz_FREQUENCY
//#define Samplingfrequency_10ms 		(f32_t)100
//#define Samplingfrequency_100ms 	(f32_t)10
//
//#define filterfrequency_Iac 		(f32_t)57000	// unit is 1Hz
//#define filterfrequency_Vac_PFC		(f32_t)100000	// unit is 1Hz
//#define filterfrequency_Vac_ATS		(f32_t)5500		// unit is 1Hz
//#define filterfrequency_Vbulk 		(f32_t)500		// unit is 1Hz
//#define filterfrequency_Vaux 		(f32_t)50		// unit is 1Hz
//#define filterfrequency_T	 		(f32_t)1		// unit is 1Hz

//#define filterparemeterA_Iac		(u16_t)(((2 * 3.14 * filterfrequency_Iac / Samplingfrequency_PWM) / (1 + 2 * 3.14 * filterfrequency_Iac / Samplingfrequency_PWM)) * Q12_)
//#define filterparemeterA_Vac_PFC 	(u16_t)(((2 * 3.14 * filterfrequency_Vac_PFC / Samplingfrequency_PWM) / (1 + 2 * 3.14 * filterfrequency_Vac_PFC / Samplingfrequency_PWM)) * Q12_)
//#define filterparemeterA_Vac_ATS	(u16_t)(((2 * 3.14 * filterfrequency_Vac_ATS / Samplingfrequency_PWM) / (1 + 2 * 3.14 * filterfrequency_Vac_ATS / Samplingfrequency_PWM)) * Q12_)
//#define filterparemeterA_Vbulk		(u16_t)(((2 * 3.14 * filterfrequency_Vbulk / Samplingfrequency_10k) / (1 + 2 * 3.14 * filterfrequency_Vbulk / Samplingfrequency_10k)) * Q12_)
//#define filterparemeterA_Vaux		(u16_t)(((2 * 3.14 * filterfrequency_Vaux / Samplingfrequency_10ms) / (1 + 2 * 3.14 * filterfrequency_Vaux / Samplingfrequency_10ms)) * Q12_)
//#define filterparemeterA_T			(u16_t)(((2 * 3.14 * filterfrequency_T / Samplingfrequency_100ms) / (1 + 2 * 3.14 * filterfrequency_T / Samplingfrequency_100ms)) * Q12_)
//
//#define filterparemeterB_Iac		(u16_t)(Q12_ - filterparemeterA_Iac)
//#define filterparemeterB_Vac_PFC	(u16_t)(Q12_ - filterparemeterA_Vac_PFC)
//#define filterparemeterB_Vac_ATS	(u16_t)(Q12_ - filterparemeterA_Vac_ATS)
//#define filterparemeterB_Vbulk		(u16_t)(Q12_ - filterparemeterA_Vbulk)
//#define filterparemeterB_Vaux		(u16_t)(Q12_ - filterparemeterA_Vaux)
//#define filterparemeterB_T			(u16_t)(Q12_ - filterparemeterA_T)

#define VrefCali					5		// Adjust Vref value to solve current balance, vaule by measurement
#define VrefCali_count				500		// 50ms, unit is 0.1ms


/****************************************************************************
	Private macro definition
****************************************************************************/ 

/****************************************************************************
	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 163
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Iac_Calibration, ".TI.ramfunc");
#pragma CODE_SECTION(Vac_Digital_filter_calculation, ".TI.ramfunc");
#pragma CODE_SECTION(Iac_Digital_filter_calculation, ".TI.ramfunc");
#pragma CODE_SECTION(DC_Digital_filter_calculation, ".TI.ramfunc");
#pragma CODE_SECTION(ADCFilter_PWM_Instant_Process, ".TI.ramfunc");
#pragma CODE_SECTION(ADCFilter_10k_Instant_Process, ".TI.ramfunc");
#pragma CODE_SECTION(ADCFilter_1ms_Periodically_Process, ".TI.ramfunc");
#pragma CODE_SECTION(ADCFilter_100ms_Periodically_Process, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declaration
****************************************************************************/
sADCfilter_AC_t tsADCfilter_AC[ADC_AC_Tag_Num];
sADCfilter_DC_t tsADCfilter_DC[ADC_DC_Tag_Num];


/***************************************************************************
*   brief  Current calibration for hall sensor
*   note   update to Line
****************************************************************************/
static void Iac_Calibration(sADCfilter_AC_t* sfilter)
{
	// integral 50 times
	sfilter->u16Vref_Previous = (u16_t)(((f32_t)sfilter->u16ADCPervious_Q12 * 0.1) + ((f32_t)sfilter->u16Vref_Previous * 0.9));
	sfilter->u16Vref_Count ++;

	if (sfilter->u16Vref_Count > VrefCali_count)
	{
		sfilter->i16Vref_Cali = (i16_t)(sfilter->u16Vref_Previous >> 1) + VrefCali;
		sfilter->u16Vref_Finished = TRUE;
	}
}

/***************************************************************************
*   brief  FW Digital filter for Vac (Line - neutral)
*   note   update to Line
****************************************************************************/
static void Vac_Digital_filter_calculation(sADCfilter_AC_t* sfilter_L, sADCfilter_AC_t* sfilter_N)
{
	i16_t i16Temp;
//	i32_t i32Temp;
	u16_t u16ADC_L;
	u16_t u16ADC_N;

	u16ADC_L = *(sfilter_L->pu16ADCInstant_Q12);
	u16ADC_N = *(sfilter_N->pu16ADCInstant_Q12);
	i16Temp = ((i16_t)u16ADC_L) - ((i16_t)u16ADC_N);
//	i32Temp = (((i32_t)i16Temp * sfilter_L->u16Filterparameter_A) >> 12) + (((i32_t)sfilter_L->i16ADCPervious_Q12 * sfilter_L->u16Filterparameter_B) >> 12);
//	sfilter_L->i16ADCPervious_Q12 = (i16_t)i32Temp;
	//Remove filter to improve litht load PF
	sfilter_L->i16ADCPervious_Q12 = i16Temp;
	sfilter_L->u16ADCPervious_Q12 = (abs)(sfilter_L->i16ADCPervious_Q12);
}

/***************************************************************************
*   brief  FW Digital filter for Iac (Sine wave with 1.65 level)
*   note   current is up side down from HW placement
****************************************************************************/
static void Iac_Digital_filter_calculation(sADCfilter_AC_t* sfilter)
{
	i32_t i32Temp;
	u16_t u16TempInstant;
	i16_t i16TempInstant;

	u16TempInstant = *(sfilter->pu16ADCInstant_Q12);
	i16TempInstant = ((i16_t)u16TempInstant - sfilter->i16Vref_Cali) << 1; //Hallsensor center level is 1.65V cause value is Q11 , after calibration need multiply by Q1 to Q12-type
	i16TempInstant = -i16TempInstant;	//current invert base on PCB layout.
	i32Temp = (((i32_t)i16TempInstant * sfilter->u16Filterparameter_A) >> 12) + (((i32_t)sfilter->i16ADCPervious_Q12 * sfilter->u16Filterparameter_B) >> 12);
	sfilter->i16ADCPervious_Q12 = (i16_t)i32Temp;
	sfilter->u16ADCPervious_Q12 = (abs)(sfilter->i16ADCPervious_Q12);
}

/***************************************************************************
*   brief  FW Digital filter for DC input
*   note
****************************************************************************/
static void DC_Digital_filter_calculation(sADCfilter_DC_t* sfilter)
{
	u32_t u32Temp;
	u16_t u16TempInstant;

	u16TempInstant = *(sfilter->pu16ADCInstant_Q12);
	u32Temp = (((u32_t)u16TempInstant * sfilter->u16Filterparameter_A) >> 12) + (((u32_t)sfilter->u16ADCPervious_Q12 * sfilter->u16Filterparameter_B) >> 12);
	sfilter->u16ADCPervious_Q12 = (u16_t)u32Temp;
}

/***************************************************************************
*   brief  FW Digital filter in PWM clock loop
*   note   40Khz
****************************************************************************/
void ADCFilter_PWM_Instant_Process(void)
{
#ifndef Enable_CLA
	Vac_Digital_filter_calculation(&tsADCfilter_AC[PFC_Vac_L], &tsADCfilter_AC[PFC_Vac_N]);
	Vac_Digital_filter_calculation(&tsADCfilter_AC[ATS_Vac1_L], &tsADCfilter_AC[ATS_Vac1_N]);
	Vac_Digital_filter_calculation(&tsADCfilter_AC[ATS_Vac2_L], &tsADCfilter_AC[ATS_Vac2_N]);
	Iac_Digital_filter_calculation(&tsADCfilter_AC[PFC_IAC_A]);
	Iac_Digital_filter_calculation(&tsADCfilter_AC[PFC_IAC_B]);
    Iac_Digital_filter_calculation(&tsADCfilter_AC[PFC_IAC_C]);
#endif
}

/***************************************************************************
*   brief  FW Digital filter in 10kHz loop
*   note   10Khz
****************************************************************************/
void ADCFilter_10k_Instant_Process(void)
{
	DC_Digital_filter_calculation(&tsADCfilter_DC[DC_Bulk_DET]);
	DC_Digital_filter_calculation(&tsADCfilter_DC[DC_Bulk_OVP1]);
	DC_Digital_filter_calculation(&tsADCfilter_DC[DC_Bulk_OVP2]);
	tsADCfilter_AC[PFC_IAC].u16ADCPervious_Q12 = tsADCfilter_AC[PFC_IAC_A].u16ADCPervious_Q12 + tsADCfilter_AC[PFC_IAC_B].u16ADCPervious_Q12 + tsADCfilter_AC[PFC_IAC_C].u16ADCPervious_Q12;

	if (tsADCfilter_AC[PFC_IAC_C].u16Vref_Finished == FALSE)
	{
		Iac_Calibration(&tsADCfilter_AC[PFC_IAC_A]);
		Iac_Calibration(&tsADCfilter_AC[PFC_IAC_B]);
        Iac_Calibration(&tsADCfilter_AC[PFC_IAC_C]);
	}
}

/***************************************************************************
*   brief  FW Digital filter in 1kHz loop
*   note   
****************************************************************************/
void ADCFilter_1ms_Periodically_Process(void)
{
	DC_Digital_filter_calculation(&tsADCfilter_DC[DC_Aux_1]);
	DC_Digital_filter_calculation(&tsADCfilter_DC[DC_Aux_2]);
}

/***************************************************************************
*   brief  FW Digital filter in 10ms loop
*   note   
****************************************************************************/
void ADCFilter_10ms_Periodically_Process(void)
{
	;
}


/***************************************************************************
*   brief  FW Digital filter in 100ms loop
*   note   
****************************************************************************/
void ADCFilter_100ms_Periodically_Process(void)
{
	DC_Digital_filter_calculation(&tsADCfilter_DC[T_PFC]);
	DC_Digital_filter_calculation(&tsADCfilter_DC[T_Inlet]);
	DC_Digital_filter_calculation(&tsADCfilter_DC[T_ATS]);
	DC_Digital_filter_calculation(&tsADCfilter_DC[T_D2D]);
}

/***************************************************************************
*   brief  ADC Filter handler initialize
*   note   
****************************************************************************/
void ADCFilter_Initialize(void)
{
	u16_t i;

	for (i=0; i<ADC_AC_Tag_Num; i++)
    {
        memset(&tsADCfilter_AC[i], 0, sizeof(tsADCfilter_AC[i]));
		tsADCfilter_AC[i].eTag = (eADC_AC_Tag_t)i;
    }

	for (i=0; i<ADC_DC_Tag_Num; i++)
	{
		memset(&tsADCfilter_DC[i], 0, sizeof(tsADCfilter_DC[i]));
		tsADCfilter_DC[i].eTag = (eADC_DC_Tag_t)i;
	}
		
	// Connect ADC input address
#ifdef Enable_CLA
    tsADCfilter_AC[PFC_IAC_A].pu16ADCInstant_Q12    = (u16_t*)CLA_GET_ADC_I_PFC_A;
    tsADCfilter_AC[PFC_IAC_B].pu16ADCInstant_Q12    = (u16_t*)CLA_GET_ADC_I_PFC_B;
    tsADCfilter_AC[PFC_IAC_C].pu16ADCInstant_Q12    = (u16_t*)CLA_GET_ADC_I_PFC_C;
    tsADCfilter_AC[PFC_Vac_L].pu16ADCInstant_Q12    = (u16_t*)CLA_GET_ADC_V_PFC_L;
    tsADCfilter_AC[PFC_Vac_N].pu16ADCInstant_Q12    = (u16_t*)CLA_GET_ADC_V_PFC_N;
    tsADCfilter_AC[ATS_Vac1_L].pu16ADCInstant_Q12   = (u16_t*)CLA_GET_ADC_V_AC1_L;
    tsADCfilter_AC[ATS_Vac1_N].pu16ADCInstant_Q12   = (u16_t*)CLA_GET_ADC_V_AC1_N;
    tsADCfilter_AC[ATS_Vac2_L].pu16ADCInstant_Q12   = (u16_t*)CLA_GET_ADC_V_AC2_L;
    tsADCfilter_AC[ATS_Vac2_N].pu16ADCInstant_Q12   = (u16_t*)CLA_GET_ADC_V_AC2_N;

    tsADCfilter_DC[DC_Bulk_DET].pu16ADCInstant_Q12  = (u16_t*)CLA_GET_ADC_V_PFC_DET;
    tsADCfilter_DC[DC_Bulk_OVP1].pu16ADCInstant_Q12 = (u16_t*)CLA_GET_ADC_V_PFC_OVP1;
    tsADCfilter_DC[DC_Bulk_OVP2].pu16ADCInstant_Q12 = (u16_t*)CLA_GET_ADC_V_PFC_OVP2;
    tsADCfilter_DC[DC_Aux_1].pu16ADCInstant_Q12     = (u16_t*)CLA_GET_ADC_V_AUX1;
    tsADCfilter_DC[DC_Aux_2].pu16ADCInstant_Q12     = (u16_t*)CLA_GET_ADC_V_AUX2;
    tsADCfilter_DC[T_PFC].pu16ADCInstant_Q12        = (u16_t*)CLA_GET_ADC_T_PFC;
    tsADCfilter_DC[T_Inlet].pu16ADCInstant_Q12      = (u16_t*)CLA_GET_ADC_T_INLET;
    tsADCfilter_DC[T_ATS].pu16ADCInstant_Q12        = (u16_t*)CLA_GET_ADC_T_ATS;
    tsADCfilter_DC[T_D2D].pu16ADCInstant_Q12        = (u16_t*)CLA_GET_ADC_T_D2D;
#else
	tsADCfilter_AC[PFC_IAC_A].pu16ADCInstant_Q12 	= &GET_ADC_I_PFC_A;
	tsADCfilter_AC[PFC_IAC_B].pu16ADCInstant_Q12 	= &GET_ADC_I_PFC_B;
    tsADCfilter_AC[PFC_IAC_C].pu16ADCInstant_Q12    = &GET_ADC_I_PFC_C;
	tsADCfilter_AC[PFC_Vac_L].pu16ADCInstant_Q12 	= &GET_ADC_V_PFC_L;
	tsADCfilter_AC[PFC_Vac_N].pu16ADCInstant_Q12 	= &GET_ADC_V_PFC_N;
	tsADCfilter_AC[ATS_Vac1_L].pu16ADCInstant_Q12 	= &GET_ADC_V_AC1_L;
	tsADCfilter_AC[ATS_Vac1_N].pu16ADCInstant_Q12 	= &GET_ADC_V_AC1_N;
	tsADCfilter_AC[ATS_Vac2_L].pu16ADCInstant_Q12 	= &GET_ADC_V_AC2_L;
	tsADCfilter_AC[ATS_Vac2_N].pu16ADCInstant_Q12 	= &GET_ADC_V_AC2_N;
	
	tsADCfilter_DC[DC_Bulk_DET].pu16ADCInstant_Q12 	= &GET_ADC_V_PFC_DET;
	tsADCfilter_DC[DC_Bulk_OVP1].pu16ADCInstant_Q12 = &GET_ADC_V_PFC_OVP1;
	tsADCfilter_DC[DC_Bulk_OVP2].pu16ADCInstant_Q12 = &GET_ADC_V_PFC_OVP2;
	tsADCfilter_DC[DC_Aux_1].pu16ADCInstant_Q12		= &GET_ADC_V_AUX1;
	tsADCfilter_DC[DC_Aux_2].pu16ADCInstant_Q12 	= &GET_ADC_V_AUX2;
	tsADCfilter_DC[T_PFC].pu16ADCInstant_Q12		= &GET_ADC_T_PFC;
	tsADCfilter_DC[T_Inlet].pu16ADCInstant_Q12 		= &GET_ADC_T_INLET;
	tsADCfilter_DC[T_ATS].pu16ADCInstant_Q12 		= &GET_ADC_T_ATS;
	tsADCfilter_DC[T_D2D].pu16ADCInstant_Q12 		= &GET_ADC_T_D2D;
#endif

	// filter parameter configuration	
	tsADCfilter_AC[PFC_IAC_A].u16Filterparameter_A 	= filterparemeterA_Iac;
	tsADCfilter_AC[PFC_IAC_B].u16Filterparameter_A 	= filterparemeterA_Iac;
    tsADCfilter_AC[PFC_IAC_C].u16Filterparameter_A  = filterparemeterA_Iac;
	tsADCfilter_AC[PFC_Vac_L].u16Filterparameter_A 	= filterparemeterA_Vac_PFC;
	tsADCfilter_AC[PFC_Vac_N].u16Filterparameter_A 	= filterparemeterA_Vac_PFC;
	tsADCfilter_AC[ATS_Vac1_L].u16Filterparameter_A = filterparemeterA_Vac_ATS;
	tsADCfilter_AC[ATS_Vac1_N].u16Filterparameter_A = filterparemeterA_Vac_ATS;
	tsADCfilter_AC[ATS_Vac2_L].u16Filterparameter_A = filterparemeterA_Vac_ATS;
	tsADCfilter_AC[ATS_Vac2_N].u16Filterparameter_A = filterparemeterA_Vac_ATS;
	
	tsADCfilter_DC[DC_Bulk_DET].u16Filterparameter_A= filterparemeterA_Vbulk;
	tsADCfilter_DC[DC_Bulk_OVP1].u16Filterparameter_A= filterparemeterA_Vbulk;
	tsADCfilter_DC[DC_Bulk_OVP2].u16Filterparameter_A= filterparemeterA_Vbulk;
	tsADCfilter_DC[DC_Aux_1].u16Filterparameter_A 	= filterparemeterA_Vaux;
	tsADCfilter_DC[DC_Aux_2].u16Filterparameter_A 	= filterparemeterA_Vaux;
	tsADCfilter_DC[T_PFC].u16Filterparameter_A 		= filterparemeterA_T;
	tsADCfilter_DC[T_Inlet].u16Filterparameter_A 	= filterparemeterA_T;
	tsADCfilter_DC[T_ATS].u16Filterparameter_A 		= filterparemeterA_T;
	tsADCfilter_DC[T_D2D].u16Filterparameter_A 		= filterparemeterA_T;

	tsADCfilter_AC[PFC_IAC_A].u16Filterparameter_B 	= filterparemeterB_Iac;
	tsADCfilter_AC[PFC_IAC_B].u16Filterparameter_B 	= filterparemeterB_Iac;
    tsADCfilter_AC[PFC_IAC_C].u16Filterparameter_B  = filterparemeterB_Iac;
	tsADCfilter_AC[PFC_Vac_L].u16Filterparameter_B 	= filterparemeterB_Vac_PFC;
	tsADCfilter_AC[PFC_Vac_N].u16Filterparameter_B 	= filterparemeterB_Vac_PFC;
	tsADCfilter_AC[ATS_Vac1_L].u16Filterparameter_B = filterparemeterB_Vac_ATS;
	tsADCfilter_AC[ATS_Vac1_N].u16Filterparameter_B = filterparemeterB_Vac_ATS;
	tsADCfilter_AC[ATS_Vac2_L].u16Filterparameter_B = filterparemeterB_Vac_ATS;
	tsADCfilter_AC[ATS_Vac2_N].u16Filterparameter_B = filterparemeterB_Vac_ATS;
	
	tsADCfilter_DC[DC_Bulk_DET].u16Filterparameter_B= filterparemeterB_Vbulk;
	tsADCfilter_DC[DC_Bulk_OVP1].u16Filterparameter_B= filterparemeterB_Vbulk;
	tsADCfilter_DC[DC_Bulk_OVP2].u16Filterparameter_B= filterparemeterB_Vbulk;
	tsADCfilter_DC[DC_Aux_1].u16Filterparameter_B 	= filterparemeterB_Vaux;
	tsADCfilter_DC[DC_Aux_2].u16Filterparameter_B 	= filterparemeterB_Vaux;
	tsADCfilter_DC[T_PFC].u16Filterparameter_B 		= filterparemeterB_T;
	tsADCfilter_DC[T_Inlet].u16Filterparameter_B 	= filterparemeterB_T;
	tsADCfilter_DC[T_ATS].u16Filterparameter_B 		= filterparemeterB_T;
	tsADCfilter_DC[T_D2D].u16Filterparameter_B 		= filterparemeterB_T;
}


