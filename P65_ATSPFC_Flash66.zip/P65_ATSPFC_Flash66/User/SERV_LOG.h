/****************************************************************************
 *	File	SERV_LOG.h
 * 	Brief	Header file for Record PSUlog
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/12/25 - 1st Release
 ****************************************************************************/

#ifndef _SERV_LOG_H_
#define _SERV_LOG_H_

#include "CONFIG_Define.h"
#include "Handler_ATS.h"


/****************************************************************************
	Public parameter definition 
****************************************************************************/

#define SHELF_DEVICE_NUMBER			6


#define GET_LOG_VAC					tsLog.u16InputVoltage
#define GET_LOG_VAC_WOF				tsLog.u16InputVoltage_WOF
#define GET_LOG_IAC					tsLog.u16InputCurrent
#define GET_LOG_IAC1				tsLog.u16InputCurrent_S1
#define GET_LOG_IAC2				tsLog.u16InputCurrent_S2
#define GET_LOG_FRQ					tsLog.u16InputFrequency
#define GET_LOG_POWER				tsLog.u16InputPower
#define GET_LOG_POWER1				tsLog.u16InputPower_S1
#define GET_LOG_POWER2				tsLog.u16InputPower_S2
#define GET_LOG_AVGPOWER			tsLog.u16InputPower_AVG
#define GET_LOG_AVGPOWER1			tsLog.u16InputPower_AVG_S1
#define GET_LOG_AVGPOWER2			tsLog.u16InputPower_AVG_S2
#define GET_LOG_MAXPOWER			tsLog.u16InputPower_Max
#define GET_LOG_MAXPOWER1			tsLog.u16InputPower_Max_S1
#define GET_LOG_MAXPOWER2			tsLog.u16InputPower_Max_S2
#define GET_LOG_D2DMAXPOWER			tsLog.u16D2D_MaxPower

#define GET_LOG_SWITCH_TIME			tsLog.u32ATSwitchCNT
#define GET_LOG_TOT_SWITCH_TIME		tsLog.u32TotATSwitchCNT
#define GET_LOG_WORK_TIME			tsLog.u32PowerOnTime
#define GET_LOG_TOT_WORK_TIME		tsLog.u32TotPowerOnTime
#define GET_LOG_UNIX_TIME			tsLog.u32UnixTimeStamp
#define GET_LOG_VARIABLE			tsLog.pu8Variable

#define GET_LOG_STATUS_TRANSFER		tsLog.nStatusTransfer.u16All
#define GET_LOG_STATUS_RELAY_S1		tsLog.nInputQuality[ATS_InputTag_Input1].u8All
#define GET_LOG_STATUS_RELAY_S2		tsLog.nInputQuality[ATS_InputTag_Input2].u8All
#define GET_LOG_STATUS_RELAY_PFC	tsLog.nOutputQuality.u8All


#define GET_LOG_STATUS_PFC			tsLog.nStatusPFC.u16All
#define GET_LOG_STATUS_SRC			tsLog.nStatusATSource.u8All
#define GET_LOG_STATUS_WORD			tsLog.nStatusWord.u16All
#define GET_LOG_STATUS_TEMP			tsLog.nStatusTEMP.u8All
#define GET_LOG_STATUS_OTHER		tsLog.nStatusOther.u8All
#define GET_LOG_STATUS_INPUT		tsLog.nStatusInput.u16All
#define GET_LOG_STATUS_P2D			tsLog.nStatus_PFC2D2D.u16All
#define GET_LED_STATUS_P2D          tsLog.nLED_StatustoD2D.u16All // Update LED Status to D2D by ModBus
#define GET_PFC_BootMode            tsLog.nStatus_PFC2D2D.u16Bits.u1ATSInBootloader
#define GET_PFC_TemporaryFault      tsLog.u16Temporary_Fault
#define GET_PFC_PermanentFault      tsLog.u16Permanent_Fault
#define GET_LOG_STATUS_D2P			tsLog.nStatus_D2D2PFC.u16All
#define GET_D2P_DYNAMIC             tsLog.nStatus_D2D2PFC.u16Bits.u1Dynamic // For D2D dynamic load used
#define GET_LOG_STATUS_CML			tsLog.nStatusCML.u8All
#define GET_LOG_RESERVED			tsLog.u16Reserved
#define GET_LOG_STATUS_TRANSITION	tsLog.nStatus_Transition.u8All



#define SET_LOG_CLEARFAULT			tsLog.u8ClearFault
#define GET_LOG_FAULTINJECTACK		tsLog.u8FaultinjectACK
#define SET_LOG_D2DAliveCNT			tsLog.u16D2DAliveCNT
#define GET_LOG_D2DAliveFlag		tsLog.u16D2DAliveFlag
#define GET_LOG_PFCAliveCNT			tsLog.u16PFCAliveCNT
#define GET_LOG_PIN_Derating		tsLog.u16InputPower_Derating_WF
#define GET_LOG_PSU_REQ_OK			tsLog.nStatus_D2D2PFC.u16Bits.u1PSU_Req_OK  // from D2D by ModBus
#define GET_LOG_D2D_OK				tsLog.nStatus_D2D2PFC.u16Bits.u1D2D_OK      // from D2D by ModBus
#define SET_LOG_VBulkUVP            tsLog.nStatus_PFC2D2D.u16Bits.u1VBULK_UVP
#define SET_LOG_VBulkUVW            tsLog.nStatus_PFC2D2D.u16Bits.u1VBULK_UVW



#define GET_LOG_INTERNAL_DEBUGGER	tsLog.nInternal_Debugger.u8All
#define GET_LOG_MAIN_ISR_TOGGLE		tsLog.nInternal_Debugger.u8Bits.u1MAIN_ISR_TOGGLE
#define GET_LOG_FIXED_PWM			tsLog.nInternal_Debugger.u8Bits.u1FIXED_PWM
#define GET_LOG_CANBUS_SILENCE		tsLog.nInternal_Debugger.u8Bits.u1CANBUS_SILENCE
#define GET_LOG_TEMP_DISABLE		tsLog.nInternal_Debugger.u8Bits.u1TEMP_DISABLE

// Variable
#define SET_LOG_COMPATIBILITY_NUMBER	tsLog.u8COMPATIBILITY_NUMBER
#define SET_LOG_REQ_BBU_NUMBER		tsLog.u8REQ_BBU_NUMBER
#define SET_LOG_HEARTBEAT_TIMEOUT	tsLog.u8HEARTBEAT_TIMEOUT
#define GET_LOG_BBU_Valid			tsLog.u16BBU_Valid
#define GET_LOG_BBUMode_Valid       tsLog.u16BBUMode_Valid // For BBU mode used , Check if any Low_SOC is assert
#define GET_LOG_BBU_Valid_Count		tsLog.u8BBU_Valid_20_NUM
#define GET_LOG_FAULT_COUNT			tsLog.u8Fault_Count
#define GET_LOG_FAULT_COUNT_LIMIT	tsLog.u8Fault_Count_Limit
#define GET_LOG_FAULT_DELAY			tsLog.u8Fault_Delay
#define GET_LOG_NOMINAL_VOLTAGE     tsLog.u16NominalVoltage
#define GET_LOG_VBulk_Protect_CNT   tsLog.u32VBulk_Protect_CNT

// For debug used
#define Debug_1         tsLog.u32Debug_1
#define Debug_2         tsLog.u32Debug_2
#define Debug_3         tsLog.u32Debug_3
#define Debug_4         tsLog.u32Debug_4



/****************************************************************************
*	Public macro Definition
****************************************************************************/

/** Status CML bit definition */
#define STATUS_CML_BIT_INVALID_COMMAND          0x80
#define STATUS_CML_BIT_INVALID_DATA             0x40
#define STATUS_CML_BIT_PEC_FAILED               0x20
#define STATUS_CML_BIT_MESSAGE_FAILURES     	0x10
#define STATUS_CML_BIT_CPU_UTILIZATION_FAULT    0x08
#define STATUS_CML_BIT_MEMORY_UTILIZATION_FAULT 0x04
#define STATUS_CML_BIT_INTERNAL_COMM_WARNING    0x02
#define STATUS_CML_BIT_INTERNAL_COMM_FAULT   	0x01


/****************************************************************************
*	Public enumeration definition 
****************************************************************************/

typedef union nStatusWord
{
    u16_t u16All;
    struct
    {
        u16_t u3Reserved            : 3;
        u16_t u1CML                 : 1;    // Communication failure event
        u16_t u1ATS_PERMANENT_FAILURE : 1;
        u16_t u1ATS_TEMPERATURE     : 1;    // ATS has temperature event
        u16_t u1ATS_PRI_SRC_Fail    : 1;    // Primary source is invalid (S1 or S2 depending on shelf setting), 1:Primary source invalid, 0:Primary source valid
        u16_t u1ATS_AUX_FAIL        : 1;    // Auxiliary power supply for S1 or S2 failed

		u16_t u1BOOT                : 1;    // Connect to u1ATSInBootloader
		u16_t u1ATS_RELAY_C_FAIL    : 1;    // ATS relay C has failure(Inrush relay)
        u16_t u1ATS_RELAY_B_FAIL    : 1;    // ATS relay B has failure
        u16_t u1ATS_RELAY_A_FAIL    : 1;    // ATS relay A has failure
        u16_t u1ATS_S2_INPUT        : 1;    // ATS S2 has input power quality event
        u16_t u1ATS_S1_INPUT        : 1;    // ATS S1 has input power quality event
        u16_t u1ATS_IOUT            : 1;    // ATS Iout has over-current protection event
        u16_t u1Reserved_4    		: 1;    // 
    }u16Bits;
}nStatusWord_t;


typedef union nStatusTransfer
{
    u16_t u16All;
    struct
    {
        u16_t u1TransferByOverCurrent     	: 1;
        u16_t u1TransferByOverTemperature   : 1;
        u16_t u1TransferByUnderVoltage      : 1;
        u16_t u1TransferByOverVoltage       : 1;
        u16_t u1TransferByFreqError         : 1;
        u16_t u1TransferByHarmonics         : 1;
        u16_t u1TransferByManual            : 1;
        u16_t u1TransferByProtection        : 1;

		u16_t u1Transfer_S12         		: 1;
        u16_t u1Transfer_S21         		: 1;
        u16_t u1Transfer_S1B         		: 1;
        u16_t u1Transfer_S2B         		: 1;
        u16_t u1Transfer_BS1         		: 1;
        u16_t u1Transfer_BS2         		: 1;
        u16_t uReserved             		: 2;
    }u16Bits;
}nStatusTransfer_t;



typedef union nStatusATSource
{
    u8_t u8All;
    struct
    {
        u8_t u1Reserved        		: 1;
        u8_t u1Available_S2         : 1;
        u8_t u1Available_S1         : 1;
        u8_t u3Reserved             : 3;
        u8_t u1CurrentSource_S2     : 1;
        u8_t u1CurrentSource_S1     : 1;
    }u8Bits;
}nStatusATSource_t;



//STATUS_RELAY_A :AC1 , STATUS_INPUT : Byte0
//STATUS_RELAY_B :AC2 , STATUS_INPUT : Byte1
typedef union nInputQuality
{
    u8_t u8All;
    struct
    {
    	u8_t u1VIN_OHP				: 1;
        u8_t u1VIN_OHW				: 1;
        u8_t u1VIN_OFW				: 1;
        u8_t u1VIN_OFP				: 1;
        u8_t u1VIN_UVP				: 1;
        u8_t u1VIN_UVW				: 1;
        u8_t u1VIN_OVW				: 1;
        u8_t u1VIN_OVP				: 1;
    }u8Bits;
}nInputQuality_t;


//STATUS_RELAY_C :PFC , STATUS_INPUT: Byte2
typedef union nOutputQuality
{
    u8_t u8All;
    struct
    {
        u8_t u1PIN_OPW             	: 1;
		u8_t u1PIN_OPP           	: 1;
		u8_t u1IIN_OCW           	: 1;
        u8_t u1IIN_OCP           	: 1;
        u8_t uReserved				: 4;
    }u8Bits;
}nOutputQuality_t;


typedef union nStatusTEMP
{
    u8_t u8All;
    struct
    {
        u8_t u1ATS_UTP				: 1;
		u8_t u1ATS_UTW				: 1;
		u8_t u1ATS_OTW				: 1;
        u8_t u1ATS_OTP				: 1;
        u8_t u1Inlet_UTP			: 1;
        u8_t u1Inlet_UTW			: 1;
		u8_t u1Inlet_OTW			: 1;
        u8_t u1Inlet_OTP			: 1;
    }u8Bits;
}nStatusTEMP_t;


typedef union nStatusOther
{
    u8_t u8All;
    struct
    {
        u8_t u1AUX_S1_FAIL    		: 1;
        u8_t u1AUX_S2_FAIL    		: 1;
		u8_t u1RELAY_A_HW_FAIL    	: 1;
		u8_t u1RELAY_B_HW_FAIL    	: 1;
		u8_t u1RELAY_C_HW_FAIL    	: 1;
		u8_t u1RELAY_COUNT_FAIL		: 1;
        u8_t u1RELAY_COUNT_WARNING	: 1;
        u8_t uReserved             	: 1;
    }u8Bits;
}nStatusOther_t;


typedef union nStatusInput
{
    u16_t u16All;
    struct
    {
        u16_t u1PIN_OPW 			: 1;
        u16_t u1PIN_OPP 			: 1;
        u16_t u1IIN_OCW   			: 1;
        u16_t u1IIN_OCP		      	: 1;
        u16_t u1VIN_UVW       		: 1;
        u16_t u1VIN_UVP      		: 1;
        u16_t u1VIN_OVW      		: 1;
        u16_t u1VIN_OVP        		: 1;
        u16_t uReserved            	: 8;
    }u16Bits;
}nStatusInput_t;



typedef union nStatusPFC
{
    u16_t u16All;
    struct
    {
        u16_t u1PTCFault			: 1;
        u16_t u1SoftStartFault		: 1;
        u16_t u1Vbulk_OV			: 1;
        u16_t u1Vbulk_UV			: 1;
		u16_t u1ATS_Valid			: 1;
		u16_t u1ATS_Enable			: 1;
		u16_t u1PFC_Enable			: 1;
        u16_t u1D2D_Enable			: 1;

		u16_t u2BBU_Valid			: 2;
		u16_t u1BBU_Enable			: 1;
		u16_t u1PFC_Fault			: 1;
        u16_t u1Vbulk_OVW           : 1;
        u16_t u1Vbulk_UVW           : 1;
		u16_t uReserved            	: 2;
    }u16Bits;
}nStatusPFC_t;


typedef union nStatusPFCtoD2D
{
    u16_t u16All;
    struct
    {
        u16_t u1ATSInBootloader 	: 1;	// 1: ATS is in bootloader process, 0: ATS not in boot mode
//        u16_t u1TemporaryFault   	: 1;	// 1: ATS is experiencing temporary faults, 0: ATS no temporary fault
//        u16_t u1PermanentFault      : 1;	// 1: ATS is experiencing permanent faults, 0: ATS no permanent fault
        u16_t u1ATS_Fault           : 1;    // 1: ATS fault
        u16_t u1PFC_Fault           : 1;    // 1: PFC fault
        u16_t u1ACPowerCycle		: 1; 	// 1: AC ok, 0:AC non-ok, 0 transform 1 must be delay 1s
		u16_t u1Temp_PFC_UTP      	: 1;	// PFC thermal hotspot UTP
		u16_t u1Temp_PFC_UTW      	: 1;	// PFC thermal hotspot UTW
		u16_t u1Temp_PFC_OTW      	: 1;	// PFC thermal hotspot OTW
		u16_t u1Temp_PFC_OTP      	: 1;	// PFC thermal hotspot OTP
		u16_t u1D2D_Enable      	: 1;	// reflect GPIO D2D enable
		u16_t u1VBULK_OVP      		: 1;	// Vbulk OVP
		u16_t u1VBULK_UVP      		: 1;	// Vbulk UVP
		u16_t u1Temp_Inlet_OTP      : 1;	// Inlet thermal hotspot OTP
		u16_t u1Temp_ATS_OTP      	: 1;	// ATS thermal hotspot OTP
        u16_t u1VBULK_OVW           : 1;
        u16_t u1VBULK_UVW           : 1;
        u16_t uReserved            	: 1;
    }u16Bits;
}nStatusPFCtoD2D_t;


typedef union nStatusD2DtoPFC
{
    u16_t u16All;
    struct
    {
        u16_t u1Dynamic			 	: 1;	// For D2D dynamic used.
        u16_t u1D2D_STB_OK   		: 1;	// 1: D2D standby power good, 0: D2D standby power not OK
        u16_t u1D2DInBootloader     : 1;	// No used! , 1: D2D is in bootloader process, 0: D2D is not in bootloader process
		u16_t u1FAMode 				: 1;	// No used! , 1: Factory mode on, 0:Factory mode off
		u16_t u1PSU_Req_OK 			: 1;	// 1: PSU request OK for ATS bbu mode state machine
		u16_t u1D2D_OK 				: 1;	// No used! , 1: D2D Vo OK, 0:D2D Vo NOK
        u16_t uReserved            	: 10;
    }u16Bits;
}nStatusD2DtoPFC_t;

/* LED Status to D2D by ModBus */
typedef union nLED_StatustoD2D
{
    u16_t u16All;
    struct
    {
        u16_t u16LED : 16;
    }u16Bits;
}nLED_StatustoD2D_t;

typedef union nStatusCML
{
    u8_t u8All;
    struct
    {
        u8_t u1INTERNAL_COMM_FAULT		: 1;
        u8_t u1INTERNAL_COMM_WARNING    : 1;
		u8_t uReserved 					: 2;
		u8_t u1MESSAGE_FAILURES_FAULT   : 1;
		u8_t u1CHECKSUM_FAIL    		: 1;
		u8_t u1INVALID_DATA    			: 1;
        u8_t u1INVALID_COMM            	: 1;
    }u8Bits;
}nStatusCML_t;

typedef union nInternal_Debug
{
    u8_t u8All;
    struct
    {
        u8_t u1MAIN_ISR_TOGGLE			: 1;	// 0x01 Enable 10kHz interrupt resource by GPIO_Debug1
        u8_t u1FIXED_PWM			    : 1;	// 0x02 NA
		u8_t u1ENABLE_WATCHDOG_RESET	: 1;	// 0x04	Enable watchdog reset NOW
		u8_t u1CANBUS_SILENCE		    : 1;	// 0x08	Disable ATS CAN pulling data
		u8_t u1TEMP_DISABLE			    : 1;	// 0x10 Disable temp flag for DQE Halt test
        u8_t uReserved            		: 3;
    }u8Bits;
}nInternal_Debug_t;


typedef union nBBUStatusWord
{
    u16_t u16All;
    struct
    {
        u16_t u1BCC_STATE   		: 1;	// Assert if BBU in BCC state
        u16_t u1CML                 : 1;	// A communications, memory or logic fault has occurred.
        u16_t u1TEMPERATURE         : 1;	// A temperature fault or warning has occurred.
        u16_t u1Reserved_2		    : 1;
        u16_t u1LOW_SOC		        : 1;	// Bit will assert if BBU_RSOC is less than BBU_EMERGENCY_THRESHOLD SOC<20%
        u16_t u1SWITCH_SOC        	: 1;	// Bit will assert if BBU_RSOC is less than SWITCH_THRESHOLD SOC<50%
        u16_t u1NOT_READY_TO_DISCHARGE  : 1;	// BBU is not ready to discharge. Used as emergency fault bit if asserted
        u16_t u1Reserved_4    		: 1;

		u16_t u1BOOT			    : 1;	// Bootloader Mode
        u16_t u1TEMPORARY_FAILURE   : 1;	// A recoverable temporary failure occurred and may impact battery performance
        u16_t u1FANS        		: 1;	// A fan or airflow fault or warning has occurred.
        u16_t u1PERMANENT_FAILURE   : 1;	// A permanent unrecoverable failure occurred. 
        u16_t u1Reserved_5		    : 1;
		u16_t u1INPUT		    	: 1;	// An core pack voltage, input current, or input power fault or warning has occurred.
		u16_t u1IOUT_POUT		    : 1;	// An output current or output power fault or warning has occurred.
		u16_t u1VOUT		    	: 1;	// An output voltage fault or warning has occurred.
    }u16Bits;
}nBBUStatusWord_t;


typedef enum ATSTransfer_State
{
    eATSTransfer_State_Off = 0,     
	eATSTransfer_State_SPS, 			//Pri to Sec
	eATSTransfer_State_SSP, 			//Sec to Pri
	eATSTransfer_State_SPB, 			//Pri to BBU
	eATSTransfer_State_SSB, 			//Sec to BBU
	eATSTransfer_State_SBP, 			//BBU to Pri
	eATSTransfer_State_SBS, 			//BBU to Sec
    eATSTransfer_State_S12,             //S1 To S2
    eATSTransfer_State_S1B,             //S1 To BBU
    eATSTransfer_State_S1O,             //S1 To Offline
    eATSTransfer_State_S21,				//S2 To S1
    eATSTransfer_State_S2B,				//S2 To BBU
    eATSTransfer_State_S2O,             //S2 To Offline
    eATSTransfer_State_BS1_1,           //BBU To S1 Scenario #1
    eATSTransfer_State_BS1_2,           //BBU To S1 Scenario #2
    eATSTransfer_State_BS2_1,           //BBU To S2 Scenario #1
    eATSTransfer_State_BS2_2,           //BBU To S2 Scenario #2
    eATSTransfer_State_BBUO,            //BBU To Offline
    eATSTransfer_State_MS1,             //Go to S1 by Manually
    eATSTransfer_State_MS2,             //Go to S2 by Manually
    eATSTransfer_State_MBBU,            //Go to BBU by Manually
}eATSTransfer_State_t;

typedef union nStatusTransition
{
    u8_t u8All;
    struct
    {
        u8_t u1BBUValid        		: 1;
        u8_t u1Available_S2         : 1;
        u8_t u1Available_S1         : 1;
        u8_t u1CurrentSource_S2     : 1;
        u8_t u1CurrentSource_S1     : 1;
		u8_t u1ForceD2DOn           : 1;
		u8_t u2Reserved             : 2;
    }u8Bits;
}nStatusTransition_t;


typedef union nComposite_failure
{
    u8_t u8All;
    struct
    {
        u8_t u1ATS_Composite_failure	: 1;
        u8_t u1PFC_Composite_failure    : 1;
		u8_t uReserved             		: 6;
    }u8Bits;
}nComposite_failure_t;



/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef struct
{
// For CAN Data
	u8_t  u8ClearFault;
	u8_t  u8COMPATIBILITY_NUMBER;
	u8_t  u8FaultinjectACK;
	u8_t  u8NewBlackboxTrigger;
	u8_t  u8Fault_Count;						//Read only
	u8_t  u8Fault_Count_Limit;					//Default is 3
	u8_t  u8Fault_Delay;						//Used for fault recovery, default is 10, for CML
	u8_t  u8ATSwitchCNT_Latch;					//latch for fault injection
	u16_t u16NominalVoltage;                    // Default is 277
    u32_t u32ATSwitchCNT;						//ATS switch count(Reset by Power off)
    u32_t u32TotATSwitchCNT;					//Total ATS switch count
    u32_t u32PowerOnTime;						//PFC working time(Reset by Power off)
	u32_t u32TotPowerOnTime;					//Total PFC working time
	u32_t u32UnixTimeStamp;						//linux time count(Reset by Power off), update by PSC
	u32_t u32UnixTimeStamp_Shift;				//time stamp shift
	u32_t u32Debug_1;							//For debug used
	u32_t u32Debug_2;							//For debug used
	u32_t u32Debug_3;							//For debug used
	u32_t u32Debug_4;							//For debug used
	u8_t  pu8Variable[8];						//For variable data buff

// For status
	nStatusWord_t nStatusWord;
    nStatusTransfer_t nStatusTransfer;
	nStatusATSource_t nStatusATSource;
    nInputQuality_t nInputQuality[ATS_InputTag_Num];
    nOutputQuality_t nOutputQuality;
	nStatusTEMP_t nStatusTEMP;
	nStatusOther_t nStatusOther;
	nStatusPFC_t nStatusPFC;
	nStatusCML_t nStatusCML;
	nInternal_Debug_t nInternal_Debugger;		//For internal debuggger function
	nComposite_failure_t nComposite_failure;

// For Reading
	u16_t u16InputVoltage;						//Apply source voltage, unit is 0.1V
	u16_t u16InputVoltage_WOF;					//Apply source voltage, unit is 0.1V, without filter
	u16_t u16InputCurrent;						//Apply source current, unit is 0.01A
	u16_t u16InputCurrent_S1;					//Apply source current, unit is 0.001A
	u16_t u16InputCurrent_S2;					//Apply source current, unit is 0.001A
	u16_t u16InputFrequency;					//Apply source frequency, unit is 0.01Hz
	u16_t u16InputPower;						//Applu source power, unit is 1W
	u16_t u16InputPower_S1;						//Applu source power, unit is 1W
	u16_t u16InputPower_S2;						//Applu source power, unit is 1W
	u16_t u16InputPower_AVG;					//Power AVG values over last hour
	u16_t u16InputPower_AVG_S1;					//Power AVG values over last hour
	u16_t u16InputPower_AVG_S2;					//Power AVG values over last hour
	u16_t u16InputPower_Max;					//Power MAX values over last hour
	u16_t u16InputPower_Max_S1;					//Power MAX values over last hour
	u16_t u16InputPower_Max_S2;					//Power MAX values over last hour

// For Waveform capture
	u8_t u8InstantValue_VS1;      				// unit is 2V, 0~255
    u8_t u8InstantValue_VS2;      				// unit is 2V, 0~255
    u8_t u8InstantValue_VAC;      				// unit is 2V, 0~255
    u8_t u8InstantValue_IAC;      				// unit is 0.125A

	u16_t u16InstantValue_VS1_VS2; 				// VS1 low byte, VS2 high byte
	u16_t u16InstantValue_VAC_IAC; 				// VAC low byte, IAC high byte


// For Modbus
	nStatusInput_t nStatusInput;
	nStatusPFCtoD2D_t nStatus_PFC2D2D;
	nStatusD2DtoPFC_t nStatus_D2D2PFC;
	nLED_StatustoD2D_t nLED_StatustoD2D;        // Update LED Status to D2D by ModBus
	nStatusTransition_t nStatus_Transition;
	u16_t u16D2DAliveCNT;						// keep counting when D2D is alive
	u16_t u16PFCAliveCNT;						// keep counting when PFC is alive
	u16_t u16InputPower_Derating;				// report input power de-rating by different input voltage, unit is 1W
	u16_t u16InputPower_Derating_WF;			// report input power de-rating by different input voltage, unit is 1W, with filter
	u16_t u16Reserved;							// for modbus reserved command

// For Other protection buff
	u16_t u16PreMainACValid;					// 0:InValid, 1:Valid, 3:Default
	u16_t u16PreDeviceFault;					// 0:Device normal, 1:Device fault
	u16_t u16D2DAlivePreCNT;					// keep counting when D2D is alive
	u16_t u16D2DAliveFlag;						// 0: D2D not alive, 1: D2D alive
	u16_t u16powercycledelayCNT;				// delay 1000ms
	u16_t u16PrePSON;							// 1 : PS ON, 0: PS_OFF
	u8_t  u8PreCML;								// previous status CML data
	u16_t u16CMLRecoveryCNT;					// CML auto recovery after 10s delay time


//	For ATS state machine
	u8_t  u8REQ_BBU_NUMBER;						// Determines how many BBUs are needed for redundancy (1 ~ 6 BBUs), default is 5
	u8_t  u8BBU_Valid_50_NUM;					// How many BBU valid, READY_TO_DISCHARGE =1 and SOC > 50
	u8_t  u8BBU_Valid_20_NUM;					// How many BBU valid, READY_TO_DISCHARGE =1 and SOC > 20
	u8_t  u8Shelf_BBU_NUM;                     // Maximum:6 , if any "BBU's SOC > 1%" then plus one
	u8_t  u8HEARTBEAT_TIMEOUT;					// How many seconds of not receiving device heartbeat to declare a device being not available, default is 5s
	u8_t  u8BBU_TIMEOUT[SHELF_DEVICE_NUMBER];	// BBU Device count down
	u8_t  u8D2D_TIMEOUT[SHELF_DEVICE_NUMBER];	// D2D Device count down
	nBBUStatusWord_t  nBBU_Status_Word[SHELF_DEVICE_NUMBER];
	u32_t u32BBU_RSOC[SHELF_DEVICE_NUMBER]; 	// BBU RSOC value
	u16_t u16BBU_Valid;							// 2: SOC>50% unit >= 5 , 1: SOC>20% unit >= 5, 0: SOC<20% unit <= 4
	u16_t u16BBUMode_Valid;                     // 2: SOC>50% unit >= 6 , 1: SOC>20% unit >= 6, 0: SOC<20% unit >= 1
	u32_t u32D2D_ReadPower[SHELF_DEVICE_NUMBER];// Read D2D linear 11 Power
	u16_t u16D2D_MaxPower;						// log D2D max real power at shelf level, unit is 1W

// Temporary and Permanent Fault
	u16_t u16Temporary_Fault;
    u16_t u16Permanent_Fault;

// For Permanent fault bit counter
	u16_t u16CompositeFault_ATSCounter;
	u16_t u16CompositeFault_PFCCounter;

// For VBulk OVP & UVP Count
	u32_t u32VBulk_Protect_CNT;
}sLog_t;



/****************************************************************************
*	Public variables
****************************************************************************/
extern sLog_t tsLog;


/****************************************************************************
*	Public function
****************************************************************************/

extern void Log_Update_ATSwitchCNT(void);
extern void Log_Status_Transfer(eATSTransfer_State_t eNewState);
extern void Log_Clear_Fault(void);
extern void Log_EDIT_Status_Input(u8_t Value1, u8_t Value2, u8_t Value3);
extern void Log_EDIT_Status_Temp(u8_t Value);
extern void Log_EDIT_Status_Other(u8_t Value);
extern void Log_EDIT_Temp(u8_t Value1 , i16_t Value2);
extern void Log_Internal_debugger(void);
extern void Log_TimeStamp_Shift(u32_t u32Time);
extern void Log_Status_CML(u8_t u8Bits);
extern void Log_1hr_Periodically_Process(void);
extern void Log_1s_Periodically_Process(void);
extern void Log_10ms_Periodically_Process(void);
extern void Log_1ms_Periodically_Process(void);
extern void Log_10k_Instant_Process(void);
extern void Log_Initialize(void);
extern void Log_EDIT_VBULK_Protection(u8_t Value);

#endif /* SERV_LOG_H_ */
