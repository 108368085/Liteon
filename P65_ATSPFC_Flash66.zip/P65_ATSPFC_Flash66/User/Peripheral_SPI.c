/****************************************************************************
 *	File	Peripheral_SPI.c
 * 	Brief	Configure and control SPI module on TI 28004x platform
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/12/10 - 1st release
 ****************************************************************************/

/****************************************************************************
*	Included Files
****************************************************************************/

#include "f28x_project.h"
#include "Peripheral_SPI.h"
#include <string.h>


/****************************************************************************
    Private parameter definition
****************************************************************************/

//
// Calculate BRR: 7-bit baud rate register value
// LSPCLK freq   = CPU freq / 4  (by default) = 200M/4 = 50MHz
// BRR           = (LSPCLK freq / SPI CLK freq) - 1 = (50MHz/1M) - 1 = 49
// SPI BAUR RATE = LSPCLK freq / (BRR+1) = 50M / (49+1) = 1M/bps
#define SPI_CLK_FREQ	1000000UL
#define SPI_BRR        ((SYS_CLK_OUT / 4) / SPI_CLK_FREQ) - 1

/** SPI Master should make the bus be idle after finished a transaction */
#define PERI_SPI_MASTER_BUS_IDLE_DELAY      		1		// 1ms (10ms to 1ms), unit is 1ms

/** SPI Master should reset the module after the transaction waste too much time */
#define PERI_SPI_MASTER_BusErrorDelay_BUSY_DELAY	1000	// 1s, unit is 1ms

/** SPI Master should disable device delay time */
#define PERI_SPI_Disable_DELAY						50		// 50ms, unit is 1ms

//
// SPI EEPROM status
//
#define MSG_STATUS_READY_M          0x0001 // EEPROM is ready (not busy)
#define MSG_STATUS_WRITE_READY_M    0x0002 // EEPROM is ready to write


// Determine the number of bits to be shifted
#define SPI_CHAR_SIZE				8	//8-bit word

// Opcodes for the EEPROM (8-bit)
#define DummyData					0x0000
#define RDSR                        0x0500
#define READ                        0x0300
#define WRITE                       0x0200
#define WREN                        0x0600
#define WRDI                        0x0400
#define WRSR                        0x0100

//
// Defines for Chip Select toggle.
//
#define CS_LOW                      GpioDataRegs.GPBCLEAR.bit.GPIO35 = 1
#define CS_HIGH                     GpioDataRegs.GPBSET.bit.GPIO35 = 1


/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

typedef enum ePeriSPI_Port
{
    ePeriSPI_Port_A = 0,
    ePeriSPI_Port_B,
}ePeriSPI_Port_t;

typedef enum ePeriSPI_Mode_Enumeration
{
    ePeriSPI_Mode_Slave = 0,
    ePeriSPI_Mode_Master,
}ePeriSPI_Mode_Enumeration_t;


/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

/*
// RAMLS0_6 : 610 -> 526
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else

//#pragma CODE_SECTION(MstSPI_FirmwareReset, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_HardwareDisable, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_HardwareEnable, ".TI.ramfunc");
#pragma CODE_SECTION(MstSPI_RemoveTransaction, ".TI.ramfunc");
#pragma CODE_SECTION(MstSPI_StartTransaction, ".TI.ramfunc");
#pragma CODE_SECTION(MstSPI_AppendTransaction, ".TI.ramfunc");
#pragma CODE_SECTION(MstSPI_PushTransaction, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_1ms_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(PeriSPI_1ms_Periodically_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_IDLE, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_CHECKWIP, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_Opcode, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_CHECKWEL, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_DATA, ".TI.ramfunc");
//#pragma CODE_SECTION(MstSPI_Handler, ".TI.ramfunc");
#pragma CODE_SECTION(PeriSPI_Background_Process, ".TI.ramfunc");

#endif
*/

/****************************************************************************
	Private variable declaration
****************************************************************************/

sPeriSPI_Driver_t ptsPeriSPIDriver[ePeriSPI_Channel_Num];


/**
 *  @brief  Master I2C Firmware reset
 *  @
 */
static inline void MstSPI_FirmwareReset(sPeriSPI_Driver_t* psDriver)
{
    psDriver->psInstance->SPICCR.bit.SPISWRESET = 0;
	psDriver->psInstance->SPICCR.bit.SPISWRESET = 1;
}

/**
 *  @brief  Master SPI hardware disable
 *  @
 */
static inline void MstSPI_HardwareDisable(sPeriSPI_Driver_t* psDriver)
{
	psDriver->sMasterHandler.nFlag.u16Bits.u1EEPROMDisable = 1;
	psDriver->sMasterHandler.u16DeviceResetDelay = PERI_SPI_Disable_DELAY;
	
	if (psDriver->u16Port == ePeriSPI_Port_A)
	{
		SET_GPIO_EEPROM_DIS;
	}
}

/**
 *  @brief  Master SPI hardware enable
 *  @
 */
static inline void MstSPI_HardwareEnable(sPeriSPI_Driver_t* psDriver)
{
	psDriver->sMasterHandler.nFlag.u16Bits.u1EEPROMDisable = 0;
	
	if (psDriver->u16Port == ePeriSPI_Port_A)
	{
		SET_GPIO_EEPROM_EN;
	}
}

/**
 *  @brief  Remove transaction from list
 *  @param  psDriver: Pointer to a sPeriI2C_Driver_t structure which needs to remove this transaction
 *  @param  psTargetTransaction: Pointer to a Pointer to a sMstI2cTransaction_t structure that attempt to remove
 *  @retval MI2C_TRANSACTION_STATE_IDLE: The transaction had been removed
 *  @retval MI2C_TRANSACTION_STATE_ERROR: Could not found target transaction from list
 */
static eMstSPITransactionState_t MstSPI_RemoveTransaction(sPeriSPI_Driver_t* psDriver, sMstSPITransaction_t* psTargetTransaction)
{
    if (psDriver->sMasterHandler.psTransaction == psTargetTransaction)
    {
        psDriver->sMasterHandler.psTransaction = psTargetTransaction->psNext;
    }
    else
    {
        sMstSPITransaction_t* psQueueingTransaction = psDriver->sMasterHandler.psTransaction;
        
        /* Traveling the list */
        while ((psQueueingTransaction->psNext != psTargetTransaction) &&
               (psQueueingTransaction->psNext != NULL))
        {
            psQueueingTransaction = psQueueingTransaction->psNext;
        }
        
        if (psQueueingTransaction->psNext == psTargetTransaction)
        {
            psQueueingTransaction->psNext = psTargetTransaction->psNext;
        }
        else
        {
            return MSPI_TRANSACTION_STATE_ERROR;
        }
    }
    
    psTargetTransaction->psNext = NULL;
    psTargetTransaction->u16ErrorCode = MSPI_ERROR_NONE;
    psTargetTransaction->eState = MSPI_TRANSACTION_STATE_IDLE;
    
    return psTargetTransaction->eState;
}

/**
 *  @brief  SPI Master start a transaction
 *  @
 *  @retval 
 */
static void MstSPI_StartTransaction(sPeriSPI_Driver_t* psDriver)
{
	/* Before start transaction, clear some variables of transaction */
    psDriver->sMasterHandler.psTransaction->u16TxIndex = 0;
    psDriver->sMasterHandler.psTransaction->u16RxIndex = 0;
    psDriver->sMasterHandler.psTransaction->u16ErrorCode = MSPI_ERROR_NONE;

	if ((psDriver->sMasterHandler.psTransaction->u16TxLength > 0) &&
        (psDriver->sMasterHandler.psTransaction->u16RxLength == 0))
    {
        /* Write operation */
		psDriver->sMasterHandler.nFlag.u16Bits.u1RWProcess = 1;
    }
    else if ((psDriver->sMasterHandler.psTransaction->u16TxLength == 0) &&
             (psDriver->sMasterHandler.psTransaction->u16RxLength > 0))
    {
        /* Read operation */
        psDriver->sMasterHandler.nFlag.u16Bits.u1RWProcess = 0;
    }

	psDriver->sMasterHandler.psTransaction->eState = MSPI_TRANSACTION_STATE_TRANSACTING;
}



/**
 *  @brief  Append a new transaction to list
 *  @param  psDriver: Pointer to a sPeriSPI_Driver_t structure which needs to handle this transaction
 *  @param  psNewTransaction: Pointer to a sMstSPITransaction_t structure which contetns coefficients of transaction
 *  @retval MSPI_TRANSACTION_STATE_QUEUEING: The new transaction is queueing
 */
static eMstSPITransactionState_t MstSPI_AppendTransaction(sPeriSPI_Driver_t* psDriver, sMstSPITransaction_t* psNewTransaction)
{
    if (psDriver->sMasterHandler.psTransaction == NULL)
    {
        psDriver->sMasterHandler.psTransaction = psNewTransaction;
        psNewTransaction->eState = MSPI_TRANSACTION_STATE_QUEUEING;
    }
    else
    {
        sMstSPITransaction_t* psQueueingTransaction = psDriver->sMasterHandler.psTransaction;

        while (psQueueingTransaction->psNext != NULL)
        {
            psQueueingTransaction = psQueueingTransaction->psNext;
        }

        psQueueingTransaction->psNext = psNewTransaction;
        psNewTransaction->eState = MSPI_TRANSACTION_STATE_QUEUEING;
    }

    return psNewTransaction->eState;
}

/**
 *  @brief  Push a transaction into list
 *  @param  u16Channel: Whcih channel is attempted to handle the transaction
 *  @param  psNewTransaction: Pointer to a sMstSPITransaction_t structure which contetns coefficients of transaction
 *  @retval MSPI_TRANSACTION_STATE_QUEUEING: The new transaction is queueing
 *  @retval MSPI_TRANSACTION_STATE_ERROR: The push request has been denied
 */
eMstSPITransactionState_t MstSPI_PushTransaction(u16_t u16Channel, sMstSPITransaction_t* psNewTransaction)
{
    if (ptsPeriSPIDriver[u16Channel].u16Role == ePeriSPI_Mode_Master)
    {
        return MstSPI_AppendTransaction(&ptsPeriSPIDriver[u16Channel], psNewTransaction);
    }
    else
    {
        return MSPI_TRANSACTION_STATE_ERROR;
    }
}

/**
 *  @brief  Master SPI Periodically Process
 *  @param  pvSubscriberObj: Pointer to a sPeriSPI_Driver_t structure which is attempted to run periodically process
 *  @retval None
 */
static inline void MstSPI_1ms_Periodically_Process(sPeriSPI_Driver_t* psDriver)
{
   
    if (psDriver->sMasterHandler.u16BusIdleDelay > 0)
    {
        psDriver->sMasterHandler.u16BusIdleDelay -= 1;
    }

	if (psDriver->sMasterHandler.psTransaction->eState == MSPI_TRANSACTION_STATE_TRANSACTING)
	{
		if (psDriver->sMasterHandler.u16BusErrorDelay > 0) 
		{
			psDriver->sMasterHandler.u16BusErrorDelay -= 1;
		}
		else
		{
			psDriver->sMasterHandler.psTransaction->u16ErrorCode = MSPI_ERROR_BUS_ERROR;
			psDriver->sMasterHandler.psTransaction->eState = MSPI_TRANSACTION_STATE_ERROR;
			MstSPI_HardwareDisable(psDriver);
		}
	}
	else
	{
		psDriver->sMasterHandler.u16BusErrorDelay = PERI_SPI_MASTER_BusErrorDelay_BUSY_DELAY;
	}

	if (psDriver->sMasterHandler.nFlag.u16Bits.u1EEPROMDisable)
	{
		if (psDriver->sMasterHandler.u16DeviceResetDelay > 0) 
		{
			psDriver->sMasterHandler.u16DeviceResetDelay -= 1;
		}
		else
		{			
			MstSPI_HardwareEnable(psDriver);
			MstSPI_FirmwareReset(psDriver);
			
			if (psDriver->sMasterHandler.psTransaction->pfFinishCallback != NULL)
        	{
            	psDriver->sMasterHandler.psTransaction->pfFinishCallback(psDriver->sMasterHandler.psTransaction);
            	MstSPI_RemoveTransaction(psDriver, psDriver->sMasterHandler.psTransaction);
        	}
		}
	}	
}

/**
 *  @brief  Peripheral - SPI 1ms periodically Process
 *  @retval While loop
 */
void PeriSPI_1ms_Periodically_Process(void)
{
	MstSPI_1ms_Periodically_Process(&ptsPeriSPIDriver[ePeriSPI_Channel_A]);
}

/**
 *  @brief  Master SPI handler - IDLE mode
 *  @param  
 *  @retval None
 */
static inline void MstSPI_IDLE(sPeriSPI_Driver_t* psDriver)
{
	if (psDriver->sMasterHandler.ePreState != psDriver->sMasterHandler.eState)
	{
		psDriver->sMasterHandler.ePreState = psDriver->sMasterHandler.eState;
	}

	if ((psDriver->sMasterHandler.psTransaction != NULL) &&
        (psDriver->sMasterHandler.psTransaction->eState == MSPI_TRANSACTION_STATE_QUEUEING) &&
        (psDriver->sMasterHandler.u16BusIdleDelay == 0))
    {
		MstSPI_StartTransaction(psDriver);
		psDriver->sMasterHandler.eState = SPI_STATE_CHECKWIP;
    }
}


/**
 *  @brief  Master SPI handler - Check WIP mode
 *  @param  
 *  @retval None
 */
static inline void MstSPI_CHECKWIP(sPeriSPI_Driver_t* psDriver)
{
	if (psDriver->sMasterHandler.ePreState != psDriver->sMasterHandler.eState)
	{
		psDriver->sMasterHandler.ePreState = psDriver->sMasterHandler.eState;
		psDriver->sMasterHandler.u16Step = 0;
	}

	// Step 0: Send RDSR opcode
	if (psDriver->sMasterHandler.u16Step == 0)
	{
		// 0:Transmit buffer is not full, 1:Transmit buffer is full
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			CS_LOW;
			psDriver->psInstance->SPITXBUF = RDSR;
			psDriver->sMasterHandler.u16Step = 1;
		}
	}
	// Step 1: Dummy read to clear INT_FLAG
	else if (psDriver->sMasterHandler.u16Step == 1)
	{
		// 0:No full words have been received or transmitted, 1:completed sending or receiving
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			psDriver->sMasterHandler.u16Step = 2;
		}
	}
	// Step 2: Send dummy data to receive the status
	else if (psDriver->sMasterHandler.u16Step == 2)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			psDriver->psInstance->SPITXBUF = DummyData;
			psDriver->sMasterHandler.u16Step = 3;
		}
	}
	// Step 3: Get EEPROM status register
	else if (psDriver->sMasterHandler.u16Step == 3)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			CS_HIGH;
			
			if ((psDriver->sMasterHandler.u16RxTemp & MSG_STATUS_READY_M) != MSG_STATUS_READY_M)
			{
				// EEPROM is ready to decode a new command
				psDriver->sMasterHandler.eState = SPI_STATE_OPCODE;
			}
			else
			{
				// EEPROM is busy, repeat again!
				psDriver->sMasterHandler.u16Step = 0;
			}
		}
	}
}


/**
 *  @brief  Master SPI handler - Enable or Disable Write Opcode mode
 *  @param  
 *  @retval None
 */
static inline void MstSPI_Opcode(sPeriSPI_Driver_t* psDriver)
{
	if (psDriver->sMasterHandler.ePreState != psDriver->sMasterHandler.eState)
	{
		psDriver->sMasterHandler.ePreState = psDriver->sMasterHandler.eState;
		psDriver->sMasterHandler.u16Step = 0;
	}

	// Step 0: Send WREN or WRDI opcode
	if (psDriver->sMasterHandler.u16Step == 0)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			CS_LOW;
			
			if (psDriver->sMasterHandler.nFlag.u16Bits.u1RWProcess == 1)
			{
				psDriver->psInstance->SPITXBUF = WREN;	// Write Enable
			}
			else
			{
				psDriver->psInstance->SPITXBUF = WRDI;	// Write Disable
			}
			
			psDriver->sMasterHandler.u16Step = 1;
		}
	}
	// Step 1: Dummy read to clear INT_FLAG
	else if (psDriver->sMasterHandler.u16Step == 1)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			CS_HIGH;
			psDriver->sMasterHandler.eState = SPI_STATE_CHECKWEL;
		}
	}
}

/**
 *  @brief  Master SPI handler - Check WEL mode
 *  @param  
 *  @retval None
 */
static inline void MstSPI_CHECKWEL(sPeriSPI_Driver_t* psDriver)
{	
	if (psDriver->sMasterHandler.ePreState != psDriver->sMasterHandler.eState)
	{
		psDriver->sMasterHandler.ePreState = psDriver->sMasterHandler.eState;
		psDriver->sMasterHandler.u16Step = 0;
	}
	
	// Step 0: Send RDSR opcode
	if (psDriver->sMasterHandler.u16Step == 0)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			CS_LOW;
			psDriver->psInstance->SPITXBUF = RDSR;
			psDriver->sMasterHandler.u16Step = 1;
		}
	}
	// Step 1: Dummy read to clear INT_FLAG
	else if (psDriver->sMasterHandler.u16Step == 1)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			psDriver->sMasterHandler.u16Step = 2;
		}
	}
	// Step 2: Send dummy data to receive the status
	else if (psDriver->sMasterHandler.u16Step == 2)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			psDriver->psInstance->SPITXBUF = DummyData;
			psDriver->sMasterHandler.u16Step = 3;
		}
	}
	// Step 3: Get EEPROM status register
	else if (psDriver->sMasterHandler.u16Step == 3)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			CS_HIGH;
			
			if (psDriver->sMasterHandler.nFlag.u16Bits.u1RWProcess == 1)
			{
				// Write
				if ((psDriver->sMasterHandler.u16RxTemp & MSG_STATUS_WRITE_READY_M) == MSG_STATUS_WRITE_READY_M)
				{
					// WEL=1, the write instruction(WRITE,WRSR,WRID,LID) are executed
					psDriver->sMasterHandler.eState = SPI_STATE_DATA;
				}
				else
				{
					// WEL=0, any decoded write instruction is not executed
					psDriver->sMasterHandler.eState = SPI_STATE_OPCODE;
				}
			}
			else
			{
				// Read
				if ((psDriver->sMasterHandler.u16RxTemp & MSG_STATUS_WRITE_READY_M) != MSG_STATUS_WRITE_READY_M)
				{
					psDriver->sMasterHandler.eState = SPI_STATE_DATA;
				}
				else
				{
					psDriver->sMasterHandler.eState = SPI_STATE_OPCODE;
				}
			}	
		}
	}
}


/**
 *  @brief  Master SPI handler - Data Transaction mode
 *  @param  
 *  @retval None
 */
static inline void MstSPI_DATA(sPeriSPI_Driver_t* psDriver)
{
	if (psDriver->sMasterHandler.ePreState != psDriver->sMasterHandler.eState)
	{
		psDriver->sMasterHandler.ePreState = psDriver->sMasterHandler.eState;
		psDriver->sMasterHandler.u16Step = 0;
	}

	// Step 0: Send RDSR opcode
	if (psDriver->sMasterHandler.u16Step == 0)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			CS_LOW;
			if (psDriver->sMasterHandler.nFlag.u16Bits.u1RWProcess == 1)
			{
				// The WRITE instruction is used to write new data in the memory
				psDriver->psInstance->SPITXBUF = WRITE;
			}
			else
			{
				// The READ instruction is used to read the content of the memory
				psDriver->psInstance->SPITXBUF = READ;
			}

			psDriver->sMasterHandler.u16Step = 1;
		}
	}
	// Step 1: Dummy read to clear INT_FLAG
	else if (psDriver->sMasterHandler.u16Step == 1)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			psDriver->sMasterHandler.u16Step = 2;
		}
	}
	// Step 2: Send the MSB of the address of the EEPROM
	else if (psDriver->sMasterHandler.u16Step == 2)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			psDriver->psInstance->SPITXBUF = psDriver->sMasterHandler.psTransaction->pu8MemoryAddress[2] << 8;
			psDriver->sMasterHandler.u16Step = 3;
		}
	}
	// Step 3: Dummy read to clear INT_FLAG
	else if (psDriver->sMasterHandler.u16Step == 3)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			psDriver->sMasterHandler.u16Step = 4;
		}
	}
	// Step 4: Send the LSB of the address of the EEPROM
	else if (psDriver->sMasterHandler.u16Step == 4)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			psDriver->psInstance->SPITXBUF = psDriver->sMasterHandler.psTransaction->pu8MemoryAddress[3] << 8;
			psDriver->sMasterHandler.u16Step = 5;
		}
	}
	// Step 5: Dummy read to clear INT_FLAG
	else if (psDriver->sMasterHandler.u16Step == 5)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;
			psDriver->sMasterHandler.u16Step = 6;
		}
	}
	// Step 6: Write Data
	else if (psDriver->sMasterHandler.u16Step == 6)
	{
		if (psDriver->psInstance->SPISTS.bit.BUFFULL_FLAG == 0)
		{
			if(psDriver->sMasterHandler.nFlag.u16Bits.u1RWProcess == 1)
			{
				// Write Data to EEPROM
				psDriver->psInstance->SPITXBUF = (*(psDriver->sMasterHandler.psTransaction->pu8TxBuff + psDriver->sMasterHandler.psTransaction->u16TxIndex)) << 8;
            	psDriver->sMasterHandler.psTransaction->u16TxIndex += 1;
				psDriver->sMasterHandler.u16Step = 7;
			}
			else
			{
				// Write Dummy Data
				psDriver->psInstance->SPITXBUF = DummyData;
				psDriver->sMasterHandler.u16Step = 7;
			}	
		}
	}
	// Step 7: Read Data
	else if (psDriver->sMasterHandler.u16Step == 7)
	{
		if (psDriver->psInstance->SPISTS.bit.INT_FLAG == 1)
		{
			if (psDriver->sMasterHandler.nFlag.u16Bits.u1RWProcess == 1)
			{
				// Read Dummy Data
				psDriver->sMasterHandler.u16RxTemp = psDriver->psInstance->SPIRXBUF;

				if (psDriver->sMasterHandler.psTransaction->u16TxIndex >= psDriver->sMasterHandler.psTransaction->u16TxLength)
				{
					// Transaction is accomplished
					CS_HIGH;
					psDriver->sMasterHandler.u16Step = 8;
				}
				else
				{
					psDriver->sMasterHandler.u16Step = 6;
				}
			}
			else
			{
				// Read Data from EEPROM
				*(psDriver->sMasterHandler.psTransaction->pu8RxBuff + psDriver->sMasterHandler.psTransaction->u16RxIndex) = psDriver->psInstance->SPIRXBUF;
        		psDriver->sMasterHandler.psTransaction->u16RxIndex += 1;

				if (psDriver->sMasterHandler.psTransaction->u16RxIndex >= psDriver->sMasterHandler.psTransaction->u16RxLength)
				{
					// Transaction is accomplished
					CS_HIGH;
					psDriver->sMasterHandler.u16Step = 8;
				}
				else
				{
					psDriver->sMasterHandler.u16Step = 6;
				}
			}	
		}
	}
	// Step 8: Transaction is accomplished
	else if (psDriver->sMasterHandler.u16Step == 8)
	{
		psDriver->sMasterHandler.eState = SPI_STATE_IDLE;
		psDriver->sMasterHandler.psTransaction->eState = MSPI_TRANSACTION_STATE_ACCOMPLISH;
     
        /* Notify transaction owner that the transaction is accomplished */
        if (psDriver->sMasterHandler.psTransaction->pfFinishCallback != NULL)
        {
            psDriver->sMasterHandler.psTransaction->pfFinishCallback(psDriver->sMasterHandler.psTransaction);
            
            /* Remove this transaction */
            MstSPI_RemoveTransaction(psDriver, psDriver->sMasterHandler.psTransaction);
        }
        
        /* Reset Bus Idle Delay */
        psDriver->sMasterHandler.u16BusIdleDelay = PERI_SPI_MASTER_BUS_IDLE_DELAY;
	}
}


/**
 *  @brief  Master SPI handler
 *  @param  Doing SPI handler
 *  @retval None
 */
static inline void MstSPI_Handler(sPeriSPI_Driver_t* psDriver)
{
	switch (psDriver->sMasterHandler.eState)
	{
		case SPI_STATE_IDLE:
			MstSPI_IDLE(psDriver);
		break;

		case SPI_STATE_CHECKWIP:
			MstSPI_CHECKWIP(psDriver);	
		break;

		case SPI_STATE_OPCODE:
			MstSPI_Opcode(psDriver);	
		break;

		case SPI_STATE_CHECKWEL:
			MstSPI_CHECKWEL(psDriver);	
		break;

		case SPI_STATE_DATA:
			MstSPI_DATA(psDriver);	
		break;
				
		default:
		break;
	}
}

/**
 *  @brief  Peripheral - SPI Background Process
 *  @retval While loop
 */
void PeriSPI_Background_Process(void)
{
	MstSPI_Handler(&ptsPeriSPIDriver[ePeriSPI_Channel_A]);
}


/**
 *  @brief  Reset bus idle delay
 *  @retval None
 */
void PeriSPI_ResetBusIdleDelay(void)
{

#ifdef USE_SPI_CHANNEL_A
    ptsPeriSPIDriver[ePeriSPI_Channel_A].sMasterHandler.u16BusIdleDelay = 0;
#endif

#ifdef USE_SPI_CHANNEL_B
    ptsPeriSPIDriver[ePeriSPI_Channel_B].sMasterHandler.u16BusIdleDelay = 0;
#endif

}


/**
 *  @brief  Start Peripheral SPI
 *  @retval None
 */
void PeriSPI_Start(void)
{

#ifdef USE_SPI_CHANNEL_A
    ptsPeriSPIDriver[ePeriSPI_Channel_A].psInstance->SPICCR.bit.SPISWRESET = 1;
#endif

#ifdef USE_SPI_CHANNEL_B
    ptsPeriSPIDriver[ePeriSPI_Channel_B].psInstance->SPICCR.bit.SPISWRESET = 1;
#endif

}

/**
 *  @brief  Stop Peripheral SPI
 *  @retval None
 */
void PeriSPI_Stop(void)
{

#ifdef USE_SPI_CHANNEL_A
		ptsPeriSPIDriver[ePeriSPI_Channel_A].psInstance->SPICCR.bit.SPISWRESET = 0;
#endif
	
#ifdef USE_SPI_CHANNEL_B
		ptsPeriSPIDriver[ePeriSPI_Channel_B].psInstance->SPICCR.bit.SPISWRESET = 0;
#endif

}


/**
 *  @brief  Initial target SPI driver as master mode
 *  @param  psDriver: Pointer to a sPeriSPI_Driver_t structure which is attempted to set as master mode
 *  @retval None
 */
static void MstSPI_Initialize(sPeriSPI_Driver_t* psDriver)
{
	psDriver->u16Role = ePeriSPI_Mode_Master;
	psDriver->sMasterHandler.u16BusErrorDelay = PERI_SPI_MASTER_BusErrorDelay_BUSY_DELAY;
	psDriver->sMasterHandler.eState = SPI_STATE_IDLE;
	psDriver->sMasterHandler.ePreState = SPI_STATE_IDLE;
	
    // Set reset low before configuration changes
    // Clock polarity (0 == rising, 1 == falling)
    // 16-bit character
    psDriver->psInstance->SPICCR.bit.SPISWRESET = 0;
    psDriver->psInstance->SPICCR.bit.CLKPOLARITY = 0;
    psDriver->psInstance->SPICCR.bit.SPICHAR = (SPI_CHAR_SIZE-1);
 
    // Enable master (0 == slave, 1 == master)
    // Enable transmission (Talk)
    // Clock phase (0 == normal, 1 == delayed)
    // SPI interrupts are disabled
    // Mode: Polarity 0, phase 1. Rising edge with delay.
//    psDriver->psInstance->SPICTL.bit.MASTER_SLAVE = 1;
    psDriver->psInstance->SPICTL.bit.CONTROLLER_PERIPHERAL = 1;
    psDriver->psInstance->SPICTL.bit.TALK = 1;
    psDriver->psInstance->SPICTL.bit.CLK_PHASE = 1;
    psDriver->psInstance->SPICTL.bit.SPIINTENA = 0;

    // Set the baud rate
    psDriver->psInstance->SPIBRR.bit.SPI_BIT_RATE = SPI_BRR;

    // Set FREE bit
    // Halting on a breakpoint will not halt the SPI
    psDriver->psInstance->SPIPRI.bit.FREE = 1;

    // Release the SPI from reset
    psDriver->psInstance->SPICCR.bit.SPISWRESET = 1;

}

/**
 *  @brief  Initial SPI module
 *          Enable SPI channel A for EEPROM
 *  @retval None
 */
void PeriSPI_Initialize(void)
{
	u16_t i;
	
	for (i=0; i<ePeriSPI_Channel_Num; i++)
	{
		memset(&ptsPeriSPIDriver[i], 0, sizeof(ptsPeriSPIDriver[i]));
	}
		
#ifdef USE_SPI_CHANNEL_A
		/* Configure IO multiplexer for SPI function */
		GPIO_SetupPinMux(SPI_A_SIMO_PIN_NUM, GPIO_MUX_CPU1, SPI_A_SIMO_MUX_SEL);
		GPIO_SetupPinMux(SPI_A_SOMI_PIN_NUM, GPIO_MUX_CPU1, SPI_A_SOMI_MUX_SEL);
		GPIO_SetupPinMux(SPI_A_CLK_PIN_NUM, GPIO_MUX_CPU1, SPI_A_CLK_MUX_SEL);
		GPIO_SetupPinMux(SPI_A_STE_PIN_NUM, GPIO_MUX_CPU1, SPI_A_STE_MUX_SEL);
		GPIO_SetupPinOptions(SPI_A_SIMO_PIN_NUM, GPIO_OUTPUT, GPIO_PULLUP | GPIO_ASYNC);
		GPIO_SetupPinOptions(SPI_A_SOMI_PIN_NUM, GPIO_INPUT, GPIO_PUSHPULL | GPIO_ASYNC);
		GPIO_SetupPinOptions(SPI_A_CLK_PIN_NUM, GPIO_OUTPUT, GPIO_PULLUP | GPIO_ASYNC);
		GPIO_SetupPinOptions(SPI_A_STE_PIN_NUM, GPIO_OUTPUT, GPIO_PULLUP | GPIO_ASYNC);

		/* Configure Driver for SPI function */
		ptsPeriSPIDriver[ePeriSPI_Channel_A].u16Port = ePeriSPI_Port_A;
		ptsPeriSPIDriver[ePeriSPI_Channel_A].psInstance = &SpiaRegs;
	   
    #ifdef SPI_A_MASTER_MODE
		MstSPI_Initialize(&ptsPeriSPIDriver[ePeriSPI_Channel_A]);
    #else
		SlvSPI_Initialize(&ptsPeriSPIDriver[ePeriSPI_Channel_A]);
    #endif  // End define of SPIA_MASTER_MODE
	
#endif  // End define of USE_SPI_CHANNEL_A

#ifdef USE_SPI_CHANNEL_B
		/* Configure IO multiplexer for SPI function */
		GPIO_SetupPinMux(SPI_B_SIMO_PIN_NUM, GPIO_MUX_CPU1, SPI_B_SIMO_MUX_SEL);
		GPIO_SetupPinMux(SPI_B_SOMI_PIN_NUM, GPIO_MUX_CPU1, SPI_B_SOMI_MUX_SEL);
		GPIO_SetupPinMux(SPI_B_CLK_PIN_NUM, GPIO_MUX_CPU1, SPI_B_CLK_MUX_SEL);
		GPIO_SetupPinMux(SPI_B_STE_PIN_NUM, GPIO_MUX_CPU1, SPI_B_STE_MUX_SEL);
		GPIO_SetupPinOptions(SPI_B_SIMO_PIN_NUM, GPIO_OUTPUT, GPIO_PULLUP | GPIO_ASYNC);
		GPIO_SetupPinOptions(SPI_B_SOMI_PIN_NUM, GPIO_INPUT, GPIO_PUSHPULL | GPIO_ASYNC);
		GPIO_SetupPinOptions(SPI_B_CLK_PIN_NUM, GPIO_OUTPUT, GPIO_PULLUP | GPIO_ASYNC);
		GPIO_SetupPinOptions(SPI_B_STE_PIN_NUM, GPIO_OUTPUT, GPIO_PULLUP | GPIO_ASYNC);

		/* Configure Driver for SPI function */
		ptsPeriSPIDriver[ePeriSPI_Channel_B].u16Port = ePeriSPI_Port_B;
		ptsPeriSPIDriver[ePeriSPI_Channel_B].psInstance = &SpibRegs;
	   
    #ifdef SPI_B_MASTER_MODE
		MstSPI_Initialize(&ptsPeriSPIDriver[ePeriSPI_Channel_B]);
    #else
		SlvSPI_Initialize(&ptsPeriSPIDriver[ePeriSPI_Channel_B]);
    #endif  // End define of SPIB_MASTER_MODE
	
#endif  // End define of USE_SPI_CHANNEL_B

}



