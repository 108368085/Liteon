/****************************************************************************
 *	File	Peripheral_DAC.c
 * 	Brief	Configure and control DAC module on TI 28004x platform
 * 	Note	DAC_B for Debug DAC Pin used
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

 
#include "F28x_Project.h"
#include "Peripheral_DAC.h"
#include <string.h>
 
/****************************************************************************
    Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/
#define ENABLE_DAC_CHANNEL_A
#define ENABLE_DAC_CHANNEL_C

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 8
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(PeriDacA_SetValue, ".TI.ramfunc");
#pragma CODE_SECTION(PeriDacC_SetValue, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/


/**
 *  @brief  Initial DAC module
 *  @retval None
 */
void PeriDac_Initialize(void)
{
	EALLOW;

#ifdef ENABLE_DAC_CHANNEL_A
    DacaRegs.DACCTL.bit.MODE = 1;
	DacaRegs.DACCTL.bit.DACREFSEL = 1;	// ADC VREFHI/VSSA are the reference voltages
	DacaRegs.DACOUTEN.bit.DACOUTEN = 1; // DAC output is enabled
   	DacaRegs.DACVALS.all = 0;			// Reset DAC value
    DELAY_US(10); 						// Delay for buffered DAC to power up
#endif

#ifdef ENABLE_DAC_CHANNEL_C
    DaccRegs.DACCTL.bit.MODE = 1;
	DaccRegs.DACCTL.bit.DACREFSEL = 1;	// ADC VREFHI/VSSA are the reference voltages
	DaccRegs.DACOUTEN.bit.DACOUTEN = 1; // DAC output is enabled
   	DaccRegs.DACVALS.all = 0;			// Reset DAC value
    DELAY_US(10); 						// Delay for buffered DAC to power up
#endif

	EDIS;
}

/**
 *  @brief  Start DAC module
 *  @retval None
 */
void PeriDac_Start(void)
{
	;
}

/**
 *  @brief  Stop DAC module
 *  @retval None
 */
void PeriDac_Stop(void)
{
    EALLOW;
    
#ifdef ENABLE_DAC_CHANNEL_A
    DacaRegs.DACVALS.all = 0;			// Reset DAC value
    DacaRegs.DACOUTEN.bit.DACOUTEN = 0; // DAC output is Disabled
#endif    
    
#ifdef ENABLE_DAC_CHANNEL_C
    DaccRegs.DACVALS.all = 0;			// Reset DAC value
    DaccRegs.DACOUTEN.bit.DACOUTEN = 0; // DAC output is Disabled
#endif

    EDIS;
}

/**
 *  @brief  Set DACa value to target channel
 *  @param  u16Value: DAC value is attempted to set
 *  @retval None
 */
void PeriDacA_SetValue(u16_t u16Value)
{

#ifdef ENABLE_DAC_CHANNEL_A
    DacaRegs.DACVALS.all = u16Value;
#endif

}

/**
 *  @brief  Set DACb value to target channel
 *  @param  u16Value: DAC value is attempted to set
 *  @retval None
 */
void PeriDacC_SetValue(u16_t u16Value)
{

#ifdef ENABLE_DAC_CHANNEL_C
    DaccRegs.DACVALS.all = u16Value;
#endif

}

/**
 *  @brief  Set DAC to toggle
 *  @param  u16Value: DAC value is attempted to set
 *  @retval None
 */
void PeriDac_SetToggle(void)
{
    if (DacaRegs.DACVALS.bit.DACVALS)
    {
        DacaRegs.DACVALS.bit.DACVALS = 0;
        DaccRegs.DACVALS.bit.DACVALS = 0;
    }
    else
    {
        DacaRegs.DACVALS.bit.DACVALS = 4095;
        DaccRegs.DACVALS.bit.DACVALS = 4095;
    }
}

