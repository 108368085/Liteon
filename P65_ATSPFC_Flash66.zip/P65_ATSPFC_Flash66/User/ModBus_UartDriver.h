/** @file       ModBus_UartDriver.h
 *  @brief      Header file of UART driver interface
 *  @author     Ollie Chen
 *  @version    1.0
 *  @date       
 */
 
#ifndef _MODBUS_UARTDRIVER_H_
#define _MODBUS_UARTDRIVER_H_

#include "CONFIG_Define.h"

/****************************************************************************
    Public parameter definition
****************************************************************************/
#define UART_TX_BUSY        0xFFFF

/****************************************************************************
	Public macro definition
****************************************************************************/
typedef u16_t (*pfUartDriverInterface_CheckTxIdle_t)(u16_t u16Channel);
typedef u16_t (*pfUartDriverInterface_TxWrite_t)(u16_t u16Channel, u16_t u16TxLength, u8_t* pu8Buff);
typedef u16_t (*pfUartDriverInterface_PreemptTx_t)(u16_t u16Channel, u16_t u16Priority);
typedef u16_t (*pfUartDriverInterface_GetRxByte_t)(u16_t u16Channel, u8_t* pu8Buff, u16_t u16BuffLimit);
typedef void (*pfUartDriverInterface_RxReset_t)(u16_t u16Channel);

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/
typedef struct sUartDriverInterface_t
{
    pfUartDriverInterface_CheckTxIdle_t   pfCheckTxIdle;
    pfUartDriverInterface_TxWrite_t       pfTxWrite;
    pfUartDriverInterface_PreemptTx_t     pfPreemptTx;
    pfUartDriverInterface_GetRxByte_t     pfGetRxByte;
    pfUartDriverInterface_RxReset_t       pfRxReset;
}sUartDriverInterface_t;

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/

#endif
