/****************************************************************************
 *	File	CanBus_Server.h
 * 	Brief	Header file for CanBus Server
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 ****************************************************************************/

#ifndef _CANBUS_SERVER_H_
#define _CANBUS_SERVER_H_

#include "CONFIG_Define.h"
#include "CANBus_Data.h"
#include "Peripheral_CAN.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/

#define CAN_Broadcast_Address		0x00
#define CAN_System_Address			0xA0
#define CAN_D2D_Device_Address		0xB0
#define CAN_ATS_Device_Address		0xC0
#define CAN_BBU_Device_Address		0xD0

	
#define CANBUS_SERVER_TX_BUFF		20

#define ENABLE_WRITE_PROTECT        0x00
#define DISABLE_WRITE_PROTECT       0x01
#define DEFAULT_WRITE_PROTECT       ENABLE_WRITE_PROTECT


#define SET_CANBUS_SERVER_BC_AC_LOSS		tsCANBusServer.nBroadcast.u16Bits.u1AC_LOSS = 1
#define SET_CANBUS_SERVER_BC_AC_RECOVER		tsCANBusServer.nBroadcast.u16Bits.u1AC_RECOVER = 1
#define SET_CANBUS_SERVER_BC_ATSPSU_FAIL	tsCANBusServer.nBroadcast.u16Bits.u1ATSPSU_FAIL = 1
#define SET_CANBUS_SERVER_BC_HEARTBEAT		tsCANBusServer.nBroadcast.u16Bits.u1HEARTBEAT = 1
#define SET_CANBUS_SERVER_BC_COMPATIBILITY	tsCANBusServer.nBroadcast.u16Bits.u1COMPATIBILITY = 1
#define SET_CANBUS_SERVER_Tx_VBulk_Protect  tsCANBusServer.nTransmit.u16Bits.u1VBulk_Protect = 1

#define SET_CANBUS_DEVICE_ADDRESS_NUM		tsCANBusServer.u16DeviceAddress_Number


#define GET_WRITE_PROTECT					tsCANBusServer.u8WriteProtect

/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/**
 *  Memory Composition is used to identify the next byte data is cascade or sequential in memory
 *  It is used to solve data reported incorrect in TI platform
 *  In other platform, Usually the data would be sequential
 *
 *  For Example:
 *                  Register Address            Register Value
 *  TI:             0x8000                      0x1234				cascade
 *                  0x8001                      0x5678
 *
 *  Otherwise:      0x8000                      0x34				sequential
 *                  0x8001                      0x12
 *                  0x8002                      0x78
 *                  0x8003                      0x56
 */
enum eMemoryComposition
{
    eMEMORY_COMPOSITION_SEQUENTIAL,
    eMEMORY_COMPOSITION_CASCADE,
};


/****************************************************************************
	Public structure definition 
****************************************************************************/
typedef union nCANBusServerBroadcast
{
    u16_t u16All;
    struct
    {
        u16_t u1AC_LOSS       	: 1;
		u16_t u1AC_RECOVER 		: 1;
		u16_t u1ATSPSU_FAIL		: 1;	//component fault
		u16_t u1HEARTBEAT       : 1;
		u16_t u1COMPATIBILITY   : 1;
        u16_t uReserved			: 11;
    }u16Bits;
    
}nCANBusServerBroadcast_t;

typedef union nCANBusServerTransmit
{
    u16_t u16All;
    struct
    {
        u16_t u1VBulk_Protect   : 1;
        u16_t uReserved         : 15;
    }u16Bits;

}nCANBusServerTransmit_t;


/*
*  ID = 0xABBCCDD, 29 bits in total
*  A = Communication type, 5 bits
*  BB = Address, 8 bits / 1 byte
*  CC = Command Code, 8 bits / 1 byte
*  DD = Extension Command Code, 8 bits / 1 byte
*/

typedef struct sCANBusServer
{
    nCANBusServerBroadcast_t nBroadcast;
    nCANBusServerTransmit_t  nTransmit;
	u8_t u8DataComposition;
    u8_t u8WriteProtect;

	u8_t u8DeviceAddress;			// 0xC0
	u16_t u16DeviceAddress_Number;	// 0, 1, ...6 , default:0 , change by modbus
	u32_t u32DeviceAddressNumber;	// 0xC1~0xC6
	u32_t u32DeviceAddressNumber_Shift;	// 0x00Cx0000, x=1~6

	u16_t u16PollingTime;			// unit is 10ms
	u16_t u16PollingData;

	// For Rx
	u32_t u32ID;
	u8_t u8ID_A_CommType;
    u8_t u8ID_BB_Address;
	u8_t u8ID_CC_Command;
	u8_t u8ID_DD_ExtCommand;
    sCANBusCmdStr_t* psCmd;    		// Pointer to a sCANBusCmdStr_t that indicated which command is serving
	
    // For Tx
    u16_t u16PushIndex;
    u16_t u16WriteIndex;
	u16_t u16EmergencyRequest;		// 1: broadcast request, 0: no broadcast request
	u16_t u16EmergencyAccept;		// 1: broadcast Data accept, 0: broadcast data not accept
	sCANDataFrame_t  sTxData[CANBUS_SERVER_TX_BUFF];
	sCANDataFrame_t  sTxDataEmergency;
}sCANBusServer_t;

/****************************************************************************
	Public export variable
****************************************************************************/
extern sCANBusServer_t tsCANBusServer;

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void CANBusServer_Rx_Callback(sCANDataFrame_t* psDataFrame);
extern void CANBusServer_Tx_Callback(void);
extern void CANBusServer_Push_CANBUS_Data(u8_t u8CommandType, u8_t u8CommandCode, u8_t u8TargetAddress);
extern void CANBusServer_Variable_Data(u8_t u8COMMAND, u8_t* pu8data);
extern void CANBusServer_1s_Periodically_Process(void);
extern void CANBusServer_1ms_Periodically_Process(void);
extern void CANBusServer_Background_Process(void);
extern void CANBusServer_Disable_Push_Data(void);
extern void CANBusServer_Initialize(void);

#endif
