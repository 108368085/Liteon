/****************************************************************************
 *	File	E2P_Data.c
 * 	Brief	Manage EEPROM data
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/12/25 - Modify from Ollie Chen
 ****************************************************************************/

#include <string.h>
#include "E2P_Data.h"
#include "E2P_BlackBox.h"
#include "SERV_Calibration.h"
#include "SERV_LOG.h"
#include "Peripheral.h"



/****************************************************************************
    Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

/*
// RAMLS0_6 : 177
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(E2pData_PushData, ".TI.ramfunc");
#pragma CODE_SECTION(E2pData_WriteProcess, ".TI.ramfunc");
#pragma CODE_SECTION(E2pData_Background_Process, ".TI.ramfunc");
#pragma CODE_SECTION(E2pData_Clear, ".TI.ramfunc");
#endif
*/

/****************************************************************************
	Private variable declaration
****************************************************************************/
sE2pDataManager_t tsE2pDataManager;

/****************************************************************************
	Public variable declaration
****************************************************************************/
u16_t pu16E2pDataInRam[E2PDATA_NUM];

/**
 *  @brief  Reset E2P Data
 *  @retval None
 */
static inline void E2pData_Reset(void)
{
    u16_t i;
    
    for (i=0; i<tsE2pDataManager.u16E2PDATA_NUM; i++)
    {
        pu16E2pDataInRam[i] = 0xFFFF;
    }
    
    tsE2pDataManager.u16PushIndex = 0;
    tsE2pDataManager.u16WriteIndex = 0;
}

/**
 *  @brief  Read EEPROM data to RAM buffer
 *  @retval RequestFailed: Read operation failed
 *  @retval RequestProcessed: Read operation success
 */
static u16_t E2pData_ReadData(void)
{
	//u16_t u16looplimit = 0;
    eE2pDriverState_t eDriverState;

	PeriSPI_ResetBusIdleDelay();
	
    do
    {
    /*
    	u16looplimit ++;
		
		if (u16looplimit > 500)	//normal 340 loop will finished
		{
			tsE2pDataManager.psE2pDriver->pfResetDriver(tsE2pDataManager.psE2pDriver);
			return RequestFailed;
		}

	*/
        eDriverState = tsE2pDataManager.psE2pDriver->pfGetDriverState(tsE2pDataManager.psE2pDriver);
        
        if (eDriverState == E2P_STATE_IDLE)
        {
#ifndef TI_C28_PLATFORM
            tsE2pDataManager.psE2pDriver->pfMemoryRead(tsE2pDataManager.psE2pDriver, E2PDATA_START_ADDRESS, tsE2pDataManager.u16E2PDATA_NUM * 2, (u8_t*)pu16E2pDataInRam);
#else
            tsE2pDataManager.psE2pDriver->pfMemoryRead(tsE2pDataManager.psE2pDriver, E2PDATA_START_ADDRESS, tsE2pDataManager.u16E2PDATA_NUM * 2, tsE2pDataManager.pu8E2pDataInRam);
#endif
        }
        else if (eDriverState == E2P_STATE_READY)
        {
#ifdef TI_C28_PLATFORM
            u16_t i;

            for (i=0; i<tsE2pDataManager.u16E2PDATA_NUM; i++)
            {
                pu16E2pDataInRam[i] = __LByteToWord(&tsE2pDataManager.pu8E2pDataInRam[i*2]);
            }
#endif
            tsE2pDataManager.psE2pDriver->pfResetDriver(tsE2pDataManager.psE2pDriver);
        }
        else if (eDriverState == E2P_STATE_ERROR)
        {
            tsE2pDataManager.psE2pDriver->pfResetDriver(tsE2pDataManager.psE2pDriver);
            return RequestFailed;
        }
		
		PeriSPI_Background_Process();
		
    }while(eDriverState != E2P_STATE_READY);

	if (Calibration_IsValidCoefficient() == RequestAccepted)
	{
		return RequestProcessed; 
	}
	else
	{
		return RequestProcessing; 
	}
}
 
/**
 *  @brief  Try to fetch EEPROM data to RAM buffer
 *  @retval None
 */
static void E2pData_ReadDataToRam(void)
{
    u16_t i;
	u16_t u16IsDataValid;
	
    for (i=0; i<E2PDATA_RETRY_TIMES; i++)
    {
    	u16IsDataValid = E2pData_ReadData();
		
        if (u16IsDataValid == RequestProcessed)
        {
            break;
        }
    }

    if ((i == E2PDATA_RETRY_TIMES) && (u16IsDataValid == RequestFailed))
    {
        E2pData_Reset();
    }
}
 
/**
 *  @brief  Initial E2P Data, read data form EEPROM when PSU start up
 *  @retval None
 */
void E2pData_Initialize(void)
{
	u16_t i;

	memset(&tsE2pDataManager, 0, sizeof(tsE2pDataManager));
	tsE2pDataManager.u16E2PDATA_NUM = E2PDATA_NUM;
	
    for (i=0; i < tsE2pDataManager.u16E2PDATA_NUM; i++)
    {
        memset(&pu16E2pDataInRam[i], 0xFFFF, sizeof(pu16E2pDataInRam[i]));
	}
	   
    tsE2pDataManager.psE2pDriver = E2pDrv_GetDriverInformation(E2p_Tag_1);
    E2pData_ReadDataToRam();
}


/**
 *  @brief  Push the index and data to write buffer
 *  @param  u16Index: The index of E2PDATA
 *  @param  u16Data: New data which is attempted to push
 *  @retval RequestDenied: This push request has been denied.
 *  @retval RequestAccepted: This push request has been accepted.
 */
u16_t E2pData_PushData(u16_t u16Index, u16_t u16Data)
{
	if ((u16Index < tsE2pDataManager.u16E2PDATA_NUM) && 
		(tsE2pDataManager.u16PushIndex < tsE2pDataManager.u16E2PDATA_NUM))
    {
        pu16E2pDataInRam[u16Index] = u16Data;

#ifndef TI_C28_PLATFORM

        tsE2pDataManager.pu16E2pDataBuff[tsE2pDataManager.u16PushIndex] = u16Data;
#else
        __WordToLByte(&tsE2pDataManager.pu16E2pDataBuff[tsE2pDataManager.u16PushIndex * 2], u16Data);
#endif
        tsE2pDataManager.pu16E2pDataIndex[tsE2pDataManager.u16PushIndex] = u16Index;

        tsE2pDataManager.u16PushIndex += 1;
		
        return RequestAccepted;
    }
    else
    {
        return RequestDenied;
    }
}

/**
 *  @brief  E2P Data Write Process
 *  @retval None
 */
static inline void E2pData_WriteProcess(void)
{
    eE2pDriverState_t eDriverState = tsE2pDataManager.psE2pDriver->pfGetDriverState(tsE2pDataManager.psE2pDriver);
    
    if (eDriverState == E2P_STATE_IDLE)
    {
        if (tsE2pDataManager.u16PushIndex != tsE2pDataManager.u16WriteIndex)
        {
#ifndef TI_C28_PLATFORM
            tsE2pDataManager.psE2pDriver->pfMemoryWrite(tsE2pDataManager.psE2pDriver, E2PDATA_START_ADDRESS + tsE2pDataManager.pu16E2pDataIndex[tsE2pDataManager.u16WriteIndex]*2, 2, (u8_t*)&tsE2pDataManager.pu16E2pDataBuff[tsE2pDataManager.u16WriteIndex]);
#else
            tsE2pDataManager.psE2pDriver->pfMemoryWrite(tsE2pDataManager.psE2pDriver, E2PDATA_START_ADDRESS + tsE2pDataManager.pu16E2pDataIndex[tsE2pDataManager.u16WriteIndex]*2, 2, (u8_t*)&tsE2pDataManager.pu16E2pDataBuff[tsE2pDataManager.u16WriteIndex*2]);
#endif
            tsE2pDataManager.nFlag.u16Bits.u1DataAccessing = 1;
        }
    }
    else if (eDriverState == E2P_STATE_READY)
    {
        if (tsE2pDataManager.nFlag.u16Bits.u1DataAccessing == 1)
        {
            /* Release E2P driver */
            tsE2pDataManager.psE2pDriver->pfResetDriver(tsE2pDataManager.psE2pDriver);
            
            tsE2pDataManager.u16WriteIndex += 1;
            
            if (tsE2pDataManager.u16WriteIndex == tsE2pDataManager.u16PushIndex)
            {
                tsE2pDataManager.u16WriteIndex = 0;
                tsE2pDataManager.u16PushIndex = 0;
            }

            tsE2pDataManager.nFlag.u16Bits.u1DataAccessing = 0;
        }
    }
    else if (eDriverState == E2P_STATE_ERROR)
    {
        if (tsE2pDataManager.nFlag.u16Bits.u1DataAccessing == 1)
        {
            /* Release E2P driver */
            tsE2pDataManager.psE2pDriver->pfResetDriver(tsE2pDataManager.psE2pDriver);

            tsE2pDataManager.nFlag.u16Bits.u1DataAccessing = 0;
        }
    }
}

/**
 *  @brief  E2pData Back Ground Process
 *  @retval None
 */
void E2pData_Background_Process(void)
{
    E2pData_WriteProcess();
}

/**
 *  @brief  Clear E2pData by internal command
 *  @retval 
 */
void E2pData_Clear(void)
{
    if (tsE2pDataManager.u8ClearE2PDATA == ON)
    {
        GET_LOG_SWITCH_TIME = 0;
        GET_LOG_TOT_SWITCH_TIME = 0;
        GET_LOG_TOT_WORK_TIME = 0;
		SET_BLACKBOX_RECORD_EVENT_NUM = 0;
		SET_BLACKBOX_LATEST_INDEX = -1;
        
        E2pData_PushData(E2pDataIndex_TotATSwitchCNT, 0);
        E2pData_PushData(E2pDataIndex_TotATSwitchCNT + 1, 0);
        E2pData_PushData(E2pDataIndex_TotPowerOnTime, 0);
        E2pData_PushData(E2pDataIndex_TotPowerOnTime + 1, 0);
        E2pData_PushData(E2pDataIndex_BlackBox_EventNumber, SET_BLACKBOX_RECORD_EVENT_NUM);
        E2pData_PushData(E2pDataIndex_BlackBox_LatestIndex, SET_BLACKBOX_LATEST_INDEX);

        tsE2pDataManager.u8ClearE2PDATA = OFF;
    }
}



