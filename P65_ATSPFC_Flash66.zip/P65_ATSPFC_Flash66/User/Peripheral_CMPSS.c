/****************************************************************************
 *	File	Peripheral_CMPSS.c
 * 	Brief	Configure Comparator SubSystem module on TI 28004x platform
 *  Note    See TI SPEC "Analog Pins and Internal Connections"
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/
 
#include "f28x_project.h"
#include "Peripheral_CMPSS.h"
#include "Handler_PFC.h"

/****************************************************************************
    Private parameter definition
****************************************************************************/

/* Configure Digital Filter 
 * Maximum SAMPWIN value provides largest number of samples
 * 3+1 sample counts,  1us*4 = 4us
 */

#define CMPSS_SAMPWIN			0x03


/* Maximum THRESH value requires static value for entire window 
 * SAMPWIN/2 < THRESH <= SAMPWIN
 * Output would be changed if condition is matched during THRESH duration
 * 2+1 sample counts,  1us*3 = 3us
 */

#define CMPSS_THRESH			0x02

/* Configure Digital Filter 
 * Maximum CLKPRESCALE value provides the most time between samples
 * 199+1, 200MHz/200 = 1MHz
 */

#define CMPSS_CLKPRESCALE		0xC7


/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

/****************************************************************************
	Private variable declaration
****************************************************************************/

/**
 *  @brief  Initial CMPSS 2H module
 *  @Note 	For Interleaved PFC phase A current positive protect
 *			Using CMPSS-2 High Comparator Positive Input 0 (CMPSS2.CTRIPH) for trip 1
 */
static inline void PeriCmpss_Init_CMPSS2HP(void)
{
    EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPHPMXSEL.bit.CMP2HPMXSEL = 0; // ADC-A4

	/* CMPSSx Comparator Config */
	Cmpss2Regs.COMPCTL.bit.COMPDACE = 1;            // Enable Comparator/DAC
    Cmpss2Regs.COMPCTL.bit.COMPHSOURCE = 0;         // Inverting input of comparator driven by internal DAC
    Cmpss2Regs.COMPCTL.bit.COMPHINV = 0;            // Output of comparator is not inverted
    Cmpss2Regs.COMPCTL.bit.ASYNCHEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

    Cmpss2Regs.COMPDACHCTL.bit.DACSOURCE = 0;        // DACHVALA is updated from DACHVALS
    Cmpss2Regs.COMPDACHCTL.bit.SELREF = 0;           // VDDA is the voltage reference for the DAC
    Cmpss2Regs.COMPDACHCTL.bit.SWLOADSEL = 0;        // DACxVALA is updated from DACxVALS on SYSCLK
    
    Cmpss2Regs.DACHVALS.bit.DACVAL = 0xFFF;         // Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss2Regs.CTRIPHFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss2Regs.CTRIPHFILCTL.bit.THRESH = CMPSS_THRESH; // (2+1)/1MHz = 3us
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
    Cmpss2Regs.CTRIPHFILCLKCTL= CMPSS_CLKPRESCALE; // 200MHz/(199+1) = 1MHz
    Cmpss2Regs.CTRIPHFILCLKCTL2.bit.CLKPRESCALEU = 0;
  
    /* Reset filter logic and start filtering */
    Cmpss2Regs.CTRIPHFILCTL.bit.FILINIT = 1;

	Cmpss2Regs.COMPCTL.bit.CTRIPHSEL = 2;           // Output of digital filter drives CTRIPH
	
	EDIS;
}


/**
 *  @brief  Initial CMPSS 2L module
 *  @Note 	For Interleaved PFC phase A current negative protect
 *			Using CMPSS-2 Low Comparator Positive Input 0 (CMPSS2.CTRIPL) for trip 7
 */
static inline void PeriCmpss_Init_CMPSS2LP(void)
{
	EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPLPMXSEL.bit.CMP2LPMXSEL = 0; // ADC-A4

	/* CMPSSx Comparator Config */
    Cmpss2Regs.COMPCTL.bit.COMPLSOURCE = 0;         // Inverting input of comparator driven by internal DAC
    Cmpss2Regs.COMPCTL.bit.COMPLINV = 1;            // Output of comparator is inverted  
    Cmpss2Regs.COMPCTL.bit.ASYNCLEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

    Cmpss2Regs.DACLVALS.bit.DACVAL = 0;         	// Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss2Regs.CTRIPLFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss2Regs.CTRIPLFILCTL.bit.THRESH = CMPSS_THRESH;
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
    Cmpss2Regs.CTRIPLFILCLKCTL= CMPSS_CLKPRESCALE;
    Cmpss2Regs.CTRIPLFILCLKCTL2.bit.CLKPRESCALEU = 0;
  
    /* Reset filter logic and start filtering */
    Cmpss2Regs.CTRIPLFILCTL.bit.FILINIT = 1;

	Cmpss2Regs.COMPCTL.bit.CTRIPLSEL = 2;			// Output of digital filter drives CTRIPH

    EDIS;
}

/**
 *  @brief  Initial CMPSS 3H module
 *  @Note   For Interleaved PFC phase B current positive protect
 *          Using CMPSS-3 High Comparator Positive Input 0 (CMPSS2.CTRIPH) for trip 2
 */
static inline void PeriCmpss_Init_CMPSS3HP(void)
{
    EALLOW;

    /* CMPSSx Input MUX Config */
    AnalogSubsysRegs.CMPHPMXSEL.bit.CMP3HPMXSEL = 0; // ADC-B2

    /* CMPSSx Comparator Config */
    Cmpss3Regs.COMPCTL.bit.COMPDACE = 1;            // Enable Comparator/DAC
    Cmpss3Regs.COMPCTL.bit.COMPHSOURCE = 0;         // Inverting input of comparator driven by internal DAC
    Cmpss3Regs.COMPCTL.bit.COMPHINV = 0;            // Output of comparator is not inverted
    Cmpss3Regs.COMPCTL.bit.ASYNCHEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

    Cmpss3Regs.COMPDACHCTL.bit.DACSOURCE = 0;        // DACHVALA is updated from DACHVALS
    Cmpss3Regs.COMPDACHCTL.bit.SELREF = 0;           // VDDA is the voltage reference for the DAC
    Cmpss3Regs.COMPDACHCTL.bit.SWLOADSEL = 0;        // DACxVALA is updated from DACxVALS on SYSCLK

    Cmpss3Regs.DACHVALS.bit.DACVAL = 0xFFF;         // Maximum value of 12Bit, application should override this value before start comparator

    /* Configure Digital Filter
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss3Regs.CTRIPHFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;

    /* Maximum THRESH value requires static value for entire window
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss3Regs.CTRIPHFILCTL.bit.THRESH = CMPSS_THRESH;

    /* Configure Digital Filter
     * Maximum CLKPRESCALE value provides the most time between samples
     */
    Cmpss3Regs.CTRIPHFILCLKCTL= CMPSS_CLKPRESCALE; // 200MHz/(199+1) = 1MHz
    Cmpss3Regs.CTRIPHFILCLKCTL2.bit.CLKPRESCALEU = 0;

    /* Reset filter logic and start filtering */
    Cmpss3Regs.CTRIPHFILCTL.bit.FILINIT = 1;

    Cmpss3Regs.COMPCTL.bit.CTRIPHSEL = 2;           // Output of digital filter drives CTRIPH

    EDIS;
}

/**
 *  @brief  Initial CMPSS 3L module
 *  @Note   For Interleaved PFC phase B current negative protect
 *          Using CMPSS-3 Low Comparator Positive Input 0 (CMPSS2.CTRIPL) for trip 2
 */
static inline void PeriCmpss_Init_CMPSS3LP(void)
{
    EALLOW;

    /* CMPSSx Input MUX Config */
    AnalogSubsysRegs.CMPLPMXSEL.bit.CMP3LPMXSEL = 0; // ADC-B2

    /* CMPSSx Comparator Config */
    Cmpss3Regs.COMPCTL.bit.COMPLSOURCE = 0;         // Inverting input of comparator driven by internal DAC
    Cmpss3Regs.COMPCTL.bit.COMPLINV = 1;            // Output of comparator is inverted
    Cmpss3Regs.COMPCTL.bit.ASYNCLEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

    Cmpss3Regs.DACLVALS.bit.DACVAL = 0;             // Maximum value of 12Bit, application should override this value before start comparator

    /* Configure Digital Filter
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss3Regs.CTRIPLFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;

    /* Maximum THRESH value requires static value for entire window
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss3Regs.CTRIPLFILCTL.bit.THRESH = CMPSS_THRESH;

    /* Configure Digital Filter
     * Maximum CLKPRESCALE value provides the most time between samples
     */
    Cmpss3Regs.CTRIPLFILCLKCTL= CMPSS_CLKPRESCALE; // 200MHz/(199+1) = 1MHz
    Cmpss3Regs.CTRIPLFILCLKCTL2.bit.CLKPRESCALEU = 0;

    /* Reset filter logic and start filtering */
    Cmpss3Regs.CTRIPLFILCTL.bit.FILINIT = 1;

    Cmpss3Regs.COMPCTL.bit.CTRIPLSEL = 2;           // Output of digital filter drives CTRIPH

    EDIS;
}

/**
 *  @brief  Initial CMPSS 5H module
 *  @Note 	For Interleaved PFC phase C current positive protect
 *			Using CMPSS-5 High Comparator Positive Input 3 (CMPSS6.CTRIPH) for trip 3
 */
static inline void PeriCmpss_Init_CMPSS5HP(void)
{
    EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPHPMXSEL.bit.CMP5HPMXSEL = 0; // ADC-C4

	/* CMPSSx Comparator Config */
	Cmpss5Regs.COMPCTL.bit.COMPDACE = 1;            // Enable Comparator/DAC
	Cmpss5Regs.COMPCTL.bit.COMPHSOURCE = 0;         // COMPH, Inverting input of comparator driven by internal DAC
	Cmpss5Regs.COMPCTL.bit.COMPHINV = 0;            // Output of comparator is not inverted
	Cmpss5Regs.COMPCTL.bit.ASYNCHEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output

	Cmpss5Regs.COMPDACHCTL.bit.DACSOURCE = 0;        // DACHVALA is updated from DACHVALS
    Cmpss5Regs.COMPDACHCTL.bit.SELREF = 0;           // VDDA is the voltage reference for the DAC
    Cmpss5Regs.COMPDACHCTL.bit.SWLOADSEL = 0;        // DACxVALA is updated from DACxVALS on SYSCLK
    
    Cmpss5Regs.DACHVALS.bit.DACVAL = 0xFFF;         // Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
    Cmpss5Regs.CTRIPHFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
    Cmpss5Regs.CTRIPHFILCTL.bit.THRESH = CMPSS_THRESH;
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
    Cmpss5Regs.CTRIPHFILCLKCTL= CMPSS_CLKPRESCALE; // 200MHz/(199+1) = 1MHz
    Cmpss5Regs.CTRIPHFILCLKCTL2.bit.CLKPRESCALEU = 0;
  
    /* Reset filter logic and start filtering */
    Cmpss5Regs.CTRIPHFILCTL.bit.FILINIT = 1;

    Cmpss5Regs.COMPCTL.bit.CTRIPHSEL = 2;			// Output of digital filter drives CTRIPH

	EDIS;
}


/**
 *  @brief  Initial CMPSS 5L module
 *  @Note 	For Interleaved PFC phase C current negative protect
 *			Using CMPSS-5 Low Comparator Positive Input 3 (CMPSS6.CTRIPL) for trip 3
 */
static inline void PeriCmpss_Init_CMPSS5LP(void)
{
	EALLOW;

	/* CMPSSx Input MUX Config */
	AnalogSubsysRegs.CMPLPMXSEL.bit.CMP5LPMXSEL = 0; // ADC-C4

	/* CMPSSx Comparator Config */
	Cmpss5Regs.COMPCTL.bit.COMPLSOURCE = 0;         // COMPH, Inverting input of comparator driven by internal DAC
	Cmpss5Regs.COMPCTL.bit.COMPLINV = 1;            // Output of comparator is inverted
	Cmpss5Regs.COMPCTL.bit.ASYNCLEN = 0;            // Asynchronous comparator output does not feed into OR gate with latched digital filter output
	
	Cmpss5Regs.DACLVALS.bit.DACVAL = 0;         	// Maximum value of 12Bit, application should override this value before start comparator

	/* Configure Digital Filter 
     * Maximum SAMPWIN value provides largest number of samples
     */
	Cmpss5Regs.CTRIPLFILCTL.bit.SAMPWIN = CMPSS_SAMPWIN;
    
    /* Maximum THRESH value requires static value for entire window 
     * SAMPWIN/2 < THRESH <= SAMPWIN
     * Output would be changed if condition is matched during THRESH duration
     */
	Cmpss5Regs.CTRIPLFILCTL.bit.THRESH = CMPSS_THRESH;
 
    /* Configure Digital Filter 
     * Maximum CLKPRESCALE value provides the most time between samples 
     */
	Cmpss5Regs.CTRIPLFILCLKCTL= CMPSS_CLKPRESCALE; // 200MHz/(199+1) = 1MHz
	Cmpss5Regs.CTRIPLFILCLKCTL2.bit.CLKPRESCALEU = 0;
  
    /* Reset filter logic and start filtering */
	Cmpss5Regs.CTRIPLFILCTL.bit.FILINIT = 1;

	Cmpss5Regs.COMPCTL.bit.CTRIPLSEL = 2;			// Output of digital filter drives CTRIPH

    EDIS;
}

/**
 *  @brief  Initial CMPSS module
 *  @retval None
 */
void PeriCmpss_Initialize(void)
{
	PeriCmpss_Init_CMPSS2HP();
	PeriCmpss_Init_CMPSS2LP();
    PeriCmpss_Init_CMPSS3HP();
    PeriCmpss_Init_CMPSS3LP();
	PeriCmpss_Init_CMPSS5HP();
	PeriCmpss_Init_CMPSS5LP();
}

/** 
 *  @brief  Set internal DAC value
 *  @param  u16Value: DAC value of comparator 
 *  @retval None
 */
static void PeriCmpss_SetCMPSSHPValue(u16_t u16Value)
{
    EALLOW;
    Cmpss2Regs.DACHVALS.bit.DACVAL = u16Value;
    Cmpss3Regs.DACHVALS.bit.DACVAL = u16Value;
	Cmpss5Regs.DACHVALS.bit.DACVAL = u16Value;
    EDIS;
}

/** 
 *  @brief  Set internal DAC value
 *  @param  u16Value: DAC value of comparator 
 *  @retval None
 */
static void PeriCmpss_SetCMPSSLPValue(u16_t u16Value)
{
    EALLOW;
    Cmpss2Regs.DACLVALS.bit.DACVAL = u16Value;
    Cmpss3Regs.DACLVALS.bit.DACVAL = u16Value;
	Cmpss5Regs.DACLVALS.bit.DACVAL = u16Value;
    EDIS;
}

/**
 *  @brief  Start peripheral - CMPSS
 *  @retval None
 */
void PeriCmpss_Start(void)
{
	PeriCmpss_SetCMPSSHPValue(PFC_CBC_HIGH);
	PeriCmpss_SetCMPSSLPValue(PFC_CBC_Low);
}

/**
 *  @brief  Stop peripheral - CMPSS
 *  @retval None
 */
void PeriCmpss_Stop(void)
{
	PeriCmpss_SetCMPSSHPValue(0xFFF);
	PeriCmpss_SetCMPSSLPValue(0);
    EALLOW;
    Cmpss2Regs.COMPCTL.bit.COMPDACE = 0;            // Disable Comparator/DAC
    Cmpss3Regs.COMPCTL.bit.COMPDACE = 0;            // Disable Comparator/DAC
    Cmpss5Regs.COMPCTL.bit.COMPDACE = 0;            // Disable Comparator/DAC
    EDIS;
}

