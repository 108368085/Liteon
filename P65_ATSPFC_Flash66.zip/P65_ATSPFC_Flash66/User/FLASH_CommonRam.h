/** @file       FLASH_CommonRam.h
 *  @brief      Header file for Common RAM
 *  @author     Adonis Wang
 *  @version    2.0
 *  @history    modify from ollie chen
 */

#ifndef _FLASH_COMMONRAM_H_
#define _FLASH_COMMONRAM_H_

#include "CONFIG_Define.h"

/****************************************************************************
    Public parameter definition
****************************************************************************/
#define COMMON_RAM_SIZE             16

#define DEVICE_COLD_STARTUP         0x66BB
#define DEVICE_WARM_STARTUP         0x55AA


//.ebss section : Global and static variables
#define RAM_START_ADDRESS           0x008000	//0x8000 is LS0, 0xC000 is GS0
#define RAM_END_ADDRESS             0x013FFF
/****************************************************************************
	Public macro definition
****************************************************************************/

#define COMMON_RAM_ADDRESS_STARTUP_TYPE     0
#define COMMON_RAM_SIZE_STARTUP_TYPE        1

#define COMMON_RAM_ADDRESS_ProgramBlocks    (COMMON_RAM_ADDRESS_STARTUP_TYPE + COMMON_RAM_SIZE_STARTUP_TYPE)
#define COMMON_RAM_SIZE_ProgramBlocks       1


/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/

extern void CommonRam_PushData(u16_t u16RamAddress, u16_t u16Data);
extern u16_t CommonRam_PopData(u16_t u16RamAddress);
extern void ClearApplicationRam(void);

#endif
