/** @file       FLASH_IAP.c
 *  @author     Adonis Wang
 *  @brief      Header file for In Application Programming
 *  @version    2.0
 *  @history    modify from ollie chen
 */ 
#ifndef _FLASH_IAP_H_
#define _FLASH_IAP_H_


#include "CONFIG_Define.h"
#include "Peripheral_CAN.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/

/* Image header Size */
#define IMAGE_HEADER_SIZE        		64      ///< Byte length of image header

/* Image Data Block size */
#define IMAGE_BLOCK_SIZE         		64      ///< Byte length of image would be send in one transaction

/* REVISION_ASCII_FOR_SYSTEM*/
#define REVISION_ASCII_FOR_SYSTEM_SIZE  23

// LED indictor Time out 30min
#define IAP_LED_Time_Out    			1800	// unit is 1s



#define SET_IAP_RECEIVE_DATA			tsIapHandler.pu8ReceiveData
#define GET_IAP_ACK						tsIapHandler.u8FWUpdateACK
#define SET_IAP_CRC8					tsIapHandler.u8FileCrc8_PSC
#define SET_IAP_CRC16					tsIapHandler.u16FileCrc_PSC
#define SET_IAP_FWAction				tsIapHandler.u8FWAction
#define GET_STATUS_BOOTLOADER			tsIapHandler.nStatus.u8All
#define GET_MAJOR_REVISION				tsIapHandler.sImageRevision.u8MajorRevision
#define GET_MINOR_REVISION   			tsIapHandler.sImageRevision.u8MiniorRevision
#define GET_IAP_PROGRAM_STAGE			tsIapHandler.u8ProgramStage
#define SET_IAP_CURRENT_PROGRAM_BLOCK	tsIapHandler.u32CurrentProgramBlocks
#define SET_IAP_MAX_PROGRAM_BYTE		tsIapHandler.u8MaxProgramBytes
#define SET_IAP_MAX_PROGRAM_BLOCK		tsIapHandler.u32MaxProgramBlocks
#define GET_IAP_INTERNAL_REVISION		tsIapHandler.u32InternalRevision
#define GET_IAP_RELEASE_DATE			tsIapHandler.u32FW_Release_Date
#define GET_IAP_LED_INDICATOR_CNT		tsIapHandler.u16LED_Indicator_CNT


/****************************************************************************
	Public macro definition
****************************************************************************/
#define UapCodeEntry        (void   (*)(void))ACTIVE_IMAGE_UAP_ADDRESS
#define BootCodeEntry       (void   (*)(void))BOOT_ENTRY_ADDRESS


/****************************************************************************
	Public enumeration definition 
****************************************************************************/
enum IapRequestEnumeration
{
    eIAP_ASKING_PERMIT_TO_SWITCH_MODE = 0x0000,
	eIAP_REQUEST_ENTER_BOOT_MODE,
    eIAP_REQUEST_ENTER_UAP_MODE,
};

enum eImageTagEnumeration
{
    eIMAGE_TAG_ACTIVE,
    eIMAGE_TAG_BACKUP,
    eIMAGE_TAG_NUM,
};

enum eProgramStageEnumeration
{
    eProgram_IDLE = 0,
    eProgram_HEADER,
    eProgram_ING,
    eProgram_BLOCK,
};


/****************************************************************************
	Public structure definition 
****************************************************************************/
typedef union nFirmwareUploadStatus
{
    u8_t u8All;    
    struct
    {
        u8_t u1FullyImageReceived          	: 1;        ///< Full image received successfully
        u8_t u1ImageReceiving              	: 1;        ///< Image has not been received or only partially received
        u8_t u1OverrideSafeModeImage       	: 1;        ///< Full image received but image is bad or corrupt. PSU can power on with minimum operating capability
        u8_t u1RecoverCorruptImage         	: 1;        ///< Full image received but image is bad or corrupt. PSU can power on and support full feature
        u8_t u1UnsupportedImage            	: 1;        ///< Image not supported.
        u8_t uReserved           			: 3;
    }u8Bits;
    
}nFirmwareUploadStatus_t;


typedef struct sHardwareCompatibility
{
    u8_t pu8HardwareCompatibleCode[2];
}sHardwareCompatibility_t;

typedef struct sFirmwareRevision
{
    u8_t u8MajorRevision;
    u8_t u8MiniorRevision;
	u8_t u8Reserved;
}sFirmwareRevision_t;

typedef struct sImageHeader
{
    u8_t pu8ImageCRC[2];
    u8_t pu8StartIndex[2];
    u8_t pu8LastIndex[2];
    u8_t pu8Reserved[4];
    u8_t pu8CodeID[12];
    u8_t pu8Location[1];
    u8_t pu8MajorRevision[1];
	u8_t pu8MinorRevision[1];
	u8_t pu8ReservedRevision[1];
    u8_t pu8ImageHWCC[2];
    u8_t pu8BlockSize[2];
    u8_t pu8WriteTime[2];
    u8_t pu8Reserved_2[32];
}sImageHeader_t;


typedef union nIapProgressFlag
{
	u16_t u16All;
	struct
	{
        u16_t u1Erasebackupimage       	: 1;
        u16_t u1VerifyImageChecksum     : 1;
        u16_t u1InspectBackupImage      : 1;
        u16_t u1AskingPermission        : 1;
        u16_t u1SwitchMode              : 1;
		u16_t uReserved			   	 	: 10;
        u16_t u1DenyUpload              : 1;
	}u16Bits;    
}nIapProgressFlag_t;

typedef struct sImageLocator
{
    u32_t u32Address_Stamp;
    u32_t u32Address_PIB;
    u32_t u32Address_RCB;
    u32_t u32Address_UAP;
}sImageLocator_t;

typedef struct sIapHandler
{
	nIapProgressFlag_t nProgressFlag;
    nFirmwareUploadStatus_t nStatus;
    sHardwareCompatibility_t sCompatibility;
    sFirmwareRevision_t sImageRevision;

	//APP internal revision
	u32_t u32InternalRevision;		//Major(FWCC).Minor.Internal.HWCC
	u32_t u32FW_Release_Date;
	
    // Flash Program
    u32_t u32CurrentProgramBlocks;	// Block start info.
	u32_t u32MaxProgramBlocks;		// Block start info.
	u32_t u32MaxProgramBlocks_image;// LastIndex from image header.
    u32_t u32TotalProgramBlocks;
    u16_t u16StoreImageStamp[8];    // Store image stamp when received first block
    u16_t pu16ProgramData[IMAGE_BLOCK_SIZE>>1];	// convert UploadData 8 to 16
    u16_t u16FileCrc;				// CRC16 value of entire FW image
    u16_t u16FileCrc_PSC;			// CRC16 value of entire FW image from PSC
	u8_t pu8ReceiveData[CAN_BUFF_SIZE];			//receive data from can bus
    u8_t pu8UploadData[IMAGE_BLOCK_SIZE];		//sum of receive data
    u8_t u8MaxProgramBytes;			// Block start info.
	u8_t u8FileCrc8;				// CRC8 value
	u8_t u8FileCrc8_PSC;			// CRC8 value from PSC
	u8_t u8FWUpdateACK;				// 0:ack, 1:Nack, 2:unsupport image
	u8_t u8ProgramStage;			// Bootloader stage: header or block data
	u8_t u8ReceiveIndex;			// Receive data index
	u8_t u8FWAction;				// 0: Restart PSU, 1: Abort FW update

	// LED indicator time out
	u16_t u16LED_Indicator_CNT;		// 0: LED off, >=1 (in bootloader progress)

    sImageHeader_t sImageHeader;
    sImageLocator_t psImageLocator[eIMAGE_TAG_NUM];

}sIapHandler_t;

/****************************************************************************
	Public export variable
****************************************************************************/
extern sIapHandler_t tsIapHandler;

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void IAP_Initialize(void);
extern void IAP_Background_Process(void);
extern void IAP_Program_START(void);
extern void IAP_HEADER_START(void);
extern void IAP_HEADER_DTAT(void);
extern void IAP_HEADER_STOP(void);
extern void IAP_BLOCK_START(void);
extern void IAP_BLOCK_DTAT(void);
extern void IAP_BLOCK_STOP(void);
extern void IAP_Program_STOP(void);

#endif

