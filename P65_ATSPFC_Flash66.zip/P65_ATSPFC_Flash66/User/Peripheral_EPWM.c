/****************************************************************************
 *	File	Peripheral_EPWM.c
 * 	Brief	Configure and control ePWM module on TI 28004x platform
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 *
 *			EPWM1A: 100kHz	BIAS_A
 *			EPWM1B: 100kHz	BIAS_B
 *			EPWM3A: 20kHz	PFC inrush limit relay
 *			EPWM3B: 20kHz	PFC inrush limit IGBT
 *			EPWM6A: 40kHz   Interleaved Totlem Pole PFC phase C H side
 *			EPWM6B: 40kHz   Interleaved Totlem Pole PFC phase C H side
 *          EPWM7A: 40kHz	Interleaved Totlem Pole PFC phase A H side
 *          EPWM7B: 40kHz	Interleaved Totlem Pole PFC phase A L side
 *          EPWM8A: 40kHz	Interleaved Totlem Pole PFC phase B H side
 *          EPWM8B: 40kHz	Interleaved Totlem Pole PFC phase B L side
 *
 *          1. EPWM7 trigger ADCSOC in up-down-count at Zero
 *          2. EPWM8 trigger ADCSOC in up-down-count at Period
 *          3. When EPWM8 trigger EOC5 over, will enter ADC 40KHz interrupt
 *
 *          GATE_A(PWM6A)       \ GATE_A(PWM7A)     \ GATE_C(PWM8A)
 *          |-------------------|-------------------|
 *          GATE_A(PWM6B)       \ GATE_B(PWM7B)     \ GATE_D(PWM8B)
 ****************************************************************************/

#include "f28x_project.h"
#include "sw_prioritized_isr_levels.h"
#include "Peripheral.h"
#include "Peripheral_EPWM.h"
#include "Handler_PFC.h"
#include <string.h>


/****************************************************************************
    Private parameter definition
****************************************************************************/

   
/****************************************************************************
	Private macro definition
****************************************************************************/

#define STOP_ALL_PWM_CLOCK()                            \
        do                                              \
        {                                               \
            EALLOW;                                     \
            CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;       \
            EDIS;                                       \
        }while(0)

#define START_ALL_PWM_CLOCK()                           \
        do                                              \
        {                                               \
            EALLOW;                                     \
            CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;       \
            EDIS;                                       \
        }while(0)        
/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 237
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else

#pragma CODE_SECTION(PeriPWM_PFC_Pos_Polarity, ".TI.ramfunc");
#pragma CODE_SECTION(PeriPWM_PFC_Neg_Polarity, ".TI.ramfunc");
#pragma CODE_SECTION(PeriPWM_PFC_DB_Enable, ".TI.ramfunc");
#pragma CODE_SECTION(PeriEPwm_PFC_Enable, ".TI.ramfunc");
#pragma CODE_SECTION(PeriEPwm_PFC_Disable, ".TI.ramfunc");
#pragma CODE_SECTION(PeriEPwm_SetDuty, ".TI.ramfunc");

#endif


/****************************************************************************
    Public parameter definition
****************************************************************************/
#define Phase_Leg  (3)   // How many phase leg count

/****************************************************************************
	Private variable declaration
****************************************************************************/
u16_t PWM_Period[ePeriEPwm_Tag_Num];


/**
 *  @brief  Initial and configure EPwm-XBar
 *  @retval None
 */
static inline void PeriEPwm_Init_EPwmXBar(void)
{
	/* Setting X-Bar */
    EALLOW;

	// PFC IpfcA Positive and Negatice current limit Select ePWMXbar Trip1 for MUX=2.0(CMPSS2.CTRIPH_OR_CTRIPL)
	EPwmXbarARegs.OUT1MUX0TO15CFG.bit.MUX2 = 0;		//Select input for Mux2.0 (ADC-A4)
	EPwmXbarARegs.OUT1MUXENABLE.bit.MUX2 = 1;		//enabled to drive the TRIP1 of EPWM-XBAR
    EPwmXbarARegs.OUT1MUX0TO15CFG.bit.MUX3 = 0;     //Select input for Mux3.0 (ADC-A4)
    EPwmXbarARegs.OUT1MUXENABLE.bit.MUX3 = 1;       //enabled to drive the TRIP1 of EPWM-XBAR

	// PFC IpfcB Positive and Negatice current limit Select ePWMXbar Trip2 for MUX=4.0(CMPSS3.CTRIPH_OR_CTRIPL)
    EPwmXbarARegs.OUT2MUX0TO15CFG.bit.MUX4 = 0;     //Select input for Mux4.0 (ADC-B2)
    EPwmXbarARegs.OUT2MUXENABLE.bit.MUX4 = 1;       //enabled to drive the TRIP2 of EPWM-XBAR
    EPwmXbarARegs.OUT2MUX0TO15CFG.bit.MUX5 = 0;     //Select input for Mux5.0 (ADC-B2)
    EPwmXbarARegs.OUT2MUXENABLE.bit.MUX5 = 1;       //enabled to drive the TRIP2 of EPWM-XBAR

    // PFC IpfcC Positive and Negatice current limit Select ePWMXbar Trip2 for MUX=8.0(CMPSS5.CTRIPH_OR_CTRIPL)
    EPwmXbarARegs.OUT3MUX0TO15CFG.bit.MUX8 = 0;     //Select input for Mux8.0 (ADC-C4)
    EPwmXbarARegs.OUT3MUXENABLE.bit.MUX8 = 1;       //enabled to drive the TRIP3 of EPWM-XBAR
    EPwmXbarARegs.OUT3MUX0TO15CFG.bit.MUX9 = 0;     //Select input for Mux9.0 (ADC-C4)
    EPwmXbarARegs.OUT3MUXENABLE.bit.MUX9 = 1;       //enabled to drive the TRIP3 of EPWM-XBAR

    EDIS;
}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM1
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM1_IO_Multiplexer(void)
{
    EALLOW;

    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO0 = 1;     // Disable pull-up on GPIO0 (EPWM1A)
    GpioCtrlRegs.GPAPUD.bit.GPIO1 = 1;     // Disable pull-up on GPIO1 (EPWM1B)
    
    /* Configure EPWM1 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM1 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0;
	GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;    // Configure GPIO0 as EPWM1A
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;    // Configure GPIO1 as EPWM1B

    EDIS;
}

/**
 *  @brief  Initial and configure EPWM1 for BIAS_A and BIAS_B
 *  @retval None
 */ 
static inline void PeriEPwm_Init_EPWM1(void)
{
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM1_IO_Multiplexer();
    
    /* Configure Time-Base(TB) Submodule */
    EPwm1Regs.TBPRD = EPWM1_PERIOD;							// Setting the period of the time-base counter
    EPwm1Regs.TBPHS.bit.TBPHS = 0;							// These bits set time-base counter phas
    EPwm1Regs.TBCTR = 0x0000;                               // Clear Time Base Counter
    EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;          // Up-down count mode
    EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;					// TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;				// TBCLK = EPWMCLK / 1*1
    EPwm1Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    
    EPwm1Regs.EPWMSYNCINSEL.bit.SEL = 1;                    // 6:0 EPWMxSYNCI source select
    EPwm1Regs.EPWMSYNCOUTEN.bit.ZEROEN = 0;
    EPwm1Regs.EPWMSYNCOUTEN.bit.SWEN = 1;

    /* Configure Counter-Compare(CC) Submodule */
    EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
	EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm1Regs.CMPA.bit.CMPA = EPWM1_PERIOD/2;				// 50% Duty
   
    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;                    // Set   when TBCTR = CMPA on Up Count
	EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;                    	// Clear when TBCTR = CMPA on Down Count
	EPwm1Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately
    
    /* Configure Dead-Band(DB) Submodule - Active High Complementary */
	EPwm1Regs.DBCTL.bit.IN_MODE = DBA_ALL;					// EPWMxA is the source for both OutA and OutB
	EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;				// EPWMxB is inverted.
	EPwm1Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;			// DBM is fully enabled
	EPwm1Regs.DBRED.bit.DBRED = 100; 						// 500ns = 100*0.005us, RED = DBRED*TBCLK
	EPwm1Regs.DBFED.bit.DBFED = 100;						// 500ns = 100*0.005us, FED = DBFED*TBCLK
    
    /* Configure Trip-Zone(TZ) Submodule */
    
    /* Configure Digital-Compare(DC) Submodule */
    
    /* Configure Event-Trigger(ET) Submodule */

}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM3
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM3_IO_Multiplexer(void)
{
    EALLOW;

    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO4  = 1;     // Disable pull-up on GPIO4  (EPWM3A)
    GpioCtrlRegs.GPBPUD.bit.GPIO60 = 1;     // Disable pull-up on GPIO60 (EPWM3B)
    
    /* Configure EPWM3 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM3 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO4 = 0;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO60 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;     // Configure GPIO4  as EPWM3A
    GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 1;    // Configure GPIO60 as EPWM3B

    EDIS;
}

/**
 *  @brief  Initial and configure EPWM3 for inrush Relay and inrush IGBT
 *  @retval None
 */ 
static inline void PeriEPwm_Init_EPWM3(void)
{
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM3_IO_Multiplexer();
    
    /* Configure Time-Base(TB) Submodule */
    EPwm3Regs.TBPRD = EPWM3_PERIOD;
    EPwm3Regs.TBPHS.bit.TBPHS = 0;
    EPwm3Regs.TBCTR = 0x0000;                               // Clear TB counter
    EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;              // Up count mode
    EPwm3Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;					// TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;				// TBCLK = EPWMCLK / 1*1
    EPwm3Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    
    /* Configure Counter-Compare(CC) Submodule */
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
	EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
    EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm3Regs.CMPA.bit.CMPA = 0;
	EPwm3Regs.CMPB.bit.CMPB = 0;
    
    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm3Regs.AQCTLA.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
	EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPA
    EPwm3Regs.AQCTLB.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
	EPwm3Regs.AQCTLB.bit.CBU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPB
	EPwm3Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately
    
    /* Configure Dead-Band(DB) Submodule */
    EPwm3Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;
    
    /* Configure Trip-Zone(TZ) Submodule */
    
    /* Configure Digital-Compare(DC) Submodule */
    
    /* Configure Event-Trigger(ET) Submodule */

}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM4
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM4_IO_Multiplexer(void)
{
    EALLOW;

    /* Disable internal pull-up for the selected output pins for reduced power consumption */
//    GpioCtrlRegs.GPAPUD.bit.GPIO6 = 1;     // Disable pull-up on GPIO4 (EPWM4A)
    GpioCtrlRegs.GPAPUD.bit.GPIO7 = 1;     // Disable pull-up on GPIO5 (EPWM4B)

    /* Configure EPWM3 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM3 functional pins */
//    GpioCtrlRegs.GPAGMUX1.bit.GPIO6 = 0;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO7 = 0;
//    GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 1;    // Configure GPIO6 as EPWM4A
    GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 1;    // Configure GPIO7 as EPWM4B

    EDIS;
}

/**
 *  @brief  Initial and configure EPWM3 for inrush Relay and inrush IGBT
 *  @retval None
 */
static inline void PeriEPwm_Init_EPWM4(void)
{
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM4_IO_Multiplexer();

    /* Configure Time-Base(TB) Submodule */
    EPwm4Regs.TBPRD = EPWM4_VbulkToD2D_PERIOD;
    EPwm4Regs.TBPHS.bit.TBPHS = 0;
    EPwm4Regs.TBCTR = 0x0000;                               // Clear TB counter
    EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;              // Up count mode
    EPwm4Regs.TBCTL.bit.PHSEN = TB_DISABLE;                 // Disable phase loading
    EPwm4Regs.TBCTL.bit.CLKDIV = TB_DIV1;                   // TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm4Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;                // TBCLK = EPWMCLK / 1*1
    EPwm4Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events

    /* Configure Counter-Compare(CC) Submodule */
    EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
    EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm4Regs.CMPA.bit.CMPA = 0;
    EPwm4Regs.CMPB.bit.CMPB = 0;

    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm4Regs.AQCTLA.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
    EPwm4Regs.AQCTLA.bit.CAU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPA
    EPwm4Regs.AQCTLB.bit.ZRO = AQ_SET;                      // Set when TBCTR count to ZERO
    EPwm4Regs.AQCTLB.bit.CBU = AQ_CLEAR;                    // Clear when TBCTR increase and equals to CMPB
    EPwm4Regs.AQSFRC.bit.RLDCSF = 0x3;                      // Load immediately

    /* Configure Dead-Band(DB) Submodule */
    EPwm4Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;

    /* Configure Trip-Zone(TZ) Submodule */

    /* Configure Digital-Compare(DC) Submodule */

    /* Configure Event-Trigger(ET) Submodule */

}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM6
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM6_IO_Multiplexer(void)
{
    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO10 = 1;     // Disable pull-up on GPIO10 (EPWM6A)
    GpioCtrlRegs.GPAPUD.bit.GPIO11 = 1;     // Disable pull-up on GPIO11 (EPWM6B)

    /* Configure EPWM6 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM6 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO10 = 0;   // Configure Peripheral Group section 0
    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1;    // Configure GPIO10 as EPWM6A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO11 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1;    // Configure GPIO11 as EPWM6B
}

/**
 *  @brief  Initial and configure EPWM6 for three Interleaved totem pole PFC phase C
 *  @retval None
 *  @Note   ePWM6A is phase C High side
 *  @Note   ePWM6B is phase C Low side
 */
static inline void PeriEPwm_Init_EPWM6(void)
{
    EALLOW;

    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM6_IO_Multiplexer();

    /* Configure Time-Base(TB) Submodule */
    EPwm6Regs.TBPRD = EPWM6_PERIOD;
    EPwm6Regs.TBPHS.bit.TBPHS = 0;
    EPwm6Regs.TBPHS.bit.TBPHSHR = 0;
    EPwm6Regs.TBCTR = 0x0000;                      // Clear TB counter

    EPwm6Regs.TBCTL.bit.FREE_SOFT = 2;             // Free run during emulation events
    EPwm6Regs.TBCTL.bit.PHSDIR = 1;                //
    EPwm6Regs.TBCTL.bit.CLKDIV = TB_DIV1;          // TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm6Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;       // TBCLK = EPWMCLK / 1*1
    EPwm6Regs.TBCTL.bit.SWFSYNC = 0;
    EPwm6Regs.TBCTL.bit.PRDLD = 0;                 //
    EPwm6Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
    EPwm6Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Up-Down count mode

    /* Configure PWM interleaved Submodule */
    EPwm6Regs.EPWMSYNCINSEL.bit.SEL = 0;           // 6:0 EPWMxSYNCI source select
    EPwm6Regs.EPWMSYNCOUTEN.bit.ZEROEN = 1;        // The EPWMxSYNCOUT signal is pulsed for one PWM clock on zero

    /* Configure Counter-Compare(CC) Submodule */
    EPwm6Regs.CMPCTL.bit.LOADAMODE = CC_CTR_PRD;  // Load on CTR = ZERO
    EPwm6Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm6Regs.CMPA.bit.CMPA = 0;

    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm6Regs.AQCTLA.bit.CAU = AQ_SET;                    // EPWMxA output low when TBCTR = CMPA on Up Count
    EPwm6Regs.AQCTLA.bit.CAD = AQ_CLEAR;                    // EPWMxA output low when TBCTR = CMPA on Down Count
    EPwm6Regs.AQCTLB.bit.CAU = AQ_SET;                    // EPWMxB output low when TBCTR = CMPA on Up Count
    EPwm6Regs.AQCTLB.bit.CAD = AQ_CLEAR;                    // EPWMxB output low when TBCTR = CMPA on Down Count
    EPwm6Regs.AQCSFRC.bit.CSFA = 0;                         // Software forcing is disabled and has no effect
    EPwm6Regs.AQCSFRC.bit.CSFB = 0;                         // Software forcing is disabled and has no effect
    EPwm6Regs.AQSFRC.bit.RLDCSF = 0x1;                      // Load on Period

    /* Configure Dead-Band(DB) Submodule - Active High Complementary */
    EPwm6Regs.DBCTL2.bit.SHDWDBCTLMODE = 1;                 // DBCTL Load is Shadow mode
    EPwm6Regs.DBCTL2.bit.LOADDBCTLMODE = 1;                 // Active DBCTL Load from Shadow Select Mode when Counter = Period

    EPwm6Regs.DBCTL.bit.DEDB_MODE = 0;
    EPwm6Regs.DBCTL.bit.SHDWDBFEDMODE = 1;
    EPwm6Regs.DBCTL.bit.SHDWDBREDMODE = 1;
    EPwm6Regs.DBCTL.bit.IN_MODE = DBA_ALL;                  // EPWMxA is the source for both OutA and OutB
    EPwm6Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;               // EPWMxB is inverted.
    EPwm6Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;          // DBM is fully enabled


    EPwm6Regs.DBRED.bit.DBRED = PWM_DeadBand_300;           // 300ns = 60*TBCLK, TBCLK=200MHz=0.005us, RED = DBRED*TBCLK
    EPwm6Regs.DBFED.bit.DBFED = PWM_DeadBand_300;           // 300ns = 60*TBCLK, TBCLK=200MHz=0.005us, FED = DBFED*TBCLK

    /* Configure Trip-Zone(TZ) Submodule
     * CBC events of EPwm7 comes from IPFC_A:
     * CMPSS2_CTRIPH or CMPSS2_CTRIPL -> EPwmXBar_TRIP7 -> DCAH/DCBH -> DCAEVT2/DCBEVT2 -> TZ  (49 p.1839)
     * Enable:CBC per one cycle , Disable:CBC per level trigger
     */
    EPwm6Regs.TZSEL.bit.DCAEVT2 = TZ_ENABLE;                // Enable DCAEVT2 as a CBC trip source for this ePWM module, DCAEVT2 CBC select
    EPwm6Regs.TZSEL.bit.DCBEVT2 = TZ_ENABLE;                // Enable DCAEVT2 as a One-shot trip source for this ePWM module, One-shot DCBEVT1

    EPwm6Regs.TZDCSEL.bit.DCAEVT2 = TZ_DCAH_HI;             // DCAEVT2 is trigger when DCAH set to high, DCAL is don't care
    EPwm6Regs.TZDCSEL.bit.DCBEVT2 = TZ_DCBH_HI;             // DCBEVT1 is trigger when DCBH set to high, DCBL is don't care

    // level trigger
    //EPwm8Regs.TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;              // EPWMxA action on DCAEVT2, Force EPWMxA to a low state.
    //EPwm8Regs.TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;              // EPWMxB action on DCBEVT2, Force EPWMxB to a low state.

    // CBC
    EPwm6Regs.TZCTL.bit.TZA = TZ_FORCE_LO;                  // TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxA, Force EPWMxA to a low state.
    EPwm6Regs.TZCTL.bit.TZB = TZ_FORCE_LO;                  // TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxB, Force EPWMxB to a low state.

    EPwm6Regs.TZCTL2.bit.ETZE = 0;                          // Use trip action from TZCTL (legacy EPWM compatibility)
    EPwm6Regs.TZFRC.bit.OST = 1;                          // Force Trip Zones One Shot Event (Disable PWM)


    /* Configure Digital-Compare(DC) Submodule */
    EPwm6Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_TRIPIN3;   //DC_TRIPIN7;       // Digital Compare A High COMP Input Select is TRIPIN7
    EPwm6Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_TRIPIN3;   //DC_TRIPIN7;       // Digital Compare B High COMP Input Select is TRIPIN7
    EPwm6Regs.DCACTL.bit.EVT2SRCSEL = DC_EVT2;              // DCAEVT2 is source by DCAEVT2 signal, not filtered
    EPwm6Regs.DCACTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;  //DC_EVT_ASYNC;     // DCAEVT2 is passed through asynchronously
    EPwm6Regs.DCBCTL.bit.EVT2SRCSEL = DC_EVT2;              // DCBEVT2 is source by DCBEVT2 signal, not filtered
    EPwm6Regs.DCBCTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;  //DC_EVT_ASYNC;     // DCBEVT2 is passed through asynchronously

    /* Configure Event-Trigger(ET) Submodule */
    EPwm6Regs.ETSEL.bit.SOCAEN = 0;                         // Disable SOC on A group
    EPwm6Regs.ETSEL.bit.SOCASEL = ET_CTR_PRD;               // Select SOC from Enable event time-base counter equal to zero for phase A average current control
    EPwm6Regs.ETPS.bit.SOCAPRD = ET_1ST;                    // Generate pulse on 1st event
    EPwm6Regs.ETPS.bit.SOCPSSEL = 1;
    EPwm6Regs.ETSOCPS.bit.SOCAPRD2 = 1;

    /* Re-mapped interrupt */
    //PieVectTable.EPWM8_TZ_INT = &PeriEPwm_EPWM8_TZ_Handler;

    EDIS;
}

/**
 *  @brief  Interrupt for EPWM7 TZ
 *  @retval None
 */ 
__interrupt void PeriEPwm_EPWM7_TZ_Handler(void)
{
    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER2.all;   // Store IER
    IER |= M_INT2;
    IER &= MINT2;                                           // Set "global" priority
    PieCtrlRegs.PIEIER2.all &= MG2_7;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");

    EINT;

    /* User code Start */
    if (EPwm7Regs.TZFLG.bit.CBC == 1)
    {
    	SET_PFC_A_CBC;
    }

    /* User code End */
    
    DINT;
    PieCtrlRegs.PIEIER2.all = TempPIEIER;                   // Restore IER
    /* Branch mechanism code End */
}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM7
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM7_IO_Multiplexer(void)
{
    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO12 = 1;     // Disable pull-up on GPIO12 (EPWM7A)
    GpioCtrlRegs.GPAPUD.bit.GPIO13 = 1;     // Disable pull-up on GPIO13 (EPWM7B)
    
    /* Configure EPWM7 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM7 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO12 = 0;	// Configure Peripheral Group section 0
    GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 1;    // Configure GPIO12 as EPWM7A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO13 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1;    // Configure GPIO13 as EPWM7B
}

/**
 *  @brief  Initial and configure EPWM7 for Interleaved totem pole PFC phase A
 *  @retval None
 *  @Note	ePWM7A is phase A High side
 *  @Note	ePWM7B is phase A Low side
 */ 
static inline void PeriEPwm_Init_EPWM7(void)
{
    EALLOW;
    
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM7_IO_Multiplexer();
    
    /* Configure Time-Base(TB) Submodule */
    EPwm7Regs.TBPRD = EPWM7_PERIOD;
    EPwm7Regs.TBPHS.bit.TBPHS = (EPWM7_PERIOD * 2) / 3;
    EPwm7Regs.TBPHS.bit.TBPHSHR = 0;
    EPwm7Regs.TBCTR = 0x0000;                               // Clear TB counter

    EPwm7Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    EPwm7Regs.TBCTL.bit.PHSDIR = 0;                         // 0: Count down after the synchronization event
    EPwm7Regs.TBCTL.bit.CLKDIV = TB_DIV1;                   // TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm7Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;                // TBCLK = EPWMCLK / 1*1
    EPwm7Regs.TBCTL.bit.SWFSYNC = 0;                        //
    EPwm7Regs.TBCTL.bit.PRDLD = 0;                          //
    EPwm7Regs.TBCTL.bit.PHSEN = TB_ENABLE;                  // Enable phase loading
    EPwm7Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;          // Up-Down count mode
    
    /* Configure PWM interleaved Submodule */
    EPwm7Regs.EPWMSYNCINSEL.bit.SEL = EPWM_SYNC_IN_PULSE_SRC_SYNCOUT_EPWM6; // 6:0 EPWMxSYNCI source select
    EPwm7Regs.EPWMSYNCOUTEN.bit.ZEROEN = 1;

    /* Configure Counter-Compare(CC) Submodule */
    EPwm7Regs.CMPCTL.bit.LOADAMODE = CC_CTR_PRD;  // Load on CTR = ZERO
    EPwm7Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm7Regs.CMPA.bit.CMPA = 0;

    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm7Regs.AQCTLA.bit.CAU = AQ_SET;                    // EPWMxA output low when TBCTR = CMPA on Up Count
    EPwm7Regs.AQCTLA.bit.CAD = AQ_CLEAR;                    // EPWMxA output low when TBCTR = CMPA on Down Count
    EPwm7Regs.AQCTLB.bit.CAU = AQ_SET;                    // EPWMxA output low when TBCTR = CMPA on Up Count
    EPwm7Regs.AQCTLB.bit.CAD = AQ_CLEAR;                    // EPWMxB output low when TBCTR = CMPA on Down Count
    EPwm7Regs.AQCSFRC.bit.CSFA = 0;                         // Software forcing is disabled and has no effect
    EPwm7Regs.AQCSFRC.bit.CSFB = 0;                         // Software forcing is disabled and has no effect
    EPwm7Regs.AQSFRC.bit.RLDCSF = 0x1;                      // Load on Period
    
    /* Configure Dead-Band(DB) Submodule - Active High Complementary */
    EPwm7Regs.DBCTL2.bit.SHDWDBCTLMODE = 1;                 // DBCTL Load is Shadow mode
    EPwm7Regs.DBCTL2.bit.LOADDBCTLMODE = 1;                 // Active DBCTL Load from Shadow Select Mode when Counter = Period

    EPwm7Regs.DBCTL.bit.DEDB_MODE = 0;
    EPwm7Regs.DBCTL.bit.SHDWDBFEDMODE = 1;
    EPwm7Regs.DBCTL.bit.SHDWDBREDMODE = 1;
    EPwm7Regs.DBCTL.bit.IN_MODE = DBA_ALL;                  // EPWMxA is the source for both OutA and OutB
    EPwm7Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;               // EPWMxB is inverted.
    EPwm7Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;          // DBM is fully enabled

    EPwm7Regs.DBRED.bit.DBRED = PWM_DeadBand_300;           // 300ns = 60*TBCLK, TBCLK=200MHz=0.005us, RED = DBRED*TBCLK
    EPwm7Regs.DBFED.bit.DBFED = PWM_DeadBand_300;           // 300ns = 60*TBCLK, TBCLK=200MHz=0.005us, RED = DBRED*TBCLK

    /* Configure Trip-Zone(TZ) Submodule
     * CBC events of EPwm7 comes from IPFC_A:
     * CMPSS2_CTRIPH or CMPSS2_CTRIPL -> EPwmXBar_TRIP7 -> DCAH/DCBH -> DCAEVT2/DCBEVT2 -> TZ  (49 p.1839)
     * Enable:CBC per one cycle , Disable:CBC per level trigger
     */
    EPwm7Regs.TZSEL.bit.DCAEVT2 = TZ_ENABLE;                // Enable DCAEVT2 as a CBC trip source for this ePWM module, DCAEVT2 CBC select
    EPwm7Regs.TZSEL.bit.DCBEVT2 = TZ_ENABLE;                // Enable DCAEVT2 as a One-shot trip source for this ePWM module, One-shot DCBEVT1

    EPwm7Regs.TZDCSEL.bit.DCAEVT2 = TZ_DCAH_HI;             // DCAEVT2 is trigger when DCAH set to high, DCAL is don't care
    EPwm7Regs.TZDCSEL.bit.DCBEVT2 = TZ_DCBH_HI;             // DCBEVT1 is trigger when DCBH set to high, DCBL is don't care

    // level trigger
//    EPwm7Regs.TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;              // EPWMxA action on DCAEVT2, Force EPWMxA to a low state.
//    EPwm7Regs.TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;              // EPWMxB action on DCBEVT2, Force EPWMxB to a low state.
//    EPwm7Regs.DCACTL.bit.EVT2LATSEL = 1;
//    EPwm7Regs.DCBCTL.bit.EVT2LATSEL = 1;

    // CBC
    EPwm7Regs.TZCTL.bit.TZA = TZ_FORCE_LO;                  // TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxA, Force EPWMxA to a low state.
    EPwm7Regs.TZCTL.bit.TZB = TZ_FORCE_LO;                  // TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxB, Force EPWMxB to a low state.

    EPwm7Regs.TZCTL2.bit.ETZE = 0;                          // Use trip action from TZCTL (legacy EPWM compatibility)
    EPwm7Regs.TZFRC.bit.OST = 1;                          // Force Trip Zones One Shot Event (Disable PWM)


    /* Configure Digital-Compare(DC) Submodule */
    EPwm7Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_TRIPIN1;   //DC_TRIPIN7;       // Digital Compare A High COMP Input Select is TRIPIN7
    EPwm7Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_TRIPIN1;   //DC_TRIPIN7;       // Digital Compare B High COMP Input Select is TRIPIN7

    EPwm7Regs.DCACTL.bit.EVT2SRCSEL = DC_EVT2;              // DCAEVT2 is source by DCAEVT2 signal, not filtered
    EPwm7Regs.DCACTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;      //DC_EVT_ASYNC;     // DCAEVT2 is passed through asynchronously
    EPwm7Regs.DCBCTL.bit.EVT2SRCSEL = DC_EVT2;              // DCBEVT2 is source by DCBEVT2 signal, not filtered
    EPwm7Regs.DCBCTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;      //DC_EVT_ASYNC;     // DCBEVT2 is passed through asynchronously

    /* Configure Event-Trigger(ET) Submodule */
    EPwm7Regs.ETSEL.bit.SOCAEN = 0;                         // Disable SOC on A group
    EPwm7Regs.ETSEL.bit.SOCASEL = ET_CTR_PRD;               // Select SOC from Enable event time-base counter equal to zero for phase A average current control
    EPwm7Regs.ETPS.bit.SOCAPRD = ET_1ST;                    // Generate pulse on 1st event

    /* Re-mapped interrupt */
    PieVectTable.EPWM7_TZ_INT = &PeriEPwm_EPWM7_TZ_Handler;

#ifdef EnableCBCISR

    EPwm7Regs.TZEINT.bit.CBC = 1;                           // Trip-zone Cycle-by-Cycle Interrupt Enable

    /* Enable CPU INT2 which is connected to EPWM7 TZ INT */
    IER |= M_INT2;

    /* Enable ePWM7 INTn in the PIE */
    PieCtrlRegs.PIEIER2.bit.INTx7 = 1;                      // Enable EWM7 TZ INT

#else

    EPwm7Regs.TZEINT.bit.CBC = 0;                           // Trip-zone Cycle-by-Cycle Interrupt Disable
    PieCtrlRegs.PIEIER2.bit.INTx7 = 0;                      // Disable EWM7 TZ INT

#endif

    EDIS;
}

/**
 *  @brief  Interrupt for EPWM8 TZ
 *  @retval None
 */ 
__interrupt void PeriEPwm_EPWM8_TZ_Handler(void)
{
    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER2.all;   // Store IER
    IER |= M_INT2;
    IER &= MINT2;                                           // Set "global" priority
    PieCtrlRegs.PIEIER2.all &= MG2_8;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");

    EINT;

    /* User code Start */
    if (EPwm8Regs.TZFLG.bit.CBC == 1)
    {
    	SET_PFC_B_CBC;
    }

    /* User code End */
    
    DINT;
    PieCtrlRegs.PIEIER2.all = TempPIEIER;                   // Restore IER
    /* Branch mechanism code End */
}

/*
 *  @brief  Initial GPIO Multiplexer for EPWM8
 *  @retval None
 */
static inline void PeriEPwm_Config_EPWM8_IO_Multiplexer(void)
{
    /* Disable internal pull-up for the selected output pins for reduced power consumption */
    GpioCtrlRegs.GPAPUD.bit.GPIO14 = 1;     // Disable pull-up on GPIO14 (EPWM8A)
    GpioCtrlRegs.GPAPUD.bit.GPIO15 = 1;     // Disable pull-up on GPIO15 (EPWM8B)
    
    /* Configure EPWM8 pins using GPIO regs.
     * This specifies which of the possible GPIO pins will be EPWM8 functional pins */
    GpioCtrlRegs.GPAGMUX1.bit.GPIO14 = 0;	// Configure Peripheral Group section 0
    GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 1;    // Configure GPIO14 as EPWM8A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO15 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 1;    // Configure GPIO15 as EPWM8B
}

/**
 *  @brief  Initial and configure EPWM8 for Interleaved totem pole PFC phase B
 *  @retval None
 */ 
static inline void PeriEPwm_Init_EPWM8(void)
{
    EALLOW;
    
    /* Configure GPIO Multiplexer */
    PeriEPwm_Config_EPWM8_IO_Multiplexer();

    /* Configure Time-Base(TB) Submodule */
    EPwm8Regs.TBPRD = EPWM8_PERIOD;
    EPwm8Regs.TBPHS.bit.TBPHS = (EPWM8_PERIOD * 2) / 3;
    EPwm8Regs.TBPHS.bit.TBPHSHR = 0;
    EPwm8Regs.TBCTR = 0x0000;                               // Clear TB counter

    EPwm8Regs.TBCTL.bit.FREE_SOFT = 2;                      // Free run during emulation events
    EPwm8Regs.TBCTL.bit.PHSDIR = 0;                         // 1: Count up after the synchronization event
    EPwm8Regs.TBCTL.bit.CLKDIV = TB_DIV1;                   // TBCLK = EPWMCLK / CLKDIV*HSPCLKDIV
    EPwm8Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;                // TBCLK = EPWMCLK / 1*1
    EPwm8Regs.TBCTL.bit.SWFSYNC = 0;                        //
    EPwm8Regs.TBCTL.bit.PRDLD = 0;                          //
    EPwm8Regs.TBCTL.bit.PHSEN = TB_ENABLE;                  // Enable phase loading
    EPwm8Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;          // Up-Down count mode

    /* Configure PWM interleaved Submodule */
    EPwm8Regs.EPWMSYNCINSEL.bit.SEL = EPWM_SYNC_IN_PULSE_SRC_SYNCOUT_EPWM7;   // 6:0 EPWMxSYNCI source select
    EPwm8Regs.EPWMSYNCOUTEN.bit.ZEROEN = 0;

    /* Configure Counter-Compare(CC) Submodule */
    EPwm8Regs.CMPCTL.bit.LOADAMODE = CC_CTR_PRD;  // Load on CTR = ZERO
    EPwm8Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm8Regs.CMPA.bit.CMPA = 0;

    /* Configure Action-Qualifier(AQ) Submodule */
    EPwm8Regs.AQCTLA.bit.CAU = AQ_SET;                 // EPWMxA output low when TBCTR = CMPA on Up Count
    EPwm8Regs.AQCTLA.bit.CAD = AQ_CLEAR;               // EPWMxA output high when TBCTR = CMPA on Down Count
    EPwm8Regs.AQCTLB.bit.CAU = AQ_SET;                 // EPWMxB output low when TBCTR = CMPA on Up Count
    EPwm8Regs.AQCTLB.bit.CAD = AQ_CLEAR;               // EPWMxB output high when TBCTR = CMPA on Down Count
    EPwm8Regs.AQCSFRC.bit.CSFA = 0;                    // Software forcing is disabled and has no effect
    EPwm8Regs.AQCSFRC.bit.CSFB = 0;                    // Software forcing is disabled and has no effect
    EPwm8Regs.AQSFRC.bit.RLDCSF = 0x1;                 // Load on Period

    /* Configure Dead-Band(DB) Submodule - Active High Complementary */
    EPwm8Regs.DBCTL2.bit.SHDWDBCTLMODE = 1;                 // DBCTL Load is Shadow mode
    EPwm8Regs.DBCTL2.bit.LOADDBCTLMODE = 1;                 // Active DBCTL Load from Shadow Select Mode when Counter = Period

    EPwm8Regs.DBCTL.bit.DEDB_MODE = 0;
    EPwm8Regs.DBCTL.bit.SHDWDBFEDMODE = 1;
    EPwm8Regs.DBCTL.bit.SHDWDBREDMODE = 1;
    EPwm8Regs.DBCTL.bit.IN_MODE = DBA_ALL;                  // EPWMxA is the source for both OutA and OutB
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;               // EPWMxB is inverted.
    EPwm8Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;          // DBM is fully enabled

    EPwm8Regs.DBRED.bit.DBRED = PWM_DeadBand_300;           // 300ns = 60*TBCLK, TBCLK=200MHz=0.005us, RED = DBRED*TBCLK
    EPwm8Regs.DBFED.bit.DBFED = PWM_DeadBand_300;           // 300ns = 60*TBCLK, TBCLK=200MHz=0.005us, RED = DBRED*TBCLK

    /* Configure Trip-Zone(TZ) Submodule
     * CBC events of EPwm7 comes from IPFC_A:
     * CMPSS2_CTRIPH or CMPSS2_CTRIPL -> EPwmXBar_TRIP7 -> DCAH/DCBH -> DCAEVT2/DCBEVT2 -> TZ  (49 p.1839)
     * Enable:CBC per one cycle , Disable:CBC per level trigger
     */
    EPwm8Regs.TZSEL.bit.DCAEVT2 = TZ_ENABLE;                // Enable DCAEVT2 as a CBC trip source for this ePWM module, DCAEVT2 CBC select
    EPwm8Regs.TZSEL.bit.DCBEVT2 = TZ_ENABLE;                // Enable DCAEVT2 as a One-shot trip source for this ePWM module, One-shot DCBEVT1

    EPwm8Regs.TZDCSEL.bit.DCAEVT2 = TZ_DCAH_HI;             // DCAEVT2 is trigger when DCAH set to high, DCAL is don't care
    EPwm8Regs.TZDCSEL.bit.DCBEVT2 = TZ_DCBH_HI;             // DCBEVT1 is trigger when DCBH set to high, DCBL is don't care

    // level trigger
    //EPwm8Regs.TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;              // EPWMxA action on DCAEVT2, Force EPWMxA to a low state.
    //EPwm8Regs.TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;              // EPWMxB action on DCBEVT2, Force EPWMxB to a low state.

    // CBC
    EPwm8Regs.TZCTL.bit.TZA = TZ_FORCE_LO;                  // TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxA, Force EPWMxA to a low state.
    EPwm8Regs.TZCTL.bit.TZB = TZ_FORCE_LO;                  // TZ1 to TZ6, DCAEVT1/2, DCBEVT1/2 Trip Action On EPWMxB, Force EPWMxB to a low state.

    EPwm8Regs.TZCTL2.bit.ETZE = 0;                          // Use trip action from TZCTL (legacy EPWM compatibility)
    EPwm8Regs.TZFRC.bit.OST = 1;                          // Force Trip Zones One Shot Event (Disable PWM)


    /* Configure Digital-Compare(DC) Submodule */
    EPwm8Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_TRIPIN2;   //DC_TRIPIN7;       // Digital Compare A High COMP Input Select is TRIPIN7
    EPwm8Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_TRIPIN2;   //DC_TRIPIN7;       // Digital Compare B High COMP Input Select is TRIPIN7
    EPwm8Regs.DCACTL.bit.EVT2SRCSEL = DC_EVT2;              // DCAEVT2 is source by DCAEVT2 signal, not filtered
    EPwm8Regs.DCACTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;  //DC_EVT_ASYNC;     // DCAEVT2 is passed through asynchronously
    EPwm8Regs.DCBCTL.bit.EVT2SRCSEL = DC_EVT2;              // DCBEVT2 is source by DCBEVT2 signal, not filtered
    EPwm8Regs.DCBCTL.bit.EVT2FRCSYNCSEL = DC_EVT_ASYNC;  //DC_EVT_ASYNC;     // DCBEVT2 is passed through asynchronously

    /* Configure Event-Trigger(ET) Submodule */
    EPwm8Regs.ETSEL.bit.SOCAEN = 0;                         // Disable SOC on A group
    EPwm8Regs.ETSEL.bit.SOCASEL = ET_CTR_PRD;               // Select SOC from Enable event time-base counter equal to zero for phase A average current control
    EPwm8Regs.ETPS.bit.SOCAPRD = ET_1ST;                    // Generate pulse on 1st event

    /* Re-mapped interrupt */
    PieVectTable.EPWM8_TZ_INT = &PeriEPwm_EPWM8_TZ_Handler;

#ifdef EnableCBCISR

    EPwm8Regs.TZEINT.bit.CBC = 1;                           // Trip-zone Cycle-by-Cycle Interrupt Enable

    /* Enable CPU INT2 which is connected to EPWM8 TZ INT */
    IER |= M_INT2;

    /* Enable ePWM8 INTn in the PIE */
    PieCtrlRegs.PIEIER2.bit.INTx8 = 1;                      // Enable EWM8 TZ INT

#else

    EPwm8Regs.TZEINT.bit.CBC = 0;                           // Trip-zone Cycle-by-Cycle Interrupt Disable
    PieCtrlRegs.PIEIER2.bit.INTx8 = 0;                      // Disable EWM8 TZ INT

#endif

    EDIS;
}

/**
 *  @brief  Initial and configure used EPwm module
 *  @retval None
 */ 
void PeriEPwm_Initialize(void)
{

    SysCtl_setEPWMClockDivider(SYSCTL_EPWMCLK_DIV_1);       //[Davidchchen]20240308 added in.
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);   //[Davidchchen]20240308 added in.

	// initial PWM period
	PWM_Period[ePeriEPwm_Tag_PFCRELAY] = EPWM3_PERIOD;
	PWM_Period[ePeriEPwm_Tag_PFCIGBT] = EPWM3_PERIOD;
	PWM_Period[ePeriEPwm_Tag_PFC_A] = EPWM6_PERIOD;
	PWM_Period[ePeriEPwm_Tag_PFC_B] = EPWM7_PERIOD;
	PWM_Period[ePeriEPwm_Tag_PFC_C] = EPWM8_PERIOD;
    PWM_Period[ePeriEPwm_Tag_VBulkToD2D] = EPWM4_VbulkToD2D_PERIOD;
	
    STOP_ALL_PWM_CLOCK();

    PeriEPwm_Init_EPwmXBar();
	PeriEPwm_Init_EPWM1();
	PeriEPwm_Init_EPWM3();
    PeriEPwm_Init_EPWM4();
    PeriEPwm_Init_EPWM6();
	PeriEPwm_Init_EPWM7();
	PeriEPwm_Init_EPWM8();

    START_ALL_PWM_CLOCK();
}

/**
 *  @brief  Setting PWM for PFC postive polarity
 *  @retval None
 */
void PeriPWM_PFC_Pos_Polarity(void)
{
//    EPwm6Regs.ETSEL.bit.SOCASEL = ET_CTR_PRD; //dbg
//    EPwm7Regs.ETSEL.bit.SOCASEL = ET_CTR_PRD;
//    EPwm8Regs.ETSEL.bit.SOCASEL = ET_CTR_PRD;

	/* Configure Action-Qualifier(AQ) Submodule */
    EPwm6Regs.AQCTLA.bit.CAU = AQ_SET;      // EPWMxA output high when TBCTR = CMPA on Up Count
    EPwm6Regs.AQCTLA.bit.CAD = AQ_CLEAR;    // EPWMxA output low when TBCTR = CMPA on Down Count
    EPwm6Regs.AQCTLB.bit.CAU = AQ_SET;      // EPWMxB output high when TBCTR = CMPA on Up Count
    EPwm6Regs.AQCTLB.bit.CAD = AQ_CLEAR;    // EPWMxB output low when TBCTR = CMPA on Down Count

	EPwm7Regs.AQCTLA.bit.CAU = AQ_SET;		// EPWMxA output high when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLA.bit.CAD = AQ_CLEAR;	// EPWMxA output low when TBCTR = CMPA on Down Count
	EPwm7Regs.AQCTLB.bit.CAU = AQ_SET;		// EPWMxB output high when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLB.bit.CAD = AQ_CLEAR;	// EPWMxB output low when TBCTR = CMPA on Down Count

	EPwm8Regs.AQCTLA.bit.CAU = AQ_SET;	// EPWMxA output low when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLA.bit.CAD = AQ_CLEAR;		// EPWMxA output high when TBCTR = CMPA on Down Count
	EPwm8Regs.AQCTLB.bit.CAU = AQ_SET;	// EPWMxB output low when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLB.bit.CAD = AQ_CLEAR;		// EPWMxB output high when TBCTR = CMPA on Down Count

    EPwm6Regs.AQCSFRC.bit.CSFA = 1;         // Forces a continuous low on output A
    EPwm6Regs.AQCSFRC.bit.CSFB = 0;         // Software forcing is disabled and has no effect
    EPwm6Regs.DBCTL.bit.IN_MODE = DBB_ALL;          // EPWMxB is the source for both OutA and OutB
    EPwm6Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;      // DBM is Disabled
    EPwm6Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;       // EPWMxA is inverted.
    EPwm6Regs.DBCTL.bit.OUTSWAP = 0;

	EPwm7Regs.AQCSFRC.bit.CSFA = 1;			// Forces a continuous low on output A
	EPwm7Regs.AQCSFRC.bit.CSFB = 0;			// Software forcing is disabled and has no effect
	EPwm7Regs.DBCTL.bit.IN_MODE = DBB_ALL;			// EPWMxB is the source for both OutA and OutB
	EPwm7Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled
    EPwm7Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;       // EPWMxA is inverted.
    EPwm7Regs.DBCTL.bit.OUTSWAP = 0;

	EPwm8Regs.AQCSFRC.bit.CSFA = 1;			// Forces a continuous low on output A
	EPwm8Regs.AQCSFRC.bit.CSFB = 0;			// Software forcing is disabled and has no effect
	EPwm8Regs.DBCTL.bit.IN_MODE = DBB_ALL;			// EPWMxB is the source for both OutA and OutB
	EPwm8Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;       // EPWMxA is inverted.
    EPwm8Regs.DBCTL.bit.OUTSWAP = 0;
}

/**
 *  @brief  Setting PWM for PFC negative polarity
 *  @retval None
 */
void PeriPWM_PFC_Neg_Polarity(void)
{

//    EPwm6Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO; //dbg
//    EPwm7Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;
//    EPwm8Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;

	/* Configure Action-Qualifier(AQ) Submodule */
    EPwm6Regs.AQCTLA.bit.CAU = AQ_SET;    // EPWMxA output low when TBCTR = CMPA on Up Count
    EPwm6Regs.AQCTLA.bit.CAD = AQ_CLEAR;      // EPWMxA output high when TBCTR = CMPA on Down Count
    EPwm6Regs.AQCTLB.bit.CAU = AQ_SET;    // EPWMxB output low when TBCTR = CMPB on Up Count
    EPwm6Regs.AQCTLB.bit.CAD = AQ_CLEAR;      // EPWMxB output high when TBCTR = CMPB on Down Count

	EPwm7Regs.AQCTLA.bit.CAU = AQ_SET;	// EPWMxA output low when TBCTR = CMPA on Up Count
	EPwm7Regs.AQCTLA.bit.CAD = AQ_CLEAR;		// EPWMxA output high when TBCTR = CMPA on Down Count
	EPwm7Regs.AQCTLB.bit.CAU = AQ_SET;	// EPWMxB output low when TBCTR = CMPB on Up Count
	EPwm7Regs.AQCTLB.bit.CAD = AQ_CLEAR;		// EPWMxB output high when TBCTR = CMPB on Down Count

	EPwm8Regs.AQCTLA.bit.CAU = AQ_SET;		// EPWMxA output high when TBCTR = CMPA on Up Count
	EPwm8Regs.AQCTLA.bit.CAD = AQ_CLEAR;	// EPWMxA output low when TBCTR = CMPA on Down Count
	EPwm8Regs.AQCTLB.bit.CAU = AQ_SET;		// EPWMxB output high when TBCTR = CMPB on Up Count
	EPwm8Regs.AQCTLB.bit.CAD = AQ_CLEAR;	// EPWMxB output low when TBCTR = CMPB on Down Count

    EPwm6Regs.AQCSFRC.bit.CSFB = 0;         // Software forcing is disabled and has no effect
    EPwm6Regs.AQCSFRC.bit.CSFA = 1;         // Forces a continuous low on output B
    EPwm6Regs.DBCTL.bit.IN_MODE = DBA_ALL;          // EPWMxA is the source for both OutA and OutB
    EPwm6Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;      // DBM is Disabled
    EPwm6Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;       // EPWMxB is inverted.
    EPwm6Regs.DBCTL.bit.OUTSWAP = 0x3;              // EPWMxA and EPWMxB output waveform swap.

    EPwm7Regs.AQCSFRC.bit.CSFB = 0;         // Software forcing is disabled and has no effect
    EPwm7Regs.AQCSFRC.bit.CSFA = 1;         // Forces a continuous low on output B
	EPwm7Regs.DBCTL.bit.IN_MODE = DBA_ALL;			// EPWMxA is the source for both OutA and OutB
	EPwm7Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled
    EPwm7Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;       // EPWMxB is inverted.
    EPwm7Regs.DBCTL.bit.OUTSWAP = 0x3;              // EPWMxA and EPWMxB output waveform swap.

    EPwm8Regs.AQCSFRC.bit.CSFB = 0;         // Software forcing is disabled and has no effect
    EPwm8Regs.AQCSFRC.bit.CSFA = 1;         // Forces a continuous low on output B
	EPwm8Regs.DBCTL.bit.IN_MODE = DBA_ALL;			// EPWMxA is the source for both OutA and OutB
	EPwm8Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;		// DBM is Disabled
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;       // EPWMxB is inverted.
    EPwm8Regs.DBCTL.bit.OUTSWAP = 0x3;              // EPWMxA and EPWMxB output waveform swap.
}

/**
 *  @brief  Setting PWM for PFC postive polarity normal work
 *  @retval None
 */
void PeriPWM_PFC_DB_Enable(void)
{
    EPwm6Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;      // DBM is Full Enabled
	EPwm7Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;		// DBM is Full Enabled
	EPwm8Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;		// DBM is Full Enabled
}

/**
 *  @brief  Enable target ePWM
 *  @note   User "MUST" set duty before enable ePWM
 *  @param  eTag: Which ePWM is attempted to enable
 *  @retval None
 */
void PeriEPwm_PFC_Enable(void)
{
	EALLOW;
    EPwm6Regs.TZCLR.bit.OST = 1;
    EPwm7Regs.TZCLR.bit.OST = 1;
	EPwm8Regs.TZCLR.bit.OST = 1;
    EDIS;
}

/**
 *  @brief  Enable target ePWM
 *  @note   User "MUST" set duty before enable ePWM
 *  @param  eTag: Which ePWM is attempted to enable
 *  @retval None
 */
void PeriEPwm_PFC_PhaseC_Enable(void) //C
{
	EALLOW;
    EPwm6Regs.TZCLR.bit.OST = 1;
    EDIS;
}

/* Enable target PWM8 */
void PeriEPwm_PFC_PhaseA_Enable(void) //A
{
    EALLOW;
    EPwm7Regs.TZCLR.bit.OST = 1;
    EDIS;
}

void PeriEPwm_PFC_PhaseB_Enable(void) //B
{
    EALLOW;
    EPwm8Regs.TZCLR.bit.OST = 1;
    EDIS;
}

/**
 *  @brief  Disable target ePWM
 *  @param  eTag: Which ePWM is attempted to disable
 *  @retval None
 */
void PeriEPwm_PFC_Disable(void)
{
	EALLOW;
    EPwm6Regs.TZFRC.bit.OST = 1;
	EPwm7Regs.TZFRC.bit.OST = 1;
	EPwm8Regs.TZFRC.bit.OST = 1;
	EDIS;
}

/**
 *  @brief  Clear PFC phase A CBC ISR flag
 *  @retval None
 */
void PeriPWM_PFC_A_CBC_Clear(void)
{
	EALLOW;
	EPwm7Regs.TZCLR.bit.CBC = 1;
	EPwm7Regs.TZCLR.bit.INT = 1;
	EDIS;
}

/**
 *  @brief  Clear PFC phase B CBC ISR flag
 *  @retval None
 */
void PeriPWM_PFC_B_CBC_Clear(void)
{
	EALLOW;
	EPwm8Regs.TZCLR.bit.CBC = 1;
	EPwm8Regs.TZCLR.bit.INT = 1;
	EDIS;
}

/**
 *  @brief  Set target ePWM Duty
 *  @param  eTag: Which ePWM is attempted to set its duty
 *  @param  u32Duty_Q16: duty in Q16 format
 *  @retval None
 */
void PeriEPwm_SetDuty(ePeriEPwmTag_t eTag, u32_t u32Duty_Q16)
{
    switch (eTag)
    {
        case ePeriEPwm_Tag_PFCRELAY:
         	EPwm3Regs.CMPA.bit.CMPA = (u32Duty_Q16 * PWM_Period[eTag] + 1) >> 16;
            break;
		
		case ePeriEPwm_Tag_PFCIGBT:
         	EPwm3Regs.CMPB.bit.CMPB = (u32Duty_Q16 * PWM_Period[eTag] + 1) >> 16;
            break;

        case ePeriEPwm_Tag_VBulkToD2D:
            EPwm4Regs.CMPB.bit.CMPB = (u32Duty_Q16 * PWM_Period[eTag] + 1) >> 16;
            break;

		case ePeriEPwm_Tag_PFC_A:
            EPwm7Regs.CMPA.bit.CMPA = (u32Duty_Q16 * PWM_Period[eTag]) >> 16;
            break;

		case ePeriEPwm_Tag_PFC_B:
            //EPwm7Regs.CMPA.bit.CMPA = PWM_Period[eTag] - ((u32Duty_Q16 * PWM_Period[eTag]) >> 16);
		    EPwm8Regs.CMPA.bit.CMPA = (u32Duty_Q16 * PWM_Period[eTag]) >> 16;
            break;

		case ePeriEPwm_Tag_PFC_C:
		    EPwm6Regs.CMPA.bit.CMPA = (u32Duty_Q16 * PWM_Period[eTag]) >> 16;
            break;
        default:
            break;
    }
}


/**
 *  @brief  Start peripheral - Enable trigger ADC interrupt
 *  @retval None
 */
void PeriPWM_Start(void)
{
	/* Configure Event-Trigger(ET) Submodule */
    EPwm7Regs.ETSEL.bit.SOCAEN = 1;            // Enable SOC on A group
    EPwm8Regs.ETSEL.bit.SOCAEN = 1;            // Enable SOC on A group
    EPwm6Regs.ETSEL.bit.SOCAEN = 1;            // Enable SOC on A group
}

/**
 *  @brief  Start peripheral - Disable trigger ADC interrupt
 *  @retval None
 */
void PeriPWM_Stop(void)
{
	/* Configure Event-Trigger(ET) Submodule */
    EPwm7Regs.ETSEL.bit.SOCAEN = 0;            // Disable SOC on A group
    EPwm8Regs.ETSEL.bit.SOCAEN = 0;            // Disable SOC on A group
    EPwm6Regs.ETSEL.bit.SOCAEN = 0;            // Disable SOC on A group
}



