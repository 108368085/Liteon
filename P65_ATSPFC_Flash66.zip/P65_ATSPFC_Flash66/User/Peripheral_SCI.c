/****************************************************************************
 *	File	Peripheral_SCI.c
 * 	Brief	Configure and control SCI module on TI 28004x platform
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/08/17 - modify by Ollie chen
 ****************************************************************************/
 
#include "F28x_Project.h"
#include "Peripheral_SCI.h"
#include <string.h>


/****************************************************************************
    Private parameter definition
****************************************************************************/
#define PERI_SCI_LSPCLK             (SYS_CLK_OUT / 4)   // ClkCfgRegs.LOSPCP.bit.LSPCLKDIV = 0b010 (default on reset) --> SYSCLK / 4
#define PERI_SCI_CCR_REG            (0x0007)            // 1 stop bit, No loopback, No parity,8 char bits, async mode, idle-line protocol
#define PERI_SCI_CTL1_REG           (0x0000)            // Disable RX, TX, ERR INT, SLEEP, TXWAKE
#define PERI_SCI_CTL2_REG           (0x0000)            // Disable RX interrupt, TX interrupt
#define PERI_SCI_FIFO_TX_REG        (0xE040)            // TX FIFO reset and FIFO enable, interrupt disabled
#define PERI_SCI_FIFO_RX_REG        (0x204F)            // RX FIFO reset, interrupt disabled
#define PERI_SCI_FIFO_CTL_REG       (0x0000)            //

#define SCI_RX_BUFF_SIZE            64                  // RX buffer size: 64 bytes
#define SCI_RX_REMAINING_TIME       100                 // unit is 1ms, RX data would be remained 100ms 

#define SCI_TX_FIFO_SIZE            8

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/
typedef union nPeriSCI_Flag
{
    u16_t u16All;
    struct
    {
        u16_t u1TxIdle      : 1;        ///< The application MUST check the flag and then write data to the driver
        u16_t u1RxIdle      : 1;        ///< The application MUST check the flag
        u16_t u1RxBuffFull  : 1;        ///< The Rx buffer is full and the application MUST reset the buffer before use
    }u16Bits;
}nPeriSCI_Flag_t;

typedef struct sPeriSCI_Driver
{
    u16_t u16Channel;    
    nPeriSCI_Flag_t nFlag;
    
    // Receiver
    u8_t pu8RxBuff[SCI_RX_BUFF_SIZE];
    u16_t u16RxIndex;
    u16_t u16RemainingTime;
    
    // Transmitter
    u16_t u16TxPreemption;
    u8_t *pu8TxBuff;
    u16_t u16TxLength;
    u16_t u16TxIndex;
        
    // Instance handler
    volatile struct SCI_REGS* psInstance;
    
}sPeriSCI_Driver_t;

/****************************************************************************
	Private function prototype
****************************************************************************/
/*
// RAMLS0_6 : 199
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(PeriSCI_CheckTxIdle, ".TI.ramfunc");
#pragma CODE_SECTION(PeriSCI_TxWrite, ".TI.ramfunc");
#pragma CODE_SECTION(PeriSCI_PreemptTx, ".TI.ramfunc");
#pragma CODE_SECTION(PeriSCI_GetRxByte, ".TI.ramfunc");
#pragma CODE_SECTION(PeriSCI_RxReset, ".TI.ramfunc");
#pragma CODE_SECTION(PeriSCI_Background_Process, ".TI.ramfunc");
#pragma CODE_SECTION(PeriSCI_1ms_Periodically_Process, ".TI.ramfunc");
#endif
*/

static u16_t PeriSCI_CheckTxIdle(u16_t u16Channel);
static u16_t PeriSCI_TxWrite(u16_t u16Channel, u16_t u16Length, u8_t* pu8Buff);
static u16_t PeriSCI_PreemptTx(u16_t u16Channel, u16_t u16Priority);
static u16_t PeriSCI_GetRxByte(u16_t u16Channel, u8_t* pu8Buff, u16_t u16BuffLimit);
static void PeriSCI_RxReset(u16_t u16Channel);

/****************************************************************************
	Private variable declaration
****************************************************************************/
sPeriSCI_Driver_t ptsPeriSciDriver[ePeriSCI_Channel_Num];

/****************************************************************************
	Public variable declaration
****************************************************************************/
const sUartDriverInterface_t gtUartDriverInterface =
{
    PeriSCI_CheckTxIdle,
    PeriSCI_TxWrite,
    PeriSCI_PreemptTx,
    PeriSCI_GetRxByte,
    PeriSCI_RxReset,
};


/**
 *  @brief  Check the SCI Tx idle or not
 *  @param  u16Channel: The channel of SCI driver which is attempted to check
 *  @retval If Tx is busy, return 0xFFFF (UART_TX_BUSY)
 *          Otherwise, return the TX preemption
 */
static u16_t PeriSCI_CheckTxIdle(u16_t u16Channel)
{
    if (ptsPeriSciDriver[u16Channel].nFlag.u16Bits.u1TxIdle == 0)
    {
        return UART_TX_BUSY;
    }
    else
    {
        return ptsPeriSciDriver[u16Channel].u16TxPreemption;
    }
}

/**
*  @brief  Start the TX transaction
*  @note   Before start the Tx transaction, the user must
*			prepare the data and store in the Tx buffer.
*			User should check the channel is idle or the self write priority
*			is greater than Tx preemptive priority.
*			This function would force to transaction data even if the priority
*			of requested application is less than Tx preemptive priority.
*   @param  u16Channel: Which Channel is attempted to send the transaction
*   @param  u16Length: The length needs to be transmit
*   @param  pu8Buff: Pointer to the Tx buffer which stored the data
*   @retval RequestDenied: The transaction is denied 
*   @retval RequestAccepted: The transaction is accepted
*/
static u16_t PeriSCI_TxWrite(u16_t u16Channel, u16_t u16Length, u8_t* pu8Buff)
{
    if (ptsPeriSciDriver[u16Channel].nFlag.u16Bits.u1TxIdle == 0)
    {
        return RequestDenied;
    }
    else
    {
        ptsPeriSciDriver[u16Channel].u16TxLength = u16Length;
        ptsPeriSciDriver[u16Channel].pu8TxBuff = pu8Buff;
        ptsPeriSciDriver[u16Channel].u16TxIndex = 0;
        ptsPeriSciDriver[u16Channel].nFlag.u16Bits.u1TxIdle = 0;
        ptsPeriSciDriver[u16Channel].psInstance->SCICTL1.bit.TXENA = 1;
        ptsPeriSciDriver[u16Channel].psInstance->SCITXBUF.bit.TXDT = *ptsPeriSciDriver[u16Channel].pu8TxBuff;
        ptsPeriSciDriver[u16Channel].u16TxIndex += 1;

        return RequestAccepted;
    }
}

/**
 *  @brief  Preempt the TX write priority
 *  @param  u16Channel: SCI Channel which is attempted to preempt write priority
 *  @retval RequestDenied: The preemption is denied
 *  @retval RequestAccpeted: The preemption is accepted
 */
static u16_t PeriSCI_PreemptTx(u16_t u16Channel, u16_t u16Priority)
{
    if (ptsPeriSciDriver[u16Channel].u16TxPreemption < u16Priority)
    {
        ptsPeriSciDriver[u16Channel].u16TxPreemption = u16Priority;
        return RequestAccepted;
    }
    else
    {
        return RequestDenied;
    }
}

/**
 *  @brief  Get received data
 *  @param  u16Channel: Which channel is attempted to retrieve data from Rx buffer
 *  @param  pu8Buff: User application's rx buffer that is attempted to store received data
 *  @param  u16BuffLimit: Maximum size of user application's buffer
 *  @retval The bytes amount retrieved from SCI driver
 */
static u16_t PeriSCI_GetRxByte(u16_t u16Channel, u8_t* pu8Buff, u16_t u16BuffLimit)
{

    if (ptsPeriSciDriver[u16Channel].u16RxIndex == 0)
    {
        return 0;
    }
    else if (ptsPeriSciDriver[u16Channel].u16RxIndex < u16BuffLimit)
    {
        u16BuffLimit = ptsPeriSciDriver[u16Channel].u16RxIndex;
    }
    else
    {
        PeriSCI_RxReset(u16Channel);
        return 0;
    }
    
    memcpy(pu8Buff, ptsPeriSciDriver[u16Channel].pu8RxBuff, u16BuffLimit);
    
    return u16BuffLimit;
}

/**
 *  @brief  Reset RX buffer
 *  @param  u16Channel: Which channel is attempted to reset
 *  @retval None
 */
static void PeriSCI_RxReset(u16_t u16Channel)
{
    ptsPeriSciDriver[u16Channel].u16RxIndex = 0;
    ptsPeriSciDriver[u16Channel].u16RemainingTime = SCI_RX_REMAINING_TIME;
}

/**
 *  @brief  Error Process
 *  @param  psDriver: Pointer to a sPeriSCI_Driver_t structure which is attempted to run Error Process
 *  @retval None
 */
static inline void PeriSCI_Error_Process(sPeriSCI_Driver_t* psDriver)
{
    if (psDriver->psInstance->SCIRXST.bit.RXERROR)
    {
        psDriver->psInstance->SCICTL1.bit.SWRESET = 0;      // Disable SCI module
        psDriver->psInstance->SCICTL1.bit.SWRESET = 1;      // active the software reset
    }
}

/**
 *  @brief  RX Process
 *  @param  psDriver: Pointer to a sPeriSCI_Driver_t structure which is attempted to run Rx Process
 *  @retval None
 */
static inline void PeriSCI_Rx_Process(sPeriSCI_Driver_t* psDriver)
{
    /* Check RX FIFO has data or not */
    if (psDriver->psInstance->SCIFFRX.bit.RXFFST != 0)
    {
        psDriver->pu8RxBuff[psDriver->u16RxIndex] = psDriver->psInstance->SCIRXBUF.all;
        psDriver->u16RxIndex += 1;
        
        if (psDriver->u16RxIndex >= SCI_RX_BUFF_SIZE)
        {
            psDriver->u16RxIndex = 0;
        }
    }
}

/**
 *  @brief  Tx Process
 *  @param  psDriver: Pointer to a sPeriSCI_Driver_t structure which is attempted to run Tx Process
 *  @retval None
 */
static inline void PeriSCI_Tx_Process(sPeriSCI_Driver_t* psDriver)
{
    if (psDriver->u16TxIndex < psDriver->u16TxLength)
    {
        /* Check TX FIFO is not full */
        if (psDriver->psInstance->SCIFFTX.bit.TXFFST < SCI_TX_FIFO_SIZE)
        {
            psDriver->psInstance->SCITXBUF.bit.TXDT = *(psDriver->pu8TxBuff + psDriver->u16TxIndex);
            psDriver->u16TxIndex += 1;
        }
    }
    else    
    {
        /* Last byte had been send to TXBUF, 
         * check TX shift register is empty or not,
         * if it is empty that indicated the transaction is accomplished
         */
        if (psDriver->psInstance->SCICTL2.bit.TXEMPTY)
        {
            psDriver->nFlag.u16Bits.u1TxIdle = 1;
            psDriver->psInstance->SCICTL1.bit.TXENA = 0;
        }
    }
}

/**
 *  @brief  Peripheral SCI Background Process
 *  @retval None
 */
void PeriSCI_Background_Process(void)
{

#ifdef USE_SCI_CHANNEL_A
    PeriSCI_Error_Process(&ptsPeriSciDriver[ePeriSCI_Channel_A]);
    PeriSCI_Rx_Process(&ptsPeriSciDriver[ePeriSCI_Channel_A]);
    PeriSCI_Tx_Process(&ptsPeriSciDriver[ePeriSCI_Channel_A]);
#endif

#ifdef USE_SCI_CHANNEL_B
    PeriSCI_Error_Process(&ptsPeriSciDriver[ePeriSCI_Channel_B]);
    PeriSCI_Rx_Process(&ptsPeriSciDriver[ePeriSCI_Channel_B]);
    PeriSCI_Tx_Process(&ptsPeriSciDriver[ePeriSCI_Channel_B]);
#endif

}

/**
 *  @brief  Run periodically process of each SCI driver in background process every 1ms
 *  @note   This function is used to Rx buffer received data, but there are no application to fetch it in RX_REMAINING_TIME
 *          SCI driver will reset it to avoid buffer overflow
 *  @param  pvSubscriberObj: Pointer to a sPeriSCI_Driver_t structure which is attempted to run
 *  @retval None
 */
void PeriSCI_1ms_Periodically_Process(void)
{
	u16_t i;
	
	for (i=0; i<ePeriSCI_Channel_Num; i++)
	{
		sPeriSCI_Driver_t* psDriver = &ptsPeriSciDriver[i];

		if (psDriver->u16RxIndex > 0)
    	{
        	psDriver->u16RemainingTime -= 1;
        
        	if (psDriver->u16RemainingTime == 0)
        	{
            	PeriSCI_RxReset(psDriver->u16Channel);
        	}
    	}
	}
}

/**
 *  @brief  Initial each SCI driver
 *  @param  psDriver: Pointer to a ptsPeriSciDriver_t structure which is attempted to initial
 *  @param  u16Channel: Channl of the driver
 *  @retval None
 */
static void PeriSCI_Initial_Each_Driver(sPeriSCI_Driver_t *psDriver, u16_t u16Channel)
{
    psDriver->u16Channel = u16Channel;
    
    /* Initial GPIO multiplexer */
    switch (psDriver->u16Channel)
    {
    
#ifdef USE_SCI_CHANNEL_A
        case ePeriSCI_Channel_A:
            GPIO_SetupPinMux(SCI_CHANNEL_A_RX_PIN_NUM, GPIO_MUX_CPU1, SCI_CHANNEL_A_RX_MUX_SEL); 	// RX
            GPIO_SetupPinOptions(SCI_CHANNEL_A_RX_PIN_NUM, GPIO_INPUT, GPIO_ASYNC);
            GPIO_SetupPinMux(SCI_CHANNEL_A_TX_PIN_NUM, GPIO_MUX_CPU1, SCI_CHANNEL_A_TX_MUX_SEL);	// TX
            GPIO_SetupPinOptions(SCI_CHANNEL_A_TX_PIN_NUM, GPIO_OUTPUT, GPIO_ASYNC);          		// GPIO_PUSHPULL
            break;
#endif

#ifdef USE_SCI_CHANNEL_B
        case ePeriSCI_Channel_B:
        	GPIO_SetupPinMux(SCI_CHANNEL_B_RX_PIN_NUM, GPIO_MUX_CPU1, SCI_CHANNEL_B_RX_MUX_SEL);  	// RX
            GPIO_SetupPinOptions(SCI_CHANNEL_B_RX_PIN_NUM, GPIO_INPUT, GPIO_ASYNC);
            GPIO_SetupPinMux(SCI_CHANNEL_B_TX_PIN_NUM, GPIO_MUX_CPU1, SCI_CHANNEL_B_TX_MUX_SEL);	// TX
            GPIO_SetupPinOptions(SCI_CHANNEL_B_TX_PIN_NUM, GPIO_OUTPUT, GPIO_PUSHPULL);             // GPIO_PUSHPULL
            break;
#endif

        default:
            break;
    }
    
    /* Initial SCI instance */
    switch (psDriver->u16Channel)
    {
#ifdef USE_SCI_CHANNEL_A
        case ePeriSCI_Channel_A:
            psDriver->psInstance = &SciaRegs;
            break;
#endif

#ifdef USE_SCI_CHANNEL_B
        case ePeriSCI_Channel_B:
            psDriver->psInstance = &ScibRegs;
            break;
#endif

        default:
            break;
    }
    
    /* SCI setting */    
    psDriver->psInstance->SCICCR.all = PERI_SCI_CCR_REG;
    psDriver->psInstance->SCICTL1.all = PERI_SCI_CTL1_REG;
    psDriver->psInstance->SCICTL2.all = PERI_SCI_CTL2_REG;

    switch (psDriver->u16Channel)
    {
#ifdef USE_SCI_CHANNEL_A        
        case ePeriSCI_Channel_A:
            psDriver->psInstance->SCIHBAUD.bit.BAUD = (PERI_SCI_LSPCLK / SCI_CHANNEL_A_BAUD_RATE / 8 - 1) >> 8;//2
            psDriver->psInstance->SCILBAUD.bit.BAUD = (PERI_SCI_LSPCLK / SCI_CHANNEL_A_BAUD_RATE / 8 - 1);//138
            break;
#endif

#ifdef USE_SCI_CHANNEL_B
        case ePeriSCI_Channel_B:
            psDriver->psInstance->SCIHBAUD.bit.BAUD = (PERI_SCI_LSPCLK / SCI_CHANNEL_B_BAUD_RATE / 8 - 1) >> 8;
            psDriver->psInstance->SCILBAUD.bit.BAUD = (PERI_SCI_LSPCLK / SCI_CHANNEL_B_BAUD_RATE / 8 - 1);
            break;
#endif
          
        default:
            break;
    }
    
    /* FIFO setting */
    psDriver->psInstance->SCIFFTX.all = PERI_SCI_FIFO_TX_REG;
    psDriver->psInstance->SCIFFRX.all = PERI_SCI_FIFO_RX_REG;
    psDriver->psInstance->SCIFFCT.all = PERI_SCI_FIFO_CTL_REG;
        
    /* Software reset */
    psDriver->psInstance->SCICTL1.bit.SWRESET = 1;
    

    /* Assign data remaining time */
    psDriver->u16RemainingTime = SCI_RX_REMAINING_TIME;

}

/**
 *  @brief  Initial used SCI module
 *  @retval None
 */
void PeriSCI_Initialize(void)
{
	u16_t i;
	
	for (i=0; i<ePeriSCI_Channel_Num; i++)
	{
		memset(&ptsPeriSciDriver[i], 0, sizeof(ptsPeriSciDriver[i]));
	}
    
#ifdef USE_SCI_CHANNEL_A
    PeriSCI_Initial_Each_Driver(&ptsPeriSciDriver[ePeriSCI_Channel_A], ePeriSCI_Channel_A);
#endif

#ifdef USE_SCI_CHANNEL_B
    PeriSCI_Initial_Each_Driver(&ptsPeriSciDriver[ePeriSCI_Channel_B], ePeriSCI_Channel_B);
#endif
   
}

/**
 *  @brief  Start Peripheral SCI
 *  @retval None
 */
void PeriSCI_Start(void)
{

#ifdef USE_SCI_CHANNEL_A
		ptsPeriSciDriver[ePeriSCI_Channel_A].psInstance->SCICTL1.bit.RXENA = 1;
		ptsPeriSciDriver[ePeriSCI_Channel_A].psInstance->SCICTL1.bit.TXENA = 0;
#endif
	
#ifdef USE_SCI_CHANNEL_B
		ptsPeriSciDriver[ePeriSCI_Channel_B].psInstance->SCICTL1.bit.RXENA = 1;
		ptsPeriSciDriver[ePeriSCI_Channel_B].psInstance->SCICTL1.bit.TXENA = 0;
#endif

}

/**
 *  @brief  Stop Peripheral SCI
 *  @retval None
 */
void PeriSCI_Stop(void)
{

#ifdef USE_SCI_CHANNEL_A
	ptsPeriSciDriver[ePeriSCI_Channel_A].psInstance->SCICTL1.bit.RXENA = 0;
	ptsPeriSciDriver[ePeriSCI_Channel_A].psInstance->SCICTL1.bit.TXENA = 0;
#endif

#ifdef USE_SCI_CHANNEL_B
    ptsPeriSciDriver[ePeriSCI_Channel_B].psInstance->SCICTL1.bit.RXENA = 0;
    ptsPeriSciDriver[ePeriSCI_Channel_B].psInstance->SCICTL1.bit.TXENA = 0;
#endif

}
