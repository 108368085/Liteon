/****************************************************************************
 *	File	SERV_SwitchDriver.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/10/19 - 1st release
 ****************************************************************************/

#ifndef _SERV_SWITCHDRIVER_H_
#define _SERV_SWITCHDRIVER_H_

#include "CONFIG_Define.h"


/****************************************************************************
*	Public enumeration definition
****************************************************************************/

typedef enum
{
	SwitchDriver_Tag_ATS_Relay1,
	SwitchDriver_Tag_ATS_Relay2,
	SwitchDriver_Tag_PFC_Relay,
	SwitchDriver_Tag_PFC_IGBT,
	SwitchDriver_Tag_Num
}eSwitchTag_t;

typedef enum
{
	SwitchDriver_State_OFF,			// Static off
	SwitchDriver_State_TurnOn,		// Turning on
	SwitchDriver_State_StaticON,	// Static on
}eSwitchState_t;


/****************************************************************************
*	Public structure definition
****************************************************************************/
typedef struct
{
	eSwitchTag_t eTag;        	// Identify Switch device
	eSwitchState_t eState;      // Transition state
	u16_t u16Duty_Q16;			// Duty Q16 type for PWM
	u16_t u16ElapsedTime;       // Unit is 1ms
}sSwitchDriver_t;


/****************************************************************************
*	Public functions
****************************************************************************/
extern sSwitchDriver_t* GetSwitchDriverRef(eSwitchTag_t eTag);
extern void SwitchDriver_Initialize(void);
extern void SetSwitchState(sSwitchDriver_t *psSwitch, eSwitchState_t eNewState);

#endif
