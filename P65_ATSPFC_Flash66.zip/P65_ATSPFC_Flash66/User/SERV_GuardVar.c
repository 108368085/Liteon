/** @file       SERV_GuardVar.c
 *  @author     Ollie Chen
 *  @brief      This module is used to guard variables
 *  @version    1.0
 *  @date       
 */

#include "SERV_GuardVar.h"


/****************************************************************************
	Private marco definition 
****************************************************************************/

/****************************************************************************
	Private enumeration definition
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 94
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(GuardVarList_CheckRequest, ".TI.ramfunc");
#pragma CODE_SECTION(GuardVarList_WriteRequest, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declare
****************************************************************************/

/****************************************************************************
	Public variable declare
****************************************************************************/

/**
*   @brief  Append GuardVarNode into list
*   @param  psList: The list which is the node container
*   @param  psNode: Target Guard Variable Node attempted to join into list
*   @retval None
*/
void GuardVarList_AppendNode(sGuardVarList_t *psList, sGuardVarNode_t* psNode)
{
	if (psList->u16NodeNumber == 0)
	{
		psList->psHeadNode = psNode;
        psList->psTailNode = psNode;
	}
	else
	{
		psList->psTailNode->psNextNode = psNode;
		psList->psTailNode = psNode;
	}
	
	psList->u16NodeNumber += 1;
}

/**
*   @brief  Send a check request to target guard variable list
*   @param  psList: Target list attempted to write
*   @param  sRequest: Access request
*   @retval <RequestDenied>: the access request content is invalid.
*   @retval <ReqeustAccepted>: the access request content is valid.
*/
u16_t GuardVarList_CheckRequest(sGuardVarList_t *psList, sGuardVarAccessRequest_t sRequest)
{
    u16_t u16Response;
    u16_t u16NodeResponse;
    sGuardVarNode_t* psProcessingNode = psList->psHeadNode;
    
    // If the List is empty. return RequestDenied
    if (psProcessingNode == NULL)
    {
        u16Response = RequestDenied;
    }
    
    // Check data content
	while (psProcessingNode != NULL)
	{
		if (psProcessingNode->pfDataCheckRequestHandler != NULL)
		{
			u16NodeResponse = psProcessingNode->pfDataCheckRequestHandler(psProcessingNode, sRequest);
		}
		else
		{
			u16NodeResponse = RequestDenied;
		}
		
		if (u16NodeResponse == RequestDenied)
		{
			u16Response = RequestDenied;
			break;
		}
		else if (u16NodeResponse == RequestAccepted)
		{
			if (psProcessingNode->psNextNode != NULL)
			{
				psProcessingNode = psProcessingNode->psNextNode;
			}
			else
			{
				u16Response = RequestAccepted;
				break;
			}
		}
	}
    
    return u16Response;
}

/**
*   @brief  Send a write request to target gaurd variable list
*   @param  psList: Target list attempted to write
*   @param  sRequest: Access request
*   @retval <RequestDenied>: the access request had been denied.
    @retval <ReqeustAccepted>: the access request had been processed.
*/
u16_t GuardVarList_WriteRequest(sGuardVarList_t *psList, sGuardVarAccessRequest_t sRequest)
{	
	u16_t u16Response;
	u16_t u16NodeResponse;
	sGuardVarNode_t* psProcessingNode = psList->psHeadNode;
	
	// If the List is empty, return RequestDenied
	if (psProcessingNode == NULL)
	{
		u16Response = RequestDenied;
	}

    // Write data to guard variables
    psProcessingNode = psList->psHeadNode;
    
    while (psProcessingNode != NULL)
    {
        if (psProcessingNode->pfDataWriteRequestHandler != NULL)
        {
            u16NodeResponse = psProcessingNode->pfDataWriteRequestHandler(psProcessingNode, sRequest);
        }
        else
        {
            u16NodeResponse = RequestDenied;
        }
        
        if (u16NodeResponse == RequestDenied)
        {
            u16Response = RequestDenied;
            break;
        }
        else if (u16NodeResponse == RequestAccepted)
        {
            if (psProcessingNode->psNextNode != NULL)
            {
                psProcessingNode = psProcessingNode->psNextNode;
            }
            else
            {
                u16Response = RequestAccepted;
                break;
            }
        }
    }

	if (psList->pfAccessNotificationHandler != NULL)
	{
		psList->pfAccessNotificationHandler(u16Response, psProcessingNode);
	}
	
	return u16Response;
}
