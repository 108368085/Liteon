/****************************************************************************
 *	File	Peripheral_ADC.h
 * 	Brief	Header file for Peripheral ADC module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

 
#ifndef _PERIPHERAL_ADC_H_
#define _PERIPHERAL_ADC_H_

#include "CONFIG_Define.h"
#include "driverlib.h"
/****************************************************************************
    Public parameter definition
****************************************************************************/

#define GET_ADC_I_PFC_A			ADCResult[ADC_I_PFC_A]
#define GET_ADC_V_PFC_L			ADCResult[ADC_V_PFC_L]
#define GET_ADC_V_AC1_L			ADCResult[ADC_V_AC1_L]
#define GET_ADC_V_AC2_L			ADCResult[ADC_V_AC2_L]
#define GET_ADC_I_PFC_A_VREF    ADCResult[ADC_I_PFC_A_VREF]
#define GET_ADC_T_INLET			ADCResult[ADC_T_INLET]
#define GET_ADC_T_ATS			ADCResult[ADC_T_ATS]
#define GET_ADC_V_AUX1          ADCResult[ADC_V_AUX1]
#define GET_ADC_V_AUX2          ADCResult[ADC_V_AUX2]

#define GET_ADC_I_PFC_B			ADCResult[ADC_I_PFC_B]
#define GET_ADC_V_PFC_N			ADCResult[ADC_V_PFC_N]
#define GET_ADC_V_AC1_N			ADCResult[ADC_V_AC1_N]
#define GET_ADC_V_AC2_N			ADCResult[ADC_V_AC2_N]
#define GET_ADC_I_PFC_B_VREF    ADCResult[ADC_I_PFC_B_VREF]

#define GET_ADC_I_PFC_C         ADCResult[ADC_I_PFC_C]
#define GET_ADC_V_PFC_DET       ADCResult[ADC_V_PFC_DET]
#define GET_ADC_V_PFC_OVP1		ADCResult[ADC_V_PFC_OVP1]
#define GET_ADC_V_PFC_OVP2		ADCResult[ADC_V_PFC_OVP2]
#define GET_ADC_I_PFC_C_VREF    ADCResult[ADC_I_PFC_C_VREF]
#define GET_ADC_T_PFC           ADCResult[ADC_T_PFC]
#define GET_ADC_T_D2D           ADCResult[ADC_T_D2D]


/****************************************************************************
	Public macro definition
****************************************************************************/
/*******************************************************************************
    Public export function prototype
*******************************************************************************/
#define dl_adc_set_prescaler(base, scale)                                       \
        ADC_setPrescaler(base, scale)

#define dl_adc_set_mode(base, resolution, signal_mode)                          \
        ADC_setMode(base, resolution, signal_mode)

#define dl_adc_setup_soc(base, soc, trigger, channel, sample_window)            \
        ADC_setupSOC(base, soc, trigger, channel, sample_window)

#define dl_adc_set_interrupt_trigger(base, soc, trigger)                        \
        ADC_setInterruptSOCTrigger(base, soc, trigger)

#define dl_adc_set_interrupt_pulse_mode(base, mode)                             \
        ADC_setInterruptPulseMode(base, mode)

#define dl_adc_enable(base)                                                     \
        ADC_enableConverter(base)

#define dl_adc_disable(base)                                                    \
        ADC_disableConverter(base)

#define dl_adc_force_soc(base, soc)                                             \
        ADC_forceSOC(base, soc)

#define dl_adc_get_interrupt_status(base, interrupt_num)                        \
        ADC_getInterruptStatus(base, interrupt_num)

#define dl_adc_clear_interrupt_status(base, interrupt_num)                      \
        ADC_clearInterruptStatus(base, interrupt_num)

#define dl_adc_get_interrupt_overflow_status(base, interrupt_num)               \
        ADC_getInterruptOverflowStatus(base, interrupt_num)

#define dl_adc_clear_interrupt_overflow_status(base, interrupt_num)             \
        ADC_clearInterruptOverflowStatus(base, interrupt_num)

#define dl_adc_read_result(base, soc)                                           \
        ADC_readResult(base, soc)

#define dl_adc_is_busy(base)                                                    \
        ADC_isBusy(base)

#define dl_adc_enable_interrupt(base, interrupt_num)                            \
        ADC_enableInterrupt(base, interrupt_num)

#define dl_adc_disable_interrupt(base, interrupt_num)                           \
        ADC_disableInterrupt(base, interrupt_num)

#define dl_adc_set_interrupt_source(base, interrupt_num, soc)                   \
        ADC_setInterruptSource(base, interrupt_num, soc)

#define dl_adc_enable_continuous_mode(base, interrupt_num)                      \
        ADC_enableContinuousMode(base, interrupt_num)

#define dl_adc_disable_continuous_mode(base, interrupt_num)                     \
        ADC_disableContinuousMode(base, interrupt_num)
/****************************************************************************
	Public enumeration definition 
****************************************************************************/
typedef enum
{
	ADC_I_PFC_A = 0,
	ADC_V_PFC_L,
	ADC_V_AC1_L,
	ADC_V_AC2_L,
	ADC_I_PFC_A_VREF,
	ADC_T_INLET,
	ADC_T_ATS,
    ADC_V_AUX1,
    ADC_V_AUX2,
	
	ADC_I_PFC_B,
	ADC_V_PFC_N,
	ADC_V_AC1_N,
	ADC_V_AC2_N,
	ADC_I_PFC_B_VREF,
	
    ADC_I_PFC_C,
    ADC_V_PFC_DET,
	ADC_V_PFC_OVP1,
	ADC_V_PFC_OVP2,
	ADC_I_PFC_C_VREF,
    ADC_T_PFC,
    ADC_T_D2D,

	ADC_Tag_Num
}eADCTag_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/
extern u16_t ADCResult[ADC_Tag_Num];


/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void PeriAdc_Initialize(void);
extern void PeriAdc_Start(void);
extern void PeriAdc_Stop(void);

#endif 
