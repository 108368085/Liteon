/****************************************************************************
 *	File	E2P_Driver.c
 * 	Brief	EEPROM driver
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/12/25 - Modify from Ollie Chen
 ****************************************************************************/

#include "E2P_Driver.h"
#include "Peripheral_SPI.h"
#include <string.h>


/****************************************************************************
    Private parameter definition
****************************************************************************/
#define E2P_DEVICE_ADDRESS 				0xA0
#define E2P_MEMORY_SIZE           		0xFFFF		//0x7FFF = 32kbytes, 0xFFFF = 64kbytes
#define E2P_MEMORY_ADDRESS_LENGTH  		2
#define E2P_PAGE_SIZE             		64

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/
typedef struct sE2pDriver
{
    eE2pDriverState_t eState;
    sE2pDriverInfo_t sInformation;
    u16_t u16DeviceAddress;
    
    /* Master SPI driver */
    u16_t u16MstSPIChannel;
    
    /* Master SPI Transaction Packet */
    sMstSPITransaction_t sTransaction;
}sE2pDriver_t;

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 165 -> 141
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(E2pDrv_Transaction_Finished, ".TI.ramfunc");
//#pragma CODE_SECTION(E2pDrv_GetDriverState, ".TI.ramfunc");
//#pragma CODE_SECTION(E2pDrv_Reset, ".TI.ramfunc");
#pragma CODE_SECTION(E2pDrv_MemoryRead, ".TI.ramfunc");
#pragma CODE_SECTION(E2pDrv_MemoryWrite, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declaration
****************************************************************************/
sE2pDriver_t ptsE2pDriver[E2p_Tag_Num];

/****************************************************************************
	Public variable declaration
****************************************************************************/


/**
 *  @brief  Transaction finish callback function
 *  @param  psTransaction: Pointer to a sMstSPITransaction_t structure which just finished
 *  @retval None
 */
static void E2pDrv_Transaction_Finished(sMstSPITransaction_t* psTransaction)
{
    sE2pDriver_t* psDriver = __ContainerOf(psTransaction, sE2pDriver_t, sTransaction);
    
    if (psTransaction->u16ErrorCode == MSPI_ERROR_NONE)
    {
        psDriver->eState = E2P_STATE_READY;
    }
    else
    {
        psDriver->eState = E2P_STATE_ERROR;
    }
}

/**
 *  @brief  Get EERPOM driver state
 *  @param  psE2pDrvInfo: Pointer to a sE2pDriverInfo_t structure which contents the EEPROM driver information
 *  @retval Driver state
 */
static eE2pDriverState_t E2pDrv_GetDriverState(struct sE2pDriverInfo* psE2pDrvInfo)
{
    sE2pDriver_t* psDriver = __ContainerOf(psE2pDrvInfo, sE2pDriver_t, sInformation);
    
    return psDriver->eState;
}

/**
 *  @brief  Reset EEPROM driver
 *  @param  psE2pDrvInfo: Pointer to a sE2pDriverInfo_t structure which contents the EEPROM driver information
 *  @retval None
 */
static void E2pDrv_Reset(struct sE2pDriverInfo* psE2pDrvInfo)
{
    sE2pDriver_t* psDriver = __ContainerOf(psE2pDrvInfo, sE2pDriver_t, sInformation);
    
    if ((psDriver->eState == E2P_STATE_READY) ||
        (psDriver->eState == E2P_STATE_ERROR))
    {
        psDriver->eState = E2P_STATE_IDLE;
    }
}

/**
 *  @brief  Read memory of EEPROM
 *  @param  psE2pDrvInfo: Pointer to a sE2pDriverInfo_t structure which contents the EEPROM driver information
 *  @param  u32RegAddr: Memory address which is attempted to read
 *  @param  u16RdLen: Byte length attempted to read
 *  @param  pu8Buff: The destination buffer
 *  @retval RequestDenied: This read request is rejected
 *  @retval RequestAccepted: This read request is accepted
 */
static u16_t E2pDrv_MemoryRead(struct sE2pDriverInfo* psE2pDrvInfo, u32_t u32RegAddr, u16_t u16RdLen, u8_t *pu8Buff)
{
    
    sE2pDriver_t *psDriver = __ContainerOf(psE2pDrvInfo, sE2pDriver_t, sInformation);

    if ((psDriver->eState == E2P_STATE_IDLE) &&
        (u16RdLen > 0) &&
        ((u32RegAddr + u16RdLen) <= psE2pDrvInfo->u32MemorySize))
    {
        __DWordToMByte(psDriver->sTransaction.pu8MemoryAddress, u32RegAddr);
        psDriver->sTransaction.u16MemoryAddressLength = E2P_MEMORY_ADDRESS_LENGTH;
        psDriver->sTransaction.pu8TxBuff = NULL;
        psDriver->sTransaction.u16TxLength = 0;
        psDriver->sTransaction.pu8RxBuff = pu8Buff;
        psDriver->sTransaction.u16RxLength = u16RdLen;
        psDriver->sTransaction.u16ErrorCode = MSPI_ERROR_NONE;
        psDriver->sTransaction.pfFinishCallback = &E2pDrv_Transaction_Finished;
        psDriver->eState = E2P_STATE_BUSY;
        MstSPI_PushTransaction(psDriver->u16MstSPIChannel, &psDriver->sTransaction);      
        return RequestAccepted;
    }
    else
    {
        return RequestDenied;
    }
}

/**
 *  @brief  Write memory of EEPROM
 *  @param  psE2pDrvInfo: Pointer to a sE2pDriverInfo_t structure which contents the EEPROM driver information
 *  @param  u32RegAddr: Memory address which is attempted to write
 *  @param  u16WrLen: Byte length attempted to write
 *  @param  pu8Buff: The source buffer
 *  @retval RequestDenied: This write request is rejected
 *  @retval RequestAccepted: This write request is accepted
 */
static u16_t E2pDrv_MemoryWrite(struct sE2pDriverInfo* psE2pDrvInfo, u32_t u32RegAddr, u16_t u16WrLen, u8_t *pu8Buff)
{
    sE2pDriver_t *psDriver = __ContainerOf(psE2pDrvInfo, sE2pDriver_t, sInformation);
    
    if ((psDriver->eState == E2P_STATE_IDLE) &&
        (u16WrLen > 0) &&
        (u16WrLen <= psE2pDrvInfo->u16PageSize) &&
        ((u32RegAddr + u16WrLen) <= psE2pDrvInfo->u32MemorySize))
    {
        __DWordToMByte(psDriver->sTransaction.pu8MemoryAddress, u32RegAddr);
        psDriver->sTransaction.u16MemoryAddressLength = E2P_MEMORY_ADDRESS_LENGTH;
        psDriver->sTransaction.pu8TxBuff = pu8Buff;
        psDriver->sTransaction.u16TxLength = u16WrLen;
        psDriver->sTransaction.pu8RxBuff = NULL;
        psDriver->sTransaction.u16RxLength = 0;
        psDriver->sTransaction.u16ErrorCode = MSPI_ERROR_NONE;
        psDriver->sTransaction.pfFinishCallback = &E2pDrv_Transaction_Finished;
		psDriver->eState = E2P_STATE_BUSY;
        MstSPI_PushTransaction(psDriver->u16MstSPIChannel, &psDriver->sTransaction);       
        return RequestAccepted;
    }
    else
    {
        return RequestDenied;
    }
}


/**
 *  @brief  Initial EEPROM Driver
 *  @retval None
 */
void E2pDrv_Initialize(void)
{
    u16_t i;
    
    for (i=0; i<E2p_Tag_Num; i++)
    {
    	memset(&ptsE2pDriver[i], 0, sizeof(ptsE2pDriver[i]));
		
        ptsE2pDriver[i].sInformation.u16Tag = i;
        ptsE2pDriver[i].sInformation.u32MemorySize = E2P_MEMORY_SIZE;
        ptsE2pDriver[i].sInformation.u16PageSize = E2P_PAGE_SIZE;
        ptsE2pDriver[i].sInformation.pfGetDriverState = &E2pDrv_GetDriverState;
        ptsE2pDriver[i].sInformation.pfResetDriver = &E2pDrv_Reset;
        ptsE2pDriver[i].sInformation.pfMemoryWrite = &E2pDrv_MemoryWrite;
        ptsE2pDriver[i].sInformation.pfMemoryRead = &E2pDrv_MemoryRead;
        
        if (i == E2p_Tag_1)
        {
            ptsE2pDriver[i].u16DeviceAddress = E2P_DEVICE_ADDRESS;
            ptsE2pDriver[i].u16MstSPIChannel = ePeriSPI_Channel_A;
            ptsE2pDriver[i].sTransaction.eState = MSPI_TRANSACTION_STATE_IDLE;
            ptsE2pDriver[i].sTransaction.u16SlaveAddress = ptsE2pDriver[i].u16DeviceAddress;
            ptsE2pDriver[i].sTransaction.u16ErrorCode = MSPI_ERROR_NONE;
            ptsE2pDriver[i].sTransaction.pfFinishCallback = &E2pDrv_Transaction_Finished;
        }
        ptsE2pDriver[i].eState = E2P_STATE_IDLE;
    }
}


/**
 *  @brief  Return information of EEPROM driver
 *  @param  u16Tag: Tag of target EEPROM driver attempted to fetch
 *  @retval Pointer to a sE2pDriverInfo_t structure which contents the driver information
 */
sE2pDriverInfo_t* E2pDrv_GetDriverInformation(u16_t u16Tag)
{
    return &ptsE2pDriver[u16Tag].sInformation;
}
