/****************************************************************************
 *	File	Monitor_AC.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/25 - 1st release
 ****************************************************************************/

#ifndef _MONITOR_AC_H
#define	_MONITOR_AC_H

#include "CONFIG_Define.h"
#include "SERV_Threshold.h"
#include "SERV_Calibration.h"


/****************************************************************************
*	Public parameter definition
****************************************************************************/

#define MOMIAC_CLEAR_FAULT				(0x0003)

#define GET_MOMIAC_VAC1_ITIC            tsMoniAC[MoniAC_Tag_VAC1].nStatus.u16Bits.u16ITIC
#define GET_MOMIAC_VAC2_ITIC            tsMoniAC[MoniAC_Tag_VAC2].nStatus.u16Bits.u16ITIC

#define GET_MOMIAC_VAC1_ITIC            tsMoniAC[MoniAC_Tag_VAC1].nStatus.u16Bits.u16ITIC
#define GET_MOMIAC_VAC2_ITIC            tsMoniAC[MoniAC_Tag_VAC2].nStatus.u16Bits.u16ITIC

#define GET_MOMIAC_VAC1_POLARITY		tsMoniAC[MoniAC_Tag_VAC1].nStatus.u16Bits.u1Polarity
#define GET_MOMIAC_VAC2_POLARITY		tsMoniAC[MoniAC_Tag_VAC2].nStatus.u16Bits.u1Polarity
#define GET_MOMIAC_VPFC_POLARITY		tsMoniAC[MoniAC_Tag_VPFC].nStatus.u16Bits.u1Polarity
#define GET_MOMIAC_VIFC_POLARITY		tsMoniAC[MoniAC_Tag_IPFC].nStatus.u16Bits.u1Polarity

#define GET_MOMIAC_VAC1_INPUTSTATUS		tsMoniAC[MoniAC_Tag_VAC1].nStatus.u16Bits.u2InputStatus
#define GET_MOMIAC_VAC2_INPUTSTATUS		tsMoniAC[MoniAC_Tag_VAC2].nStatus.u16Bits.u2InputStatus
#define GET_MOMIAC_VPFC_INPUTSTATUS		tsMoniAC[MoniAC_Tag_VPFC].nStatus.u16Bits.u2InputStatus
#define GET_MOMIAC_VIFC_INPUTSTATUS		tsMoniAC[MoniAC_Tag_IPFC].nStatus.u16Bits.u2InputStatus

#define GET_MOMIAC_VAC1_FLAG			tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16All
#define GET_MOMIAC_VAC2_FLAG			tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16All
#define GET_MOMIAC_VPFC_FLAG			tsMoniAC[MoniAC_Tag_VPFC].nFlag.u16All
#define GET_MOMIAC_IPFC_FLAG			tsMoniAC[MoniAC_Tag_IPFC].nFlag.u16All

#define GET_MOMIAC_VAC1_PRESENT_FLAG	tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1SourcePresent
#define GET_MOMIAC_VAC2_PRESENT_FLAG	tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1SourcePresent
#define GET_MOMIAC_VPFC_PRESENT_FLAG	tsMoniAC[MoniAC_Tag_VPFC].nFlag.u16Bits.u1SourcePresent

#define GET_MOMIAC_VAC1_REALRMS			tsMoniAC[MoniAC_Tag_VAC1].u16RealRMS
#define GET_MOMIAC_VAC2_REALRMS			tsMoniAC[MoniAC_Tag_VAC2].u16RealRMS
#define GET_MOMIAC_VPFC_REALRMS			tsMoniAC[MoniAC_Tag_VPFC].u16RealRMS
#define GET_MOMIAC_IPFC_REALRMS			tsMoniAC[MoniAC_Tag_IPFC].u16RealRMS
#define GET_MOMIAC_VAC1_REALRMS_WF		tsMoniAC[MoniAC_Tag_VAC1].u16RealRMS_WF
#define GET_MOMIAC_VAC2_REALRMS_WF		tsMoniAC[MoniAC_Tag_VAC2].u16RealRMS_WF
#define GET_MOMIAC_VPFC_REALRMS_WF		tsMoniAC[MoniAC_Tag_VPFC].u16RealRMS_WF
#define GET_MOMIAC_IPFC_REALRMS_WF		tsMoniAC[MoniAC_Tag_IPFC].u16RealRMS_WF

#define GET_MOMIAC_VAC1_REALINSTANT		tsMoniAC[MoniAC_Tag_VAC1].u16RealInstant
#define GET_MOMIAC_VAC2_REALINSTANT		tsMoniAC[MoniAC_Tag_VAC2].u16RealInstant
#define GET_MOMIAC_VPFC_REALINSTANT		tsMoniAC[MoniAC_Tag_VPFC].u16RealInstant
#define GET_MOMIAC_IPFC_REALINSTANT		tsMoniAC[MoniAC_Tag_IPFC].u16RealInstant

#define GET_MOMIAC_VAC1_PEAK			tsMoniAC[MoniAC_Tag_VAC1].f32RealPeak
#define GET_MOMIAC_VAC2_PEAK			tsMoniAC[MoniAC_Tag_VAC2].f32RealPeak
#define GET_MOMIAC_VPFC_PEAK			tsMoniAC[MoniAC_Tag_VPFC].f32RealPeak
#define GET_MOMIAC_IPFC_PEAK			tsMoniAC[MoniAC_Tag_IPFC].f32RealPeak

#define GET_MOMIAC_VAC1_FREQ			tsMoniAC[MoniAC_Tag_VAC1].u16Freq
#define GET_MOMIAC_VAC2_FREQ			tsMoniAC[MoniAC_Tag_VAC2].u16Freq
#define GET_MOMIAC_VPFC_FREQ			tsMoniAC[MoniAC_Tag_VPFC].u16Freq
#define GET_MOMIAC_VAC1_FREQ_WF			tsMoniAC[MoniAC_Tag_VAC1].u16Freq_WF
#define GET_MOMIAC_VAC2_FREQ_WF			tsMoniAC[MoniAC_Tag_VAC2].u16Freq_WF
#define GET_MOMIAC_VPFC_FREQ_WF			tsMoniAC[MoniAC_Tag_VPFC].u16Freq_WF

#define GET_MOMIAC_VPFC_PHASE			tsMoniAC[MoniAC_Tag_VPFC].u16Period_CNT
#define GET_MOMIAC_VPFC_HALFPERIOD		tsMoniAC[MoniAC_Tag_VPFC].u16Period

#define SET_MOMIAC_VAC1_CALI			UpdateMoniACCalibration(MoniAC_Tag_VAC1)
#define SET_MOMIAC_VAC2_CALI			UpdateMoniACCalibration(MoniAC_Tag_VAC2)
#define SET_MOMIAC_VPFC_CALI			UpdateMoniACCalibration(MoniAC_Tag_VPFC)
#define SET_MOMIAC_IPFC_CALI			UpdateMoniACCalibration(MoniAC_Tag_IPFC)


// For Fault injection

#define GET_MOMIAC_VAC1_DROP			tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1Dropout
#define GET_MOMIAC_VAC1_UVW				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1BrownoutWarning
#define GET_MOMIAC_VAC1_UVP				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1BrownoutProtect
#define GET_MOMIAC_VAC1_OVW				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1OverVoltageWarning
#define GET_MOMIAC_VAC1_OVP				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1OverVoltageProtect
#define GET_MOMIAC_VAC1_FRW				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1FreqWarning
#define GET_MOMIAC_VAC1_FRP				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1FreqError
#define GET_MOMIAC_VAC1_HAW				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1HarmonicWarning
#define GET_MOMIAC_VAC1_HAP				tsMoniAC[MoniAC_Tag_VAC1].nFlag.u16Bits.u1HarmonicProtect

#define GET_MOMIAC_VAC2_DROP			tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1Dropout
#define GET_MOMIAC_VAC2_UVW				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1BrownoutWarning
#define GET_MOMIAC_VAC2_UVP				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1BrownoutProtect
#define GET_MOMIAC_VAC2_OVW				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1OverVoltageWarning
#define GET_MOMIAC_VAC2_OVP				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1OverVoltageProtect
#define GET_MOMIAC_VAC2_FRW				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1FreqWarning
#define GET_MOMIAC_VAC2_FRP				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1FreqError
#define GET_MOMIAC_VAC2_HAW				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1HarmonicWarning
#define GET_MOMIAC_VAC2_HAP				tsMoniAC[MoniAC_Tag_VAC2].nFlag.u16Bits.u1HarmonicProtect

#define GET_MOMIAC_IPFC_OCW				tsMoniAC[MoniAC_Tag_IPFC].nFlag.u16Bits.u1OverCurrentWarning
#define GET_MOMIAC_IPFC_OCP				tsMoniAC[MoniAC_Tag_IPFC].nFlag.u16Bits.u1OverCurrentProtect
#define GET_MOMIAC_IPFC_OPW				tsMoniAC[MoniAC_Tag_IPFC].nFlag.u16Bits.u1OverPowerWarning
#define GET_MOMIAC_IPFC_OPP				tsMoniAC[MoniAC_Tag_IPFC].nFlag.u16Bits.u1OverPowerProtect

#define SET_MOMIAC_VAC1_DROP_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sDropout.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_DROP_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sDropout.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC1_DROP_Disable	tsMoniAC[MoniAC_Tag_VAC1].sConfig.sDropout.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC1_UVW_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sUVW.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_UVW_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sUVW.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC1_UVW_Disable		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sUVW.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC1_UVP_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sUVP.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_UVP_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sUVP.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC1_UVP_Disable		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sUVP.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC1_OVW_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOVW.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_OVW_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOVW.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_VAC1_OVP_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOVP.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_OVP_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOVP.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_VAC1_FRW_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sFreqWarning.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_FRW_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sFreqWarning.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC1_FRW_Disable		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sFreqWarning.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC1_FRP_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sFreqError.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_FRP_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sFreqError.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC1_FRP_Disable		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sFreqError.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC1_HAW_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOHW.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_HAW_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOHW.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_VAC1_HAP_Latch		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOHP.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC1_HAP_Clear		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOHP.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC1_HAP_Disable		tsMoniAC[MoniAC_Tag_VAC1].sConfig.sOHP.eTriggerType = TriggerDisable



#define SET_MOMIAC_VAC2_DROP_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sDropout.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_DROP_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sDropout.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC2_DROP_Disable	tsMoniAC[MoniAC_Tag_VAC2].sConfig.sDropout.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC2_UVW_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sUVW.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_UVW_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sUVW.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC2_UVW_Disable		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sUVW.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC2_UVP_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sUVP.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_UVP_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sUVP.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC2_UVP_Disable		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sUVP.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC2_OVW_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOVW.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_OVW_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOVW.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_VAC2_OVP_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOVP.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_OVP_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOVP.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_VAC2_FRW_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sFreqWarning.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_FRW_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sFreqWarning.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC2_FRW_Disable		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sFreqWarning.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC2_FRP_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sFreqError.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_FRP_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sFreqError.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC2_FRP_Disable		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sFreqError.eTriggerType = TriggerDisable

#define SET_MOMIAC_VAC2_HAW_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOHW.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_HAW_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOHW.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_VAC2_HAP_Latch		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOHP.eTriggerType = TriggerLatch
#define SET_MOMIAC_VAC2_HAP_Clear		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOHP.eTriggerType = TriggerAutoRecover
#define SET_MOMIAC_VAC2_HAP_Disable		tsMoniAC[MoniAC_Tag_VAC2].sConfig.sOHP.eTriggerType = TriggerDisable


#define SET_MOMIAC_IPFC_OCW_Latch		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOCW.eTriggerType = TriggerLatch
#define SET_MOMIAC_IPFC_OCW_Clear		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOCW.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_IPFC_OCP_Latch		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOCP.eTriggerType = TriggerLatch
#define SET_MOMIAC_IPFC_OCP_Clear		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOCP.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_IPFC_OPW_Latch		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOPW.eTriggerType = TriggerLatch
#define SET_MOMIAC_IPFC_OPW_Clear		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOPW.eTriggerType = TriggerAutoRecover

#define SET_MOMIAC_IPFC_OPP_Latch		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOPP.eTriggerType = TriggerLatch
#define SET_MOMIAC_IPFC_OPP_Clear		tsMoniAC[MoniAC_Tag_IPFC].sConfig.sOPP.eTriggerType = TriggerAutoRecover


/****************************************************************************
*	Public macro definition
****************************************************************************/

/****************************************************************************
*	Public enumeration definition 
****************************************************************************/

typedef enum
{
	MoniAC_Tag_VAC1 = 0,
	MoniAC_Tag_VAC2,
	MoniAC_Tag_VPFC,
	MoniAC_Tag_IPFC,
	MoniAC_Tag_Num
}eMoniACTag_t;


typedef enum
{
	MoniAC_Type_Volt,
	MoniAC_Type_Curr,
}eMoniACType_t;

typedef enum
{
	MoniAC_InputStatus_NA = 0,
	MoniAC_InputStatus_AC,
	MoniAC_InputStatus_DC,
	MoniAC_InputStatus_Loss,
}eMoniInputStatus_t;


typedef enum
{
	MoniAC_RelayONZC,		//Relay turn on at Zero Cross
	MoniAC_RelayONAngle,	//Relay turn on at Setting Angle
	MoniAC_RelayOFFZC,		//Relay turn off at Zero Cross
	MoniAC_SwitchZC,		//IGBT or MOSFET turn on or turn off at Zero Cross
	MoniAC_SwitchAngle,		//IGBT or MOSFET turn on or turn off at Setting Angle
}eMoniSwitchTiming_t;


/****************************************************************************
*	Public structure definition 
****************************************************************************/

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1SourcePresent			: 1;	// For ATS input usefull
		u16_t u1SourceGood				: 1;	// For ATS input Valid
		u16_t u1Dropout					: 1;	// For ATS standby mode and ATS relay manage
		u16_t u1BrownoutWarning			: 1;
		u16_t u1BrownoutProtect			: 1;
		u16_t u1OverVoltageWarning		: 1;
		u16_t u1OverVoltageProtect		: 1;
		u16_t u1OverCurrentWarning		: 1;
		
		u16_t u1OverCurrentProtect		: 1;
		u16_t u1FreqWarning				: 1;
		u16_t u1FreqError				: 1;
		u16_t u1OverPowerWarning		: 1;
		u16_t u1OverPowerProtect		: 1;
		u16_t u1HarmonicWarning			: 1;
		u16_t u1HarmonicProtect			: 1;
		u16_t u1OVP_H					: 1;	// Reserved
	}u16Bits;
}nMoniACFlag_t;

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1Polarity				: 1;	// 0:Negative, 1:Positive
		u16_t u1PolarityPreRMS			: 1;	// previously Polarity for RMS calculation
		u16_t u2InputStatus				: 2;	// 0:NA , 1:AC input, 2:DC input, 3:input loss	
		u16_t u2InputStatusPre			: 2;	// previously InputStatus
		u16_t u1NeedtodoRMS				: 1;	// Setting at initialize, Need to do RMS calculation
		u16_t u1Phaselock				: 1;	// phaselock, period 2time check
		
		u16_t u1CalRMS					: 1;	// Calculation RMS
        u16_t u16ITIC                   : 1;    // 0:Nothing , 1:ITIC above 140% is occur
        u16_t u16ReportVrms              : 1;    // 0:Do not report RMS , 1:Report RMS
		u16_t uReserved					: 5;
	}u16Bits;
}nMoniACStatus_t;


typedef struct
{	
	sSingleThreshold_t 	sDropout;
	sSingleThreshold_t	sUVP;
	sSingleThreshold_t	sUVW;
	sSingleThreshold_t	sOVP;
	sSingleThreshold_t	sOVW;
	sThreshold_t	    sOCP;
	sThreshold_t        sOCW;
	sSingleThreshold_t	sOPP;
	sSingleThreshold_t	sOPW;
	sSingleThreshold_t	sOHP;
	sSingleThreshold_t	sOHW;
	sSingleThreshold_t	sOVPH;
	sBetweenThreshold_t	sSourcePresent;
	sBetweenThreshold_t sSourceGood;
	sBetweenThreshold_t sFreqWarning;
	sBetweenThreshold_t sFreqError;
}sMoniACConfig_t;


typedef struct
{
	eMoniACTag_t eTag;				// AC Source report identifier
	eMoniACType_t eType;			// Identifier Voltage or Current
	nMoniACFlag_t nFlag;			// AC Monitor Flag
	nMoniACStatus_t nStatus;		// AC Monitor Status
	sMoniACConfig_t sConfig;		// AC Monitor Configuration
	sCaliCoeff_t* psCali;           // AC measure calibration

	/* Key Variable */
	i16_t* pi16ADCVSin_Q12;			// ADC Voltage Sin wave
	u16_t* pu16ADCVnnn_Q12;			// ADC Voltage m wave
	u16_t* pu16ADCInnn_Q12;			// ADC Current m wave
	u16_t u16RealInstant;			// Unit is 0.1V, 0.01A, from nnn_Q12
	f32_t f32RealPeak;				// Record real peak value of half cycle, AC only, Unit is 0.1V, 0.01A
	u16_t u16Real_Peak_BUF;			// Update peak value of half cycle, AC only
	u32_t u32Square_Sum_Q12;		// Total Square sum value, AC only
	u32_t u32Square_Sum_Buff_Q12;	// Current square sum value, AC only
	u16_t u16RealRMS_Buff1;			// Unit is 0.1V, 0.01A, previous, AC only
	u16_t u16RealRMS_Buff2;			// Unit is 0.1V, 0.01A, present, AC only
	u16_t u16RealRMS;				// Unit is 0.1V, 0.001A, (Buff1+Buff2) / 2
	u16_t u16RealRMS_WF;			// Unit is 0.1V, 0.001A, with filter for report
	u16_t u16Period_CNT;			// phase count in half period, unit is 0.1ms, AC only
	u16_t u16Period;				// half period, AC only
	u16_t u16Period_Pre;			// previously half period for phase lock, AC only
	u16_t u16Period_Cycle;			// one cycle of period, AC only, Period + Period_Pre
	u16_t u16Freq;					// Unit is 0.01Hz, AC only
	u16_t u16Freq_WF;				// Unit is 0.01Hz, with filter for report, AC only
	u16_t u16Power_WF;				// Unit is 1 Watt, with filter, for AC1 and AC2
	u16_t u16Harmonic_WF;			// unit is 0.01%, with filter, for AC1 and AC2

	/* Other Variable */
	u16_t u16AngleofCNT; 			// switch Angle to period cnt
	u16_t u16Filter_CNT;			// Filter zero cross noise
    u16_t u16BlackoutCNT;			// Blackout Fail Count

	/* Constant */
    u16_t u16ReportRMS_Delay;       // Fixed AMC issue, this variable avoid report RMS when AC turn off
	u16_t u16FreqMinlimit;       	// Minimum frequence limit cnt
	u16_t u16FreqMaxlimit;       	// Maximum frequence limit cnt
	u16_t u16Blackout_HV;			// Black out High voltage Threshold
	u16_t u16Blackout_LV;			// Black out Low voltage Threshold
    u16_t u16ITIC_Vpeak_SetPoint;   // Detect Vpeak for ITIC
	f32_t f32Cali_Gain;				// Calibration Gain , 0.01A ; 0.1V
	f32_t f32Cali_Offset;			// Calibration Offset, 0.01A ; 0.1V
}sMoniAC_t;


/****************************************************************************
*	Public export variable
****************************************************************************/
extern	sMoniAC_t tsMoniAC[MoniAC_Tag_Num];


/****************************************************************************
*	Public export function prototype
****************************************************************************/
extern void MoniAC_Initialize(void);
extern void MoniAC_10k_Instant_Process(void);
extern void MoniAC_1ms_Periodically_Process(void);
extern void MoniAC_10ms_Periodically_Process(void);
extern void MoniAC_1s_Periodically_Process(void);
extern sMoniAC_t* GetMoniACRef(eMoniACTag_t eTag);
extern void UpdateMoniACCalibration(eMoniACTag_t eTag);
extern void Update_ObservationWindow(u16_t u16Value);
extern u16_t SwitchTiming(eMoniSwitchTiming_t eTiming, eMoniACTag_t eTag);



#endif
