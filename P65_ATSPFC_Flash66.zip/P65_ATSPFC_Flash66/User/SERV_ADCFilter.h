/****************************************************************************
 *	File	SERV_ADCFilter.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/29 - 1st release
 ****************************************************************************/

#ifndef _SERV_ADCFILTER_H_
#define _SERV_ADCFILTER_H_

#include "CONFIG_Define.h"

/****************************************************************************
    Private parameter definition
****************************************************************************/
#define Samplingfrequency_PWM       (f32_t)EPWM7_FREQ
#define Samplingfrequency_10k       (f32_t)CPU_TIMER_10KHz_FREQUENCY
#define Samplingfrequency_1k        (f32_t)CPU_TIMER_1KHz_FREQUENCY
#define Samplingfrequency_10ms      (f32_t)100
#define Samplingfrequency_100ms     (f32_t)10

#define filterfrequency_Iac         (f32_t)57000    // unit is 1Hz
#define filterfrequency_Vac_PFC     (f32_t)100000   // unit is 1Hz
#define filterfrequency_Vac_ATS     (f32_t)5500     // unit is 1Hz
#define filterfrequency_Vbulk       (f32_t)500      // unit is 1Hz
#define filterfrequency_Vaux        (f32_t)50       // unit is 1Hz
#define filterfrequency_T           (f32_t)1        // unit is 1Hz

#define filterparemeterA_Iac        (u16_t)(((2 * 3.14 * filterfrequency_Iac / Samplingfrequency_PWM) / (1 + 2 * 3.14 * filterfrequency_Iac / Samplingfrequency_PWM)) * Q12_)
#define filterparemeterA_Vac_PFC    (u16_t)(((2 * 3.14 * filterfrequency_Vac_PFC / Samplingfrequency_PWM) / (1 + 2 * 3.14 * filterfrequency_Vac_PFC / Samplingfrequency_PWM)) * Q12_)
#define filterparemeterA_Vac_ATS    (u16_t)(((2 * 3.14 * filterfrequency_Vac_ATS / Samplingfrequency_PWM) / (1 + 2 * 3.14 * filterfrequency_Vac_ATS / Samplingfrequency_PWM)) * Q12_)
#define filterparemeterA_Vbulk      (u16_t)(((2 * 3.14 * filterfrequency_Vbulk / Samplingfrequency_10k) / (1 + 2 * 3.14 * filterfrequency_Vbulk / Samplingfrequency_10k)) * Q12_)
#define filterparemeterA_Vaux       (u16_t)(((2 * 3.14 * filterfrequency_Vaux / Samplingfrequency_10ms) / (1 + 2 * 3.14 * filterfrequency_Vaux / Samplingfrequency_10ms)) * Q12_)
#define filterparemeterA_T          (u16_t)(((2 * 3.14 * filterfrequency_T / Samplingfrequency_100ms) / (1 + 2 * 3.14 * filterfrequency_T / Samplingfrequency_100ms)) * Q12_)

#define filterparemeterB_Iac        (u16_t)(Q12_ - filterparemeterA_Iac)
#define filterparemeterB_Vac_PFC    (u16_t)(Q12_ - filterparemeterA_Vac_PFC)
#define filterparemeterB_Vac_ATS    (u16_t)(Q12_ - filterparemeterA_Vac_ATS)
#define filterparemeterB_Vbulk      (u16_t)(Q12_ - filterparemeterA_Vbulk)
#define filterparemeterB_Vaux       (u16_t)(Q12_ - filterparemeterA_Vaux)
#define filterparemeterB_T          (u16_t)(Q12_ - filterparemeterA_T)

/****************************************************************************
    Public parameter definition
****************************************************************************/

#define GET_ADCFilter_PFC_IAC_nnn		tsADCfilter_AC[PFC_IAC].u16ADCPervious_Q12
#define GET_ADCFilter_PFC_IAC_A_nnn		tsADCfilter_AC[PFC_IAC_A].u16ADCPervious_Q12
#define GET_ADCFilter_PFC_IAC_B_nnn		tsADCfilter_AC[PFC_IAC_B].u16ADCPervious_Q12
#define GET_ADCFilter_PFC_IAC_C_nnn     tsADCfilter_AC[PFC_IAC_C].u16ADCPervious_Q12
#define GET_ADCFilter_PFC_IAC_A_Sin		tsADCfilter_AC[PFC_IAC_A].i16ADCPervious_Q12
#define GET_ADCFilter_PFC_IAC_B_Sin		tsADCfilter_AC[PFC_IAC_B].i16ADCPervious_Q12
#define GET_ADCFilter_PFC_IAC_C_Sin     tsADCfilter_AC[PFC_IAC_C].i16ADCPervious_Q12
#define GET_ADCFilter_PFC_VAC_Sin		tsADCfilter_AC[PFC_Vac_L].i16ADCPervious_Q12
#define GET_ADCFilter_PFC_VAC_nnn		tsADCfilter_AC[PFC_Vac_L].u16ADCPervious_Q12
#define GET_ADCFilter_ATS_VAC1_Sin		tsADCfilter_AC[ATS_Vac1_L].i16ADCPervious_Q12
#define GET_ADCFilter_ATS_VAC1_nnn		tsADCfilter_AC[ATS_Vac1_L].u16ADCPervious_Q12
#define GET_ADCFilter_ATS_VAC2_Sin		tsADCfilter_AC[ATS_Vac2_L].i16ADCPervious_Q12
#define GET_ADCFilter_ATS_VAC2_nnn		tsADCfilter_AC[ATS_Vac2_L].u16ADCPervious_Q12
#define GET_ADCFilter_DC_VBulk_DET		tsADCfilter_DC[DC_Bulk_DET].u16ADCPervious_Q12
#define GET_ADCFilter_DC_VBulk_OVP1		tsADCfilter_DC[DC_Bulk_OVP1].u16ADCPervious_Q12
#define GET_ADCFilter_DC_VBulk_OVP2		tsADCfilter_DC[DC_Bulk_OVP2].u16ADCPervious_Q12
#define GET_ADCFilter_DC_VAUX1			tsADCfilter_DC[DC_Aux_1].u16ADCPervious_Q12
#define GET_ADCFilter_DC_VAUX2			tsADCfilter_DC[DC_Aux_2].u16ADCPervious_Q12
#define GET_ADCFilter_T_PFC				tsADCfilter_DC[T_PFC].u16ADCPervious_Q12
#define GET_ADCFilter_T_INLET			tsADCfilter_DC[T_Inlet].u16ADCPervious_Q12
#define GET_ADCFilter_T_ATS				tsADCfilter_DC[T_ATS].u16ADCPervious_Q12
#define GET_ADCFilter_T_D2D				tsADCfilter_DC[T_D2D].u16ADCPervious_Q12

#define GET_IAC_A_Central_Point         tsADCfilter_AC[PFC_IAC_A].i16Vref_Cali
#define GET_IAC_B_Central_Point         tsADCfilter_AC[PFC_IAC_B].i16Vref_Cali
#define GET_IAC_C_Central_Point         tsADCfilter_AC[PFC_IAC_C].i16Vref_Cali



/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/
typedef enum
{
	PFC_IAC = 0,
	PFC_IAC_A,
	PFC_IAC_B,
    PFC_IAC_C,
	PFC_Vac_L,
	PFC_Vac_N,
	ATS_Vac1_L,
	ATS_Vac1_N,
	ATS_Vac2_L,
	ATS_Vac2_N,
	ADC_AC_Tag_Num
}eADC_AC_Tag_t;


typedef enum
{
	DC_Bulk_DET = 0,
	DC_Bulk_OVP1,
	DC_Bulk_OVP2,
	DC_Aux_1,
	DC_Aux_2,
	T_PFC,
	T_Inlet,
	T_ATS,
	T_D2D,
	ADC_DC_Tag_Num
}eADC_DC_Tag_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef struct
{
	eADC_AC_Tag_t 	eTag;
	u16_t* pu16ADCInstant_Q12;	//ADC input
	u16_t u16ADCPervious_Q12;	//Input m wave, full range is 0~Q12
	i16_t i16ADCPervious_Q12;	//Input sin wave, full range is -Q12~Q12
	u16_t u16Filterparameter_A;
	u16_t u16Filterparameter_B;
	i16_t i16Vref_Cali;			// Record Vref level before ATS start up
	u16_t u16Vref_Previous;		// filter Vref value
	u16_t u16Vref_Count;		// filter count
	u16_t u16Vref_Finished;		// Vref finish flag
}sADCfilter_AC_t;   

typedef struct
{
	eADC_DC_Tag_t 	eTag;
	u16_t* pu16ADCInstant_Q12;
	u16_t u16ADCPervious_Q12;
	u16_t u16Filterparameter_A;
	u16_t u16Filterparameter_B;
}sADCfilter_DC_t;   


/****************************************************************************
	Public export variable
****************************************************************************/
extern	sADCfilter_AC_t tsADCfilter_AC[ADC_AC_Tag_Num];
extern	sADCfilter_DC_t tsADCfilter_DC[ADC_DC_Tag_Num];

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void ADCFilter_PWM_Instant_Process(void);
extern void ADCFilter_10k_Instant_Process(void);
extern void ADCFilter_1ms_Periodically_Process(void);
extern void ADCFilter_10ms_Periodically_Process(void);
extern void ADCFilter_100ms_Periodically_Process(void);
extern void ADCFilter_Initialize(void);


#endif /* SERV_ADCFILTER_H_ */
