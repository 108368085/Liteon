//#############################################################################
//
// FILE:   mcan_ex9_transmit.c
//
// TITLE:  MCAN External Transmit using Tx Buffer
//
//! \addtogroup driver_example_c28x_list
//! <h1> MCAN External Transmit using Tx Buffer </h1>
//!
//! This example demonstrates the MCAN External Transmit function. External
//! communication is done between two CAN nodes. The receiving node could be
//! another MCU or a CAN bus analysis tool capable of Receiving/ACKnowledging
//! transmitted frames. The transmit and receive pins of the MCAN module
//! should be connected to a CAN Transceiver. Nominal Bit Rate of 500 kbps and
//! Data bit rate of 1 Mbps is used.
//! Standard Identifier (STD ID) 0x4 is transmitted with 64 data bytes.
//! #defines that are not required for this test case have been commented out.
//! However, they have been left in the code should the scope of this code
//! be expanded to include Receive and FIFO functions.
//!
//! If another C2000 MCU is used as the receiver, mcan_ex4_receive.c can be
//! run on it for the receive function.
//!
//! \b Hardware \b Required \n
//!  - A C2000 board with CAN transceiver
//!
//! \b External \b Connections \n
//!  Both nodes should communicate through CAN FD capable transceivers.
//!
//!  - MCAN is on DEVICE_GPIO_PIN_CANRXA (MCANRXA)
//!  - and DEVICE_GPIO_PIN_CANTXA (MCANTXA)
//!
//! \b Watch \b Variables \n
//!  - txMsg
//!
//
//#############################################################################
//
//
// $Copyright:
// Copyright (C) 2022 Texas Instruments Incorporated - http://www.ti.com
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

// Include Filesz
#include "Peripheral_MCAN.h"
#include "F28x_Project.h"
#include "sw_prioritized_isr_levels.h"
#include "device.h"
#include "Peripheral_CAN.h"
#include "CANBus_Server.h"
#include "driverlib.h"
#include "mcan.h"
#include "inc/stw_types.h"
#include "inc/stw_dataTypes.h"
#include <string.h>

#ifdef Enable_MCAN

// Defines.
#define Protocol_TX                      (1U)
#define Protocol_RX                      (0U)

#define NUM_OF_MSG                      (7U)
#define MCAN_STD_ID_FILTER_NUM          (0U)
#define MCAN_EXT_ID_FILTER_NUM          (1U)
#define MCAN_FIFO_0_NUM                 (0U)
#define MCAN_FIFO_0_ELEM_SIZE           (MCAN_ELEM_SIZE_64BYTES)
#define MCAN_FIFO_1_NUM                 (NUM_OF_MSG) // 0
#define MCAN_FIFO_1_WATERMARK           (NUM_OF_MSG)
#define MCAN_FIFO_1_ELEM_SIZE           (MCAN_ELEM_SIZE_64BYTES)
#define MCAN_RX_BUFF_NUM                (0U)
#define MCAN_RX_BUFF_ELEM_SIZE          (MCAN_ELEM_SIZE_64BYTES)
#define MCAN_TX_BUFF_SIZE               (NUM_OF_MSG)
#define MCAN_TX_FQ_SIZE                 (0U)
#define MCAN_TX_BUFF_ELEM_SIZE          (MCAN_ELEM_SIZE_64BYTES)
#define MCAN_TX_EVENT_SIZE              (0U)

#define MCAN_EXT_ID_AND_MASK            (0x1FFFFFFFU)


//#define NUM_OF_MSG                      (7U)
//#define MCAN_STD_ID_FILTER_NUM          (0U)
//#define MCAN_EXT_ID_FILTER_NUM          (1U)
//#define MCAN_FIFO_0_NUM                 (0U)
//#define MCAN_FIFO_0_ELEM_SIZE           (MCAN_ELEM_SIZE_64BYTES)
//#define MCAN_FIFO_1_NUM                 (NUM_OF_MSG)
//#define MCAN_FIFO_1_WATERMARK           (NUM_OF_MSG)
//#define MCAN_FIFO_1_ELEM_SIZE           (MCAN_ELEM_SIZE_64BYTES)
//#define MCAN_RX_BUFF_NUM                (0U)
//#define MCAN_RX_BUFF_ELEM_SIZE          (MCAN_ELEM_SIZE_64BYTES)
//#define MCAN_TX_BUFF_SIZE               (0U)
//#define MCAN_TX_FQ_SIZE                 (0U)
//#define MCAN_TX_BUFF_ELEM_SIZE          (MCAN_ELEM_SIZE_64BYTES)
//#define MCAN_TX_EVENT_SIZE              (0U)
//#define MCAN_EXT_ID_AND_MASK            (0x1FFFFFFFU)

//
//  Defining Starting Addresses for Message RAM Sections,
//  (Calculated from Macros based on User defined configuration above)
//
//#define MCAN_STD_ID_FILT_START_ADDR     (0x0U)
//#define MCAN_EXT_ID_FILT_START_ADDR     (MCAN_STD_ID_FILT_START_ADDR + ((MCAN_STD_ID_FILTER_NUM * MCANSS_STD_ID_FILTER_SIZE_WORDS * 4U)))
//#define MCAN_FIFO_0_START_ADDR          (MCAN_EXT_ID_FILT_START_ADDR + ((MCAN_EXT_ID_FILTER_NUM * MCANSS_EXT_ID_FILTER_SIZE_WORDS * 4U)))
//#define MCAN_FIFO_1_START_ADDR          (MCAN_FIFO_0_START_ADDR + (MCAN_getMsgObjSize(MCAN_FIFO_0_ELEM_SIZE) * 4U * MCAN_FIFO_0_NUM))
//#define MCAN_RX_BUFF_START_ADDR         (MCAN_FIFO_1_START_ADDR + (MCAN_getMsgObjSize(MCAN_FIFO_1_ELEM_SIZE) * 4U * MCAN_FIFO_1_NUM))
//#define MCAN_TX_BUFF_START_ADDR         (MCAN_RX_BUFF_START_ADDR + (MCAN_getMsgObjSize(MCAN_RX_BUFF_ELEM_SIZE) * 4U * MCAN_RX_BUFF_NUM))
//#define MCAN_TX_EVENT_START_ADDR        (MCAN_TX_BUFF_START_ADDR + (MCAN_getMsgObjSize(MCAN_TX_BUFF_ELEM_SIZE) * 4U * (MCAN_TX_BUFF_SIZE + MCAN_TX_FQ_SIZE)))

#define MCAN_STD_ID_FILT_START_ADDR     (0x0U)
#define MCAN_EXT_ID_FILT_START_ADDR     (MCAN_STD_ID_FILT_START_ADDR + ((MCAN_STD_ID_FILTER_NUM * MCANSS_STD_ID_FILTER_SIZE_WORDS * 4U)))
#define MCAN_FIFO_0_START_ADDR          (MCAN_EXT_ID_FILT_START_ADDR + ((MCAN_EXT_ID_FILTER_NUM * MCANSS_EXT_ID_FILTER_SIZE_WORDS * 4U)))
#define MCAN_FIFO_1_START_ADDR          (MCAN_FIFO_0_START_ADDR + (MCAN_getMsgObjSize(MCAN_FIFO_0_ELEM_SIZE) * 4U * MCAN_FIFO_0_NUM))
#define MCAN_RX_BUFF_START_ADDR         (MCAN_FIFO_1_START_ADDR + (MCAN_getMsgObjSize(MCAN_FIFO_1_ELEM_SIZE) * 4U * MCAN_FIFO_1_NUM))
#define MCAN_TX_BUFF_START_ADDR         (MCAN_RX_BUFF_START_ADDR + (MCAN_getMsgObjSize(MCAN_RX_BUFF_ELEM_SIZE) * 4U * MCAN_RX_BUFF_NUM))
#define MCAN_TX_EVENT_START_ADDR        (MCAN_TX_BUFF_START_ADDR + (MCAN_getMsgObjSize(MCAN_TX_BUFF_ELEM_SIZE) * 4U * (MCAN_TX_BUFF_SIZE + MCAN_TX_FQ_SIZE)))


/****************************************************************************
    Public export variable
****************************************************************************/
sPeriCAN_Driver_t ptsPeriCANDriver[ePeriCAN_Channel_Num];

MCAN_TxBufElement       txMsg[1];
MCAN_InitParams         initParams;
MCAN_MsgRAMConfigParams msgRAMConfigParams;
MCAN_BitTimingParams    bitTimes;             // Calculate CAN-FD speed.
MCAN_ProtocolStatus     CANFD_ProtocolStatus; // Monitor CAN protocol status
MCAN_ErrCntStatus       CANFD_ErrCntStatus;   // Monitor error counter status

// Rx
MCAN_ConfigParams          ConfigParams;
MCAN_ExtMsgIDFilterElement extFiltelem;
MCAN_RxFIFOStatus RxFS;
MCAN_RxBufElement rxMsg1;

uint32_t     error1 = 0;
uint32_t     error2 = 0;

int32_t loopCnt = 0U;


// Function Prototype.
static void MCANConfig(void);

void PeriMCAN_Initialize()
{
    int i = 0;
    volatile uint32_t mode = 0U;
    uint32_t dataBytes = 64;

    // Configure the divisor for the MCAN bit-clock
    SysCtl_setMCANClk(SYSCTL_MCANA, SYSCTL_MCANCLK_DIV_5);

    // Configure GPIO pins for MCANTX/MCANRX operation
    GPIO_setPinConfig(GPIO_70_CANA_RX);
    GPIO_setPinConfig(GPIO_71_CANA_TX);

    txMsg[loopCnt].rtr      = 0U;   // RTR = 0 (Data frame)
    txMsg[loopCnt].xtd      = 1U;   // XTD = 1 (29-bit extended identifier)
    txMsg[loopCnt].esi      = 0U;
    txMsg[loopCnt].dlc      = 15U;  // 64 bytes
    txMsg[loopCnt].brs      = 1U;   // Bit-rate switching enabled
    txMsg[loopCnt].fdf      = 1U;   // Frame transmitted in CAN FD format
    txMsg[loopCnt].efc      = 1U;   // Store TX events
    txMsg[loopCnt].mm       = 0xAAU;

    rxMsg1.id = 0U;
    rxMsg1.rtr = 0U;
    rxMsg1.xtd = 1U;
    rxMsg1.esi = 0U;
    rxMsg1.rxts = 0U;
    rxMsg1.dlc = 0U;
    rxMsg1.brs = 0U;
    rxMsg1.fdf = 0U;
    rxMsg1.fidx = 0U;
    rxMsg1.anmf = 0U;
    for(i = 0; i < dataBytes; i++)
    {
        rxMsg1.data[i]  = 0;
    }

    // Configure the MCAN Module.
    MCANConfig();
}

static void MCANConfig(void)
{
    // Initializing all structures to zero to prevent stray values
    memset(&initParams, 0, sizeof(initParams));
    memset(&bitTimes, 0, sizeof(bitTimes));
    memset(&msgRAMConfigParams, 0, sizeof(msgRAMConfigParams));
    memset(&ConfigParams, 0, sizeof(ConfigParams));
    memset(&extFiltelem, 0, sizeof(extFiltelem));


    // Initialize MCAN Init parameters.
    initParams.darEnable         = 0x1U; // Re-transmition disabled.
    initParams.fdMode            = 0x0U; // FD operation enabled.
    initParams.brsEnable         = 0x0U; // Bit rate switching for transmissions enabled.

    // Transmitter Delay Compensation parameters.
    initParams.tdcConfig.tdcf    = 0xAU;
    initParams.tdcConfig.tdco    = 0x6U;

    ConfigParams.filterConfig.anfe = 1; // Accept all extended id
    ConfigParams.filterConfig.anfs = 1; // Accept all standard id

    /*
     *  Initialize Message RAM Sections Configuration Parameters
     */
    msgRAMConfigParams.flesa                = MCAN_EXT_ID_FILT_START_ADDR;
    // Extended ID Filter List Start Address (0)

    msgRAMConfigParams.lse                  = MCAN_EXT_ID_FILTER_NUM;
    // Extended ID Filter List Size (1)

    msgRAMConfigParams.rxFIFO1startAddr     = MCAN_FIFO_1_START_ADDR;
    // Rx FIFO1 Start Address (748U)

    msgRAMConfigParams.rxFIFO1size          = MCAN_FIFO_1_NUM; //MCAN_FIFO_1_NUM
    // Number of Rx FIFO elements (1)

    msgRAMConfigParams.rxFIFO1waterMark     = MCAN_FIFO_1_WATERMARK;
    // Level for Rx FIFO 1 watermark interrupt (1)

    msgRAMConfigParams.rxFIFO1OpMode        = 0U;
    // FIFO blocking mode.

    msgRAMConfigParams.rxFIFO1ElemSize      = MCAN_FIFO_1_ELEM_SIZE;
    // Rx FIFO1 Element Size - RBDS field of MCAN_RXESC Register

    // Initialize Rx FIFO Filter element Configuration parameters.
    extFiltelem.efid2 = 0x1FFFFFFFU; // Extended ID2
    extFiltelem.efid1 = 0x0U;        // Extended ID1
    extFiltelem.efec  = 0x0U;        // Store into FIFO 1.
    extFiltelem.eft   = 0x0U;        // Range filter from EFID1 to EFID2


    //////////////////////////////// TX ////////////////////////////////
    // Initialize Message RAM Sections Configuration Parameters
    msgRAMConfigParams.txStartAddr          = MCAN_TX_BUFF_START_ADDR;

    // Tx Buffers Start Address
    msgRAMConfigParams.txBufNum             = MCAN_TX_BUFF_SIZE;

    // Number of Dedicated Transmit Buffers.
    msgRAMConfigParams.txBufMode            = 0U;
    msgRAMConfigParams.txFIFOSize           = MCAN_TX_FQ_SIZE; 
    // Number of Tx FIFO or Tx Queue Elements

    msgRAMConfigParams.txBufElemSize        = MCAN_TX_BUFF_ELEM_SIZE;
    // Tx Buffer Element Size.

    // Initialize bit timings.
    /*  nominal rate:0.5MHz , bit rate : 1MHz , ok*/
//    bitTimes.nomRatePrescalar   = 0x3U; // Nominal Baud Rate Pre-scaler
//    bitTimes.nomTimeSeg1        = 0x9U; // Nominal Time segment before SP
//    bitTimes.nomTimeSeg2        = 0x8U; // Nominal Time segment after SP
//    bitTimes.nomSynchJumpWidth  = 0x8U; // Nominal SJW
//    bitTimes.dataRatePrescalar  = 0x1U; // Data Baud Rate Pre-scaler
//    bitTimes.dataTimeSeg1       = 0x9U; // Data Time segment before SP
//    bitTimes.dataTimeSeg2       = 0x8U; // Data Time segment after SP
//    bitTimes.dataSynchJumpWidth = 0x8U; // Data SJW

    /*  nominal rate:1MHz , bit rate : 1MHz , ok*/
    bitTimes.nomRatePrescalar   = 0x1U; // Nominal Baud Rate Pre-scaler
    bitTimes.nomTimeSeg1        = 0x9U; // Nominal Time segment before SP
    bitTimes.nomTimeSeg2        = 0x8U; // Nominal Time segment after SP
    bitTimes.nomSynchJumpWidth  = 0x8U; // Nominal SJW
    bitTimes.dataRatePrescalar  = 0x1U; // Data Baud Rate Pre-scaler
    bitTimes.dataTimeSeg1       = 0x9U; // Data Time segment before SP
    bitTimes.dataTimeSeg2       = 0x8U; // Data Time segment after SP
    bitTimes.dataSynchJumpWidth = 0x8U; // Data SJW

    /*  nominal rate:0.5MHz , bit rate : 2MHz , ok */
//    bitTimes.nomRatePrescalar   = 0x3U; // Nominal Baud Rate Pre-scaler
//    bitTimes.nomTimeSeg1        = 0x9U; // Nominal Time segment before SP
//    bitTimes.nomTimeSeg2        = 0x8U; // Nominal Time segment after SP
//    bitTimes.nomSynchJumpWidth  = 0x8U; // Nominal SJW
//    bitTimes.dataRatePrescalar  = 0x0U; // Data Baud Rate Pre-scaler
//    bitTimes.dataTimeSeg1       = 0x9U; // Data Time segment before SP
//    bitTimes.dataTimeSeg2       = 0x8U; // Data Time segment after SP
//    bitTimes.dataSynchJumpWidth = 0x8U; // Data SJW

    /*  nominal rate:1MHz , bit rate : 2MHz , ok */
//    bitTimes.nomRatePrescalar   = 0x1U; // Nominal Baud Rate Pre-scaler
//    bitTimes.nomTimeSeg1        = 0x9U; // Nominal Time segment before SP
//    bitTimes.nomTimeSeg2        = 0x8U; // Nominal Time segment after SP
//    bitTimes.nomSynchJumpWidth  = 0x8U; // Nominal SJW
//    bitTimes.dataRatePrescalar  = 0x0U; // Data Baud Rate Pre-scaler
//    bitTimes.dataTimeSeg1       = 0x9U; // Data Time segment before SP
//    bitTimes.dataTimeSeg2       = 0x8U; // Data Time segment after SP
//    bitTimes.dataSynchJumpWidth = 0x8U; // Data SJW

    /* 5MHz */
//    bitTimes.nomRatePrescalar   = 0x3U; // Nominal Baud Rate Pre-scaler
//    bitTimes.nomTimeSeg1        = 0x9U; // Nominal Time segment before SP
//    bitTimes.nomTimeSeg2        = 0x8U; // Nominal Time segment after SP
//    bitTimes.nomSynchJumpWidth  = 0x8U; // Nominal SJW
//    bitTimes.dataRatePrescalar  = 0x0U; // Data Baud Rate Pre-scaler
//    bitTimes.dataTimeSeg1       = 0x4U; // Data Time segment before SP
//    bitTimes.dataTimeSeg2       = 0x3U; // Data Time segment after SP
//    bitTimes.dataSynchJumpWidth = 0x3U; // Data SJW

    // Wait for memory initialization to happen.
    while(FALSE == MCAN_isMemInitDone(MCANA_DRIVER_BASE))
    {
    }

    // Put MCAN in SW initialization mode.
    MCAN_setOpMode(MCANA_DRIVER_BASE, MCAN_OPERATION_MODE_SW_INIT);

    // Wait till MCAN is not initialized.
    while (MCAN_OPERATION_MODE_SW_INIT != MCAN_getOpMode(MCANA_DRIVER_BASE))
    {}

    // Initialize MCAN module.
    MCAN_init(MCANA_DRIVER_BASE, &initParams);

    // Configure Bit timings.
    MCAN_setBitTime(MCANA_DRIVER_BASE, &bitTimes);

    // Configure Message RAM Sections
    MCAN_msgRAMConfig(MCANA_DRIVER_BASE, &msgRAMConfigParams);

    // Configure Standard ID filter element
    MCAN_addExtMsgIDFilter(MCANA_DRIVER_BASE, 0U, &extFiltelem);

    // Set Extended ID Mask for acceptance filtering of received frames
    // (Mask disabled when all bits are set to 1)
    MCAN_setExtIDAndMask(MCANA_DRIVER_BASE, MCAN_EXT_ID_AND_MASK);

    MCAN_config(MCANA_DRIVER_BASE, &ConfigParams);

    // Take MCAN out of the SW initialization mode
    MCAN_setOpMode(MCANA_DRIVER_BASE, MCAN_OPERATION_MODE_NORMAL);

//    while (MCAN_OPERATION_MODE_NORMAL != MCAN_getOpMode(MCANA_DRIVER_BASE))
//    {
//
//    }
}

/**
 *  @brief  Parsing message length object
 *  @retval "DLC" or "real data length"
 */
static inline u16_t PeriCAN_ParsingMessage(u32_t DataLength, u8_t u8ProtocolType)
{
    u16_t u16DataLength; // For RX used
    u16_t u16DLC_Value;  // For TX used

    if (u8ProtocolType == Protocol_TX)
    {
        // For TX used
        switch (DataLength)
        {
            case MCAN_TX_12Byte :
            {
                u16DLC_Value = 9;
            }
            break;

            case MCAN_TX_16Byte :
            {
                u16DLC_Value = 10;
            }
            break;

            case MCAN_TX_20Byte :
            {
                u16DLC_Value = 11;
            }
            break;

            case MCAN_TX_24Byte :
            {
                u16DLC_Value = 12;
            }
            break;

            case MCAN_TX_32Byte :
            {
                u16DLC_Value = 13;
            }
            break;

            case MCAN_TX_48Byte :
            {
                u16DLC_Value = 14;
            }
            break;

            case MCAN_TX_64Byte :
            {
                u16DLC_Value = 15;
            }
            break;
        }

        return u16DLC_Value;
    }
    else
    {
        // For RX used
        switch (DataLength)
        {
            case MCAN_RX_12Byte :
            {
                u16DataLength = 12;
            }
            break;

            case MCAN_RX_16Byte :
            {
                u16DataLength = 16;
            }
            break;

            case MCAN_RX_20Byte :
            {
                u16DataLength = 20;
            }
            break;

            case MCAN_RX_24Byte :
            {
                u16DataLength = 24;
            }
            break;

            case MCAN_RX_32Byte :
            {
                u16DataLength = 32;
            }
            break;

            case MCAN_RX_48Byte :
            {
                u16DataLength = 48;
            }
            break;

            case MCAN_RX_64Byte :
            {
                u16DataLength = 64;
            }
            break;
        }

        return u16DataLength;
    }
}

/**
 *  @brief  Read message object
 *  @retval None
 */
static inline void PeriCAN_ReadMessage(sPeriCAN_Driver_t* psDriver)
{
    memset(&psDriver->sRxCANHandler.sDataFrame.pu8Data, 0, sizeof(psDriver->sRxCANHandler.sDataFrame.pu8Data)); // Clear data buffer
    psDriver->sRxCANHandler.sDataFrame.u32ID = rxMsg1.id;                                                       // Store id

    if (rxMsg1.dlc <= 8)
    {
        psDriver->sRxCANHandler.sDataFrame.u16Length = rxMsg1.dlc;                   // Store data length
        memcpy(psDriver->sRxCANHandler.sDataFrame.pu8Data, rxMsg1.data, rxMsg1.dlc); // Copy data to read buffer
    }
    else
    {
        // For data length over 8Bytes
        memcpy(psDriver->sRxCANHandler.sDataFrame.pu8Data, rxMsg1.data, PeriCAN_ParsingMessage(rxMsg1.dlc, Protocol_RX)); // Copy data to read buffer
    }
}

/**
 *  @brief  Send message object
 *  @retval None
 */
static inline void PeriCAN_SendMessage(sPeriCAN_Driver_t* psDriver)
{
    memset(&txMsg[loopCnt].data, 0, sizeof(txMsg[loopCnt].data));     // Clear data
    u16_t u16Length = psDriver->sTxCANHandler.psDataFrame->u16Length;
    txMsg[loopCnt].id = psDriver->sTxCANHandler.psDataFrame->u32ID;   // Fill CAN ID

    if (u16Length <= 8)
    {
        txMsg[loopCnt].dlc = u16Length;                                                       // Fill data length
        memcpy(txMsg[loopCnt].data, psDriver->sTxCANHandler.psDataFrame->pu8Data, u16Length); // Copy data to transmit buffer
    }
    else
    {
        // For over 8byte used
        txMsg[loopCnt].dlc = PeriCAN_ParsingMessage(u16Length, Protocol_TX);
        memcpy(txMsg[loopCnt].data, psDriver->sTxCANHandler.psDataFrame->pu8Data, u16Length); // Copy data to transmit buffer
    }

    // Write message to Message RAM.
    MCAN_writeMsgRam(MCANA_DRIVER_BASE, MCAN_MEM_TYPE_BUF, loopCnt,
                     &txMsg[loopCnt]);

    // Add transmission request for Tx buffer 0
    MCAN_txBufAddReq(MCANA_DRIVER_BASE, 0U);

    /* Wait till the frame is successfully transmitted (and ACKnowledged)
       "Tx Buffer Transmission Occurred" register is polled. */
//    while(MCAN_getTxBufReqPend(MCANA_DRIVER_BASE))
//    {
//    }
}

/**
 *  @brief  Monitor can register to check CAN module error, status, and interrupt register
 *  @Note   Two option for user choose, ISR got status or while loop monitor status
 *  @retval None
 */
static inline void Monitor_CAN_Reg(sPeriCAN_Driver_t* psDriver)
{
    // Monitor CAN-FD protocol status for MCAN module
    MCAN_getProtocolStatus(MCANA_DRIVER_BASE, &CANFD_ProtocolStatus);

    // Monitor error counter status for MCAN module.
    MCAN_getErrCounters(MCANA_DRIVER_BASE, &CANFD_ErrCntStatus);

    // Check to see if an error occurred.
//    if ((psDriver->nESReg.u16Bits.u3LEC != CAN_STATUS_LEC_MSK) &&
//        (psDriver->nESReg.u16Bits.u3LEC != CAN_STATUS_LEC_NONE))
//    {
//        // Set a flag to indicate some errors may have occurred.
//        if (psDriver->u16CANerrorFlag < Q15_)
//        {
//            psDriver->u16CANerrorFlag ++;
//        }
//    }

    // Check RX no error occurred
    if (((CANFD_ProtocolStatus.lastErrCode == MCAN_ERR_CODE_NO_ERROR) ||
        (CANFD_ProtocolStatus.dlec == MCAN_ERR_CODE_NO_ERROR)) &&
        (CANFD_ProtocolStatus.resi == 0))
    {
        psDriver->nFlag.u16Bits.u1RxOK = TRUE;
    }

    // Check TX no error occurred
    if (((CANFD_ProtocolStatus.lastErrCode == MCAN_ERR_CODE_NO_ERROR) ||
        (CANFD_ProtocolStatus.dlec == MCAN_ERR_CODE_NO_ERROR)) &&
        (MCAN_getTxBufTransmissionStatus(MCANA_DRIVER_BASE)))
    {
        psDriver->nFlag.u16Bits.u1TxOK = TRUE;
    }
}

/**
 *  @brief  CAN Rx Handler
 *  @retval None
 */
static inline void CAN_Rx_Handler(sPeriCAN_Driver_t* psDriver)
{
    u8_t i;

    if ((psDriver->nFlag.u16Bits.u1RxOK == TRUE) &&
        (psDriver->nFlag.u16Bits.u1CANError == FALSE))
    {
        psDriver->nFlag.u16Bits.u1RxOK = FALSE;

        RxFS.num = MCAN_RX_FIFO_NUM_1;
        MCAN_getRxFIFOStatus(MCANA_DRIVER_BASE, &RxFS);

        if (RxFS.fillLvl)
        {
            error1 = RxFS.fillLvl;  // For debug used
            error2 += 1;            // For debug used

            for (i=0; i<RxFS.fillLvl; i++)
            {
                MCAN_readMsgRam(MCANA_DRIVER_BASE, MCAN_MEM_TYPE_FIFO, 0U, MCAN_RX_FIFO_NUM_1, &rxMsg1);

                /* If receive id is standard */
                if (rxMsg1.xtd == 0)
                {
                    rxMsg1.id = (rxMsg1.id >> 18U);
                }

                PeriCAN_ReadMessage(psDriver);
                CANBusServer_Rx_Callback(&psDriver->sRxCANHandler.sDataFrame);

                // Response to FIFO an ACK
                MCAN_writeRxFIFOAck(MCANA_DRIVER_BASE, MCAN_RX_FIFO_NUM_1, RxFS.getIdx); //RxFS.getIdx
            }
        }
    }
}

/**
 *  @brief  CAN Tx Handler
 *  @retval None
 */
static inline void CAN_Tx_Handler(sPeriCAN_Driver_t* psDriver)
{
    switch (psDriver->sTxCANHandler.eState)
    {
        case CAN_STATE_IDLE:
        {
            if ((psDriver->nFlag.u16Bits.u1TxRequest == TRUE) &&
                (psDriver->nFlag.u16Bits.u1CANError == FALSE))
            {
                psDriver->nFlag.u16Bits.u1TxTransacting = TRUE;
                psDriver->nFlag.u16Bits.u1TxRequest = FALSE;
                psDriver->sTxCANHandler.u16BusErrorDelay = 0;

                // Write data to mailbox
                PeriCAN_SendMessage(psDriver);
                psDriver->nFlag.u16Bits.u1TxOK = FALSE;
                psDriver->sTxCANHandler.eState = CAN_STATE_ACCOMPLISH;
            }
        }
        break;

        case CAN_STATE_ACCOMPLISH:
        {
            if (psDriver->nFlag.u16Bits.u1TxOK == TRUE)
            {
                psDriver->nFlag.u16Bits.u1TxTransacting = FALSE;
                psDriver->sTxCANHandler.eState = CAN_STATE_IDLE;
                CANBusServer_Tx_Callback();
            }
        }
        break;

        case CAN_STATE_ERROR:
        {
            psDriver->nFlag.u16Bits.u1TxTransacting = FALSE;
            psDriver->sTxCANHandler.eState = CAN_STATE_IDLE;
        }
        break;

        default:
        break;
    }
}

/**
 *  @brief  CAN main handler
 *  @retval None
 */
static inline void CAN_Handler(sPeriCAN_Driver_t* psDriver)
{
    Monitor_CAN_Reg(psDriver);
    CAN_Rx_Handler(psDriver);
    CAN_Tx_Handler(psDriver);
}

/**
 *  @brief  Check Can bus Tx Idel
 *  @retval
 */
u16_t PeriCAN_IsTxIDLE(void)
{
    if (ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.eState == CAN_STATE_IDLE)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 *  @brief  Canbus server request to send data
 *  @retval
 */
void PeriCAN_TxRequest(sCANDataFrame_t* psDataFrame_Src)
{
    if (ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.eState == CAN_STATE_IDLE)
    {
        ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.psDataFrame = psDataFrame_Src;
        ptsPeriCANDriver[ePeriCAN_Channel_A].nFlag.u16Bits.u1TxRequest = TRUE;
    }
}


/**
 *  @brief  Peripheral - CAN 1ms periodically Process
 *  @retval While loop
 */
void PeriCAN_1ms_Periodically_Process(void)
{
    if (ptsPeriCANDriver[ePeriCAN_Channel_A].nFlag.u16Bits.u1TxTransacting)
    {
        if (ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.u16BusErrorDelay < PERI_CAN_Tx_BusErrorDelay)
        {
            ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.u16BusErrorDelay ++;
        }
        else
        {
            //CAN_Module_Reset(&ptsPeriCANDriver[ePeriCAN_Channel_A]);
            ptsPeriCANDriver[ePeriCAN_Channel_A].sTxCANHandler.eState = CAN_STATE_ERROR;
        }
    }
}

/**
 *  @brief  Peripheral - CAN Background Process
 *  @retval While loop
 */
void PeriMCAN_Background_Process(void)
{
    CAN_Handler(&ptsPeriCANDriver[ePeriCAN_Channel_A]);
}


#endif /* Enable_MCAN */
