/****************************************************************************
 *	File	Peripheral_CAN.h
 * 	Brief	Header file for Peripheral CAN module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/12/10 - 1st release
 ****************************************************************************/

#ifndef _PERIPHERAL_CAN_H_
#define _PERIPHERAL_CAN_H_

#include <CONFIG_RisingPower.h>
#include "CONFIG_Define.h"
#include "Peripheral.h"

#ifdef Enable_DCAN


/****************************************************************************
    Public parameter definition
****************************************************************************/
#define USE_CAN_CHANNEL_A
//#define USE_CAN_CHANNEL_B
#ifdef  USE_CAN_CHANNEL_A
#define CAN_CHANNEL_A_Tx_MUX_SEL       1
#define CAN_CHANNEL_A_Rx_MUX_SEL       1
#define CAN_CHANNEL_A_Tx_PIN_NUM       GPIO_PIN_31 
#define CAN_CHANNEL_A_Rx_PIN_NUM       GPIO_PIN_30
#endif

#ifdef  USE_CAN_CHANNEL_B
#define CAN_CHANNEL_B_Tx_MUX_SEL       2
#define CAN_CHANNEL_B_Rx_MUX_SEL       2
#define CAN_CHANNEL_B_Tx_PIN_NUM       GPIO_PIN_16 
#define CAN_CHANNEL_B_Rx_PIN_NUM       GPIO_PIN_17
#endif

/****************************************************************************
	Public macro definition
****************************************************************************/
#define CAN_BUFF_SIZE                	8

/** Can bus should reset the module after the transaction waste too much time */
#define PERI_CAN_Tx_BusErrorDelay   100   // 100ms, unit is 1ms
/****************************************************************************
	Public enumeration definition 
****************************************************************************/

typedef enum ePeripheral_CAN_Channel
{

#ifdef USE_CAN_CHANNEL_A
    ePeriCAN_Channel_A,
#endif

#ifdef USE_CAN_CHANNEL_B
    ePeriCAN_Channel_B,
#endif

    ePeriCAN_Channel_Num,
}ePeripheral_CAN_Channel_t;



/** Tx and Rx CAN Handler state */
typedef enum eCANState
{
	CAN_STATE_IDLE = 0,			///< This transaction is Idle
    CAN_STATE_DATATRANSFER, 	///< This transaction is wait IFx data transfer
	CAN_STATE_ACCOMPLISH,  		///< This transaction has accomplished
    CAN_STATE_ERROR,       		///< This transaction triggered an error
}eCANState_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef union nCAN_ES_Reg
{
    u16_t u16All;

    struct
    {
		u16_t u3LEC		         	: 3;	//Last Error Code
		u16_t u1TxOK         		: 1;	//A message has been successfully transmitted
		u16_t u1RxOK        		: 1;	//A message has been successfully received
		u16_t u1EPass				: 1;	//The CAN Core is in the error passive state
        u16_t u1EWarn       		: 1;	//At least one of the error counters has reached the error warning limit of 96
		u16_t u1BOff       			: 1;	//The CAN module is in Bus-Off state
		u16_t u1PER		         	: 1;	//The parity check mechanism has detected a parity error in the Message RAM
        u16_t uReserved           	: 7;
    }u16Bits;

}nCAN_ES_Reg_t;

typedef union nCAN_ERRC_Reg
{
    u16_t u16All;

    struct
    {
		u16_t u8TEC		         	: 8;	//Transmit Error Counter(values from 0 to 255)
		u16_t u7REC         		: 7;	//Receive Error Counter(values from 0 to 127)
		u16_t u1RP        			: 1;	//Receive Error Passive(Error Counter has reached the error passive level)
    }u16Bits;

}nCAN_ERRC_Reg_t;

typedef union nCANFlag
{
    u16_t u16All;

    struct
    {
		u16_t u1CANError         	: 1;	//CAN module error happen
		u16_t u1RxOK       			: 1;	//message received
        u16_t u1RxTransacting       : 1;	//Rx transacting message from mailbox to IFx
		u16_t u1TxRequest         	: 1;	//message transmit request
		u16_t u1TxTransacting       : 1;	//Tx transacting message from IFx to mailbox
		u16_t u1TxOK       			: 1;	//message transmitted
        u16_t uReserved           	: 10;
    }u16Bits;

}nCANFlag_t;


typedef struct sCANDataFrame
{
	u32_t u32ID;
    u8_t  pu8Data[CAN_BUFF_SIZE];
	u16_t u16Length;
}sCANDataFrame_t;


typedef struct sTxCANHandler
{
	eCANState_t eState;  
    sCANDataFrame_t* psDataFrame;
	u16_t u16BusErrorDelay;
}sTxCANHandler_t;


typedef struct sRxCANHandler
{
	eCANState_t eState;
    sCANDataFrame_t sDataFrame;
	u32_t u32FIFOIndex;
    u16_t u16TransationElapsedTime;
}sRxCANHandler_t;

typedef struct sPeriCAN_Driver
{
    u16_t u16Port;			///< Which Port is used
    nCAN_ES_Reg_t nESReg;
	nCAN_ERRC_Reg_t nERRCReg;
    nCANFlag_t nFlag;
	u16_t u16CANerrorFlag;
	
    /* Instance handler */
    volatile struct CAN_REGS* psInstance;
    
    /* Tx CAN Handler*/
    sTxCANHandler_t sTxCANHandler;
    
    /* Rx CAN Handler */
    sRxCANHandler_t sRxCANHandler;
    
}sPeriCAN_Driver_t;



/****************************************************************************
	Public export variable
****************************************************************************/
extern sPeriCAN_Driver_t ptsPeriCANDriver[ePeriCAN_Channel_Num];

/****************************************************************************
	Public export function prototype
****************************************************************************/

extern u16_t PeriCAN_IsTxIDLE(void);
extern void PeriCAN_TxRequest(sCANDataFrame_t* psDataFrame_Src);
extern void PeriCAN_1ms_Periodically_Process(void);
extern void PeriCAN_Background_Process(void);
extern void PeriCAN_Stop(void);
extern void PeriCAN_Start(void);
extern void PeriCAN_Initialize(void);

#endif /* Enable_DCAN */
#endif /* _PERIPHERAL_CAN_H_ */
