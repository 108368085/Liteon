/****************************************************************************
 *	File	SERV_LED.h
 * 	Brief	Header file for LED status update
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2021/02/17 - 1st release
 ****************************************************************************/


#ifndef _SERV_LED_H_
#define _SERV_LED_H_

#include "CONFIG_Define.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/

#define GET_STATUS_LED		nLEDstatus.u8All

#define LED_STATIC_OFF		0x0
#define LED_BLINKING_GREEN	0x1
#define LED_SOLID_GREEN		0x3
#define LED_SOLID_ORANGE	0xC

/* For S1 LED */
#define LED_S1_SOLID_GREEN     0b1        // bit-0
#define LED_S1_SOLID_ORANGE    0b10       // bit-1
#define LED_S1_BLINKING_GREEN  0b100      // bit-2

/* For S2 LED */
#define LED_S2_SOLID_GREEN     0b1000     // bit-3
#define LED_S2_SOLID_ORANGE    0b10000    // bit-4
#define LED_S2_BLINKING_GREEN  0b100000   // bit-5

/* BootMode and Fault */
#define LED_BootMode           0b1000000   // bit-6 , PFC is in Boot mode now
#define LED_TemporaryFault     0b10000000  // bit-7
#define LED_PermanentFault     0b100000000 // bit-8


/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

typedef enum
{
	LED_Tag_AC1,
	LED_Tag_AC2,
	LED_Tag_Num,
}eLedTag_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

/***************************************************************************
*   LED_STATUS [1Eh]
*   
*   LED b9  b8  b7  b6  b5  b4  b3  b2  b1  b0   Value	Description
*       0   0   0   0   0   0   0   0   0   0      0     S1 & S2 Off
*   S1  0   0   0   0   0   0   0   0   0   1      1     S1 Solid Green
*   S1  0   0   0   0   0   0   0   0   1   0      2     S1 Orange
*   S1  0   0   0   0   0   0   0   1   0   0      4     S1 Blinking Green
*
*   S2  0   0   0   0   0   0   1   0   0   0      8     S2 Solid Green
*   S2  0   0   0   0   0   1   0   0   0   0      16    S2 Orange
*   S2  0   0   0   0   1   0   0   0   0   0      32    S2 Blinking Green
*
* Off: input is below auxiliary operating voltage and not valid
* Solid Green: input is considered valid input source and active 
* Blinking Green: input is considered valid input source but not active 
* Solid Orange: input is out of frequency or voltage range and an AC input is expected
*
****************************************************************************/

typedef union
{
    u8_t u8All;

    struct
    {
        u8_t  u4AC1         : 4;
        u8_t  u4AC2         : 4;
    }u8Bits;
}nLedStatus_t;


typedef struct
{
    eLedTag_t   eTag;       // LED location tag
    u8_t        u8State;    // LED display type
}sLED_t;

/****************************************************************************
	Public export variable
****************************************************************************/

extern nLedStatus_t nLEDstatus;

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void LED_Initialize(void);
extern void LED_SetState(sLED_t* psLED, u8_t u8NewState);
extern sLED_t* GetLedRef(eLedTag_t eTag);

#endif

