/** @file       Peripheral_Flash.h
 *  @brief      Header file for Peripheral Flash module
 *  @author     Adonis Wang
 *  @version    1.0
 *  @date       
 */
 
#ifndef _PERIPHERAL_FLASH_H_
#define _PERIPHERAL_FLASH_H_

#include "CONFIG_Define.h"

/****************************************************************************
    Public parameter definition
****************************************************************************/

// Boot, 128KWx16
#define FlashAddr_B0_S0_start	        0x80000

// APP1, 128KWx16
#define FlashAddr_B1_S0_start	        0xA0000
#define FlashAddr_B1_S128_END           0xBFFFF

// APP2, 128KWx16
#define FlashAddr_B2_S0_start	        0xC0000
#define FlashAddr_B2_S128_END           0xDFFFF


#define STAMP_LENGTH					((u32_t)0x10)
#define PIB_LENGTH						((u32_t)0x40)
#define RCB_LENGTH						((u32_t)0x60)

/* Bootloader Location */
#define BOOT_ENTRY_ADDRESS              (FlashAddr_B0_S0_start)

/* Active Image Location */
#define ACTIVE_IMAGE_START_ADDRESS      (FlashAddr_B1_S0_start)
#define ACTIVE_IMAGE_END_ADDRESS        (FlashAddr_B1_S128_END)
#define ACTIVE_IMAGE_SIZE               (ACTIVE_IMAGE_END_ADDRESS - ACTIVE_IMAGE_START_ADDRESS +1)

#define ACTIVE_IMAGE_STAMP_ADDRESS      (ACTIVE_IMAGE_START_ADDRESS)
#define ACTIVE_IMAGE_PIB_ADDRESS        (ACTIVE_IMAGE_STAMP_ADDRESS + STAMP_LENGTH)
#define ACTIVE_IMAGE_RCB_ADDRESS        (ACTIVE_IMAGE_PIB_ADDRESS + PIB_LENGTH)
#define ACTIVE_IMAGE_UAP_ADDRESS        (ACTIVE_IMAGE_RCB_ADDRESS + RCB_LENGTH)

/* Backup Image Location */
#define BACKUP_IMAGE_START_ADDRESS      (FlashAddr_B2_S0_start)
#define BACKUP_IMAGE_END_ADDRESS        (FlashAddr_B2_S128_END)
#define BACKUP_IMAGE_SIZE               (BACKUP_IMAGE_END_ADDRESS - BACKUP_IMAGE_START_ADDRESS +1)

#define BACKUP_IMAGE_STAMP_ADDRESS      (BACKUP_IMAGE_START_ADDRESS)
#define BACKUP_IMAGE_PIB_ADDRESS        (BACKUP_IMAGE_STAMP_ADDRESS + STAMP_LENGTH)
#define BACKUP_IMAGE_RCB_ADDRESS        (BACKUP_IMAGE_PIB_ADDRESS + PIB_LENGTH)
#define BACKUP_IMAGE_UAP_ADDRESS        (BACKUP_IMAGE_RCB_ADDRESS + RCB_LENGTH)

#define FLASH_WRAPPER_PROGRAM_BASE      0x57000U /*(FLASH0CMD_BASE - 0x1000UL)*/

/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/

/****************************************************************************
	Public export function prototype
****************************************************************************/

extern u16_t PeriFlash_Initialize(void);
extern u16_t PeriFlash_Erase(u32_t u32SectorMask);
extern u16_t PeriFlash_Erase_Bank(u32_t u32BankStartAddress);
extern u16_t PeriFlash_Program(u32_t u32FlashAddress, u16_t* pu16ProgramData, u32_t u32ProgramLength);
extern u16_t PeriFlash_Read(u32_t u32FlashAddress, u16_t* pu16ReadBuffer, u32_t u32ReadLength);
extern u16_t PeriFlash_Verify(u32_t u32FlashAddress, u16_t* pu16VerifyData, u32_t u32VerifyLength);
extern u16_t PeriFlash_Copy(u32_t u32DestinationAddress, u32_t u32SourceAddress, u32_t u32CopyLength);
#endif

