/****************************************************************************
 *	File	SERV_Calibration.c
 * 	Brief	Calibration function
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/10/06 - modify by Ollie
 ****************************************************************************/

#include <CONFIG_RisingPower.h>
#include <string.h>
#include "E2P_Data.h"
#include "SERV_CRC.h"
#include "SERV_Calibration.h"


/****************************************************************************
	Private parameter definition 
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/ 

/****************************************************************************
	Private variable declaration
****************************************************************************/

sCalibrationHandler_t tsCalibrationHandler;

sCaliCoeff_t ptsCaliCoeff[eCalibration_Tag_Num];


/**
 *  @brief  Get calibration coefficient check sum
 *  @param  eTag: Which coefficient attempted to get check sum
 *  @retval check sum of CRC8
 */
static u16_t Calibration_GetChcekSum(u16_t u16Slope, u16_t u16Offset)
{
	u16_t i;
	u8_t u8CaliCrc8 = 0xFF;
	u8_t u8CheckData[4];

	__WordToLByte(&u8CheckData[0], u16Slope);
	__WordToLByte(&u8CheckData[2], u16Offset);
    
    for (i=0; i<4; i++)
    {
        CalCRC8(&u8CaliCrc8, u8CheckData[i]);
    }

	return (u16_t)u8CaliCrc8;
}

/**
 *  @brief  Check EEPROM calibration coefficient is valid or not
 *  @retval response pass of fail
 */
u16_t Calibration_IsValidCoefficient(void)
{
	u16_t u16Response = RequestAccepted;
	u16_t u16CheckSum_VS1, u16CheckSum_VS2, u16CheckSum_VPFC, u16CheckSum_IAC, u16CheckSum_VBULK;

	u16CheckSum_VS1 = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVS1_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVS1_Offset]);
	u16CheckSum_VS2 = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVS2_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVS2_Offset]);
	u16CheckSum_VPFC = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Offset]);
	u16CheckSum_IAC = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliIAC_Slope], pu16E2pDataInRam[E2pDataIndex_CaliIAC_Offset]);
	u16CheckSum_VBULK = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Offset]);

	if (pu16E2pDataInRam[E2pDataIndex_CaliVS1_Password] != u16CheckSum_VS1)
	{
		u16Response = RequestFailed;
	}

	if (pu16E2pDataInRam[E2pDataIndex_CaliVS2_Password] != u16CheckSum_VS2)
	{
		u16Response = RequestFailed;
	}

	if (pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Password] != u16CheckSum_VPFC)
	{
		u16Response = RequestFailed;
	}

	if (pu16E2pDataInRam[E2pDataIndex_CaliIAC_Password] != u16CheckSum_IAC)
	{
		u16Response = RequestFailed;
	}

	if (pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Password] != u16CheckSum_VBULK)
	{
		u16Response = RequestFailed;
	}

	return u16Response;
}


/**
 *  @brief  Reset calibration coefficient
 *  @param  eTag: Which coefficient attempted to reset
 *  @retval None
 */
void Calibration_ResetCoefficient(eCalibrationTag_t eTag)
{
    switch (eTag)
    {
        case eCalibration_Tag_VS1:
        case eCalibration_Tag_VS2:
            ptsCaliCoeff[eTag].i32HwGain = V_ACATS_FS;
            ptsCaliCoeff[eTag].u16Slope = 4096;
            ptsCaliCoeff[eTag].i16Offset = 0;
			ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain;
            break;
			
		case eCalibration_Tag_VPFC:
            ptsCaliCoeff[eTag].i32HwGain = V_ACPFC_FS;
            ptsCaliCoeff[eTag].u16Slope = 4096;
            ptsCaliCoeff[eTag].i16Offset = 0;
			ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain;
            break;
			
        case eCalibration_Tag_VAuxiliary:
            ptsCaliCoeff[eTag].i32HwGain = V_AUX_FS;
            ptsCaliCoeff[eTag].u16Slope = 4096;
            ptsCaliCoeff[eTag].i16Offset = 0;
			ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain;
            break;

        case eCalibration_Tag_VBus:
            ptsCaliCoeff[eTag].i32HwGain = V_BUS_FS;
            ptsCaliCoeff[eTag].u16Slope = 4096;
			ptsCaliCoeff[eTag].i16Offset = 0;
			ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain;
            break;

        case eCalibration_Tag_Current:
            ptsCaliCoeff[eTag].i32HwGain = I_AC_FS;
            ptsCaliCoeff[eTag].u16Slope = 4096;
            ptsCaliCoeff[eTag].i16Offset = 0;
			ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain;
            break;

        default:
            break;
    }
}


/**
 *  @brief  Store calibration coefficient to EEPROM
 *  @param  eTag: Which coefficient attempted to store
 *  @retval None
 */
void Calibration_StoreCoefficient(eCalibrationTag_t eTag)
{
	u16_t u16Slope = ptsCaliCoeff[eTag].u16Slope;
	u16_t u16Offset = (u16_t)ptsCaliCoeff[eTag].i16Offset;	
	u16_t u16CheckSum = Calibration_GetChcekSum(u16Slope, u16Offset);

    switch (eTag)
    {
        case eCalibration_Tag_VS1:
            E2pData_PushData(E2pDataIndex_CaliVS1_Slope, u16Slope);
            E2pData_PushData(E2pDataIndex_CaliVS1_Offset, u16Offset);
            E2pData_PushData(E2pDataIndex_CaliVS1_Password, u16CheckSum);
            break;

        case eCalibration_Tag_VS2:
            E2pData_PushData(E2pDataIndex_CaliVS2_Slope, u16Slope);
            E2pData_PushData(E2pDataIndex_CaliVS2_Offset, u16Offset);
            E2pData_PushData(E2pDataIndex_CaliVS2_Password, u16CheckSum);
            break;

		case eCalibration_Tag_VPFC:
            E2pData_PushData(E2pDataIndex_CaliVPFC_Slope, u16Slope);
            E2pData_PushData(E2pDataIndex_CaliVPFC_Offset, u16Offset);
            E2pData_PushData(E2pDataIndex_CaliVPFC_Password, u16CheckSum);
            break;
			
        case eCalibration_Tag_Current:
            E2pData_PushData(E2pDataIndex_CaliIAC_Slope, u16Slope);
            E2pData_PushData(E2pDataIndex_CaliIAC_Offset, u16Offset);
            E2pData_PushData(E2pDataIndex_CaliIAC_Password, u16CheckSum);
            break;

		case eCalibration_Tag_VBus:
            E2pData_PushData(E2pDataIndex_CaliVBulk_Slope, u16Slope);
            E2pData_PushData(E2pDataIndex_CaliVBulk_Offset, u16Offset);
            E2pData_PushData(E2pDataIndex_CaliVBulk_Password, u16CheckSum);
            break;

        default:
            break;
    }
}

/**
 *  @brief  Restore calibration coefficient from EEPROM
 *  @param  eTag: Which coefficient attempted to restore
 *  @retval None
 */
static void Calibration_RestoreCoefficient(eCalibrationTag_t eTag)
{
	u16_t u16CheckSum;
	
    switch (eTag)
    {
        case eCalibration_Tag_VS1:

			u16CheckSum = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVS1_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVS1_Offset]);
			
			if (pu16E2pDataInRam[E2pDataIndex_CaliVS1_Password] == u16CheckSum)
            {
                ptsCaliCoeff[eTag].u16Slope = pu16E2pDataInRam[E2pDataIndex_CaliVS1_Slope];
                ptsCaliCoeff[eTag].i16Offset = pu16E2pDataInRam[E2pDataIndex_CaliVS1_Offset];
                ptsCaliCoeff[eTag].i32HwGain = V_ACATS_FS;
				ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain * ((f32_t)ptsCaliCoeff[eTag].u16Slope / (f32_t)CALI_SLOPE_GAIN);
            }
            else
            {
                Calibration_ResetCoefficient(eTag);
            }
            break;

        case eCalibration_Tag_VS2:

			u16CheckSum = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVS2_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVS2_Offset]);

			if (pu16E2pDataInRam[E2pDataIndex_CaliVS2_Password] == u16CheckSum)
            {
                ptsCaliCoeff[eTag].u16Slope = pu16E2pDataInRam[E2pDataIndex_CaliVS2_Slope];
                ptsCaliCoeff[eTag].i16Offset = pu16E2pDataInRam[E2pDataIndex_CaliVS2_Offset];
                ptsCaliCoeff[eTag].i32HwGain = V_ACATS_FS;
				ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain * ((f32_t)ptsCaliCoeff[eTag].u16Slope / (f32_t)CALI_SLOPE_GAIN);
            }
            else
            {
                Calibration_ResetCoefficient(eTag);
            }
            break;

		case eCalibration_Tag_VPFC:

			u16CheckSum = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Offset]);

			if (pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Password] == u16CheckSum)
            {
                ptsCaliCoeff[eTag].u16Slope = pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Slope];
                ptsCaliCoeff[eTag].i16Offset = pu16E2pDataInRam[E2pDataIndex_CaliVPFC_Offset];
                ptsCaliCoeff[eTag].i32HwGain = V_ACPFC_FS;
				ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain * ((f32_t)ptsCaliCoeff[eTag].u16Slope / (f32_t)CALI_SLOPE_GAIN);
            }
            else
            {
                Calibration_ResetCoefficient(eTag);
            }
            break;

        case eCalibration_Tag_Current:

			u16CheckSum = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliIAC_Slope], pu16E2pDataInRam[E2pDataIndex_CaliIAC_Offset]);

			if (pu16E2pDataInRam[E2pDataIndex_CaliIAC_Password] == u16CheckSum)
            {
                ptsCaliCoeff[eTag].u16Slope = pu16E2pDataInRam[E2pDataIndex_CaliIAC_Slope];
                ptsCaliCoeff[eTag].i16Offset = pu16E2pDataInRam[E2pDataIndex_CaliIAC_Offset];
                ptsCaliCoeff[eTag].i32HwGain = I_AC_FS;
				ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain * ((f32_t)ptsCaliCoeff[eTag].u16Slope / (f32_t)CALI_SLOPE_GAIN);
            }
            else
            {
                Calibration_ResetCoefficient(eTag);
            }
            break;

		case eCalibration_Tag_VBus:

			u16CheckSum = Calibration_GetChcekSum(pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Slope], pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Offset]);

			if (pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Password] == u16CheckSum)
            {
                ptsCaliCoeff[eTag].u16Slope = pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Slope];
                ptsCaliCoeff[eTag].i16Offset = pu16E2pDataInRam[E2pDataIndex_CaliVBulk_Offset];
                ptsCaliCoeff[eTag].i32HwGain = V_BUS_FS;
				ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain * ((f32_t)ptsCaliCoeff[eTag].u16Slope / (f32_t)CALI_SLOPE_GAIN);
            }
            else
            {
                Calibration_ResetCoefficient(eTag);
            }
            break;

        default:
            break;
    }
}

/**
 *  @brief  Set calibration Coefficient
 *  @param  eTag: Which coefficient attempted to set
 *  @param  u16Slope: Slope
 *  @param  i16Offset: Offset
 *  @retval None
 */
void Calibration_SetCoefficient(eCalibrationTag_t eTag, u16_t u16Slope, i16_t i16Offset)
{
    ptsCaliCoeff[eTag].u16Slope = u16Slope;
	ptsCaliCoeff[eTag].i16Offset = i16Offset;
	ptsCaliCoeff[eTag].f32CaliGain = (f32_t)ptsCaliCoeff[eTag].i32HwGain * ((f32_t)ptsCaliCoeff[eTag].u16Slope / (f32_t)CALI_SLOPE_GAIN);
}

/**
 *  @brief  retrieve calibration coefficient from EEPROM and return it back
 *  @param  eTag: Which coefficient attempted to retrieve
 *  @retval Requested calibration coefficient
 */
sCaliCoeff_t* Calibration_GetCoefficient(eCalibrationTag_t eTag)
{
    return &ptsCaliCoeff[eTag];
}

/**
 *  @brief  Is manufacturer key valid
 *  @param  pu8Key: Pointer to start byte of inquiry manufacturer key
 *  @retval FALSE: The key is invalid
 *  @retval TRUE: The key is valid
 */
u16_t Calibration_IsValidManufacturerKey(u8_t* pu8Key)
{
    if (strncmp((const char*)pu8Key, CALIBRATION_KEY, CALIBRATION_KEY_LENGTH) == 0)
    {
    	tsCalibrationHandler.u8CalibrationkeyOK = 1;
        return TRUE;
    }
    else
    {
    	tsCalibrationHandler.u8CalibrationkeyOK = 0;
        return FALSE;
    }
}

/**
 *  @brief  Initial calibration handler
 *  @retval None
 */
void Calibration_Initialize(void)
{
	u16_t i;
	
    memset(&tsCalibrationHandler, 0, sizeof(tsCalibrationHandler));	

	for (i=0; i<eCalibration_Tag_Num; i++)
    {
        memset(&ptsCaliCoeff[i], 0, sizeof(ptsCaliCoeff[i]));
    }

    /* Restore coefficient from EEPROM */
    Calibration_RestoreCoefficient(eCalibration_Tag_VS1);
    Calibration_RestoreCoefficient(eCalibration_Tag_VS2);
	Calibration_RestoreCoefficient(eCalibration_Tag_VPFC);
    Calibration_RestoreCoefficient(eCalibration_Tag_Current);
	Calibration_RestoreCoefficient(eCalibration_Tag_VBus);
	
    /* Set other coefficient to default value */
    Calibration_ResetCoefficient(eCalibration_Tag_VAuxiliary);

}
