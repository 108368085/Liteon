/****************************************************************************
 *	File	SERV_Threshold.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/29 - 1st release
 ****************************************************************************/

#ifndef _SERV_THRESHOLD_H_
#define _SERV_THRESHOLD_H_

#include "CONFIG_Define.h"

/****************************************************************************
*	Public parameter definition
****************************************************************************/

/****************************************************************************
*	Public macro definition
****************************************************************************/

/****************************************************************************
*	Public enumeration definition 
****************************************************************************/

typedef enum
{
	TriggerDisable,     // disable mode, when MCU start
	TriggerLatch,       // latch mode
	TriggerAutoRecover, // auto recover mode
}eTriggerType_t;

typedef enum
{
	Limit_Upper,     	// Upper limit
	Limit_Lower,       	// Lower limit
}eLimitType_t;



/****************************************************************************
*	Public structure definition 
****************************************************************************/

/* Single Threshold - Upper limit
 *
 * Bit Set
 * _____________ Set Threshold
 *
 * ------------- Clear Threshold
 * Bit Clear
 *
 *
 * Single Threshold - Lower limit
 *
 * Bit Clear
 * ------------- Clear Threshold
 *
 * _____________ Set Threshold
 * Bit Set
 *
 */

typedef struct
{
	u16_t u16SetDelay;
	u16_t u16ClearDelay;
}sThresholdDelay_t;


typedef struct
{
	eTriggerType_t eTriggerType;
	eLimitType_t eLimitType;
	u16_t u16SetBits;
	i16_t i16SetThreshold;
	i16_t i16ClearThreshold;	
	sThresholdDelay_t sConst;
	sThresholdDelay_t sVar;
}sSingleThreshold_t;

/* For Iin OCP used */
typedef struct
{
    eTriggerType_t eTriggerType;
    eLimitType_t eLimitType;
    u16_t u16SetBits;
    u16_t u16SetThreshold;
    u16_t u16ClearThreshold;
    sThresholdDelay_t sConst;
    sThresholdDelay_t sVar;
}sThreshold_t;



/* Between Threshold
 *
 * Bit Clear
 * ------------- ClearThresholdHigh
 * _____________ SetThresholdHigh
 * BitSet
 * _____________ SetThresholdLow
 * ------------- ClearThresholdLow
 * Bit Clear
 *
 */

typedef struct
{
	eTriggerType_t eTriggerType;
	i16_t i16ClearThresholdHigh;
	i16_t i16ClearThresholdLow;
	i16_t i16SetThresholdHigh;
	i16_t i16SetThresholdLow;
	sThresholdDelay_t sConst;
	sThresholdDelay_t sVar;
}sBetweenThreshold_t;



/* Dual Threshold
 *
 * Protection Bit Set
 * _____________ Protection Threshold
 * Warning Bit Set
 * _____________ Warning Threshold
 * ------------- Recover Threshold
 * Both Bits Clear (or only warning bit clear)
 *
 */

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u2WarningEnable	: 2;
		u16_t u2ProtectEnable	: 2;
		u16_t u12Reserved		: 12;
	}u16Bits;
}nDualThresholdTrigger_t;

typedef struct
{
	u16_t u16ProtectDelay;
	u16_t u16WarningDelay;
	u16_t u16RecoverDelay;
}sDualThresholdDelay_t;

typedef struct
{
	nDualThresholdTrigger_t nTriggerType;
	i16_t i16ProtectThreshold;
	i16_t i16WarningThreshold;
	i16_t i16RecoverThreshold;
	sDualThresholdDelay_t sConst;
	sDualThresholdDelay_t sVar;
}sDualThreshold_t;



/* Triple Threshold
 *
 * Protection Bit Set
 * _____________ Protection fast Threshold
 * Protection Bit Set
 * _____________ Protection slow Threshold
 * Warning Bit Set
 * _____________ Warning Threshold
 * ------------- Recover Threshold
 * Both Bits Clear (or only warning bit clear)
 *
 */

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u2WarningEnable	: 2;
		u16_t u2ProtectEnable	: 2;
		u16_t u12Reserved		: 12;
	}u16Bits;
}ntripleThresholdTrigger_t;

typedef struct
{
	u16_t u16ProtectFastDelay;
    u16_t u16ProtectSlowDelay;
	u16_t u16WarningDelay;
	u16_t u16RecoverDelay;
}stripleThresholdDelay_t;

typedef struct
{
	ntripleThresholdTrigger_t nTriggerType;
	i16_t i16ProtectFastThreshold;
    i16_t i16ProtectSlowThreshold;
	i16_t i16WarningThreshold;
	i16_t i16RecoverThreshold;
	stripleThresholdDelay_t sConst;
	stripleThresholdDelay_t sVar;
}stripleThreshold_t;


/****************************************************************************
*	Public export variable
****************************************************************************/

/****************************************************************************
*	Public export function prototype
****************************************************************************/

extern void Single_Threshold(sSingleThreshold_t *psConfig, i16_t i16Value, u16_t *u16Flag);
extern void Threshold(sThreshold_t *psConfig, i16_t i16Value, u16_t *u16Flag);


#endif
