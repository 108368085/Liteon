/** @file       E2P_BlackBox.c
 *  @note       Recorder Procedure
 *              1. External application invoke "BlackBox StartRecord" process to start recording
 *              2. In the "BlackBox_Record" process:
 *                  2.a Fetch value of each Black Box items from its assigned source
 *                  2.b Invoke "Waveform_Record" to start recording and callback "BlackBox_WaveformPublishCallback" process 
 *                      after waveform recording accomplished
 *              3. In the "BlackBox_WaveformPublishCallback" process, 
 *                  process will assert "Awaiting" flag to notify "BlackBox_Background_Process" to start storing data into EEPROM
 *              4. In the "BlackBox_Background_Process", process will push data into EEPROM
 *
 *  @note       Publisher Procedure
 *              1. Select blackbox page: the Process will check inquiry event index is exist or not
 *              2. BlackBox Read Start : Select which block want to read
 *              3. BlackBox Read Data : MCU start retrieve 64 bytes data from EEPROM, and publish to system                  
 *  @author     Adonis Wang
 *  @brief      Black Box
 *  @version    2.0
 *  @date       2017-10-25 1.0 create by ollie
 */
 
#include "E2P_BlackBox.h"
#include "E2P_Data.h"
#include "SERV_LOG.h"
#include "SERV_CRC.h"
#include "CANBus_Data.h"
#include "CANBus_Server.h"
#include "Peripheral.h"
#include <string.h>


/****************************************************************************
	Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/
#define BLACK_BOX_EEPROM_DRIVER_FAILURE_RETRY_TIMES         3

#define WAVEFORM_CAPTURE_PAGE         						0xFF


/****************************************************************************
	Private enumeration definition
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 926 -> 57

#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(BlackBox_StoreBlackBoxIndex, ".TI.ramfunc");
#pragma CODE_SECTION(BlackBox_Waveform_Callback, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_StartRecord, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_IsTargetEventExist, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_Read_Start, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_Read_Data, ".TI.ramfunc");
//#pragma CODE_SECTION(Waveform_Read_Start, ".TI.ramfunc");
//#pragma CODE_SECTION(Waveform_0XFF_Publish_Data, ".TI.ramfunc");
//#pragma CODE_SECTION(Waveform_Read_Data, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_Publish_Data, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_GetEventLocateAddress, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_RetrieveEvent, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_Background_Process, ".TI.ramfunc");
//#pragma CODE_SECTION(BlackBox_1min_Periodically_Process, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declare
****************************************************************************/

sBlackBoxHandler_t tsBlackBoxHandler;

sBlackBoxItem_t ptsBlackBoxItem[eBLACKBOX_ITEM_NUM] =
{
//  Tag,                                    Address,                                Size,                                   Source
	{eBLACKBOX_ITEM_BMC_UNIX_TIMESTAMP,		BLACKBOX_ADDR_BMC_UNIX_TIMESTAMP,		BLACKBOX_SIZE_BMC_UNIX_TIMESTAMP,		NULL},
	{eBLACKBOX_ITEM_STATUS_WORD,			BLACKBOX_ADDR_STATUS_WORD,				BLACKBOX_SIZE_STATUS_WORD,				NULL},
    {eBLACKBOX_ITEM_STATUS_TRANSFER,		BLACKBOX_ADDR_STATUS_TRANSFER,			BLACKBOX_SIZE_STATUS_TRANSFER,			NULL},
    {eBLACKBOX_ITEM_STATUS_ATS_SOURCE,		BLACKBOX_ADDR_STATUS_ATS_SOURCE,		BLACKBOX_SIZE_STATUS_ATS_SOURCE,		NULL},
	{eBLACKBOX_ITEM_STATUS_RELAY_S1,		BLACKBOX_ADDR_STATUS_RELAY_S1,			BLACKBOX_SIZE_STATUS_RELAY_S1,			NULL},
    {eBLACKBOX_ITEM_STATUS_RELAY_S2,		BLACKBOX_ADDR_STATUS_RELAY_S2,			BLACKBOX_SIZE_STATUS_RELAY_S2,			NULL},
    {eBLACKBOX_ITEM_STATUS_RELAY_PFC,		BLACKBOX_ADDR_STATUS_RELAY_PFC,			BLACKBOX_SIZE_STATUS_RELAY_PFC,			NULL},
	{eBLACKBOX_ITEM_STATUS_TEMP,			BLACKBOX_ADDR_STATUS_TEMP,				BLACKBOX_SIZE_STATUS_TEMP,				NULL},
    {eBLACKBOX_ITEM_STATUS_OTHER,			BLACKBOX_ADDR_STATUS_OTHER,				BLACKBOX_SIZE_STATUS_OTHER,				NULL},
    {eBLACKBOX_ITEM_STATUS_LED,				BLACKBOX_ADDR_STATUS_LED,				BLACKBOX_SIZE_STATUS_LED,				NULL},
    {eBLACKBOX_ITEM_STATUS_BOOTLOADER,		BLACKBOX_ADDR_STATUS_BOOTLOADER,		BLACKBOX_SIZE_STATUS_BOOTLOADER,		NULL},
    {eBLACKBOX_ITEM_READ_VS1,				BLACKBOX_ADDR_READ_VS1,					BLACKBOX_SIZE_READ_VS1,					NULL},
	{eBLACKBOX_ITEM_READ_VS2,				BLACKBOX_ADDR_READ_VS2,					BLACKBOX_SIZE_READ_VS2,					NULL},
	{eBLACKBOX_ITEM_READ_VAC,				BLACKBOX_ADDR_READ_VAC,					BLACKBOX_SIZE_READ_VAC,					NULL},
	{eBLACKBOX_ITEM_READ_IAC,				BLACKBOX_ADDR_READ_IAC,					BLACKBOX_SIZE_READ_IAC,					NULL},
    {eBLACKBOX_ITEM_READ_FS1,				BLACKBOX_ADDR_READ_FS1,					BLACKBOX_SIZE_READ_FS1,					NULL},
    {eBLACKBOX_ITEM_READ_FS2,				BLACKBOX_ADDR_READ_FS2,					BLACKBOX_SIZE_READ_FS2,					NULL},
    {eBLACKBOX_ITEM_READ_PS1,				BLACKBOX_ADDR_READ_PS1,					BLACKBOX_SIZE_READ_PS1,					NULL},
    {eBLACKBOX_ITEM_READ_PS2,				BLACKBOX_ADDR_READ_PS2,					BLACKBOX_SIZE_READ_PS2,					NULL},
    {eBLACKBOX_ITEM_READ_MAXPS1,			BLACKBOX_ADDR_READ_MAXPS1,				BLACKBOX_SIZE_READ_MAXPS1,				NULL},
    {eBLACKBOX_ITEM_READ_MAXPS2,			BLACKBOX_ADDR_READ_MAXPS2,				BLACKBOX_SIZE_READ_MAXPS2,				NULL},
    {eBLACKBOX_ITEM_READ_AVGPS1,			BLACKBOX_ADDR_READ_AVGPS1,				BLACKBOX_SIZE_READ_AVGPS1,				NULL},
    {eBLACKBOX_ITEM_READ_AVGPS2,			BLACKBOX_ADDR_READ_AVGPS2,				BLACKBOX_SIZE_READ_AVGPS2,				NULL},
    {eBLACKBOX_ITEM_READ_TINLET,			BLACKBOX_ADDR_READ_TINLET,				BLACKBOX_SIZE_READ_TINLET,				NULL},
    {eBLACKBOX_ITEM_READ_TATS,				BLACKBOX_ADDR_READ_TATS,				BLACKBOX_SIZE_READ_TATS,				NULL},
    {eBLACKBOX_ITEM_READ_SWITCH_TIMES,		BLACKBOX_ADDR_READ_SWITCH_TIMES,		BLACKBOX_SIZE_READ_SWITCH_TIMES,		NULL},
    {eBLACKBOX_ITEM_READ_TOTAL_SWITCH_TIMES,BLACKBOX_ADDR_READ_TOTAL_SWITCH_TIMES,	BLACKBOX_SIZE_READ_TOTAL_SWITCH_TIMES,	NULL},
    {eBLACKBOX_ITEM_READ_VS1_HARMONIC,		BLACKBOX_ADDR_READ_VS1_HARMONIC,		BLACKBOX_SIZE_READ_VS1_HARMONIC,		NULL},
    {eBLACKBOX_ITEM_READ_VS2_HARMONIC,		BLACKBOX_ADDR_READ_VS2_HARMONIC,		BLACKBOX_SIZE_READ_VS2_HARMONIC,		NULL},
	{eBLACKBOX_ITEM_READ_BBU_COUNT, 		BLACKBOX_ADDR_READ_BBU_COUNT,			BLACKBOX_SIZE_READ_BBU_COUNT,			NULL},
	{eBLACKBOX_ITEM_READ_VAUX1,				BLACKBOX_ADDR_READ_VAUX1,				BLACKBOX_SIZE_READ_VAUX1,				NULL},
    {eBLACKBOX_ITEM_READ_VAUX2,				BLACKBOX_ADDR_READ_VAUX2,				BLACKBOX_SIZE_READ_VAUX2,				NULL},
    {eBLACKBOX_ITEM_READ_IAUX1,				BLACKBOX_ADDR_READ_IAUX1,				BLACKBOX_SIZE_READ_IAUX1,				NULL},
    {eBLACKBOX_ITEM_READ_IAUX2,				BLACKBOX_ADDR_READ_IAUX2,				BLACKBOX_SIZE_READ_IAUX2,				NULL},
	{eBLACKBOX_ITEM_MAJOR_REVISION,			BLACKBOX_ADDR_MAJOR_REVISION,			BLACKBOX_SIZE_MAJOR_REVISION,			NULL},
    {eBLACKBOX_ITEM_MINOR_REVISION,			BLACKBOX_ADDR_MINOR_REVISION,			BLACKBOX_SIZE_MINOR_REVISION,			NULL},
	{eBLACKBOX_ITEM_ATS_PRI_SRC,			BLACKBOX_ADDR_ATS_PRI_SRC,				BLACKBOX_SIZE_ATS_PRI_SRC,				NULL},
    {eBLACKBOX_ITEM_SINGLE_FEED_MODE,		BLACKBOX_ADDR_SINGLE_FEED_MODE,			BLACKBOX_SIZE_SINGLE_FEED_MODE,			NULL},
    {eBLACKBOX_ITEM_OBSERVE_WINDOW,			BLACKBOX_ADDR_OBSERVE_WINDOW,			BLACKBOX_SIZE_OBSERVE_WINDOW,			NULL},
    {eBLACKBOX_ITEM_OUTAGE_DELAY,			BLACKBOX_ADDR_OUTAGE_DELAY,				BLACKBOX_SIZE_OUTAGE_DELAY,				NULL},
    {eBLACKBOX_ITEM_WALKIN_LOW,				BLACKBOX_ADDR_WALKIN_LOW,				BLACKBOX_SIZE_WALKIN_LOW,				NULL},
    {eBLACKBOX_ITEM_WALKIN_HIGH,			BLACKBOX_ADDR_WALKIN_HIGH,				BLACKBOX_SIZE_WALKIN_HIGH,				NULL},
    {eBLACKBOX_ITEM_STABILIZATION_DELAY,	BLACKBOX_ADDR_STABILIZATION_DELAY,		BLACKBOX_SIZE_STABILIZATION_DELAY,		NULL},
    {eBLACKBOX_ITEM_BLACKBOX_PAGE,			BLACKBOX_ADDR_BLACKBOX_PAGE,			BLACKBOX_SIZE_BLACKBOX_PAGE,			NULL},
    {eBLACKBOX_ITEM_BLACKBOX_RESERVED,		BLACKBOX_ADDR_BLACKBOX_RESERVED,		BLACKBOX_SIZE_BLACKBOX_RESERVED,		NULL},
    {eBLACKBOX_ITEM_WAVEFORM_LOG,			BLACKBOX_ADDR_WAVEFORM_LOG,				BLACKBOX_SIZE_WAVEFORM_LOG,				NULL},
};



/**
 *  @brief  Only Record SENSOR_DATA and Variable value
 *  @retval None
 */
static inline void BlackBox_Status_Record()
{ 
	u16_t i;

    /* Update value immediately */
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_VS1]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_VS2]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_VAC]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_FS1]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_FS2]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_PS1]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_PS2]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_AVGPS1]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_AVGPS2]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_Read_VS1_Harmonic]);
    LiteralMonitor_Update(&ptsLiteralMonitor[eCANBusData_LM_Read_VS2_Harmonic]);

	for (i=0; i<eBLACKBOX_ITEM_NUM; i++)
	{
		if (ptsBlackBoxItem[i].u16Size == 1)
		{
			memcpy(&tsBlackBoxHandler.sRecorder.pu8Data[ptsBlackBoxItem[i].u16Address], ptsBlackBoxItem[i].pu8Source, ptsBlackBoxItem[i].u16Size);
		}
		else if (ptsBlackBoxItem[i].u16Size == 2)
		{
			__WordToLByte(&tsBlackBoxHandler.sRecorder.pu8Data[ptsBlackBoxItem[i].u16Address], *((u16_t*)ptsBlackBoxItem[i].pu8Source));
		}
		else if (ptsBlackBoxItem[i].u16Size == 4)
		{
			__DWordToLByte(&tsBlackBoxHandler.sRecorder.pu8Data[ptsBlackBoxItem[i].u16Address], *((u32_t*)ptsBlackBoxItem[i].pu8Source));
		}
	}
}

/**
 *  @brief  record Waveform data finished callback
 *  @Note	
 */
void BlackBox_Waveform_Callback(void)
{
	BlackBox_Status_Record();
	
    tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Recording = 0;
	tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Awaiting = 1;
	tsBlackBoxHandler.sRecorder.u16StoredBytes = 0;
}

/**
 *  @brief  Store Blackbox index into EEPROM
 *  @note   Store index before store data. it can be keep latest data when PSU shut down during store data.
 *  @retval None
 */
static inline void BlackBox_StoreBlackBoxIndex(void)
{
	tsBlackBoxHandler.i16LatestSectionIndex += 1;
        
    if (tsBlackBoxHandler.i16LatestSectionIndex == MAXIMUM_BLACK_BOX_EVENT_NUMBER)
    {
        tsBlackBoxHandler.i16LatestSectionIndex = 0;
    }
    
    // Push Latest Section index to EEPROM
    if (pu16E2pDataInRam[E2pDataIndex_Manufacture_Password] == AcceptPassword)
    {
        E2pData_PushData(E2pDataIndex_BlackBox_LatestIndex, tsBlackBoxHandler.i16LatestSectionIndex);
    }
        
    if (tsBlackBoxHandler.u16RecordedEventNumber < MAXIMUM_BLACK_BOX_EVENT_NUMBER)
    {
        tsBlackBoxHandler.u16RecordedEventNumber += 1;

		if (pu16E2pDataInRam[E2pDataIndex_Manufacture_Password] == AcceptPassword)
        {
            E2pData_PushData(E2pDataIndex_BlackBox_EventNumber, tsBlackBoxHandler.u16RecordedEventNumber);
        }
    }
}

/**
 *  @brief  Start record blackbox while receive trigger blackbox event
 *  @note   clear data and copy data need 1.9ms , call back form SERV_Log.c
 *  @retval None
 */
void BlackBox_StartRecord(void)
{
    // All bits except Bit "u1Enable" should be zero, that indicated we only begin a new recording process after previous event finished storing
    if (tsBlackBoxHandler.sRecorder.nFlag.u16All == 0)
    {
        tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Recording = 1;       

		// Notify waveform to start recording
        Waveform_Record();

		BlackBox_StoreBlackBoxIndex();
    }
}

/**
 *  @brief  Store recored data into EEPROM
 *  @note   
 *  @retval None
 */
static inline void BlackBox_Store_Event(void)
{
    u32_t u32Address;
	u32_t u32LatestIndex;
  
    // All record data had been stored into EEPROM, terminate store progress
    if (tsBlackBoxHandler.sRecorder.u16StoredBytes == BLACKBOX_DATA_SIZE)
    {
        tsBlackBoxHandler.sRecorder.u16StoredBytes = 0;
    }
    else
    {
    	u32LatestIndex = tsBlackBoxHandler.i16LatestSectionIndex;
			
        // Get Section start address
        u32Address = BLACK_BOX_STORE_ADDRESS_OFFSET + (u32LatestIndex * BLACKBOX_EVENT_SIZE);

        // Add data offset
        u32Address += tsBlackBoxHandler.sRecorder.u16StoredBytes;
        
        // If rest length is more than a page size, write a page size of data
        if ((BLACKBOX_DATA_SIZE - tsBlackBoxHandler.sRecorder.u16StoredBytes) > tsBlackBoxHandler.psE2pDriver->u16PageSize)
        {
            tsBlackBoxHandler.sRecorder.u16PushingBytes = tsBlackBoxHandler.psE2pDriver->u16PageSize;
        }
        else
        {
            tsBlackBoxHandler.sRecorder.u16PushingBytes = (BLACKBOX_DATA_SIZE - tsBlackBoxHandler.sRecorder.u16StoredBytes);
        }
        
        // Write to EEPROM
        tsBlackBoxHandler.psE2pDriver->pfMemoryWrite(tsBlackBoxHandler.psE2pDriver, u32Address, tsBlackBoxHandler.sRecorder.u16PushingBytes, &tsBlackBoxHandler.sRecorder.pu8Data[tsBlackBoxHandler.sRecorder.u16StoredBytes]);
        tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Storing = 1;
    }
}

/**
 *  @brief  Inquiry taget event is exist or not
 *  @param  u16EventIndex: Event index which is attempted to inquiry
 *  @retval FALSE: Target event is not exist
 *  @retval TRUE: Target event is exist
 */
u16_t BlackBox_IsTargetEventExist(u16_t u16EventIndex)
{
    if ((tsBlackBoxHandler.u16RecordedEventNumber == 0) ||
        (u16EventIndex > (tsBlackBoxHandler.u16RecordedEventNumber - 1)) ||
        (u16EventIndex >= MAXIMUM_BLACK_BOX_EVENT_NUMBER))
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

/**
 *  @brief  Record the current page for CANbus reporting
 *  @Note   Execute once when receiving the requirement of the first block data
 */
void BlackBox_UpdateReportBaseIndex(void)
{
    tsBlackBoxHandler.i16ReportBaseIndex = tsBlackBoxHandler.i16LatestSectionIndex;
}

/**
 *  @brief  BlackBox Read Start callback from Canbus
 *  @Note	Check Block Sequence Number and response ACK/NACK
 */
void BlackBox_Read_Start(void)
{
	u32_t u32Respone = (tsBlackBoxHandler.sPublisher.u32BlackBox_Byte_of_LastBlock << 24) + (tsBlackBoxHandler.sPublisher.u32BlackBox_Max_Block_Number << 8);
	
	if ((tsBlackBoxHandler.sPublisher.u16BlackBox_Read_Block_Sequence > tsBlackBoxHandler.sPublisher.u32BlackBox_Max_Block_Number) ||
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData) ||
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData) ||
        (tsBlackBoxHandler.i16ReportBaseIndex != tsBlackBoxHandler.i16LatestSectionIndex))
	{
		// NACK
		tsBlackBoxHandler.sPublisher.u32BlackBox_Response_Read_Start = u32Respone | 0x01;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadStart = 0;
	}
	else
	{
		// ACK
		tsBlackBoxHandler.sPublisher.u32BlackBox_Response_Read_Start = u32Respone;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadStart = 1;
	}
}

/**
 *  @brief  BlackBox Read Data callback from Canbus
 *  @Note	Start retrieve data from EEPROM
 */
void BlackBox_Read_Data(void)
{
	if ((tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadStart) &&
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData == 0) &&
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData == 0))
	{
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData = 1;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Failure = 0;
        tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Awaiting = 1;
		tsBlackBoxHandler.sPublisher.u16FailureRetryTimes = 0;
		tsBlackBoxHandler.sPublisher.u8DataCRC8 = 0x00;
	}
}

/**
 *  @brief  Waveform Read Start callback from Canbus
 *  @Note	Check Block Sequence Number and response ACK/NACK
 */
void Waveform_Read_Start(void)
{
	u32_t u32Respone = (tsBlackBoxHandler.sPublisher.u32Waveform_Byte_of_LastBlock << 24) + (tsBlackBoxHandler.sPublisher.u32Waveform_Max_Block_Number << 8);

	if ((tsBlackBoxHandler.sPublisher.u16Waveform_Read_Block_Sequence > tsBlackBoxHandler.sPublisher.u32Waveform_Max_Block_Number) ||
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData) ||
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData) ||
        (tsBlackBoxHandler.i16ReportBaseIndex != tsBlackBoxHandler.i16LatestSectionIndex))
	{
		// NACK
		tsBlackBoxHandler.sPublisher.u32Waveform_Response_Read_Start = u32Respone | 0x01;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart = 0;
	}
	else
	{
		if ((tsBlackBoxHandler.sPublisher.u8Waveform_Page == WAVEFORM_CAPTURE_PAGE) &&
			(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_Capture == 0))
		{
			// NACK
			tsBlackBoxHandler.sPublisher.u32Waveform_Response_Read_Start = u32Respone | 0x01;
			tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart = 0;
		}
		else
		{
			// ACK
			tsBlackBoxHandler.sPublisher.u32Waveform_Response_Read_Start = u32Respone;
			tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart = 1;
		}
	}
}

/**
 *  @brief  callback when retrieve Waveform Read Data
 *  @Note	Start publish data to CANbus
 */
static inline void Waveform_0XFF_Publish_Data(void)
{
	u16_t i, j;
	u16_t u16Publish_Byte_CNT = 0;	// max is 64
	u16_t u16Publish_Data_Byte = 0;	// max is 8
	u8_t *pu8Source;				// waveform capture address

	// fetch push bytes
	if (tsBlackBoxHandler.sPublisher.u16Waveform_Read_Block_Sequence == tsBlackBoxHandler.sPublisher.u32Waveform_Max_Block_Number)
	{
		u16Publish_Byte_CNT = tsBlackBoxHandler.sPublisher.u32Waveform_Byte_of_LastBlock;
	}
	else
	{
		u16Publish_Byte_CNT = E2P_BLACK_BOX_RETRIEVE_SIZE;
	}

	// Copy Waveform Capture data to retrieve data
	pu8Source = tsBlackBoxHandler.sRecorder.sWaveformRecorderConfig.pu8Destination;
	pu8Source += tsBlackBoxHandler.sPublisher.u16Waveform_Read_Block_Sequence * E2P_BLACK_BOX_RETRIEVE_SIZE;
	memcpy(tsBlackBoxHandler.sPublisher.pu8RetrieveData, pu8Source, u16Publish_Byte_CNT);

	// push data to can bus and record CRC8
	for (i=0; i < u16Publish_Byte_CNT; i+=E2P_BLACK_BOX_PUBLISH_SIZE)
	{
		if ((i + E2P_BLACK_BOX_PUBLISH_SIZE) > u16Publish_Byte_CNT)
		{
			u16Publish_Data_Byte = u16Publish_Byte_CNT - i;
		}
		else
		{
			u16Publish_Data_Byte = E2P_BLACK_BOX_PUBLISH_SIZE;
		}

		// Copy retrieve data to publish section
		memcpy(tsBlackBoxHandler.sPublisher.pu8PublishData, tsBlackBoxHandler.sPublisher.pu8RetrieveData + i, u16Publish_Data_Byte);

   		// CRC8
    	for (j=0; j < u16Publish_Data_Byte; j++)
    	{
        	CalCRC8(&tsBlackBoxHandler.sPublisher.u8DataCRC8, tsBlackBoxHandler.sPublisher.pu8PublishData[j]);
    	}

		// Push data to CAN
		CANBusData_Set_Waveform_Data_Length((u8_t)u16Publish_Data_Byte);
		CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_BLOCK_READ, CANBUS_CMD_WAVEFORM_READ_DATA, CAN_System_Address);
	}

	// Push CRC8 to CAN
	CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_BLOCK_READ, CANBUS_CMD_WAVEFORM_READ_STOP, CAN_System_Address);
	tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart = 0;
	tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData = 0;
}

/**
 *  @brief  Waveform Read Data callback from Canbus
 *  @Note	Start retrieve data from EEPROM
 */
void Waveform_Read_Data(void)
{
	if ((tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart) &&
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData == 0) &&
		(tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData == 0))
	{
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData = 1;
		tsBlackBoxHandler.sPublisher.u8DataCRC8 = 0x00;
		
		if (tsBlackBoxHandler.sPublisher.u8Waveform_Page == WAVEFORM_CAPTURE_PAGE)
		{
			Waveform_0XFF_Publish_Data();
		}
		else
		{
			tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Failure = 0;
        	tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Awaiting = 1;
			tsBlackBoxHandler.sPublisher.u16FailureRetryTimes = 0;
		}		
	}
}

/**
 *  @brief  callback when retrieve data finished
 *  @Note	Start publish data to CANbus
 */
static inline void BlackBox_Publish_Data(void)
{
	u16_t i, j;
	u16_t u16Publish_Byte_CNT = 0;
	u16_t u16Publish_Data_Byte = 0;

	// fetch push bytes
	if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData)
	{
		if (tsBlackBoxHandler.sPublisher.u16BlackBox_Read_Block_Sequence == tsBlackBoxHandler.sPublisher.u32BlackBox_Max_Block_Number)
		{
			u16Publish_Byte_CNT = tsBlackBoxHandler.sPublisher.u32BlackBox_Byte_of_LastBlock;
		}
		else
		{
			u16Publish_Byte_CNT = E2P_BLACK_BOX_RETRIEVE_SIZE;
		}
	}
	else if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData)
	{
		if (tsBlackBoxHandler.sPublisher.u16Waveform_Read_Block_Sequence == tsBlackBoxHandler.sPublisher.u32Waveform_Max_Block_Number)
		{
			u16Publish_Byte_CNT = tsBlackBoxHandler.sPublisher.u32Waveform_Byte_of_LastBlock;
		}
		else
		{
			u16Publish_Byte_CNT = E2P_BLACK_BOX_RETRIEVE_SIZE;
		}
	}

	// push data to can bus and record CRC8
	for (i=0; i < u16Publish_Byte_CNT; i+=E2P_BLACK_BOX_PUBLISH_SIZE)
	{
		if ((i + E2P_BLACK_BOX_PUBLISH_SIZE) > u16Publish_Byte_CNT)
		{
			u16Publish_Data_Byte = u16Publish_Byte_CNT - i;
		}
		else
		{
			u16Publish_Data_Byte = E2P_BLACK_BOX_PUBLISH_SIZE;
		}
	
		if ((tsBlackBoxHandler.u16RecordedEventNumber < MAXIMUM_BLACK_BOX_EVENT_NUMBER) &&
            ((i16_t)tsBlackBoxHandler.sPublisher.u8BlackBox_Page > tsBlackBoxHandler.i16LatestSectionIndex))
		{
	        // Filling zero for the reporting of invalid pages
		    memset(tsBlackBoxHandler.sPublisher.pu8PublishData, 0, u16Publish_Data_Byte);
		}
		else
		{
            // Store current record page number when the last block, each block is 64bytes
            if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData && (tsBlackBoxHandler.sPublisher.u16BlackBox_Read_Block_Sequence == tsBlackBoxHandler.sPublisher.u32BlackBox_Max_Block_Number))
                tsBlackBoxHandler.sPublisher.pu8RetrieveData[BLACKBOX_ADDR_BLACKBOX_PAGE - (E2P_BLACK_BOX_RETRIEVE_SIZE*tsBlackBoxHandler.sPublisher.u32BlackBox_Max_Block_Number)] = tsBlackBoxHandler.sPublisher.u8BlackBox_Page;

		    // Copy retrieve data to publish section
		    memcpy(tsBlackBoxHandler.sPublisher.pu8PublishData, tsBlackBoxHandler.sPublisher.pu8RetrieveData + i, u16Publish_Data_Byte);
		}

   		// CRC8
    	for (j=0; j < u16Publish_Data_Byte; j++)
    	{
        	CalCRC8(&tsBlackBoxHandler.sPublisher.u8DataCRC8, tsBlackBoxHandler.sPublisher.pu8PublishData[j]);
    	}

		// Push data to CAN
		if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData)
		{
			CANBusData_Set_BlackBox_Data_Length((u8_t)u16Publish_Data_Byte);
			CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_BLOCK_READ, CANBUS_CMD_BLACKBOX_READ_DATA, CAN_System_Address);
		}
		else if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData)
		{
			CANBusData_Set_Waveform_Data_Length((u8_t)u16Publish_Data_Byte);
			CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_BLOCK_READ, CANBUS_CMD_WAVEFORM_READ_DATA, CAN_System_Address);
		}
	}

	// Push CRC8 to CAN
	if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData)
	{	
		CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_BLOCK_READ, CANBUS_CMD_BLACKBOX_READ_STOP, CAN_System_Address);
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadStart = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData = 0;
	}
	else if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData)
	{
		CANBusServer_Push_CANBUS_Data(CANBUS_COMMTYPE_BLOCK_READ, CANBUS_CMD_WAVEFORM_READ_STOP, CAN_System_Address);
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData = 0;
	}
	else
	{
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadStart = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData = 0;
	}
}

/**
 *  @brief  Get event locate address in EEPROM
 *  @param  u16EventIndex
 *  @retval Locate address in EEPROM
 */
static u32_t BlackBox_GetEventLocateAddress()
{
    u32_t u32LocateAddress = BLACK_BOX_STORE_ADDRESS_OFFSET;
	u16_t u16EventIndex = 0;
    u16_t u16EventSectionIndex;

	// Fetch event page
	if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData)
	{
		u16EventIndex = (u16_t)tsBlackBoxHandler.sPublisher.u8BlackBox_Page;
	}
	else if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData)
	{
		u16EventIndex = (u16_t)tsBlackBoxHandler.sPublisher.u8Waveform_Page;
	}

	// Fetch EEPROM event address
	if (tsBlackBoxHandler.i16LatestSectionIndex < 0)
	{
	    // if "i16LatestSectionIndex" is -1 , then read form Page-0
	    u16EventSectionIndex = 0;
	}
	else if (tsBlackBoxHandler.i16LatestSectionIndex >= u16EventIndex)
    {
        u16EventSectionIndex = tsBlackBoxHandler.i16LatestSectionIndex - u16EventIndex;
    }
    else
    {
        u16EventSectionIndex = (tsBlackBoxHandler.i16LatestSectionIndex + MAXIMUM_BLACK_BOX_EVENT_NUMBER) - u16EventIndex;
    }
    
    u32LocateAddress += (u16EventSectionIndex * BLACKBOX_EVENT_SIZE);

	if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData)
	{
		// Waveform log offset
		u32LocateAddress += BLACKBOX_ADDR_WAVEFORM_LOG;
	}

	if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData)
	{
		u32LocateAddress += (tsBlackBoxHandler.sPublisher.u16BlackBox_Read_Block_Sequence * E2P_BLACK_BOX_RETRIEVE_SIZE);
	}
	else if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData)
	{
		u32LocateAddress += (tsBlackBoxHandler.sPublisher.u16Waveform_Read_Block_Sequence * E2P_BLACK_BOX_RETRIEVE_SIZE);
	}
    
    return u32LocateAddress;
}

/**
 *  @brief  Retrieve event from EEPROM
 *  @retval None
 */
static inline void BlackBox_RetrieveEvent(void)
{
    u32_t u32Address = BlackBox_GetEventLocateAddress();

    tsBlackBoxHandler.psE2pDriver->pfMemoryRead(tsBlackBoxHandler.psE2pDriver, u32Address, E2P_BLACK_BOX_RETRIEVE_SIZE, tsBlackBoxHandler.sPublisher.pu8RetrieveData);
    tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Retrieving = 1;
}

/**
 *  @brief  Black Box Background Process
 *  @note   In order to prevent EEPROM driver race starving, we should reset driver regardless of tranacation was success or failure
 *  @retval None
 */
void BlackBox_Background_Process(void)
{
	eE2pDriverState_t eDriverState = tsBlackBoxHandler.psE2pDriver->pfGetDriverState(tsBlackBoxHandler.psE2pDriver);

    // First priority is process publisher request due to it was request from PSC
    if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Awaiting)
    {
        /*************************************************************/
        //fixing the risk of the state machine(halt here)
        if (eDriverState == E2P_STATE_READY)
        {
            if(tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Awaiting ||  \
               tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Recording||  \
               tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Storing      )
            {
                //assert a flag to notify the recorder is interrupted by the publisher
                tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Interrupted = 1;
            }

            tsBlackBoxHandler.psE2pDriver->pfResetDriver(tsBlackBoxHandler.psE2pDriver);
        }
        /*************************************************************/
        if (eDriverState == E2P_STATE_IDLE)
        {
            tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Awaiting = 0;
            BlackBox_RetrieveEvent(); // Read BlackBox data form EEPROM
        }
    }
    else if (tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Retrieving)
    {
        if (eDriverState == E2P_STATE_READY)
        {
            tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Retrieving = 0;     
            tsBlackBoxHandler.psE2pDriver->pfResetDriver(tsBlackBoxHandler.psE2pDriver);
			BlackBox_Publish_Data(); // Push data to CanBus
        }
        else if (eDriverState == E2P_STATE_ERROR)
        {
            tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Retrieving = 0;       
            tsBlackBoxHandler.sPublisher.u16FailureRetryTimes += 1;
			
            if (tsBlackBoxHandler.sPublisher.u16FailureRetryTimes == BLACK_BOX_EEPROM_DRIVER_FAILURE_RETRY_TIMES)
            {
                tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Failure = 1;
            }
            else
            {
                tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Awaiting = 1;
            }
            
            tsBlackBoxHandler.psE2pDriver->pfResetDriver(tsBlackBoxHandler.psE2pDriver);
        }
		else if (eDriverState == E2P_STATE_IDLE)
		{
			tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Retrieving = 0;
		}
    }
    else if (tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Awaiting)
    {
        if (eDriverState == E2P_STATE_IDLE)
        {
            tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Awaiting = 0;
			BlackBox_Store_Event(); // Store BlackBox data to EEPROM
        }
    }
    else if (tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Storing)
    {
        //normal operation or interrupted by publisher
        if ((eDriverState == E2P_STATE_READY) || ((eDriverState == E2P_STATE_IDLE) && tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Interrupted))
        {
            tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Interrupted = 0;
            tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Storing = 0;
            tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Awaiting = 1;
            tsBlackBoxHandler.sRecorder.u16StoredBytes += tsBlackBoxHandler.sRecorder.u16PushingBytes;
            tsBlackBoxHandler.psE2pDriver->pfResetDriver(tsBlackBoxHandler.psE2pDriver);
        }
        else if (eDriverState == E2P_STATE_ERROR)
        {
            tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Storing = 0;        
            tsBlackBoxHandler.sRecorder.u16FailureRetryTimes += 1;
			
            if (tsBlackBoxHandler.sRecorder.u16FailureRetryTimes == BLACK_BOX_EEPROM_DRIVER_FAILURE_RETRY_TIMES)
            {
                tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Failure = 1;
            }
            else
            {
                tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Awaiting = 1;
            }
            
            tsBlackBoxHandler.psE2pDriver->pfResetDriver(tsBlackBoxHandler.psE2pDriver);
        }
		else if (eDriverState == E2P_STATE_IDLE)
		{
			tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Storing = 0;
		}
    }	
} 

/**
 *  @brief  Reset sRecorder of failure per 1min
 *  @retval None
 */
void BlackBox_1min_Periodically_Process(void)
{
	// BlackBox Failure auto Reset
	if (tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Failure)
	{
		tsBlackBoxHandler.sRecorder.nFlag.u16Bits.u1Failure = 0;
		tsBlackBoxHandler.sRecorder.u16FailureRetryTimes = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadStart = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1BlackBox_ReadData = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadStart = 0;
		tsBlackBoxHandler.sPublisher.nFlag.u16Bits.u1Waveform_ReadData = 0;
	}
}

/**
 *  @brief  Initial Black Box item
 *  @param  eTag: Tag of black box item which is attempted to initial
 *  @param  pu8Source: Pointer to source variable which is attempted to record
 *  @retval None
 */
void BlackBox_Initial_Item(eBlackBoxItemTag_t eTag, u8_t* pu8Source)
{
    switch (eTag)
    {
    	case eBLACKBOX_ITEM_BLACKBOX_RESERVED:
        case eBLACKBOX_ITEM_WAVEFORM_LOG:
            break;
		
        default:
            ptsBlackBoxItem[eTag].pu8Source = pu8Source;
            break;
    }
}

/**
 *  @brief  Initial Black Box Handler
 *  @retval None
 */
void BlackBox_Initialize(void)
{
    memset(&tsBlackBoxHandler, 0, sizeof(tsBlackBoxHandler));
    
    /* Get EEPROM driver */
    tsBlackBoxHandler.psE2pDriver = E2pDrv_GetDriverInformation(E2p_Tag_1);
    
    /* Get handler information form E2pData */
    if (pu16E2pDataInRam[E2pDataIndex_Manufacture_Password] == AcceptPassword)
    {
        tsBlackBoxHandler.u16RecordedEventNumber = pu16E2pDataInRam[E2pDataIndex_BlackBox_EventNumber];
        tsBlackBoxHandler.i16LatestSectionIndex = pu16E2pDataInRam[E2pDataIndex_BlackBox_LatestIndex];
    }
    else
    {
        GET_LOG_TOT_SWITCH_TIME = 0;
        GET_LOG_TOT_WORK_TIME = 0;
        tsBlackBoxHandler.u16RecordedEventNumber = 0;
        tsBlackBoxHandler.i16LatestSectionIndex = -1;
        
        E2pData_PushData(E2pDataIndex_TotATSwitchCNT, 0);
        E2pData_PushData(E2pDataIndex_TotATSwitchCNT+1, 0);
        E2pData_PushData(E2pDataIndex_TotPowerOnTime, 0);
        E2pData_PushData(E2pDataIndex_TotPowerOnTime+1, 0);
        E2pData_PushData(E2pDataIndex_BlackBox_EventNumber, tsBlackBoxHandler.u16RecordedEventNumber);
        E2pData_PushData(E2pDataIndex_BlackBox_LatestIndex, tsBlackBoxHandler.i16LatestSectionIndex);
        E2pData_PushData(E2pDataIndex_Manufacture_Password, AcceptPassword);
    }

    /* Initial waveform */
    Waveform_Initialize();
    
    /* Initial Recorder */
    tsBlackBoxHandler.sRecorder.sWaveformRecorderConfig.pu8Destination = &tsBlackBoxHandler.sRecorder.pu8Data[ptsBlackBoxItem[eBLACKBOX_ITEM_WAVEFORM_LOG].u16Address];

	Waveform_Address_Setting(tsBlackBoxHandler.sRecorder.sWaveformRecorderConfig);

    /* Initial Publisher */
	tsBlackBoxHandler.sPublisher.u8BlackBox_Page = 0x00;
	// data 76 byte = 1 block(64byte) + 12byte
	tsBlackBoxHandler.sPublisher.u32BlackBox_Max_Block_Number = 1;	//0,1
	tsBlackBoxHandler.sPublisher.u32BlackBox_Byte_of_LastBlock = 12;	//1,2,3..9
	
	// data 4000 byte = 62 block(64byte) + 32byte
	tsBlackBoxHandler.sPublisher.u8Waveform_Page = 0xFF;
	tsBlackBoxHandler.sPublisher.u32Waveform_Max_Block_Number = 62;	//0,1,2...62
	tsBlackBoxHandler.sPublisher.u32Waveform_Byte_of_LastBlock = 32;	//1,2,3..32
}

