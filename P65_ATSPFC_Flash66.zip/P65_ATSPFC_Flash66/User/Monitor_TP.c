/****************************************************************************
 *	File	Monitor_TP.c
 * 	Brief	Temperature input signals handler
 * 			- Inlet temperature
 * 			- PFC heatsink temperature
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/25 - 1st release
 ****************************************************************************/
#include <string.h>
#include "Monitor_TP.h"
#include "SERV_LOG.h"
#include "SERV_ADCFilter.h"


/****************************************************************************
*	Private parameter definition 
****************************************************************************/

#define MOMITP_Bits_OTP				0x0001
#define MOMITP_Bits_OTW				0x0002
#define MOMITP_Bits_UTP				0x0004
#define MOMITP_Bits_UTW				0x0008


#define OTP_Inlet_SetThreshold		600			// unit is 0.1 degreeC
#define	OTP_Inlet_CleThreshold		550			// unit is 0.1 degreeC

#define OTW_Inlet_SetThreshold		480			// unit is 0.1 degreeC
#define	OTW_Inlet_CleThreshold		430			// unit is 0.1 degreeC

#define OTP_Hotspot_SetThreshold	1100		// unit is 0.1 degreeC
#define	OTP_Hotspot_CleThreshold	1050		// unit is 0.1 degreeC

#define OTW_Hotspot_SetThreshold	1050		// unit is 0.1 degreeC
#define	OTW_Hotspot_CleThreshold	1000		// unit is 0.1 degreeC

#define UTW_SetThreshold			(i16_t)-30	// unit is 0.1 degreeC
#define	UTW_CleThreshold			20			// unit is 0.1 degreeC

#define UTP_SetThreshold			(i16_t)-100	// unit is 0.1 degreeC
#define	UTP_CleThreshold			(i16_t)-50	// unit is 0.1 degreeC

#define Protect_SetDelay			5			// unit is 1s
#define Warning_SetDelay			1			// unit is 1s
#define ClearDelay					3			// unit is 1s



/****************************************************************************
*	Private macro definition
****************************************************************************/ 

/****************************************************************************
*	Private enumeration definition
****************************************************************************/ 

/****************************************************************************
*	Private structure definition 
****************************************************************************/

/****************************************************************************
*	Private function prototype
****************************************************************************/ 

// RAMLS0_6 : 105
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(MoniTP_1s_Periodically_Process, ".TI.ramfunc");
#endif


/****************************************************************************
*	Private variable declaration
****************************************************************************/
sMoniTP_t tsMoniTP[MoniTP_Tag_Num];

//PN:TSM2A103F34D1HZ, 822148
const i16_t pi16HeatsinkTemperatureArray[256] = 
{
	1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 	    // 0xf  000-015
	1500, 1500, 1500, 1500, 1500, 1500, 1500, 1480, 1450, 1430, 1410, 1390, 1370, 1360, 1340, 1320,			// 0x1f 016-031
	1300, 1290, 1270, 1260, 1240, 1230, 1220, 1200, 1190, 1180, 1170, 1150, 1140, 1130, 1120, 1110,			// 0x2f 032-047
	1100, 1090, 1080, 1070, 1060, 1050, 1040, 1030, 1020, 1010, 1005, 1000,  990,  980,  970,  960,			// 0x3f 048-063
	 955,  950,  940,  930,  925,  920,  910,  900,  895,  890,  880,  875,  870,  860,  855,  850,			// 0x4f 064-079
	 840,  835,  830,  820,  815,  810,  805,  800,  790,  785,  780,  775,  770,  760,  755,  750,			// 0x5f	080-095
	 745,  740,  735,  730,  720,  715,  710,  705,  700,  695,  690,  685,  680,  675,  670,  660, 		// 0x6f 096-111
	 655,  650,  645,  640,  635,  630,  625,  620,  615,  610,  605,  600,  595,  590,  585,  580,			// 0x7f 112-127
	 575,  570,  565,  560,  555,  550,  545,  540,  535,  530,  525,  520,  515,  510,  507,  503, 		// 0x8f 128-143
	 500,  495,  490,  485,  480,  475,  470,  465,  460,  455,  450,  445,  440,  435,  430,  425, 		// 0x9f 144-159
	 420,  415,  410,  405,  400,  395,  390,  385,  380,  375,  370,  365,  360,  355,  350,  345,			// 0xaf 160-175
	 340,  335,  330,  325,  320,  315,  310,  305,  300,  295,  290,  285,  280,  275,  270,  260, 		// 0xbf 176-191
	 255,  250,  245,  240,  235,  230,  225,  220,  210,  205,  200,  195,  190,  180,  175,  170, 		// 0xcf 192-207
	 160,  155,  150,  140,  135,  130,  120,  115,  110,  100,   90,   80,   75,   70,   60,   50, 		// 0xdf 208-223
	  40,   30,   25,   20,   10,    0,  -10,  -20,  -30,  -40,  -50,  -60,  -80,  -90, -100, -110, 		// 0xef 224-239
	-130, -140, -150, -170, -190, -200, -220, -240, -270, -290, -320, -350, -390, -400, -400, -400			// 0xff 240-255
};


/***************************************************************************
*   brief  Update Real value
*   note   
****************************************************************************/
static inline void MoniTP_RealValue_Cal(sMoniTP_t *psMoni)
{
	u16_t u16Temp;
	u16Temp = *psMoni->pu16ADC_Q12;
	psMoni->i16RealInstant = pi16HeatsinkTemperatureArray[(u16Temp >> 4)]; //Q12 to Q8

	if (psMoni->eTag == MoniTP_Tag_INLET)
	{
		// Inlet will calibration point is front of Fan
		psMoni->i16RealInstant = psMoni->i16RealInstant - 20; // calibration inlet temperature
		psMoni->i16RealInstant = psMoni->i16RealInstant - (GET_LOG_D2DMAXPOWER / 100); // calibration by output power
	}

#ifdef PPTSample

	// For PPT sample calibration PFC temperature
	if (psMoni->eTag == MoniTP_Tag_PFC)
	{	
		if (psMoni->i16RealInstant > 250)
		{
			psMoni->i16RealInstant = (((psMoni->i16RealInstant - 250)*7)/10) + psMoni->i16RealInstant;
		}
	}
	
#endif

	psMoni->u16RealInstant = (u16_t)(psMoni->i16RealInstant + 400);
}

/***************************************************************************
*   brief  Record max temperture
*   note   
****************************************************************************/
static inline void MoniTP_Record_Max_Temperture(sMoniTP_t *psMoni)
{
	if (psMoni->i16RealInstant > psMoni->i16RealMax)
	{
		psMoni->i16RealMax = psMoni->i16RealInstant;
	}
}

/***************************************************************************
*   brief  Update TP flag
*   note
****************************************************************************/
static inline void MoniTP_UpdateFlag(sMoniTP_t *psMoni)
{
	Single_Threshold(&psMoni->sConfig.sOTP, psMoni->i16RealInstant, &psMoni->nFlag.u16All);
	Single_Threshold(&psMoni->sConfig.sOTW, psMoni->i16RealInstant, &psMoni->nFlag.u16All);
	Single_Threshold(&psMoni->sConfig.sUTP, psMoni->i16RealInstant, &psMoni->nFlag.u16All);
	Single_Threshold(&psMoni->sConfig.sUTW, psMoni->i16RealInstant, &psMoni->nFlag.u16All);
}

/***************************************************************************
*   brief  Temperature periodically Process at 1s system time
*   note   
****************************************************************************/
void MoniTP_1s_Periodically_Process(void)
{
	u16_t i;
	
	for (i=0; i<MoniTP_Tag_Num; i++)
	{
		if (tsMoniTP[i].nFlag.u16Bits.u1FIJ == FALSE)
		{
			MoniTP_RealValue_Cal(&tsMoniTP[i]);
		}
		
		MoniTP_Record_Max_Temperture(&tsMoniTP[i]);
		MoniTP_UpdateFlag(&tsMoniTP[i]);
	}
}

/***************************************************************************
*   brief  Set trigger type
*   note   
****************************************************************************/
void MoniTP_Set_TriggerType(u16_t u16Type)
{
	u16_t i;
	eTriggerType_t eSetTriggerType;

	if (u16Type == TRUE)
	{
		eSetTriggerType = TriggerDisable;
	}
	else
	{
		eSetTriggerType = TriggerAutoRecover;
	}
	
	for (i=0; i<MoniTP_Tag_Num; i++)
	{
		tsMoniTP[i].sConfig.sOTP.eTriggerType = eSetTriggerType;
		tsMoniTP[i].sConfig.sOTW.eTriggerType = eSetTriggerType;
		tsMoniTP[i].sConfig.sUTP.eTriggerType = eSetTriggerType;
		tsMoniTP[i].sConfig.sUTW.eTriggerType = eSetTriggerType;
	}
}

/***************************************************************************
*   brief  Return TP source address
*   note   
****************************************************************************/
sMoniTP_t* GetMoniTPRef(eMoniTPTag_t eTag)
{
	return &tsMoniTP[eTag];
}

/****************************************************************************
*	Brief	Monitor TP initialize
*	Note	
****************************************************************************/
void MoniTP_Initialize(void)
{
    u16_t i;

	for (i=0; i<MoniTP_Tag_Num; i++)
    {
    	memset(&tsMoniTP[i], 0, sizeof(tsMoniTP[i]));
		
    	/* For Over Temperature Protect */
		tsMoniTP[i].eTag = (eMoniTPTag_t)i;
		tsMoniTP[i].sConfig.sOTP.eTriggerType = TriggerAutoRecover;
		tsMoniTP[i].sConfig.sOTP.eLimitType = Limit_Upper;
		tsMoniTP[i].sConfig.sOTP.u16SetBits = MOMITP_Bits_OTP;
		tsMoniTP[i].sConfig.sOTP.i16SetThreshold = OTP_Hotspot_SetThreshold;
		tsMoniTP[i].sConfig.sOTP.i16ClearThreshold = OTP_Hotspot_CleThreshold;
		tsMoniTP[i].sConfig.sOTP.sConst.u16SetDelay = Protect_SetDelay;
		tsMoniTP[i].sConfig.sOTP.sConst.u16ClearDelay = ClearDelay;
		tsMoniTP[i].sConfig.sOTP.sVar.u16SetDelay = tsMoniTP[i].sConfig.sOTP.sConst.u16SetDelay;
		tsMoniTP[i].sConfig.sOTP.sVar.u16ClearDelay = tsMoniTP[i].sConfig.sOTP.sConst.u16ClearDelay;

		/* For Over Temperature Warning */
		tsMoniTP[i].sConfig.sOTW.eTriggerType = TriggerAutoRecover;
		tsMoniTP[i].sConfig.sOTW.eLimitType = Limit_Upper;
		tsMoniTP[i].sConfig.sOTW.u16SetBits = MOMITP_Bits_OTW;
		tsMoniTP[i].sConfig.sOTW.i16SetThreshold = OTW_Hotspot_SetThreshold;
		tsMoniTP[i].sConfig.sOTW.i16ClearThreshold = OTW_Hotspot_CleThreshold;
		tsMoniTP[i].sConfig.sOTW.sConst.u16SetDelay = Warning_SetDelay;
		tsMoniTP[i].sConfig.sOTW.sConst.u16ClearDelay = ClearDelay;
		tsMoniTP[i].sConfig.sOTW.sVar.u16SetDelay = tsMoniTP[i].sConfig.sOTW.sConst.u16SetDelay;
		tsMoniTP[i].sConfig.sOTW.sVar.u16ClearDelay = tsMoniTP[i].sConfig.sOTW.sConst.u16ClearDelay;

		/* For Under Temperature Protect */
		tsMoniTP[i].sConfig.sUTP.eTriggerType = TriggerAutoRecover;
		tsMoniTP[i].sConfig.sUTP.eLimitType = Limit_Lower;
		tsMoniTP[i].sConfig.sUTP.u16SetBits = MOMITP_Bits_UTP;
		tsMoniTP[i].sConfig.sUTP.i16SetThreshold = UTP_SetThreshold;
		tsMoniTP[i].sConfig.sUTP.i16ClearThreshold = UTP_CleThreshold;
		tsMoniTP[i].sConfig.sUTP.sConst.u16SetDelay = Protect_SetDelay;
		tsMoniTP[i].sConfig.sUTP.sConst.u16ClearDelay = ClearDelay;
		tsMoniTP[i].sConfig.sUTP.sVar.u16SetDelay = tsMoniTP[i].sConfig.sUTP.sConst.u16SetDelay;
		tsMoniTP[i].sConfig.sUTP.sVar.u16ClearDelay = tsMoniTP[i].sConfig.sUTP.sConst.u16ClearDelay;

		/* For Under Temperature Warning */
		tsMoniTP[i].sConfig.sUTW.eTriggerType = TriggerAutoRecover;
		tsMoniTP[i].sConfig.sUTW.eLimitType = Limit_Lower;
		tsMoniTP[i].sConfig.sUTW.u16SetBits = MOMITP_Bits_UTW;
		tsMoniTP[i].sConfig.sUTW.i16SetThreshold = UTW_SetThreshold;
		tsMoniTP[i].sConfig.sUTW.i16ClearThreshold = UTW_CleThreshold;
		tsMoniTP[i].sConfig.sUTW.sConst.u16SetDelay = Warning_SetDelay;
		tsMoniTP[i].sConfig.sUTW.sConst.u16ClearDelay = ClearDelay;
		tsMoniTP[i].sConfig.sUTW.sVar.u16SetDelay = tsMoniTP[i].sConfig.sUTW.sConst.u16SetDelay;
		tsMoniTP[i].sConfig.sUTW.sVar.u16ClearDelay = tsMoniTP[i].sConfig.sUTW.sConst.u16ClearDelay;
    }

	/* For Inlet Over Temperature Threshold hysteresis */
	tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTP.i16SetThreshold = OTP_Inlet_SetThreshold;
	tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTP.i16ClearThreshold = OTP_Inlet_CleThreshold;
	
	tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTW.i16SetThreshold = OTW_Inlet_SetThreshold;
	tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTW.i16ClearThreshold = OTW_Inlet_CleThreshold;
	
	/* Disable UTP and UTW for T_ATS and T_PFC */
	tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTP.eTriggerType = TriggerDisable;
	tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTP.eTriggerType = TriggerDisable;
	tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTP.eTriggerType = TriggerDisable;

	tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTW.eTriggerType = TriggerDisable;
	tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTW.eTriggerType = TriggerDisable;
	tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTW.eTriggerType = TriggerDisable;


	tsMoniTP[MoniTP_Tag_PFC].pu16ADC_Q12 = &GET_ADCFilter_T_PFC;
	tsMoniTP[MoniTP_Tag_INLET].pu16ADC_Q12 = &GET_ADCFilter_T_INLET;
	tsMoniTP[MoniTP_Tag_ATS].pu16ADC_Q12 = &GET_ADCFilter_T_ATS;
	tsMoniTP[MoniTP_Tag_D2D].pu16ADC_Q12 = &GET_ADCFilter_T_D2D;
}


