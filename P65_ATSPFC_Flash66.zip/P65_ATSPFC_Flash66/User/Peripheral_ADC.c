/****************************************************************************
 *	File	Peripheral_ADC.c
 * 	Brief	Configure and control ADC module on TI 28004x platform
 *  @note       In this file, we use two ADC module: ADCa, ADCb and ADCc 
 *              In order to avoid switch noise interfere,
 *              ADCa have to handle 6 SOC
 *                  -SOC0: ADC_CHANNEL_I_PFC_B
 *                  -SOC1: ADC_CHANNEL_V_PFC_N
 *                  -SOC2: ADC_CHANNEL_V_AC1_L
 *                  -SOC3: ADC_CHANNEL_V_AC2_N
 *                  -SOC4: ADC_CHANNEL_T_INLET
 *                  -SOC5: ADC_CHANNEL_T_ATS
 *
 *              ADCb have to handle 5 SOC
 *                  -SOC0: ADC_CHANNEL_I_PFC_A
 *                  -SOC1: ADC_CHANNEL_V_PFC_L
 *                  -SOC2: ADC_CHANNEL_V_AC1_N
 *                  -SOC3: ADC_CHANNEL_V_AC2_L
 *                  -SOC4: ADC_CHANNEL_T_PFC
 *                  -SOC5: ADC_CHANNEL_T_D2D
 *
 *              ADCc have to handle 5 SOC
 *                  -SOC0: ADC_CHANNEL_V_PFC_OVP1
 *                  -SOC1: ADC_CHANNEL_V_PFC_DET
 *                  -SOC2: ADC_CHANNEL_V_PFC_OVP2
 *                  -SOC3: ADC_CHANNEL_V_AUX1
 *                  -SOC4: ADC_CHANNEL_V_AUX2
 *
 *  @note       This peripheral generate a interrupt after ADCa-EOC5 event triggered
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

#include "F28x_Project.h"
#include "Peripheral_ADC.h"
#include "Peripheral.h"
#include "sw_prioritized_isr_levels.h"
#include <string.h>
#include "SysTime.h"
#include "SERV_LOG.h"


/****************************************************************************
    Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/
//ADC_A
#define ADC_CHANNEL_I_PFC_A         eADCINA4    // SOC-0
#define ADC_CHANNEL_V_PFC_L         eADCINA14   // SOC-1
#define ADC_CHANNEL_V_AC1_L         eADCINA15   // SOC-2
#define ADC_CHANNEL_V_AC2_L         eADCINA1    // SOC-3
#define ADC_CHANNEL_I_PFC_A_VREF    eADCINA6    // SOC-4
#define ADC_CHANNEL_T_INLET         eADCINA2    // SOC-5
#define ADC_CHANNEL_T_ATS           eADCINA3    // SOC-6
#define ADC_CHANNEL_V_AUX1	        eADCINA10   // SOC-7
#define ADC_CHANNEL_V_AUX2          eADCINA11   // SOC-8

//ADC_B
#define ADC_CHANNEL_I_PFC_B         eADCINB2    // SOC-0
#define ADC_CHANNEL_V_PFC_N         eADCINB0    // SOC-1
#define ADC_CHANNEL_V_AC1_N         eADCINB7    // SOC-2
#define ADC_CHANNEL_V_AC2_N         eADCINB3    // SOC-3
#define ADC_CHANNEL_I_PFC_B_VREF    eADCINB6    // SOC-4

//ADC_C
#define ADC_CHANNEL_I_PFC_C         eADCINC4    // SOC-0
#define ADC_CHANNEL_V_PFC_DET       eADCINC3    // SOC-1
#define ADC_CHANNEL_V_PFC_OVP1      eADCINC1    // SOC-2
#define ADC_CHANNEL_V_PFC_OVP2     	eADCINC2    // SOC-3
#define ADC_CHANNEL_I_PFC_C_VREF    eADCINC5    // SOC-4
#define ADC_CHANNEL_T_D2D           eADCINC0    // SOC-5
#define ADC_CHANNEL_T_PFC           eADCINC6    // SOC-6




/* S+H time is (ACQPS + 1)xSYSCLK cycles, (20+1)*10ns=210ns */
#define CONFIG_SOC(ADCREG, SOC_NUM, _CHSEL, _ACQPS, _TRIGSEL)                \
        do                                                                   \
        {                                                                    \
            ADCREG.ADC##SOC_NUM##CTL.bit.CHSEL = _CHSEL;                     \
            ADCREG.ADC##SOC_NUM##CTL.bit.ACQPS = _ACQPS;                     \
            ADCREG.ADC##SOC_NUM##CTL.bit.TRIGSEL = _TRIGSEL;                 \
        }while(0)
/****************************************************************************
	Private enumeration definition 
****************************************************************************/
enum ADC_CHSEL_ENUMERATION
{
    eADCINA0 = 0,
    eADCINA1,
    eADCINA2,
    eADCINA3,
    eADCINA4,
    eADCINA5,
    eADCINA6,
    eADCINA7,
    eADCINA8,
    eADCINA9,
    eADCINA10,
    eADCINA11,
    eADCINA12,
    eADCINA13,
    eADCINA14,
    eADCINA15,
    eADCINB0 = eADCINA0,
    eADCINB1,
    eADCINB2,
    eADCINB3,
    eADCINB4,
    eADCINB5,
    eADCINB6,
    eADCINB7,
    eADCINB8,
    eADCINB9,
    eADCINB10,
    eADCINC0 = eADCINA0,
    eADCINC1,
    eADCINC2,
    eADCINC3,
    eADCINC4,
    eADCINC5,
    eADCINC6,
    eADCINC7,
    eADCINC8,
    eADCINC9,
    eADCINC10,
};

enum ADC_SOC_TRIGGER_ENUMERATION
{
    eAdcSoc_Trigger_Software = 0,
    eAdcSoc_Trigger_CpuTimer0,
    eAdcSoc_Trigger_CpuTimer1,
    eAdcSoc_Trigger_CpuTimer2,
    eAdcSoc_Trigger_ExternGPIO,
    eAdcSoc_Trigger_ePWM1_SOCA,
    eAdcSoc_Trigger_ePWM1_SOCB,
    eAdcSoc_Trigger_ePWM2_SOCA,
    eAdcSoc_Trigger_ePWM2_SOCB,
    eAdcSoc_Trigger_ePWM3_SOCA,
    eAdcSoc_Trigger_ePWM3_SOCB,
    eAdcSoc_Trigger_ePWM4_SOCA,
    eAdcSoc_Trigger_ePWM4_SOCB,
    eAdcSoc_Trigger_ePWM5_SOCA,
    eAdcSoc_Trigger_ePWM5_SOCB,
    eAdcSoc_Trigger_ePWM6_SOCA,
    eAdcSoc_Trigger_ePWM6_SOCB,
    eAdcSoc_Trigger_ePWM7_SOCA,
    eAdcSoc_Trigger_ePWM7_SOCB,
    eAdcSoc_Trigger_ePWM8_SOCA,
    eAdcSoc_Trigger_ePWM8_SOCB,
};

enum ADC_INT_TRIGGER_ENUMERATION
{
    eAdcInt_Trigger_EOC0,
    eAdcInt_Trigger_EOC1,
    eAdcInt_Trigger_EOC2,
    eAdcInt_Trigger_EOC3,
    eAdcInt_Trigger_EOC4,
    eAdcInt_Trigger_EOC5,
    eAdcInt_Trigger_EOC6,
    eAdcInt_Trigger_EOC7,
    eAdcInt_Trigger_EOC8,
    eAdcInt_Trigger_EOC9,
    eAdcInt_Trigger_EOC10,
    eAdcInt_Trigger_EOC11,
    eAdcInt_Trigger_EOC12,
    eAdcInt_Trigger_EOC13,
    eAdcInt_Trigger_EOC14,
    eAdcInt_Trigger_EOC15,
};

/****************************************************************************
	Private structure definition 
****************************************************************************/


/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 142
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(ISR_ADCa_EOC, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/
u16_t ADCResult[ADC_Tag_Num];

/**
 *  @brief  Interrupt for end of conversion event of high speed sampling on ADCa
 *  @note   Due to we need use software prioritized interrupt service,
 *          So we need to insert our application code between the branch mechanism code
 *  @retval None
 */
__interrupt void ISR_ADCa_EOC(void)
{
//    DacaRegs.DACVALS.bit.DACVALS = 4095; //dbg

    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER1.all;   // Store IER
    IER |= M_INT1;
    IER &= MINT1;                                           // Set "global" priority
    PieCtrlRegs.PIEIER1.all &= MG1_1;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");
    EINT;
    
    /* User code Start */

    // ADToDo: use DMA
    /* ADC-A */
    ADCResult[ADC_I_PFC_A]      = AdcaResultRegs.ADCRESULT0;
    ADCResult[ADC_V_PFC_L]      = AdcaResultRegs.ADCRESULT1;
    ADCResult[ADC_V_AC1_L]      = AdcaResultRegs.ADCRESULT2;
    ADCResult[ADC_V_AC2_L]      = AdcaResultRegs.ADCRESULT3;
    ADCResult[ADC_T_INLET]      = AdcaResultRegs.ADCRESULT4;
    ADCResult[ADC_T_ATS]        = AdcaResultRegs.ADCRESULT5;
    ADCResult[ADC_V_AUX1]       = AdcaResultRegs.ADCRESULT6;
    ADCResult[ADC_V_AUX2]       = AdcaResultRegs.ADCRESULT7;

    /* ADC-B */
    ADCResult[ADC_V_PFC_N]      = AdcbResultRegs.ADCRESULT0;
    ADCResult[ADC_I_PFC_B]      = AdcbResultRegs.ADCRESULT1;
    ADCResult[ADC_V_AC1_N]      = AdcbResultRegs.ADCRESULT2;
    ADCResult[ADC_V_AC2_N]      = AdcbResultRegs.ADCRESULT3;

    /* ADC-C */
    ADCResult[ADC_I_PFC_C]      = AdccResultRegs.ADCRESULT0;
    ADCResult[ADC_V_PFC_DET]    = AdccResultRegs.ADCRESULT1;
    ADCResult[ADC_V_PFC_OVP1]   = AdccResultRegs.ADCRESULT2;
    ADCResult[ADC_V_PFC_OVP2]   = AdccResultRegs.ADCRESULT3;
    ADCResult[ADC_T_PFC]        = AdccResultRegs.ADCRESULT4;
    ADCResult[ADC_T_D2D]        = AdccResultRegs.ADCRESULT5;

//    DacaRegs.DACVALS.bit.DACVALS = ADCResult[ADC_V_PFC_DET];
//    DaccRegs.DACVALS.bit.DACVALS = ADCResult[ADC_I_PFC_A];
//    DaccRegs.DACVALS.bit.DACVALS = abs(ADCResult[ADC_V_PFC_L] - ADCResult[ADC_V_PFC_N]);

    INTERRUPT_ADC();

	/* User code End */
   
    // Clear the interrupt flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    // Check if overflow has occurred
    if (1 == AdcaRegs.ADCINTOVF.bit.ADCINT1)
    {
        AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
        AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
    }
   
    DINT;
    PieCtrlRegs.PIEIER1.all = TempPIEIER;      // Restore IER
//    DacaRegs.DACVALS.bit.DACVALS = 0; // dbg
    /* Branch mechanism code End */
}

__interrupt void ISR_ADCb_EOC(void)
{
//    DacaRegs.DACVALS.bit.DACVALS = 4095;

    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER1.all;   // Store IER
    IER |= M_INT1;
    IER &= MINT1;                                           // Set "global" priority
    PieCtrlRegs.PIEIER1.all &= MG1_3;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");
    EINT;

    /* User code Start */

    // ADToDo: use DMA
    /* ADC-A */
    ADCResult[ADC_I_PFC_A]      = AdcaResultRegs.ADCRESULT0;
    ADCResult[ADC_V_PFC_L]      = AdcaResultRegs.ADCRESULT1;
    ADCResult[ADC_V_AC1_L]      = AdcaResultRegs.ADCRESULT2;
    ADCResult[ADC_V_AC2_L]      = AdcaResultRegs.ADCRESULT3;
    ADCResult[ADC_T_INLET]      = AdcaResultRegs.ADCRESULT4;
    ADCResult[ADC_T_ATS]        = AdcaResultRegs.ADCRESULT5;
    ADCResult[ADC_V_AUX1]       = AdcaResultRegs.ADCRESULT6;
    ADCResult[ADC_V_AUX2]       = AdcaResultRegs.ADCRESULT7;

    /* ADC-B */
    ADCResult[ADC_V_PFC_N]      = AdcbResultRegs.ADCRESULT0;
    ADCResult[ADC_I_PFC_B]      = AdcbResultRegs.ADCRESULT1;
    ADCResult[ADC_V_AC1_N]      = AdcbResultRegs.ADCRESULT2;
    ADCResult[ADC_V_AC2_N]      = AdcbResultRegs.ADCRESULT3;

    /* ADC-C */
    ADCResult[ADC_I_PFC_C]      = AdccResultRegs.ADCRESULT0;
    ADCResult[ADC_V_PFC_DET]    = AdccResultRegs.ADCRESULT1;
    ADCResult[ADC_V_PFC_OVP1]   = AdccResultRegs.ADCRESULT2;
    ADCResult[ADC_V_PFC_OVP2]   = AdccResultRegs.ADCRESULT3;
//    ADCResult[ADC_T_PFC]        = AdccResultRegs.ADCRESULT4;
//    ADCResult[ADC_T_D2D]        = AdccResultRegs.ADCRESULT5;

//    DacaRegs.DACVALS.bit.DACVALS = abs(ADCResult[ADC_V_PFC_L] - ADCResult[ADC_V_PFC_N]);
//    DaccRegs.DACVALS.bit.DACVALS = ADCResult[ADC_I_PFC_B];

    INTERRUPT_ADC();

    /* User code End */

    // Clear the interrupt flag
    AdcbRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    // Check if overflow has occurred
    if (1 == AdcbRegs.ADCINTOVF.bit.ADCINT1)
    {
        AdcbRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
        AdcbRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
    }

    DINT;
    PieCtrlRegs.PIEIER1.all = TempPIEIER;      // Restore IER
    /* Branch mechanism code End */

//    DacaRegs.DACVALS.bit.DACVALS = 0;
}

__interrupt void ISR_ADCc_EOC(void)
{
//    DacaRegs.DACVALS.bit.DACVALS = 4095;

    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER1.all;   // Store IER
    IER |= M_INT1;
    IER &= MINT1;                                           // Set "global" priority
    PieCtrlRegs.PIEIER1.all &= MG1_3;                       // Set "group" priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                        // Enable PIE interrupts
    __asm("     NOP");
    EINT;

    /* User code Start */

    // ADToDo: use DMA
    /* ADC-A */
//    ADCResult[ADC_I_PFC_A]      = AdcaResultRegs.ADCRESULT0;
//    ADCResult[ADC_V_PFC_L]      = AdcaResultRegs.ADCRESULT1;
    ADCResult[ADC_V_PFC_L]      = AdcaResultRegs.ADCRESULT0;
    ADCResult[ADC_I_PFC_A]      = AdcaResultRegs.ADCRESULT1;
    ADCResult[ADC_V_AC1_L]      = AdcaResultRegs.ADCRESULT2;
    ADCResult[ADC_V_AC2_L]      = AdcaResultRegs.ADCRESULT3;
    ADCResult[ADC_T_INLET]      = AdcaResultRegs.ADCRESULT4;
    ADCResult[ADC_T_ATS]        = AdcaResultRegs.ADCRESULT5;
    ADCResult[ADC_V_AUX1]       = AdcaResultRegs.ADCRESULT6;
    ADCResult[ADC_V_AUX2]       = AdcaResultRegs.ADCRESULT7;

    /* ADC-B */
    ADCResult[ADC_V_PFC_N]      = AdcbResultRegs.ADCRESULT0;
    ADCResult[ADC_I_PFC_B]      = AdcbResultRegs.ADCRESULT1;
    ADCResult[ADC_V_AC1_N]      = AdcbResultRegs.ADCRESULT2;
    ADCResult[ADC_V_AC2_N]      = AdcbResultRegs.ADCRESULT3;

    /* ADC-C */
    ADCResult[ADC_I_PFC_C]      = AdccResultRegs.ADCRESULT0;
    ADCResult[ADC_V_PFC_DET]    = AdccResultRegs.ADCRESULT1;
    ADCResult[ADC_V_PFC_OVP1]   = AdccResultRegs.ADCRESULT2;
    ADCResult[ADC_V_PFC_OVP2]   = AdccResultRegs.ADCRESULT3;
    ADCResult[ADC_T_PFC]        = AdccResultRegs.ADCRESULT4;
    ADCResult[ADC_T_D2D]        = AdccResultRegs.ADCRESULT5;

//    DacaRegs.DACVALS.bit.DACVALS = ADCResult[ADC_V_PFC_DET];
//    DaccRegs.DACVALS.bit.DACVALS = ADCResult[ADC_I_PFC_C];
//    DaccRegs.DACVALS.bit.DACVALS = abs(ADCResult[ADC_V_PFC_L] - ADCResult[ADC_V_PFC_N]);

    INTERRUPT_ADC();

    /* User code End */

    // Clear the interrupt flag
    AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    // Check if overflow has occurred
    if (1 == AdccRegs.ADCINTOVF.bit.ADCINT1)
    {
        AdccRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
        AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
    }

    DINT;
    PieCtrlRegs.PIEIER1.all = TempPIEIER;      // Restore IER

//    DacaRegs.DACVALS.bit.DACVALS = 0;
    /* Branch mechanism code End */
}

/* PinMux for modules assigned to CPU1
   ANALOG -> myANALOGPinMux0 Pinmux    */
static inline void PinMux_init()
{
    // Analog PinMux for A1
    GPIO_setAnalogMode(228, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A10, GPIO213
    GPIO_setAnalogMode(213, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A11, GPIO214
    GPIO_setAnalogMode(214, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A14/B14/C14
    GPIO_setAnalogMode(225, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A15/B15/C15
    GPIO_setAnalogMode(226, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A2
    GPIO_setAnalogMode(229, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A3
    GPIO_setAnalogMode(230, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A4
    // AIO -> Analog mode selected
    GPIO_setAnalogMode(231, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A6, GPIO209
    GPIO_setAnalogMode(209, GPIO_ANALOG_ENABLED);

    // Analog PinMux for A9, GPIO212
    GPIO_setAnalogMode(212, GPIO_ANALOG_ENABLED);

    // Analog PinMux for B0/VDAC
    GPIO_setAnalogMode(233, GPIO_ANALOG_ENABLED);

    // Analog PinMux for B2
    GPIO_setAnalogMode(235, GPIO_ANALOG_ENABLED);

    // Analog PinMux for B3
    GPIO_setAnalogMode(236, GPIO_ANALOG_ENABLED);

    // Analog PinMux for B6, GPIO207
    GPIO_setAnalogMode(207, GPIO_ANALOG_ENABLED);

    // Analog PinMux for B7, GPIO208
    GPIO_setAnalogMode(208, GPIO_ANALOG_ENABLED);

    // Analog PinMux for C0, GPIO199
    GPIO_setAnalogMode(199, GPIO_ANALOG_ENABLED);

    // Analog PinMux for C2
    GPIO_setAnalogMode(237, GPIO_ANALOG_ENABLED);

    // Analog PinMux for C3, GPIO206
    GPIO_setAnalogMode(206, GPIO_ANALOG_ENABLED);

    // Analog PinMux for C4, GPIO205
    GPIO_setAnalogMode(205, GPIO_ANALOG_ENABLED);

    // Analog PinMux for C5, GPIO204
    GPIO_setAnalogMode(204, GPIO_ANALOG_ENABLED);

    // Analog PinMux for C6, GPIO203
    GPIO_setAnalogMode(203, GPIO_ANALOG_ENABLED);

    // Analog PinMux for C1, GPIO200
    GPIO_setAnalogMode(200, GPIO_ANALOG_ENABLED);
}

/**
 *  @brief  Initial ADCa module
 *  @retval None
 */
static inline void PeriAdc_Initial_ADCa(void)
{
    EALLOW;
    
	/* Set ADCCLK divider to 4, 200M / 4 = 50MHz */
    AdcaRegs.ADCCTL2.bit.PRESCALE = 6;

    /* Set pulse positions to late, EOC trips after conversion completed */
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    /* Configure each SOC of ADC
     *         ADCREG SOC_NUM      _CHSEL   		 _ACQPS 		_TRIGSEL
     */
//    CONFIG_SOC(AdcaRegs, SOC0, ADC_CHANNEL_I_PFC_A,		 23, eAdcSoc_Trigger_ePWM7_SOCA);
//    CONFIG_SOC(AdcaRegs, SOC1, ADC_CHANNEL_V_PFC_L,      23, eAdcSoc_Trigger_ePWM6_SOCA);
    CONFIG_SOC(AdcaRegs, SOC0, ADC_CHANNEL_V_PFC_L,      23, eAdcSoc_Trigger_ePWM6_SOCA);
    CONFIG_SOC(AdcaRegs, SOC1, ADC_CHANNEL_I_PFC_A,      23, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdcaRegs, SOC2, ADC_CHANNEL_V_AC1_L,      23, eAdcSoc_Trigger_ePWM8_SOCA);
    CONFIG_SOC(AdcaRegs, SOC3, ADC_CHANNEL_V_AC2_L,      23, eAdcSoc_Trigger_ePWM8_SOCA);
	CONFIG_SOC(AdcaRegs, SOC4, ADC_CHANNEL_T_INLET,		 23, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdcaRegs, SOC5, ADC_CHANNEL_T_ATS,        23, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdcaRegs, SOC6, ADC_CHANNEL_V_AUX1,       23, eAdcSoc_Trigger_ePWM7_SOCA);
    CONFIG_SOC(AdcaRegs, SOC7, ADC_CHANNEL_V_AUX2,       23, eAdcSoc_Trigger_ePWM7_SOCA);

    /* Configure ADCa_INT1 Interrupt */
//    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = eAdcInt_Trigger_EOC0;  // End of EOC5 to trigger ADCa_INT1
//    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;                       // Enable ADCa_INT1
//    AdcaRegs.ADCINTSEL1N2.bit.INT1CONT = 1;                    // Enable ADCa_INT1 continue mode
//    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;                     // Make sure INT1 flag had been cleared
//
//    /* Check if overflow has occurred */
//    if (1 == AdcaRegs.ADCINTOVF.bit.ADCINT1)
//    {
//        AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
//    }
//
//    /*
//     *  Enable IER and PieCtrlRegs for ADCa_INT1
//     *  PIE Channel: 1.1
//     */
//    IER |= M_INT1;                    							// Enable PIE Group 1 interrupt
//    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;             				// Enable ADCa_INT1 in the PIE Group 1
//
//    /* Re-mapped ADCa_INT1 interrupt function */
//    PieVectTable.ADCA1_INT = &ISR_ADCa_EOC;

	/* Power up the ADC */
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;

    /* Delay 1000us to allow ADC time to power up */
    DELAY_US(1000);
    
    EDIS;
}


/**
 *  @brief  Initial ADCb module
 *  @retval None
 */
static inline void PeriAdc_Initial_ADCb(void)
{
    EALLOW;
    
	/* Set ADCCLK divider to 4, 200M / 4 = 50MHz */
    AdcbRegs.ADCCTL2.bit.PRESCALE = 6;
	
    /* Set pulse positions to late, EOC trips after conversion completed */
    AdcbRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    /* Configure each SOC of ADC
     *         ADCREG SOC_NUM      _CHSEL   		 _ACQPS 		_TRIGSEL
     */
    CONFIG_SOC(AdcbRegs, SOC0, ADC_CHANNEL_V_PFC_N,     23, eAdcSoc_Trigger_ePWM6_SOCA);
    CONFIG_SOC(AdcbRegs, SOC1, ADC_CHANNEL_I_PFC_B,		23, eAdcSoc_Trigger_ePWM8_SOCA);
    CONFIG_SOC(AdcbRegs, SOC2, ADC_CHANNEL_V_AC1_N,		23, eAdcSoc_Trigger_ePWM8_SOCA);
    CONFIG_SOC(AdcbRegs, SOC3, ADC_CHANNEL_V_AC2_N,		23, eAdcSoc_Trigger_ePWM8_SOCA);
	
    /* Configure ADCa_INT1 Interrupt */
//    AdcbRegs.ADCINTSEL1N2.bit.INT1SEL = eAdcInt_Trigger_EOC1;  // End of EOC5 to trigger ADCa_INT1
//    AdcbRegs.ADCINTSEL1N2.bit.INT1E = 1;                       // Enable ADCa_INT1
//    AdcbRegs.ADCINTSEL1N2.bit.INT1CONT = 1;                    // Enable ADCa_INT1 continue mode
//    AdcbRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;                     // Make sure INT1 flag had been cleared
//
//    /* Check if overflow has occurred */
//    if (1 == AdcbRegs.ADCINTOVF.bit.ADCINT1)
//    {
//        AdcbRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
//    }
//
//    /*
//     *  Enable IER and PieCtrlRegs for ADCa_INT1
//     *  PIE Channel: 1.1
//     */
//    IER |= M_INT1;                                              // Enable PIE Group 1 interrupt
//    PieCtrlRegs.PIEIER1.bit.INTx2 = 1;                          // Enable ADCa_INT1 in the PIE Group 1
//
//    /* Re-mapped ADCa_INT1 interrupt function */
//    PieVectTable.ADCB1_INT = &ISR_ADCb_EOC;


    /* Power up the ADC */
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    
    /* Delay 1000us to allow ADC time to power up */
    DELAY_US(1000);
    
    EDIS;
}

/**
 *  @brief  Initial ADCc module
 *  @retval None
 */
static inline void PeriAdc_Initial_ADCc(void)
{
    EALLOW;
    
	/* Set ADCCLK divider to 2, 200M / 4 = 50MHz */
    AdccRegs.ADCCTL2.bit.PRESCALE = 6;
	    
    /* Set pulse positions to late, EOC trips after conversion completed */
    AdccRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    /* Configure each SOC of ADC
     *         ADCREG SOC_NUM      _CHSEL   		 _ACQPS 		_TRIGSEL
     */
    CONFIG_SOC(AdccRegs, SOC0, ADC_CHANNEL_I_PFC_C,     23, eAdcSoc_Trigger_ePWM6_SOCA);
    CONFIG_SOC(AdccRegs, SOC1, ADC_CHANNEL_V_PFC_DET,	23, eAdcSoc_Trigger_ePWM6_SOCA);
    CONFIG_SOC(AdccRegs, SOC2, ADC_CHANNEL_V_PFC_OVP1,	23, eAdcSoc_Trigger_ePWM6_SOCA);
	CONFIG_SOC(AdccRegs, SOC3, ADC_CHANNEL_V_PFC_OVP2,	23, eAdcSoc_Trigger_ePWM6_SOCA);
    CONFIG_SOC(AdccRegs, SOC4, ADC_CHANNEL_T_D2D,		23, eAdcSoc_Trigger_ePWM6_SOCA);
    CONFIG_SOC(AdccRegs, SOC5, ADC_CHANNEL_T_PFC,       23, eAdcSoc_Trigger_ePWM6_SOCA);
 
    /* Configure ADCa_INT1 Interrupt */
    AdccRegs.ADCINTSEL1N2.bit.INT1SEL = eAdcInt_Trigger_EOC1;  // End of EOC5 to trigger ADCa_INT1
    AdccRegs.ADCINTSEL1N2.bit.INT1E = 1;                       // Enable ADCa_INT1
    AdccRegs.ADCINTSEL1N2.bit.INT1CONT = 1;                    // Enable ADCa_INT1 continue mode
    AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;                     // Make sure INT1 flag had been cleared

    /* Check if overflow has occurred */
    if (1 == AdccRegs.ADCINTOVF.bit.ADCINT1)
    {
        AdccRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
    }

    /*
     *  Enable IER and PieCtrlRegs for ADCa_INT1
     *  PIE Channel: 1.1
     */
    IER |= M_INT1;                                              // Enable PIE Group 1 interrupt
    PieCtrlRegs.PIEIER1.bit.INTx3 = 1;                          // Enable ADCa_INT1 in the PIE Group 1

    /* Re-mapped ADCa_INT1 interrupt function */
    PieVectTable.ADCC1_INT = &ISR_ADCc_EOC;

 
    /* Power up the ADC */
    AdccRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    
    /* Delay 1000us to allow ADC time to power up */
    DELAY_US(1000);
    
    EDIS;
}



/**
 *  @brief  Initial ADC module - Set ADC configurations and power up the ADC 
 *          for ADC A and ADC B
 *  @retval None
 */
void PeriAdc_Initialize(void)
{

#ifdef DEMO_BOARD

    PinMux_init();
    ADC_setVREF(ADC_ADCA, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_3_3V);
    ADC_setVREF(ADC_ADCB, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_3_3V);
    ADC_setVREF(ADC_ADCC, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_3_3V);

    dl_adc_set_mode(ADCA_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
    dl_adc_set_mode(ADCB_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
    dl_adc_set_mode(ADCC_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
    ASysCtl_setAnalogReferenceExternal(ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC);
//    ASysCtl_setAnalogReferenceInternal(ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC);
//    ADC_enableConverter(ADC_ADCA);
//    ADC_enableConverter(ADC_ADCB);

#else
//    SetVREF(ADC_ADCA, ADC_EXTERNAL, ADC_VREF3P3);
//    SetVREF(ADC_ADCB, ADC_EXTERNAL, ADC_VREF3P3);
//    SetVREF(ADC_ADCC, ADC_EXTERNAL, ADC_VREF3P3);
//    adc_setup_conv(ADCA_BASE);
//    adc_setup_conv(ADCB_BASE);
//    adc_setup_conv(ADCC_BASE);

//    dl_adc_set_mode(ADCA_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
//    dl_adc_set_mode(ADCB_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
//    dl_adc_set_mode(ADCC_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
//    ASysCtl_setAnalogReferenceInternal(ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC);
    PinMux_init();
    ADC_setMode(ADC_ADCA, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
    ADC_setMode(ADC_ADCB, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
    ADC_setMode(ADC_ADCC, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
    ADC_setVREF(ADC_ADCA, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_3_3V);
    ADC_setVREF(ADC_ADCB, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_3_3V);
    ADC_setVREF(ADC_ADCC, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_3_3V);

#endif

    PeriAdc_Initial_ADCa();
    PeriAdc_Initial_ADCb();
	PeriAdc_Initial_ADCc();
}

/**
 *  @brief  Start peripheral - ADC
 *  @retval None
 */
void PeriAdc_Start(void)
{
    ;
}

/**
 *  @brief  Stop peripheral - ADC
 *  @retval None
 */
void PeriAdc_Stop(void)
{
    EALLOW;
    
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 0;
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 0;
	AdccRegs.ADCCTL1.bit.ADCPWDNZ = 0;
    DELAY_US(1000);

    /* Disable ADCa interrupt */
    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 0;
    
    /* Clear ADCa INT flag */
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

	/* Clear ADCa INT overflow flag */
	AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1;
    
    /* Disable ADCa interrupt in the PIE */
    PieCtrlRegs.PIEIER1.bit.INTx1 = 0;

    /* Acknowledge the PIE group 1 */
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
    
    EDIS;
}
