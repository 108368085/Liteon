/****************************************************************************
 *	File	Monitor_TP.h
 * 	Brief	
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/09/25 - 1st release
 ****************************************************************************/

#ifndef _MONITOR_TP_H
#define	_MONITOR_TP_H

#include "CONFIG_Define.h"
#include "SERV_Threshold.h"

/****************************************************************************
*	Public parameter definition
****************************************************************************/

#define GET_MOMITP_PFC_FLAG			tsMoniTP[MoniTP_Tag_PFC].nFlag.u16All
#define GET_MOMITP_INLET_FLAG		tsMoniTP[MoniTP_Tag_INLET].nFlag.u16All
#define GET_MOMITP_ATS_FLAG			tsMoniTP[MoniTP_Tag_ATS].nFlag.u16All
#define GET_MOMITP_D2D_FLAG			tsMoniTP[MoniTP_Tag_D2D].nFlag.u16All


#define GET_MOMITP_PFC_OTP			tsMoniTP[MoniTP_Tag_PFC].nFlag.u16Bits.u1OTP
#define GET_MOMITP_PFC_OTW			tsMoniTP[MoniTP_Tag_PFC].nFlag.u16Bits.u1OTW
#define GET_MOMITP_PFC_UTP			tsMoniTP[MoniTP_Tag_PFC].nFlag.u16Bits.u1UTP
#define GET_MOMITP_PFC_UTW			tsMoniTP[MoniTP_Tag_PFC].nFlag.u16Bits.u1UTW
#define GET_MOMITP_PFC_FIJ			tsMoniTP[MoniTP_Tag_PFC].nFlag.u16Bits.u1FIJ


#define GET_MOMITP_INLET_OTP		tsMoniTP[MoniTP_Tag_INLET].nFlag.u16Bits.u1OTP
#define GET_MOMITP_INLET_OTW		tsMoniTP[MoniTP_Tag_INLET].nFlag.u16Bits.u1OTW
#define GET_MOMITP_INLET_UTP		tsMoniTP[MoniTP_Tag_INLET].nFlag.u16Bits.u1UTP
#define GET_MOMITP_INLET_UTW		tsMoniTP[MoniTP_Tag_INLET].nFlag.u16Bits.u1UTW
#define GET_MOMITP_INLET_FIJ		tsMoniTP[MoniTP_Tag_INLET].nFlag.u16Bits.u1FIJ


#define GET_MOMITP_ATS_OTP			tsMoniTP[MoniTP_Tag_ATS].nFlag.u16Bits.u1OTP
#define GET_MOMITP_ATS_OTW			tsMoniTP[MoniTP_Tag_ATS].nFlag.u16Bits.u1OTW
#define GET_MOMITP_ATS_UTP			tsMoniTP[MoniTP_Tag_ATS].nFlag.u16Bits.u1UTP
#define GET_MOMITP_ATS_UTW			tsMoniTP[MoniTP_Tag_ATS].nFlag.u16Bits.u1UTW
#define GET_MOMITP_ATS_FIJ			tsMoniTP[MoniTP_Tag_ATS].nFlag.u16Bits.u1FIJ


#define GET_MOMITP_D2D_OTP			tsMoniTP[MoniTP_Tag_D2D].nFlag.u16Bits.u1OTP
#define GET_MOMITP_D2D_OTW			tsMoniTP[MoniTP_Tag_D2D].nFlag.u16Bits.u1OTW
#define GET_MOMITP_D2D_UTP			tsMoniTP[MoniTP_Tag_D2D].nFlag.u16Bits.u1UTP
#define GET_MOMITP_D2D_UTW			tsMoniTP[MoniTP_Tag_D2D].nFlag.u16Bits.u1UTW
#define GET_MOMITP_D2D_FIJ			tsMoniTP[MoniTP_Tag_D2D].nFlag.u16Bits.u1FIJ



#define GET_MOMITP_PFC_Temper_P		tsMoniTP[MoniTP_Tag_PFC].u16RealInstant
#define GET_MOMITP_INLET_Temper_P	tsMoniTP[MoniTP_Tag_INLET].u16RealInstant
#define GET_MOMITP_ATS_Temper_P		tsMoniTP[MoniTP_Tag_ATS].u16RealInstant
#define GET_MOMITP_D2D_Temper_P		tsMoniTP[MoniTP_Tag_D2D].u16RealInstant


#define GET_MOMITP_PFC_Temper		tsMoniTP[MoniTP_Tag_PFC].i16RealInstant
#define GET_MOMITP_INLET_Temper		tsMoniTP[MoniTP_Tag_INLET].i16RealInstant
#define GET_MOMITP_ATS_Temper		tsMoniTP[MoniTP_Tag_ATS].i16RealInstant
#define GET_MOMITP_D2D_Temper		tsMoniTP[MoniTP_Tag_D2D].i16RealInstant



// For Fault injection

#define SET_MOMITP_INLET_OTW_Latch		tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTW.eTriggerType = TriggerLatch
#define SET_MOMITP_INLET_OTW_Clear		tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTW.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_INLET_OTP_Latch		tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTP.eTriggerType = TriggerLatch
#define SET_MOMITP_INLET_OTP_Clear		tsMoniTP[MoniTP_Tag_INLET].sConfig.sOTP.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_INLET_UTW_Latch		tsMoniTP[MoniTP_Tag_INLET].sConfig.sUTW.eTriggerType = TriggerLatch
#define SET_MOMITP_INLET_UTW_Clear		tsMoniTP[MoniTP_Tag_INLET].sConfig.sUTW.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_INLET_UTP_Latch		tsMoniTP[MoniTP_Tag_INLET].sConfig.sUTP.eTriggerType = TriggerLatch
#define SET_MOMITP_INLET_UTP_Clear		tsMoniTP[MoniTP_Tag_INLET].sConfig.sUTP.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_ATS_OTW_Latch		tsMoniTP[MoniTP_Tag_ATS].sConfig.sOTW.eTriggerType = TriggerLatch
#define SET_MOMITP_ATS_OTW_Clear		tsMoniTP[MoniTP_Tag_ATS].sConfig.sOTW.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_ATS_OTP_Latch		tsMoniTP[MoniTP_Tag_ATS].sConfig.sOTP.eTriggerType = TriggerLatch
#define SET_MOMITP_ATS_OTP_Clear		tsMoniTP[MoniTP_Tag_ATS].sConfig.sOTP.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_ATS_UTW_Latch		tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTW.eTriggerType = TriggerLatch
#define SET_MOMITP_ATS_UTW_Clear		tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTW.eTriggerType = TriggerAutoRecover
#define SET_MOMITP_ATS_UTW_Disable		tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTW.eTriggerType = TriggerDisable

#define SET_MOMITP_ATS_UTP_Latch		tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTP.eTriggerType = TriggerLatch
#define SET_MOMITP_ATS_UTP_Clear		tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTP.eTriggerType = TriggerAutoRecover
#define SET_MOMITP_ATS_UTP_Disable		tsMoniTP[MoniTP_Tag_ATS].sConfig.sUTP.eTriggerType = TriggerDisable

#define SET_MOMITP_PFC_OTW_Latch		tsMoniTP[MoniTP_Tag_PFC].sConfig.sOTW.eTriggerType = TriggerLatch
#define SET_MOMITP_PFC_OTW_Clear		tsMoniTP[MoniTP_Tag_PFC].sConfig.sOTW.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_PFC_OTP_Latch		tsMoniTP[MoniTP_Tag_PFC].sConfig.sOTP.eTriggerType = TriggerLatch
#define SET_MOMITP_PFC_OTP_Clear		tsMoniTP[MoniTP_Tag_PFC].sConfig.sOTP.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_PFC_UTW_Latch		tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTW.eTriggerType = TriggerLatch
#define SET_MOMITP_PFC_UTW_Clear		tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTW.eTriggerType = TriggerAutoRecover
#define SET_MOMITP_PFC_UTW_Disable		tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTW.eTriggerType = TriggerDisable

#define SET_MOMITP_PFC_UTP_Latch		tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTP.eTriggerType = TriggerLatch
#define SET_MOMITP_PFC_UTP_Clear		tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTP.eTriggerType = TriggerAutoRecover
#define SET_MOMITP_PFC_UTP_Disable		tsMoniTP[MoniTP_Tag_PFC].sConfig.sUTP.eTriggerType = TriggerDisable

#define SET_MOMITP_D2D_OTW_Latch		tsMoniTP[MoniTP_Tag_D2D].sConfig.sOTW.eTriggerType = TriggerLatch
#define SET_MOMITP_D2D_OTW_Clear		tsMoniTP[MoniTP_Tag_D2D].sConfig.sOTW.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_D2D_OTP_Latch		tsMoniTP[MoniTP_Tag_D2D].sConfig.sOTP.eTriggerType = TriggerLatch
#define SET_MOMITP_D2D_OTP_Clear		tsMoniTP[MoniTP_Tag_D2D].sConfig.sOTP.eTriggerType = TriggerAutoRecover

#define SET_MOMITP_D2D_UTW_Latch		tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTW.eTriggerType = TriggerLatch
#define SET_MOMITP_D2D_UTW_Clear		tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTW.eTriggerType = TriggerAutoRecover
#define SET_MOMITP_D2D_UTW_Disable		tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTW.eTriggerType = TriggerDisable

#define SET_MOMITP_D2D_UTP_Latch		tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTP.eTriggerType = TriggerLatch
#define SET_MOMITP_D2D_UTP_Clear		tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTP.eTriggerType = TriggerAutoRecover
#define SET_MOMITP_D2D_UTP_Disable		tsMoniTP[MoniTP_Tag_D2D].sConfig.sUTP.eTriggerType = TriggerDisable


/****************************************************************************
*	Public macro definition
****************************************************************************/

/****************************************************************************
*	Public enumeration definition 
****************************************************************************/

typedef enum
{
	MoniTP_Tag_PFC = 0,
	MoniTP_Tag_INLET,
	MoniTP_Tag_ATS,
	MoniTP_Tag_D2D,
	MoniTP_Tag_Num
}eMoniTPTag_t;


/****************************************************************************
*	Public structure definition 
****************************************************************************/

typedef union
{
	u16_t u16All;
	struct
	{
		u16_t u1OTP					: 1;
		u16_t u1OTW 				: 1;
		u16_t u1UTP 				: 1;
		u16_t u1UTW					: 1;
		u16_t u1FIJ					: 1;	// 1: Enable fault inject, 0: Disable fault inject
		u16_t uReserved				: 11;
	}u16Bits;
}nMoniTPFlag_t;


typedef struct
{
	sSingleThreshold_t	sOTP;
	sSingleThreshold_t	sOTW;
	sSingleThreshold_t	sUTP;
	sSingleThreshold_t	sUTW;
}sMoniTPConfig_t;


typedef struct
{
	eMoniTPTag_t eTag;				// Source report identifier
	nMoniTPFlag_t nFlag;			// Monitor Flag
	sMoniTPConfig_t sConfig;		// Monitor Configuration

	/* Key Variable */
	u16_t* pu16ADC_Q12;				// ADC Q12 input value from SERV_ADCFilter
	i16_t  i16RealInstant;			// unit is 0.1 degreeC, with negative value
	u16_t  u16RealInstant;			// unit is 0.1 degreeC, only positive value (+40C) for modbus
	i16_t  i16RealMax;				// monitor Max temperature, unit is degreeC

}sMoniTP_t;

/****************************************************************************
*	Public export variable
****************************************************************************/
extern sMoniTP_t tsMoniTP[MoniTP_Tag_Num];

/****************************************************************************
*	Public export function prototype
****************************************************************************/
extern void MoniTP_Initialize(void);
extern sMoniTP_t* GetMoniTPRef(eMoniTPTag_t eTag);
extern void MoniTP_Set_TriggerType(u16_t u16Type);
extern void MoniTP_1s_Periodically_Process(void);


#endif
