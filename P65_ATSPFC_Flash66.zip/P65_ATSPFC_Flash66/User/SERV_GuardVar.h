/** @file       SERV_GuardVar.h
 *  @author     Ollie Chen
 *  @brief      This header is used to guard variables
 *  @version    1.0
 *  @date       
 */


#ifndef _SERV_GUARDVAR_H_
#define _SERV_GUARDVAR_H_

#include "CONFIG_Define.h"

/****************************************************************************
	Public macro definition
****************************************************************************/
#define GuardVarNode_Attr( _Index, _HostTag, _PrivyTag, _Var, _VarSize,     \
                            _CheckCallBack, _WriteCallBack)                 \
    [_Index] =                                                              \
    {                                                                       \
        .sLocalTag.u16HostIdentifier = _HostTag,                            \
        .sLocalTag.u16PrivyIdentifier = _PrivyTag,                          \
        .pVar = _Var,                                                       \
        .u16VarSize = _VarSize,                                             \
        .pfDataCheckRequestHandler = _CheckCallBack,                        \
        .pfDataWriteRequestHandler = _WriteCallBack,                        \
    }


/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
*   Public structure definition
****************************************************************************/

/**
    @brief  Access request structure
*/
typedef struct
{
	u16_t u16Offset;    ///< Offset of node attempted to start access
	u8_t* pu8Data;      ///< Data attempted to override
	u16_t u16Length;    ///< Bytes length of data
}sGuardVarAccessRequest_t;

/**
    @brief  Local tag is used to identify which guard variable node attempted 
            to access.
    @note   If the guard variable node had been integrated in an array, 
            user also could use marco "__OffsetOf" to identify it.
            
*/
typedef struct
{
	u16_t u16HostIdentifier;
	u16_t u16PrivyIdentifier;
}sLocalTagIdentifier_t;

/**
    @brief  Definition of Guard variable node structure
*/
typedef struct sGuardVarNode
{
	sLocalTagIdentifier_t sLocalTag;
	void* pVar;
	u16_t u16VarSize;
    u16_t (*pfDataCheckRequestHandler)(struct sGuardVarNode* psNode, sGuardVarAccessRequest_t sRequest);
	u16_t (*pfDataWriteRequestHandler)(struct sGuardVarNode* psNode, sGuardVarAccessRequest_t sRequest);
	struct sGuardVarNode* psNextNode;
}sGuardVarNode_t;

typedef struct
{
	u16_t u16NodeNumber;
	sGuardVarNode_t *psHeadNode;
	sGuardVarNode_t *psTailNode;
    void (*pfAccessNotificationHandler)(u16_t u16AccessResponse, sGuardVarNode_t* psAccessNode);
}sGuardVarList_t;

/****************************************************************************
	Public export variable 
****************************************************************************/

/****************************************************************************
*   public function prototype
****************************************************************************/
extern void GuardVarList_AppendNode(sGuardVarList_t *psList, sGuardVarNode_t* psNode);
extern u16_t GuardVarList_CheckRequest(sGuardVarList_t *psList, sGuardVarAccessRequest_t sCheckRequest);
extern u16_t GuardVarList_WriteRequest(sGuardVarList_t *psList, sGuardVarAccessRequest_t sAccessRequest);

#endif

