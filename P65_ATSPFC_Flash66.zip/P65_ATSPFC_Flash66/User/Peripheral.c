/****************************************************************************
 *	File	Peripheral.c
 *	Brief	Configure and control peripheral modules on TI 28004x platform
 *	Note
 *	Author	Adonis Wang
 *	Ver 	01
 *	History 2020/08/17 - 1st release
 ****************************************************************************/

/****************************************************************************
*	Included Files
****************************************************************************/

#include <CONFIG_RisingPower.h>
#include "Peripheral.h"

/****************************************************************************
    Private parameter definition
****************************************************************************/

/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 8
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Peripheral_Background_Process, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declaration
****************************************************************************/

/**
 *  @brief  Initial all used peripheral
 *  @retval None
 */
void Peripheral_Initialize(void)
{	
	/* Initial Peripheral - GPIO */
    PeriGPIO_Initialize();

    /* Initial Peripheral - CLA */
    init_cla_driver();

    /* Initial Peripheral - ADC */
    PeriAdc_Initialize();

    /* Initial Peripheral - DAC */
    PeriDac_Initialize();

    /* Initial Peripheral - CMPSS */
    PeriCmpss_Initialize();

	/* Initial Peripheral - EPWM */
	PeriEPwm_Initialize();
    
    /* Initial Peripheral - CPU Timer */
    PeriCpuTimer_Initialize();

#ifdef Enable_SCI
    /* Initial Peripheral - SCI */
     PeriSCI_Initialize();
#endif

    /* Initial Peripheral - I2C */
    // PeriI2C_Initialize();

#ifdef Enable_SPI
	/* Initial Peripheral - SPI */
	PeriSPI_Initialize();
#endif

#ifdef Enable_DCAN
	/* Initial Peripheral - DCAN */
	PeriCAN_Initialize();
#endif

#ifdef Enable_MCAN
    /* Initial Peripheral - MCAN */
    PeriMCAN_Initialize();
#endif

	/* Initial Peripheral - Flash */
	PeriFlash_Initialize();

}


/**
 *  @brief Start necessary peripheral
 *  @retval None
 */
void Peripheral_Start(void)
{
    PeriAdc_Start();
    PeriDac_Start();
	PeriCpuTimer_Start();
	PeriPWM_Start();
	enable_cla_driver();

#ifdef Enable_CMPSS
    PeriCmpss_Start();
#endif

#ifdef Enable_SPI
	PeriSPI_Start();
#endif

#ifdef Enable_SCI
    PeriSCI_Start();
#endif

#ifdef Enable_DCAN
	PeriCAN_Start();
#endif
    //PeriI2C_Start();
}

/**
 *  @brief  Stop necessary peripheral
 *  @retval None
 */
void Peripheral_Stop(void)
{
	PeriPWM_Stop();
	PeriCpuTimer_Stop();
    PeriAdc_Stop();
    PeriDac_Stop();

#ifdef Enable_DCAN
    PeriCAN_Stop();
#endif

#ifdef Enable_CMPSS
    PeriCmpss_Stop();
#endif

#ifdef Enable_SPI
	PeriSPI_Stop();
#endif

#ifdef Enable_SCI
	PeriSCI_Stop();
#endif

    //PeriI2C_Stop();
    SET_GPIO_D2D_DIS; // Turn off D2D after disable modbus for D2D UVP issue when ATS bootloader
}

/**
 *  @brief  Peripheral background process
 *  @retval None
 */
void Peripheral_Background_Process(void)
{

#ifdef Enable_SPI
	PeriSPI_Background_Process();
#endif

#ifdef Enable_SCI
    PeriSCI_Background_Process();
#endif

#ifdef Enable_DCAN
	PeriCAN_Background_Process();
#endif

#ifdef Enable_MCAN
    PeriMCAN_Background_Process();
#endif

	//PeriI2C_Background_Process();
}


