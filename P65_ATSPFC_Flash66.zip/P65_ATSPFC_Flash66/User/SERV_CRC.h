/*******************************************************************************
* file				SERV_CRC.h
* brief				The file includes CRC8 checksum of the PMBus.
* note
* author			Adonis Wang
* version			02
* section History	2014/09/01 - 1st release by slade fang
*******************************************************************************/
#ifndef _SERV_CRC_H_
#define _SERV_CRC_H_

#include "CONFIG_Define.h"

/*******************************************************************************
* declare extern function
*******************************************************************************/
extern void CalCRC8(u8_t *pu8CRC, u8_t u8Data);
extern u16_t CalCRC16(u16_t u16seed, u8_t *pu8Msg, u16_t u16DataLen, u8_t u8SwapValue);
/*******************************************************************************
* end of file
*******************************************************************************/

#endif 

