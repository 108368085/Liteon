/****************************************************************************
 *	File	SERV_Calibration.h
 * 	Brief	Head file for Calibration function
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/10/06
 ****************************************************************************/

#ifndef _SERV_CALIBRATION_H_
#define _SERV_CALIBRATION_H_

#include "CONFIG_Define.h"

/****************************************************************************
	Public parameter definition 
****************************************************************************/
#define CALIBRATION_KEY				"Lion"
#define CALIBRATION_KEY_LENGTH		4


#define GET_CALI_KEY				tsCalibrationHandler.pu8CalibrationKey
#define SET_CALI_KEY_OK				tsCalibrationHandler.u8CalibrationkeyOK


#define GET_CALI_VS1_Gain			ptsCaliCoeff[eCalibration_Tag_VS1].f32CaliGain			
#define GET_CALI_VS2_Gain			ptsCaliCoeff[eCalibration_Tag_VS2].f32CaliGain
#define GET_CALI_PFC_Gain			ptsCaliCoeff[eCalibration_Tag_VPFC].f32CaliGain
#define GET_CALI_BUS_Gain			ptsCaliCoeff[eCalibration_Tag_VBus].f32CaliGain
#define GET_CALI_IAC_Gain			ptsCaliCoeff[eCalibration_Tag_Current].f32CaliGain




/****************************************************************************
*	Public macro Definition
****************************************************************************/
#define CALI_OFFSET_QFORMAT         (12)
#define CALI_OFFSET_GAIN            Q12_

#define CALI_SLOPE_QFORMAT          (12)
#define CALI_SLOPE_GAIN             Q12_

/****************************************************************************
*	Public enumeration definition
****************************************************************************/
typedef enum eCalibrationTag
{
    eCalibration_Tag_VS1 = 0,
    eCalibration_Tag_VS2,
    eCalibration_Tag_VPFC,
    eCalibration_Tag_Current,
    eCalibration_Tag_VAuxiliary,
    eCalibration_Tag_VBus,
    eCalibration_Tag_Num,
}eCalibrationTag_t;

/****************************************************************************
*	Public structure definition
****************************************************************************/

/** Calibrate coefficient structure */
typedef struct sCaliCoeff
{
    u16_t u16Slope;		// unit is 1 V/A * Q12
    i16_t i16Offset;	// unit is 1 V/A * Q12, range -8~+8
    i32_t i32HwGain;	// Real value to ADC input(3.3V) gain
    f32_t f32CaliGain;	// Real value to ADC input(3.3V) gain = HwGain*Slope
}sCaliCoeff_t;

typedef struct sCalibrationHandler
{
	u8_t u8CalibrationkeyOK;	// 0: calibration key NOK, 1: calibration key OK
    u8_t pu8CalibrationKey[CALIBRATION_KEY_LENGTH];
}sCalibrationHandler_t;

/****************************************************************************
*	Public variables
****************************************************************************/
extern sCalibrationHandler_t tsCalibrationHandler;
extern sCaliCoeff_t ptsCaliCoeff[eCalibration_Tag_Num];

/****************************************************************************
*	Public functions
****************************************************************************/
extern u16_t Calibration_IsValidCoefficient(void);
extern void Calibration_ResetCoefficient(eCalibrationTag_t eTag);
extern void Calibration_StoreCoefficient(eCalibrationTag_t eTag);
extern void Calibration_SetCoefficient(eCalibrationTag_t eTag, u16_t u16Slope, i16_t i16Offset);
extern sCaliCoeff_t* Calibration_GetCoefficient(eCalibrationTag_t eTag);
extern u16_t Calibration_IsValidManufacturerKey(u8_t* pu8Key);
extern void Calibration_Initialize(void);

#endif
