/** @file       E2P_Waveform.h
 *  @brief      Header file for Waveform feature
 *  @author     Adonis Wang
 *  @version    2.0
 *  @date       
 */
 
#ifndef _E2P_WAVEFORM_H_
#define _E2P_WAVEFORM_H_

#include "CONFIG_Define.h"

/****************************************************************************
	Public parameter definition 
****************************************************************************/
#define WaveformSampleChannels      	2           // Support to recorder 4 channel data: VAC1,VAC2,VPFC,IPFC
#define WaveformSampleQuantities    	1000        // 100ms (-50ms~+50ms), unit is 100us, Each channel sample quantities in per waveform log

/****************************************************************************
	Public macro Definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/
typedef struct sWaveformProbeConfig
{
    u16_t* pu16Source[WaveformSampleChannels];    //Point to tsLog.u8InstantValue
}sWaveformProbeConfig_t;

typedef struct sChannelLog
{
    u16_t u16Value[WaveformSampleChannels];
}sChannel_t;

typedef struct sWaveformMonitor
{
    sWaveformProbeConfig_t sConfig;
    u16_t u16RollingIndex;
    sChannel_t psLogs[WaveformSampleQuantities];
}sWaveformMonitor_t;


typedef union nRecorderFlag
{
    u16_t u16All;
    struct
    {
        u16_t u1BlackBox_Recording  : 1;
		u16_t u1Capture_Recording	: 1;
        u16_t u15Reserved       	: 14;
    }u16Bits;
}nRecorderFlag_t;

typedef struct sWaveformRecorderConfig
{
    u8_t* pu8Destination;		//Point to tsBlackBoxHandler.sRecorder.pu8Data[] waveform start address
}sWaveformRecorderConfig_t;

typedef struct sWaveformRecorder
{
	u16_t u16RecordIndex;
    nRecorderFlag_t nFlag;
    sWaveformRecorderConfig_t sConfig;
}sWaveformRecorder_t;


/****************************************************************************
	Public variables
****************************************************************************/


/****************************************************************************
	Public function
****************************************************************************/

extern void Waveform_10k_Instant_Process(void);
extern void Waveform_Record(void);
extern void Waveform_StartCapture(void);
extern void Waveform_Address_Setting(sWaveformRecorderConfig_t sRecorderConfig);
extern void Waveform_ConfigureProbe(sWaveformProbeConfig_t sProbeConfig);
extern void Waveform_Initialize(void);

#endif

