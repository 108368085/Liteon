/****************************************************************************
 *	File	Peripheral_SCI.h
 * 	Brief	Header file for Peripheral SCI module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/08/17 - modify by Ollie chen
 ****************************************************************************/

#ifndef _PERIPHERAL_SCI_H_
#define _PERIPHERAL_SCI_H_

#include "ModBus_UartDriver.h"
#include "Peripheral.h"
#include "CONFIG_Define.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/
#define USE_SCI_CHANNEL_A
//#define USE_SCI_CHANNEL_B


#ifdef USE_SCI_CHANNEL_A
#define SCI_CHANNEL_A_TX_MUX_SEL    15
#define SCI_CHANNEL_A_TX_PIN_NUM    GPIO_PIN_42
#define SCI_CHANNEL_A_RX_MUX_SEL    15
#define SCI_CHANNEL_A_RX_PIN_NUM    GPIO_PIN_43
#define SCI_CHANNEL_A_BAUD_RATE     9600
#endif

#ifdef USE_SCI_CHANNEL_B
#define SCI_CHANNEL_B_TX_MUX_SEL    6
#define SCI_CHANNEL_B_TX_PIN_NUM    GPIO_PIN_12
#define SCI_CHANNEL_B_RX_MUX_SEL    6
#define SCI_CHANNEL_B_RX_PIN_NUM    GPIO_PIN_13
#define SCI_CHANNEL_B_BAUD_RATE     9600
#endif

/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/
typedef enum ePeripheral_SCI_Channel
{

#ifdef USE_SCI_CHANNEL_A
    ePeriSCI_Channel_A,
#endif

#ifdef USE_SCI_CHANNEL_B
    ePeriSCI_Channel_B,
#endif

    ePeriSCI_Channel_Num,
}ePeripheral_SCI_Channel_t;

/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/
extern const sUartDriverInterface_t gtUartDriverInterface;

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void PeriSCI_Initialize(void);
extern void PeriSCI_Start(void);
extern void PeriSCI_Stop(void);
extern void PeriSCI_Background_Process(void);
extern void PeriSCI_1ms_Periodically_Process(void);


#endif
