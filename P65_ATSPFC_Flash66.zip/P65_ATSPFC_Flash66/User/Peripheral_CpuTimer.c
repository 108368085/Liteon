/****************************************************************************
 *	File	Peripheral_CpuTimer.c
 * 	Brief	Configure and control CPU timer module on TI 28004x platform
 * 	Note	- CpuTimer1 : 10KHz
 *			- CpuTimer2 : 1KHz
 *			- CpuTimer2 : Variable Frequency for FFT
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

#include <string.h>
#include "F28x_Project.h"
#include "Peripheral_CpuTimer.h"
#include "sw_prioritized_isr_levels.h"
#include "SysTime.h"
#include "SERV_FFT.h"


/****************************************************************************
    Private parameter definition
****************************************************************************/

#define CPU_TIMER_10KHz_PERIOD		(CPU_TIMER_CLOCK_BASE/CPU_TIMER_10KHz_FREQUENCY)	// Unit is us
#define CPU_TIMER_1KHz_PERIOD		(CPU_TIMER_CLOCK_BASE/CPU_TIMER_1KHz_FREQUENCY)		// Unit is us


/****************************************************************************
	Private macro definition
****************************************************************************/

/****************************************************************************
	Private enumeration definition 
****************************************************************************/

/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 139
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(ISR_CpuTimer0_10KHz, ".TI.ramfunc");
#pragma CODE_SECTION(ISR_CpuTimer1_1KHz, ".TI.ramfunc");
#pragma CODE_SECTION(ISR_CpuTimer2_FFT, ".TI.ramfunc");
#endif


/****************************************************************************
	Private variable declaration
****************************************************************************/


/**
 *  @brief  Interrupt for timer0
 *  @note   All callback function of subscriber which register to interrupt timer
 *          would be run in the interrupt
 *  @retval None
 */
__interrupt void ISR_CpuTimer0_10KHz(void)
{
    /* Branch mechanism code Start */
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER1.all;       // Store PIE IER
    IER |= M_INT1;
    IER &= MINT1;                                               // Set "global" priority
    PieCtrlRegs.PIEIER1.all &= MG1_7;                           // Set "group"  priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;                            // Enable PIE interrupts
    __asm("  NOP");
    EINT;

    /* User code Start */


	INTERRUPT_10kHz();


    /* User code End */

    DINT;
    PieCtrlRegs.PIEIER1.all = TempPIEIER;

    /* Branch mechanism code End */
}

/**
 *  @brief  Interrupt for timer1
 *  @retval None
 */
__interrupt void ISR_CpuTimer1_1KHz(void)
{
        
    IER |= MINT13;                                          // Set "global" priority                   
    EINT;

	/* User code Start */
	GET_SYSTEM_1K_CNT = 1;
} 

/**
 *  @brief  Interrupt for timer2
 *  @retval None
 */
__interrupt void ISR_CpuTimer2_FFT(void)
{       
    IER |= MINT14;                                          // Set "global" priority                   
    EINT;

	/* User code Start */
	FFT_Timercallback();
} 

/**
 *  @brief  Initial used CpuTimer module
 *  @retval None
 */
void PeriCpuTimer_Initialize(void)
{

    /* Initialize all three CPU timers to a known state , it had been declared in source/platform */
    InitCpuTimers();
    
    /* Configure CPU timer 
	 *                Regs,          100MHz CPU Freq,        Period in uSeconds
	 */
    ConfigCpuTimer(&CpuTimer0, CPU_TIMER_FREQUENCY_IN_MHZ, CPU_TIMER_10KHz_PERIOD);
	ConfigCpuTimer(&CpuTimer1, CPU_TIMER_FREQUENCY_IN_MHZ, CPU_TIMER_1KHz_PERIOD);
	ConfigCpuTimer(&CpuTimer2, CPU_TIMER_FREQUENCY_IN_MHZ, CPU_TIMER_1KHz_PERIOD);

    /*
     * To ensure precise timing, use write-only instructions to write to the
     * entire register. Therefore, if any of the configuration bits are changed
     * in ConfigCpuTimer and InitCpuTimers, the below settings must also be
     * be updated.
     */
    CpuTimer0Regs.TCR.all = 0x4000;
    CpuTimer1Regs.TCR.all = 0x4000;
    CpuTimer2Regs.TCR.all = 0x4000;

    /*
     * Enable IER of CPU Timer
     * CPU int1  which is connected to CPU-Timer 0
     * CPU int13 which is connected to CPU-Timer 1
     * CPU int14 which is connected to CPU-Timer 2
     */
    IER |= M_INT1;		// Enable PIE Group 1  interrupt
    IER |= M_INT13;		// Enable PIE Group 13 interrupt
    IER |= M_INT14;		// Enable PIE Group 14 interrupt

    /*
     * Enable TINT0 in the PIE: Group 1 interrupt 7
     */
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

    /*
     * Re-mapped ISR functions
     */     
    EALLOW;
    PieVectTable.TIMER0_INT = &ISR_CpuTimer0_10KHz;
    PieVectTable.TIMER1_INT = &ISR_CpuTimer1_1KHz;
    PieVectTable.TIMER2_INT = &ISR_CpuTimer2_FFT;
    EDIS;

}


/**
 *  @brief  Start peripheral - CPU Timer
 *  @retval None
 */
void PeriCpuTimer_Start(void)
{
	StartCpuTimer0();
	StartCpuTimer1();
	//StartCpuTimer2();
}

/**
 *  @brief  Stop peripheral - CPU Timer
 *  @retval None
 */
void PeriCpuTimer_Stop(void)
{
    StopCpuTimer0();
	StopCpuTimer1();
	StopCpuTimer2();
}
