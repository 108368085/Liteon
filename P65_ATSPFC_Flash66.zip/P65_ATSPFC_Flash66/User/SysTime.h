/****************************************************************************
 *	File	SysTime.h
 * 	Brief	used to get the system time
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/08/17 - 2nd release
 *		-	2014/04/09: initial version by allen lee
 ****************************************************************************/


#ifndef _SYSTIME_H_
#define	_SYSTIME_H_

#include "CONFIG_Define.h"



/****************************************************************************
    Public parameter definition
****************************************************************************/

#define GET_SYSTEM_1K_CNT		tsSysTimer.u16SysTimeBase


/****************************************************************************
	Public macro definition
****************************************************************************/


/****************************************************************************
	Public enumeration definition 
****************************************************************************/


/****************************************************************************
*	Public structure definition 
****************************************************************************/

typedef struct
{	
	volatile u16_t u16SysTimeBase;	//unit ms
    u16_t u16Sys_1ms;
	u16_t u16Sys_10ms;
	u16_t u16Sys_100ms;
	u16_t u16Sys_1sec;
	u16_t u16Sys_1min;
	u16_t u16Sys_1hour;
} sSysTimer_t;

/****************************************************************************
*	Public export variable
****************************************************************************/

extern sSysTimer_t  tsSysTimer;

/****************************************************************************
*	Public export function prototype
****************************************************************************/
extern void INTERRUPT_ADC(void);
extern void INTERRUPT_10kHz(void);
extern void SysTime(void);
extern void Service_Initialize(void);

#endif
