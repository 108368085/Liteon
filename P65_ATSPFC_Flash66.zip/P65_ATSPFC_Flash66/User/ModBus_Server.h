/** @file       ModBus_Server.h
 *  @author     Ollie Chen
 *  @brief      Header file for ModBus Server
 *  @version    1.0
 *  @date       2017-10-25
*/
 
#ifndef _MODBUS_SERVER_H_
#define _MODBUS_SERVER_H_

#include "CONFIG_Define.h"
#include "SERV_GuardVar.h"
#include "ModBus_UartDriver.h"

/****************************************************************************
	Public macro definition
****************************************************************************/
/* ModBus Broadcast address */
#define MBUS_BROADCAST_ADDRESS              0x00
	
/**
*	ModBus module supported function code 
*	- Read Coils
*	- Read Holding Registers
*	- Read Input Registers
*	- Write Single Holding Register
*	- Write Multiple Holding Register
*	@defgroup ModBusFunctionCode ModBus supported function code
*/
#define MBUS_FC_READ_COILS                  0x01
#define MBUS_FC_READ_HOLDING                0x03
#define MBUS_FC_READ_INPUT                  0x04
#define MBUS_FC_WRITE_SINGLE_HOLDING        0x06
#define MBUS_FC_WRITE_MULTIPLE_HOLDING      0x10


/* MBus Common Configuration */
#define MBUS_CRC_SEED                       0xFFFF
#define MBUS_CRC_SWAP                       1
	
#define MBUS_MAX_QUAN_READ_COIL             2000    ///< Maximum Quantities of Read Coil register
#define MBUS_QUAN_READ_REGISTER         	30     	///< Quantities of Read register
#define MBUS_MAX_QUAN_READ_REGISTER         125     ///< Maximum Quantities of Read register
#define MBUS_QUAN_WRITE_REGISTER        	30     	///< Quantities of Write register (Holding)
#define MBUS_MAX_QUAN_WRITE_REGISTER        123     ///< Maximum Quantities of Write register (Holding)


/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/* Enumerate the ModBus server interface */
enum eMBusServerInterface
{
    eMBusServer_IF_Secondary = 0,       ///< ModBus Server which communicate with Secondary MCU
    eMBusServer_IF_Num,                 ///< Total ModBus server number
};


/* MosBus Request Exceptions */
typedef enum
{
    MBUS_EXCEPTION_NONE = 0x00,
    MBUS_EXCEPTION_UNSUPPORT_FUNCTION,  ///< Function Code is unsupported
    MBUS_EXCEPTION_INVALID_ADDRESS,     ///< The inquiring register address is invalid
    MBUS_EXCEPTION_INVALID_DATA,        ///< Data value is invalid
    MBUS_EXCEPTION_REQUEST_FAIL,        ///< The request is denied by ModBus server
}eMBUS_REQ_EXCEPTIONS_t;

/****************************************************************************
*   Public structure definition
****************************************************************************/

/****************************************************************************
	Public export variable 
****************************************************************************/

/****************************************************************************
*   public function prototype
****************************************************************************/
extern void MBusServer_Initialize(void);
extern void MBusServer_Background_Process(void);
extern void MBusServer_10ms_Periodically_Process(void);

 #endif
