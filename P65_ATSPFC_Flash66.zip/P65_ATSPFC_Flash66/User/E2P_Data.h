/****************************************************************************
 *	File	E2P_Data.h
 * 	Brief	Header file for E2pData
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		02
 * 	History	2020/12/25 - Modify from Ollie Chen
 ****************************************************************************/
 
#ifndef _E2P_DATA_H_
#define _E2P_DATA_H_

#include "CONFIG_Define.h"
#include "E2P_Driver.h"

/****************************************************************************
	Public parameter definition
****************************************************************************/

#define GET_E2P_CLEAR_DATA			tsE2pDataManager.u8ClearE2PDATA



/* EEPROM data map*/

// 0
#define E2pDataIndex_CaliVS1_Password      			0
#define E2pDataSize_CaliVS1_Password				1	// length unit is word

// 1
#define E2pDataIndex_CaliVS1_Slope		    		(E2pDataIndex_CaliVS1_Password + E2pDataSize_CaliVS1_Password)
#define E2pDataSize_CaliVS1_Slope					1

// 2
#define E2pDataIndex_CaliVS1_Offset					(E2pDataIndex_CaliVS1_Slope + E2pDataSize_CaliVS1_Slope)
#define E2pDataSize_CaliVS1_Offset					1

// 3
#define E2pDataIndex_CaliVS2_Password	    		(E2pDataIndex_CaliVS1_Offset + E2pDataSize_CaliVS1_Offset)
#define E2pDataSize_CaliVS2_Password				1

// 4
#define E2pDataIndex_CaliVS2_Slope		    		(E2pDataIndex_CaliVS2_Password + E2pDataSize_CaliVS2_Password)
#define E2pDataSize_CaliVS2_Slope					1

// 5
#define E2pDataIndex_CaliVS2_Offset					(E2pDataIndex_CaliVS2_Slope + E2pDataSize_CaliVS2_Slope)
#define E2pDataSize_CaliVS2_Offset					1

// 6
#define E2pDataIndex_CaliIAC_Password	    		(E2pDataIndex_CaliVS2_Offset + E2pDataSize_CaliVS2_Offset)
#define E2pDataSize_CaliIAC_Password				1

// 7
#define E2pDataIndex_CaliIAC_Slope		    		(E2pDataIndex_CaliIAC_Password + E2pDataSize_CaliIAC_Password)
#define E2pDataSize_CaliIAC_Slope					1

// 8
#define E2pDataIndex_CaliIAC_Offset					(E2pDataIndex_CaliIAC_Slope + E2pDataSize_CaliIAC_Slope)
#define E2pDataSize_CaliIAC_Offset					1

// 9
#define E2pDataIndex_CaliVBulk_Password	    		(E2pDataIndex_CaliIAC_Offset + E2pDataSize_CaliIAC_Offset)
#define E2pDataSize_CaliVBulk_Password				1

// 10
#define E2pDataIndex_CaliVBulk_Slope		    	(E2pDataIndex_CaliVBulk_Password + E2pDataSize_CaliVBulk_Password)
#define E2pDataSize_CaliVBulk_Slope					1

// 11
#define E2pDataIndex_CaliVBulk_Offset				(E2pDataIndex_CaliVBulk_Slope + E2pDataSize_CaliVBulk_Slope)
#define E2pDataSize_CaliVBulk_Offset				1

// 12
#define E2pDataIndex_CaliVPFC_Password	    		(E2pDataIndex_CaliVBulk_Offset + E2pDataSize_CaliVBulk_Offset)
#define E2pDataSize_CaliVPFC_Password				1

// 13
#define E2pDataIndex_CaliVPFC_Slope		    		(E2pDataIndex_CaliVPFC_Password + E2pDataSize_CaliVPFC_Password)
#define E2pDataSize_CaliVPFC_Slope					1

// 14
#define E2pDataIndex_CaliVPFC_Offset				(E2pDataIndex_CaliVPFC_Slope + E2pDataSize_CaliVPFC_Slope)
#define E2pDataSize_CaliVPFC_Offset					1

// 15
#define E2pDataIndex_Reserved_Offset				(E2pDataIndex_CaliVPFC_Offset + E2pDataSize_CaliVPFC_Offset)
#define E2pDataSize_Reserved_Offset					6

// 21
#define E2pDataIndex_TotATSwitchCNT                 (E2pDataIndex_Reserved_Offset + E2pDataSize_Reserved_Offset)
#define E2pDataSize_TotATSwitchCNT                  2

// 23
#define E2pDataIndex_TotPowerOnTime                 (E2pDataIndex_TotATSwitchCNT + E2pDataSize_TotATSwitchCNT)
#define E2pDataSize_TotPowerOnTime                  2

// 25
#define E2pDataIndex_BlackBox_EventNumber           (E2pDataIndex_TotPowerOnTime + E2pDataSize_TotPowerOnTime)
#define E2pDataSize_BlackBox_EventNumber            1

// 26
#define E2pDataIndex_BlackBox_LatestIndex           (E2pDataIndex_BlackBox_EventNumber + E2pDataSize_BlackBox_EventNumber)
#define E2pDataSize_BlackBox_LatestIndex            1

// 27
#define E2pDataIndex_Manufacture_Password           (E2pDataIndex_BlackBox_LatestIndex + E2pDataSize_BlackBox_LatestIndex)
#define E2pDataSize_Manufacture_Password            1

// END
#define E2pDataNum                                  (E2pDataIndex_Manufacture_Password + E2pDataSize_Manufacture_Password)

/****************************************************************************
	Public macro definition
****************************************************************************/
#define E2PDATA_START_ADDRESS           0x0100          // start at page 4 (256)
#define E2PDATA_NUM                     E2pDataNum

#define E2PDATA_RETRY_TIMES             3               // Retry times when read EEPROM data to ram failed

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

/****************************************************************************
	Public structure definition 
****************************************************************************/

typedef union nE2pDataFlag
{
    u16_t u16All;
    struct
    {
        u16_t u1DataAccessing       : 1;
        u16_t u15Reserved           : 15;
    }u16Bits;
}nE2pDataFlag_t;

typedef struct sE2pDataManager
{
    nE2pDataFlag_t nFlag;
    sE2pDriverInfo_t* psE2pDriver;
    u16_t u16PushIndex;
    u16_t u16WriteIndex;
	u16_t u16E2PDATA_NUM;
    u8_t  u8ClearE2PDATA;  //1:reset EEPROM value; 0: do nothing
    u16_t pu16E2pDataIndex[E2PDATA_NUM];
    
#ifndef TI_C28_PLATFORM

    u16_t pu16E2pDataBuff[E2PDATA_NUM];
#else
    u16_t pu16E2pDataBuff[E2PDATA_NUM*2];
    u8_t pu8E2pDataInRam[E2PDATA_NUM*2];
#endif


}sE2pDataManager_t;


/****************************************************************************
	Public export variable
****************************************************************************/
extern sE2pDataManager_t tsE2pDataManager;
extern u16_t pu16E2pDataInRam[E2PDATA_NUM];

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void E2pData_Initialize(void);
extern void E2pData_Background_Process(void);
extern u16_t E2pData_PushData(u16_t u16E2pIndex, u16_t u16E2pData);
extern void E2pData_Clear(void);

#endif
