/********************************************************************************
* file              cla_diver.c
* brief
* note
* author            Darren ZW Chen
* version           01
* section History   2023/05/03  -   1st release
********************************************************************************/

#include <CLA_Control_PFC.h>
#include "cla_driver.h"
#include "CPU.h"
#include "driverlib.h"
#include "string.h"

__interrupt void cla1Isr1();
__interrupt void cla1Isr8();

/*******************************************************************************
*   name:   init_cla_driver
*   brief:  initialization of the cla driver
*   note:   adc triggered
*******************************************************************************/
void init_cla_driver(void)
{
    extern uint32_t Cla1ProgRunStart, Cla1ProgLoadStart, Cla1ProgLoadSize;
    extern uint32_t Cla1ConstRunStart, Cla1ConstLoadStart, Cla1ConstLoadSize;

    EALLOW;
    Cla1Regs.MCTL.bit.HARDRESET = 1;
    // Wait for few cycles till the reset is complete
    NOP;
    NOP;
    NOP;

    /************ Memory and Flash Configuration ***************/
    #ifdef _FLASH
    /* Copy over code from FLASH to RAM */
    memcpy((uint32_t *)&Cla1ProgRunStart, (uint32_t *)&Cla1ProgLoadStart, (uint32_t)&Cla1ProgLoadSize);
    memcpy((uint32_t *)&Cla1ConstRunStart, (uint32_t *)&Cla1ConstLoadStart, (uint32_t)&Cla1ConstLoadSize);
    #endif

    /* Initialize and wait for CLA1ToCPUMsgRAM */
    MemCfgRegs.MSGxINIT.bit.INIT_CLA1TOCPU = 1;
    while(MemCfgRegs.MSGxINITDONE.bit.INITDONE_CLA1TOCPU != 1);

    /* Initialize and wait CPUToCLA1MsgRAM */
    MemCfgRegs.MSGxINIT.bit.INIT_CPUTOCLA1 = 1;
    while(MemCfgRegs.MSGxINITDONE.bit.INITDONE_CPUTOCLA1 != 1);

    /*Select LS0 as a programming space for the CLA*/
    MemCfgRegs.LSxMSEL.bit.MSEL_LS0 = 1;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS0 = 1;

    MemCfgRegs.LSxMSEL.bit.MSEL_LS1 = 1;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS1 = 1;

    MemCfgRegs.LSxMSEL.bit.MSEL_LS2 = 1;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS2 = 0;

    /************ Function task Configuration ***************/
    /*  Compute all CLA task vectors
     *  On Type-1 CLAs the MVECT registers accept full 16-bit task addresses as
     *  opposed to offsets used on older Type-0 CLAs
     */
    #pragma diag_suppress 770   //Disable Compiler show this warning
    Cla1Regs.MVECT1 = (uint16_t)(&ClaTask1);
//    Cla1Regs.MVECT2 = (uint16_t)(&ClaTask2);
//    Cla1Regs.MVECT3 = (uint16_t)(&ClaTask3);
//    Cla1Regs.MVECT4 = (uint16_t)(&ClaTask4);
//    Cla1Regs.MVECT5 = (uint16_t)(&ClaTask5);
//    Cla1Regs.MVECT6 = (uint16_t)(&ClaTask6);
//    Cla1Regs.MVECT7 = (uint16_t)(&ClaTask7);
    Cla1Regs.MVECT8 = (uint16_t)(&ClaTask8);
    #pragma diag_default 770   //Enable Compiler show this warning
    /*  Enable the IACK instruction to start a task on CLA in software
     *  for all 8 CLA tasks. Also, globally enable all 8 tasks (or abort
     *  subset of tasks) by writing to their respective bits in the MIER
     *  register
     */



    /*  Configure the vectors for the end-of-task interrupt for all
     *  8 tasks
     */
//    PieVectTable.CLA1_1_INT = &PeriCLA_Interrupt_EndOfClaTask1;
//    PieVectTable.CLA1_2_INT = &PeriCLA_Interrupt_EndOfClaTask2;
//    PieVectTable.CLA1_3_INT = &PeriCLA_Interrupt_EndOfClaTask3;
//    PieVectTable.CLA1_4_INT = &PeriCLA_Interrupt_EndOfClaTask4;
//    PieVectTable.CLA1_5_INT = &PeriCLA_Interrupt_EndOfClaTask5;
//    PieVectTable.CLA1_6_INT = &PeriCLA_Interrupt_EndOfClaTask6;
//    PieVectTable.CLA1_7_INT = &PeriCLA_Interrupt_EndOfClaTask7;
//    PieVectTable.CLA1_8_INT = &PeriCLA_Interrupt_EndOfClaTask8;

    /* Auto Trigger for task1 */
//    DmaClaSrcSelRegs.CLA1TASKSRCSEL1.bit.TASK1 = 1; //ADCA1 Triggered task1
//    DmaClaSrcSelRegs.CLA1TASKSRCSEL2.bit.TASK8 = 0U; //Software
//    Cla1Regs.MIER.bit.INT1 = 1;
//    Cla1Regs.MIER.bit.INT8 = 1;
//    Cla1Regs.MCTL.bit.IACKE = 1;
//    IER |= (M_INT11);
    EDIS;
}

/*******************************************************************************
*   name:   enable_cla_driver
*   brief:  none
*   note:   none
*******************************************************************************/
void enable_cla_driver(void)
{
    EALLOW;
    DmaClaSrcSelRegs.CLA1TASKSRCSEL1.bit.TASK1 = 11; //ADC-C_INT1 Triggered task1ZA
    DmaClaSrcSelRegs.CLA1TASKSRCSEL2.bit.TASK8 = 0;  //software Triggered task8
    Cla1Regs.MIER.bit.INT1 = 1;
    Cla1Regs.MIER.bit.INT8 = 1;
    Cla1Regs.MCTL.bit.IACKE = 1;
    EDIS;

    memset(&CpuToClaMessage, 0, sizeof(sCpuToClaMessage_t));

    /* Initial CLA variable */
    Cla1ForceTask8andWait();
}

/*******************************************************************************
*   name:   disable_cla_driver
*   brief:  none
*   note:   let the application layer disable the cla driver
*******************************************************************************/
void disable_cla_driver(void)
{
    EALLOW;
    DmaClaSrcSelRegs.CLA1TASKSRCSEL1.bit.TASK1 = 0;
    DmaClaSrcSelRegs.CLA1TASKSRCSEL2.bit.TASK8 = 0;
    Cla1Regs.MCTL.bit.IACKE = 0;
    Cla1Regs.MIER.all = 0;
    MemCfgRegs.LSxMSEL.all = 0;
    MemCfgRegs.LSxCLAPGM.all = 0;
    EDIS;
}
