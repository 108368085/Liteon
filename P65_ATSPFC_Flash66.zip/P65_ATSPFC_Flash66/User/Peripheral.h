/****************************************************************************
 *	File	Peripheral.h
 * 	Brief	Header file for peripheral
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

#ifndef _PERIPHERAL_H_
#define _PERIPHERAL_H_


#include "Peripheral_ADC.h"
#include "Peripheral_CAN.h"
#include "Peripheral_MCan.h"
#include "Peripheral_CMPSS.h"
#include "Peripheral_CpuTimer.h"
#include "Peripheral_DAC.h"
#include "Peripheral_EPWM.h"
#include "Peripheral_Flash.h"
#include "Peripheral_GPIO.h"
#include "Peripheral_SCI.h"
#include "Peripheral_SPI.h"
#include "CLA_Driver.h"
//#include "Peripheral_I2C.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/
#define SYS_CLK_OUT         (200000000UL)

/****************************************************************************
    Public macro definition
****************************************************************************/

/****************************************************************************
    Public enumeration definition
****************************************************************************/

/****************************************************************************
    Public structure definition
****************************************************************************/

/****************************************************************************
    Public export variable
****************************************************************************/

/****************************************************************************
    Public export function prototype
****************************************************************************/
extern void Peripheral_Initialize(void);
extern void Peripheral_Start(void);
extern void Peripheral_Stop(void);
extern void Peripheral_Background_Process(void);

#endif /* _INCLUDED_PERIPHERAL_H_ */
