/********************************************************************************
* file              llc_converter.h
* brief
* note
* author            Darren ZW Chen
* version           01
* section History   2023/05/03  -   1st release
********************************************************************************/
#ifndef LLC_CONVERTER_H_
#define LLC_CONVERTER_H_

#include "f28x_project.h"
#include "CONFIG_Define.h"
#include <math.h>
#include "Handler_PFC.h"
#include "Handler_ATS.h"
#include "SERV_ADCFilter.h"


/****************************************************************************
    Private enumeration definition
****************************************************************************/
/****************************************************************************
    Public macro definition
****************************************************************************/
#define CLA_GET_ADC_I_PFC_A         CLA_ADCResult[CLA_ADC_I_PFC_A]
#define CLA_GET_ADC_V_PFC_L         CLA_ADCResult[CLA_ADC_V_PFC_L]
#define CLA_GET_ADC_V_AC1_L         CLA_ADCResult[CLA_ADC_V_AC1_L]
#define CLA_GET_ADC_V_AC2_L         CLA_ADCResult[CLA_ADC_V_AC2_L]
#define CLA_GET_ADC_I_PFC_A_VREF    CLA_ADCResult[CLA_ADC_I_PFC_A_VREF]
#define CLA_GET_ADC_T_INLET         CLA_ADCResult[CLA_ADC_T_INLET]
#define CLA_GET_ADC_T_ATS           CLA_ADCResult[CLA_ADC_T_ATS]
#define CLA_GET_ADC_V_AUX1          CLA_ADCResult[CLA_ADC_V_AUX1]
#define CLA_GET_ADC_V_AUX2          CLA_ADCResult[CLA_ADC_V_AUX2]

#define CLA_GET_ADC_I_PFC_B         CLA_ADCResult[CLA_ADC_I_PFC_B]
#define CLA_GET_ADC_V_PFC_N         CLA_ADCResult[CLA_ADC_V_PFC_N]
#define CLA_GET_ADC_V_AC1_N         CLA_ADCResult[CLA_ADC_V_AC1_N]
#define CLA_GET_ADC_V_AC2_N         CLA_ADCResult[CLA_ADC_V_AC2_N]
#define CLA_GET_ADC_I_PFC_B_VREF    CLA_ADCResult[CLA_ADC_I_PFC_B_VREF]

#define CLA_GET_ADC_I_PFC_C         CLA_ADCResult[CLA_ADC_I_PFC_C]
#define CLA_GET_ADC_V_PFC_DET       CLA_ADCResult[CLA_ADC_V_PFC_DET]
#define CLA_GET_ADC_V_PFC_OVP1      CLA_ADCResult[CLA_ADC_V_PFC_OVP1]
#define CLA_GET_ADC_V_PFC_OVP2      CLA_ADCResult[CLA_ADC_V_PFC_OVP2]
#define CLA_GET_ADC_I_PFC_C_VREF    CLA_ADCResult[CLA_ADC_I_PFC_C_VREF]
#define CLA_GET_ADC_T_PFC           CLA_ADCResult[CLA_ADC_T_PFC]
#define CLA_GET_ADC_T_D2D           CLA_ADCResult[CLA_ADC_T_D2D]

/****************************************************************************
    Public enumeration definition
****************************************************************************/
/****************************************************************************
    Public enumeration definition
****************************************************************************/
typedef enum
{
    CLA_ADC_I_PFC_A = 0,
    CLA_ADC_V_PFC_L,
    CLA_ADC_V_AC1_L,
    CLA_ADC_V_AC2_L,
    CLA_ADC_I_PFC_A_VREF,
    CLA_ADC_T_INLET,
    CLA_ADC_T_ATS,
    CLA_ADC_V_AUX1,
    CLA_ADC_V_AUX2,

    CLA_ADC_I_PFC_B,
    CLA_ADC_V_PFC_N,
    CLA_ADC_V_AC1_N,
    CLA_ADC_V_AC2_N,
    CLA_ADC_I_PFC_B_VREF,

    CLA_ADC_I_PFC_C,
    CLA_ADC_V_PFC_DET,
    CLA_ADC_V_PFC_OVP1,
    CLA_ADC_V_PFC_OVP2,
    CLA_ADC_I_PFC_C_VREF,
    CLA_ADC_T_PFC,
    CLA_ADC_T_D2D,

    CLA_ADC_Tag_Num
}eCLA_ADCTag_t;

typedef enum
{
    CLA_PFC_IAC = 0,
    CLA_PFC_IAC_A,
    CLA_PFC_IAC_B,
    CLA_PFC_IAC_C,
    CLA_PFC_Vac_L,
    CLA_PFC_Vac_N,
    CLA_ATS_Vac1_L,
    CLA_ATS_Vac1_N,
    CLA_ATS_Vac2_L,
    CLA_ATS_Vac2_N,
    CLA_ADC_AC_Tag_Num
}eCLA_ADC_AC_Tag_t;


/****************************************************************************
    Public structure definition
****************************************************************************/
/****************************************************************************
    Public structure definition
****************************************************************************/
typedef struct
{
    eCLA_ADC_AC_Tag_t   eTag;
    u32_t* pu32ADCInstant_Q12;  //ADC input
    u32_t u32ADCPervious_Q12;   //Input m wave, full range is 0~Q12
    i32_t i32ADCPervious_Q12;   //Input sin wave, full range is -Q12~Q12
    u32_t u32Filterparameter_A;
    u32_t u32Filterparameter_B;
    i32_t i32Vref_Cali;         // Record Vref level before ATS start up
    u32_t u32Vref_Previous;     // filter Vref value
    u32_t u32Vref_Count;        // filter count
    u32_t u32Vref_Finished;     // Vref finish flag
}sCLA_ADCfilter_AC_t;

typedef struct
{
    eADC_DC_Tag_t   eTag;
    u32_t* pu32ADCInstant_Q12;
    u32_t u32ADCPervious_Q12;
    u32_t u32Filterparameter_A;
    u32_t u32Filterparameter_B;
}sCLA_ADCfilter_DC_t;

/* CPU to CLA */
typedef struct sCpuToClaMessage
{
    u32_t   u32llc_ctrl_switch;
    u32_t   u32llc_volt_ref;
    u32_t   u32llc_curr_limit_ref;
    u32_t   u32llc_prot_status;
    i32_t   u32llc_cs_ref;
}sCpuToClaMessage_t;

/* CLA to CPU */
typedef struct sClaToCpuMessage
{
    /* ADC-A */
    u32_t*  pu32ADCResult_IPFC_A;
    u32_t*  pu32ADCResult_VPFC_L;
    u32_t*  pu32ADCResult_VAC1_L;
    u32_t*  pu32ADCResult_VAC2_L;
    u32_t*  pu32ADCResult_IPFC_A_VREF;
    u32_t*  pu32ADCResult_T_Inlet;
    u32_t*  pu32ADCResult_T_ATS;
    u32_t*  pu32ADCResult_V_AUX1;
    u32_t*  pu32ADCResult_V_AUX2;

    /* ADC-B */
    u32_t*  pu32ADCResult_IPFC_B;
    u32_t*  pu32ADCResult_VPFC_N;
    u32_t*  pu32ADCResult_VAC1_N;
    u32_t*  pu32ADCResult_VAC2_N;
    u32_t*  pu32ADCResult_IPFC_B_VREF;

    /* ADC-C */
    u32_t*  pu32ADCResult_IPFC_C;
    u32_t*  pu32ADCResult_VPFC_Detect;
    u32_t*  pu32ADCResult_VPFC_OVP1;
    u32_t*  pu32ADCResult_VPFC_OVP2;
    u32_t*  pu32ADCResult_IPFC_C_VREF;
    u32_t*  pu32ADCResult_T_PFC;
    u32_t*  pu32ADCResult_T_D2D;

    u32_t   u32llc_status;
    u32_t   u32llc_freq;
    u32_t   test2;
    u32_t   test3;
    float   test4;
    float   test5;
}sClaToCpuMessage_t;

//////////////////////////////////////////////////////////////

/****************************************************************************
*   Public enumeration definition
****************************************************************************/

typedef enum
{
    CLA_PFC_State_Off = 1,
    CLA_PFC_State_PTC,
    CLA_PFC_State_IGBTOn,
    CLA_PFC_State_Softstart,
    CLA_PFC_State_Operating,
    CLA_PFC_State_Suspend,
}eCLAPFCState_t;

typedef enum
{
    CLA_PFC_VOLT_State_Reset = 1,
    CLA_PFC_VOLT_State_Operating,
}eCLAPFC_Volt_State_t;

typedef enum
{
    CLA_PFC_CURR_State_Reset = 1,
    CLA_PFC_CURR_State_Operating,
}eCLAPFC_Curr_State_t;

typedef enum
{
    CLA_PFC_CBC_A = 0,
    CLA_PFC_CBC_B,
}eCLAPFC_CBC_Event_t;
/****************************************************************************
*   Public structure definition
****************************************************************************/

typedef union
{
    u32_t u32All;
    struct
    {
        u32_t u1PFC_Enable          : 1;    // 0:PFC Disable , 1:PFC Enable, ATS to PFC, enable PFC
        u32_t u1PFC_OK              : 1;    // 0:PFC NOT OK , 1:PFC OK, PFC at operation mode(Vbulk OK)
        u32_t u2PFC_Vin_Status      : 2;    // 0:NA , 1:AC input, 2:DC input, 3:input loss
        u32_t u1Vin_Polarity        : 1;    // 1:Positive polarity ; 0:Negative polarity
        u32_t u1VoltagePIFast       : 1;    // 0:slow , 1:fast
        u32_t u1VoltagePIRequest_AC : 1;    // 0:do nothing, 1:Need to do Voltage PI control
        u32_t u1VoltagePIRequest_1K : 1;    // 0:do nothing, 1:Need to do Voltage PI control

        u32_t u2PFC_Polarity        : 2;    // 0:DeadZone, 1:Positive, 2:Negative
        u32_t u1InrushIGBTOn        : 1;    // 0:Inrush IGBT off, 1:Inrush IGBT on
        u32_t u1InrushRealyOn       : 1;    // 0:Inrush relay off, 1:Inrush relay on
        u32_t u1SinglePFC           : 1;    // 0:Interleaved PFC, 1:single PFC (phase A) while light Load
        u32_t u1PFC_Fault           : 1;    // 0:PFC not failure, 1:PFC device fault, PFC to ATS, turn off ATS
        u32_t u1PFC_Vpeak_Ready     : 1;    // 0:PFC Vpeak not ready, 1:PFC Vpeak ready
        u32_t Reserved              : 17;
    }u32Bits;
}nCLAPFC_State_Flag_t;

typedef union
{
    u32_t u32All;
    struct
    {
        u32_t u1PTC_Fault           : 1;    //10s auto recovery
        u32_t u1SoftStart_Fail      : 1;    //10s auto recovery
        u32_t u1PFC_Relay_Fail      : 1;    //PFC inrush relay fail for fault injection, 10min PTC or softstart retry fail will into latch mode
        u32_t u1Vbulk_OV            : 1;    //From MoniDC, 10s auto recovery
        u32_t u1Vbulk_UV            : 1;    //From MoniDC, auto recovery
        u32_t u1PFC_OCP             : 1;    //PFC RMS current protect, auto recovery
        u32_t u1PFC_phase_A_CBC     : 1;    //CBC protection flag, Reserved
        u32_t u1PFC_phase_B_CBC     : 1;    //CBC protection flag, Reserved

        u32_t u1Inlet_UTP           : 1;    //auto recovery
        u32_t u1Inlet_OTP           : 1;    //auto recovery
        u32_t u1PFC_UTP             : 1;    //auto recovery
        u32_t u1PFC_OTP             : 1;    //auto recovery
        u32_t u1ATS_UTP             : 1;    //auto recovery
        u32_t u1ATS_OTP             : 1;    //auto recovery
        u32_t Reserved              : 18;
    }u32Bits;
}nCLAPFC_Protect_Flag_t;


typedef struct
{
    u32_t*  pu32Vin_nnn_Q12;        //ADC input from SERV_ADCFilter
    i32_t*  pi32Vin_sin_Q12;        //ADC input from SERV_ADCFilter
    u32_t*  pu32IinA_nnn_Q12;       //ADC input from SERV_ADCFilter
    i32_t*  pi32IinA_sin_Q12;       //ADC input from SERV_ADCFilter
    u32_t*  pu32IinB_nnn_Q12;       //ADC input from SERV_ADCFilter
    i32_t*  pi32IinB_sin_Q12;       //ADC input from SERV_ADCFilter
    u32_t*  pu32IinC_nnn_Q12;       //ADC input from SERV_ADCFilter
    i32_t*  pi32IinC_sin_Q12;       //ADC input from SERV_ADCFilter
    u32_t*  pu32Vbulk_DET_Q12;      //ADC input from SERV_ADCFilter
    u32_t   u32VinRMS;              //RMS value from MoniAC unit is 0.1V
    u32_t   u32Vinpeak_Q15;         //Vac peak value from MoniAC ATS per half cycle
    u32_t   u32Vbulk_DET_Q15;       //pu16Vbulk_DET_Q12 << 3
    u32_t   u32Vbulk_DET_ZC_Q15;    //Saving Vulk value when AC zero cross
    u32_t   u32Vbulk_Ref_Q15;       //Bulkacp Reference voltage for softstart
    u32_t   u32Vbulk_Target_Q15;    //Bulkacp target Reference voltage for operation
    u32_t   u32VinFreq;             //Vac freq, unit is 0.1Hz
    u32_t   u32VPFC_Peak_Ready_CNT; //VPFC peak ready count
}sCLAPFC_Parameter_t;


typedef struct
{
    u32_t   u32PTC_ChargeTime_CNT;      //PTC
    u32_t   u32PTC_SustainedTime_CNT;
    u32_t   u32PTC_Fault_Recovery_CNT;
    u32_t   u32SS_RisingTime_CNT;       //SoftStart
    u32_t   u32SS_RisingStep_Volt;
    u32_t   u32SS_Fault_Recovery_CNT;
    u32_t   u32UV_Fault_Recovery_CNT;   //Bulk UV fault
    u32_t   u32OV_Fault_Recovery_CNT;   //Bulk OV fault
    u32_t   u32PWMEnableCNT;            //Prevent PWM not enable

    u32_t   u32SoftStart_Duty_Control;
    u64_t   u64Report_SoftStart_Phase_Change;
    u64_t   u64Report_Normal_Phase_Change;
    u32_t   u32Const_SyncRectifierTurnOnDelay;
    u32_t   u32SyncRectifierTurnOnDelay;

    u32_t   u32Const_SoftStartIref;
    u32_t   u32SoftStartIref;
    u32_t   u32EnablePFCDelay;          // unit is 0.1ms
    u32_t   u32PFCRelayFaultCNT;
    u32_t   u32BBUMode_Turnoff_CNT;     // unit is 0.1ms, set point is 60ms
    u32_t   u32VrefLoadLevel;           // 1: min, 2:L , 3:M , 4: H, 5:max
    u32_t   u32VrefVinLevel;            // 1: VinRMS < VacLevel_L, 2:VinRMS > VacLevel_H
    u32_t   u32DynamicKPKILevel;        // 0,1,2....10
    u32_t   u32FrequencyLevel;          // 1:50KHz , 0:40KHz
    u32_t   u32Suspend_CNT;             // PFC in Suspend mode during 2s, go back to off mode
    i32_t   i32IXcapCompensate;         //Compensate current of Xcap
}sCLAControl_Parameter_t;


typedef struct
{
    u32_t   u32VBulkRef_Limit_MAX_Q15;
    u32_t   u32VBulkRef_Limit_H_Q15;
    u32_t   u32VBulkRef_Limit_M_Q15;
    u32_t   u32VBulkRef_Limit_L_Q15;
    u32_t   u32VBulkRef_442V_Q15;
    u32_t   u32VBulkRef_Limit_MIN_Q15;
    u32_t   u32PTC_Target_differ_Voltage; // Target is 70V
    u32_t   u32VBulkshort_Limit_L_Q15;
    u32_t   u32VBulk_10V_Q15;
    u32_t   u32VBulk_20V_Q15;
    u32_t   u32VBulk_35V_Q15;
    f32_t   f32DynamicBulkVG;               //Dynamic Bulk Voltage gain
    f32_t   f32DynamicBulkVG_DC;            //Dynamic Bulk Voltage gain for DC input
    f32_t   f32DynamicBulkIG;               //Dynamic Bulk Current gain
    f32_t   f32DynamicBulkPG;               //Dynamic Bulk Power gain
    u32_t   u32Vacpeak_10V_THRESHOLD_Q15;
    u32_t   u32Vacpeak_20V_THRESHOLD_Q15;
    u32_t   u32Vacpeak_THRESHOLD_H_Q15;
    u32_t   u32Vacpeak_THRESHOLD_L_Q15;
    i32_t   i32Iacpeak_Poslimit;
    i32_t   i32Iacpeak_Neglimit;
    i32_t   i32Iacpeak_Lightload_L;
    i32_t   i32Iacpeak_Lightload_H;
    i32_t   i32Xcap_Currentadjust;
    f32_t   f32XcapCompensate;
    i32_t   i32PhaseChange_V_Pos_Q15;
    i32_t   i32PhaseChange_V_Neg_Q15;

    i32_t   i32PhaseChange_SoftStart_V_Pos_Q15;
    i32_t   i32PhaseChange_SoftStart_V_Neg_Q15;

    u32_t   u32Duty_feedward_shift;
    f32_t   f32Duty_feedward_Gain;          // 1.03 > 1 backward, <1 forward
    u32_t   u32Report_feedward_Gain;        // For Report Duty Gain , unit is 0.01
    u32_t   u32PI_Control_Key;
    f32_t   f32BUS_FS;
    f32_t   f32PFC_FS;
    f32_t   f32IAC_FS;
    f32_t   f32PFC_to_BUS;

    /* Variable Frequency */
    u32_t   u32HighFreq;
    u32_t   u32LowFreq;
}sCLAConfig_Parameter_t;


typedef struct
{
    u32_t u32KP;                //Q15
    u32_t u32KITS;              //Q20
    i32_t i32Ref;               //Q15 Voltage Vref is Vbulk Q15, Current Vref is Iref Q15
    i32_t i32Error;             //Q15
    i32_t i32ErrorPre;          //Q15 Previously Error
    i32_t i32Integral;          //Q30
    i32_t i32IntegralPre;       //Q30 Previously Integral
    i32_t i32IntegralGain;      //Q30 integral gain for zero cross soft start
    u32_t u32Const_IntegralGain;//Q30 Const integral gain for zero cross soft start
    f32_t f32Integral_Poslimit; //Q30
    f32_t f32Integral_Neglimit; //Q30
    i32_t i32PIout;             //Q16
    f32_t f32PIout_Poslimit;    //Q30
    f32_t f32PIout_Neglimit;    //Q30
    u32_t u32AdjustGain_H;      //Q15
    u32_t u32AdjustGain_L;      //Q15
    u32_t u32KP_SS;             //Q15 for softstart
    u32_t u32KP_H;              //Q15
    u32_t u32KP_L;              //Q15
    u32_t u32KITS_SS;           //Q20 for softstart
    u32_t u32KITS_H;            //Q20
    u32_t u32KITS_L;            //Q20
}sCLAPI_Parameter_t;


typedef struct
{
    eCLAPFCState_t eState;                 // Current state
    eCLAPFCState_t ePreState;              // Previously state
    eCLAPFC_Volt_State_t eVoltState;
    eCLAPFC_Volt_State_t ePreVoltState;
    eCLAPFC_Curr_State_t eCurrState;
    eCLAPFC_Curr_State_t ePreCurrState;
    nCLAPFC_State_Flag_t nSFlag;
    nCLAPFC_Protect_Flag_t nPFlag;
    sCLAPFC_Parameter_t sPFCRara;          // key Variable
    sCLAControl_Parameter_t sConPara;      // Variable
    sCLAConfig_Parameter_t sConfigPara;    // Constant
    sCLAPI_Parameter_t sVOLT_PI;
    sCLAPI_Parameter_t sCURR_PI;
    sCLAPI_Parameter_t sCURR2_PI;
    sCLAPI_Parameter_t sCURR3_PI;
//    sSwitchDriver_t* psPFCRelay;
//    sSwitchDriver_t* psPFCIGBT;
}sCLAPFC_t;
////////////////////////////////////////////////////////////////////////////

typedef struct sClaData
{
    /*input from CPU*/
    sCpuToClaMessage_t* input;
    /*output from CPU*/
    sClaToCpuMessage_t* output;

}sClaData_t;
/***************************************************************************
*   brief  FW Digital filter for Vac (Line - neutral)
*   note   update to Line
****************************************************************************/
static void CLA_Vac_Digital_filter_calculation(sCLA_ADCfilter_AC_t* sfilter_L, sCLA_ADCfilter_AC_t* sfilter_N)
{
    i32_t i32Temp;
//  i32_t i32Temp;
    u16_t u16ADC_L;
    u16_t u16ADC_N;

    u16ADC_L = *(sfilter_L->pu32ADCInstant_Q12);
    u16ADC_N = *(sfilter_N->pu32ADCInstant_Q12);
    i32Temp = ((i32_t)u16ADC_L) - ((i32_t)u16ADC_N);
//  i32Temp = (((i32_t)i16Temp * sfilter_L->u16Filterparameter_A) >> 12) + (((i32_t)sfilter_L->i16ADCPervious_Q12 * sfilter_L->u16Filterparameter_B) >> 12);
//  sfilter_L->i16ADCPervious_Q12 = (i16_t)i32Temp;
    //Remove filter to improve litht load PF
    sfilter_L->i32ADCPervious_Q12 = i32Temp;
    sfilter_L->u32ADCPervious_Q12 = (abs)(sfilter_L->i32ADCPervious_Q12);
}

/***************************************************************************
*   brief  FW Digital filter for Iac (Sine wave with 1.65 level)
*   note   current is up side down from HW placement
****************************************************************************/
static void CLA_Iac_Digital_filter_calculation(sCLA_ADCfilter_AC_t* sfilter)
{
    i32_t i32Temp;
    u32_t u32TempInstant;
    i32_t i32TempInstant;

    u32TempInstant = *(sfilter->pu32ADCInstant_Q12);
    i32TempInstant = ((i32_t)u32TempInstant - sfilter->i32Vref_Cali) << 1; //Hallsensor center level is 1.65V cause value is Q11 , after calibration need multiply by Q1 to Q12-type
    i32TempInstant = -i32TempInstant;   //current invert base on PCB layout.
    i32Temp = (((i32_t)i32TempInstant * sfilter->u32Filterparameter_A) >> 12) + (((i32_t)sfilter->i32ADCPervious_Q12 * sfilter->u32Filterparameter_B) >> 12);
    sfilter->i32ADCPervious_Q12 = i32Temp;
    sfilter->u32ADCPervious_Q12 = (abs)(sfilter->i32ADCPervious_Q12);
}

/****************************************************************************
    Public export variable
****************************************************************************/
extern u32_t CLA_ADCResult[CLA_ADC_Tag_Num];

#pragma diag_push
#pragma diag_suppress 1173
__attribute__((noblocked))
extern sCpuToClaMessage_t CpuToClaMessage;
#pragma diag_pop

#pragma diag_push
#pragma diag_suppress 1173
__attribute__((noblocked))
extern sClaToCpuMessage_t ClaToCpuMessage;
#pragma diag_pop


/****************************************************************************
    Public export function prototype
****************************************************************************/
extern __interrupt void ClaTask1(void);
extern __interrupt void ClaTask2(void);
extern __interrupt void ClaTask3(void);
extern __interrupt void ClaTask4(void);
extern __interrupt void ClaTask5(void);
extern __interrupt void ClaTask6(void);
extern __interrupt void ClaTask7(void);
extern __interrupt void ClaTask8(void);


#endif /* LLC_CONVERTER_H_ */
