/********************************************************************************
* file              cla_diver.h
* brief
* note
* author            Darren ZW Chen
* version           01
* section History   2023/05/03  -   1st release
********************************************************************************/

#ifndef CLA_DRIVER_H_
#define CLA_DRIVER_H_

#include "f28x_project.h"
#include "CONFIG_Define.h"
//#include "string.h"


extern void init_cla_driver(void);
extern void enable_cla_driver(void);
extern void disable_cla_driver(void);


#endif /* CLA_DRIVER_H_ */
