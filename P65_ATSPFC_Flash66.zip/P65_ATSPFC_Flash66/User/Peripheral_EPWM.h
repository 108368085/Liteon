/****************************************************************************
 *	File	Peripheral_EPWM.h
 * 	Brief	Header file for Peripheral EPWM module
 * 	Note
 * 	Author	Adonis Wang
 * 	Ver		01
 * 	History	2020/08/17 - 1st release
 ****************************************************************************/

#ifndef _PERIPHERAL_EPWM_H_
#define _PERIPHERAL_EPWM_H_

#include "CONFIG_Define.h"
#include "Peripheral.h"


/****************************************************************************
    Public parameter definition
****************************************************************************/
#define EPWM1_FREQ          100000			// 100KHz
#define EPWM3_FREQ          20000           // 20KHz
#define EPWM7_FREQ          40000			// 40kHz
#define EPWM8_FREQ          EPWM7_FREQ
#define VbulkToD2D_FREQ     200000          // 200KHz

#define TBCLK                    (SYS_CLK_OUT)           // 200MHz
#define EPWM1_PERIOD             (u16_t)(((TBCLK / EPWM1_FREQ) / 2) - 1)     //Count_Up_Down
#define EPWM3_PERIOD             (u16_t)((TBCLK / EPWM3_FREQ) - 1)           //Count_Up
#define EPWM4_VbulkToD2D_PERIOD  (u16_t)((TBCLK / VbulkToD2D_FREQ) - 1)      //Count_Up
#define EPWM6_PERIOD             (u16_t)(((TBCLK / EPWM7_FREQ) / 2) - 1)     //Count_Up_Down
#define EPWM7_PERIOD             EPWM6_PERIOD     //Count_Up_Down
#define EPWM8_PERIOD             EPWM6_PERIOD                                //Count_Up_Down
#define PWM_DeadBand_300         60                                          // 300ns = 60*TBCLK = 60*0.005, TBCLK=200MHz=0.005us, RED = DBRED*TBCLK
#define PWM_DeadBand_240         48                                          // 240ns = 48*TBCLK = 48*0.005, TBCLK=200MHz=0.005us, RED = DBRED*TBCLK

/* For PFC frequency conversion */
#define EPWM_35KHz         (u16_t)(((TBCLK / 35000) / 2) - 1)           //Count_Up_Down
#define EPWM_40KHz         (u16_t)(((TBCLK / 40000) / 2) - 1)           //Count_Up_Down
#define EPWM_43KHz         (u16_t)(((TBCLK / 43000) / 2) - 1)           //Count_Up_Down
#define EPWM_45KHz         (u16_t)(((TBCLK / 45000) / 2) - 1)           //Count_Up_Down
#define EPWM_50KHz         (u16_t)(((TBCLK / 50000) / 2) - 1)           //Count_Up_Down
#define EPWM_51KHz         (u16_t)(((TBCLK / 51000) / 2) - 1)           //Count_Up_Down
#define EPWM_52KHz         (u16_t)(((TBCLK / 52000) / 2) - 1)           //Count_Up_Down
#define EPWM_55KHz         (u16_t)(((TBCLK / 55000) / 2) - 1)           //Count_Up_Down


/****************************************************************************
	Public macro definition
****************************************************************************/

/****************************************************************************
	Public enumeration definition 
****************************************************************************/

typedef enum ePeriEPwmTag
{
    ePeriEPwm_Tag_PFCRELAY,
	ePeriEPwm_Tag_PFCIGBT,
    ePeriEPwm_Tag_PFC_A,
    ePeriEPwm_Tag_PFC_B,
    ePeriEPwm_Tag_PFC_C,
    ePeriEPwm_Tag_VBulkToD2D,
    ePeriEPwm_Tag_Num,
}ePeriEPwmTag_t;


/****************************************************************************
	Public structure definition 
****************************************************************************/

/****************************************************************************
	Public export variable
****************************************************************************/
extern u16_t PWM_Period[ePeriEPwm_Tag_Num];

/****************************************************************************
	Public export function prototype
****************************************************************************/
extern void PeriEPwm_Initialize(void);
extern void PeriPWM_PFC_A_CBC_Clear(void);
extern void PeriPWM_PFC_B_CBC_Clear(void);
extern void PeriPWM_PFC_Pos_Polarity(void);
extern void PeriPWM_PFC_Neg_Polarity(void);
extern void PeriPWM_PFC_DB_Enable(void);
extern void PeriEPwm_PFC_Enable(void);
extern void PeriEPwm_PFC_PhaseA_Enable(void);
extern void PeriEPwm_PFC_PhaseB_Enable(void);
extern void PeriEPwm_PFC_PhaseC_Enable(void);
extern void PeriEPwm_PFC_Disable(void);
extern void PeriEPwm_SetDuty(ePeriEPwmTag_t eTag, u32_t u32Duty_Q16);
extern void PeriPWM_Start(void);
extern void PeriPWM_Stop(void);

#endif
