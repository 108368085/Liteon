/** @file       ModBus_Data.c
 *  @author     Ollie Chen
 *  @brief      ModBus Database
 *  @version    1.0
 *  @date       2017-10-25
*/

#include <string.h>
#include "ModBus_Data.h"
#include "SERV_LOG.h"
#include "SERV_LED.h"
#include "Monitor_AC.h"
#include "Monitor_DC.h"
#include "Monitor_TP.h"
#include "CANBus_Server.h"
#include "Handler_ATS.h"



/****************************************************************************
	Private macro definition
****************************************************************************/
//#define SUPPORT_COIL_REGISTER
#define SUPPORT_INPUT_REGISTER
#define SUPPORT_HOLDING_REGSITER

/** Macro for configure coil register attribute */
#define COIL_REG_ATTR( _Index, _StartAddr, _EndAddr,                        \
                        _StartBit, _EndBit, _RegPointer)                    \
    [_Index] =                                                              \
    {                                                                       \
        .u16StartAddr = _StartAddr,                                         \
        .u16EndAddr = _EndAddr,                                             \
        .u16StartBit = _StartBit,                                           \
        .u16EndBit = _EndBit,                                               \
        .pu16Reg = _RegPointer,                                             \
    }

/** Macro for configure input register attribute */
#define INPUT_REG_ATTR( _Index, _StartAddr, _EndAddr, _RegPointer)          \
    [_Index] =                                                              \
    {                                                                       \
        .u16StartAddr = _StartAddr,                                         \
        .u16EndAddr = _EndAddr,                                             \
        .pu16Reg = _RegPointer,                                             \
    }
    
/** Macro for configure holding register attribute */
#define HOLDING_REG_ATTR( _Index, _StartAddr, _EndAddr, _RegPointer)        \
    [_Index] =                                                              \
    {                                                                       \
        .u16StartAddr = _StartAddr,                                         \
        .u16EndAddr = _EndAddr,                                             \
        .psGuardVarList = _RegPointer,                                      \
    }

/****************************************************************************
	Private enumeration definition
****************************************************************************/

/**
    Enumeration of Coil register bit definition
*/
typedef enum
{
    eCoilBit0 = 0,
	eCoilBit1,
	eCoilBit2,
	eCoilBit3,
	eCoilBit4,
	eCoilBit5,
	eCoilBit6,
	eCoilBit7,
	eCoilBit8,
	eCoilBit9,
	eCoilBit10,
	eCoilBit11,
	eCoilBit12,
	eCoilBit13,
	eCoilBit14,
	eCoilBit15,
}eCoilRegBit_t;

/**
    Enumeration of Coil register index
*/
enum eCoilRegEnumeration
{
    eCoilReg_Num,
};

/**
    Enumeration of Input Registers
*/
enum eInputRegEnumeration
{
    eInputReg_PFC_InputVoltage,             // unit is 0.1V
    eInputReg_PFC_InputCurrent,             // unit is 1mA
    eInputReg_PFC_InputPower,               // unit is 1 Watt
    eInputReg_PFC_Temperature,              // unit is 0.1 degreeC + 40C
    eInputReg_INLET_Temperature,            // unit is 0.1 degreeC + 40C
    eInputReg_PFC_BulkCapVoltage,           // unit is 0.1V
    eInputReg_StatusInput,
    eInputReg_LED_Status,
    eInputReg_PFC2D2D_Status,
    eInputReg_AVG_Power,					// unit is 1 Watt
    eInputReg_MAX_Power,					// unit is 1 Watt
    eInputReg_PFC_Alive,
    eInputReg_D2D_Temperature,				// unit is 0.1 degreeC + 40C
    eInputReg_PIN_Derating,					// unit is 1 Watt
    eInputReg_PFC_Frequency,
    eInputReg_StatusTransition,
    eInputReg_WalkinTime_Out,
    eInputReg_Reserved3,
    eInputReg_Reserved2,
    eInputReg_Reserved1,
    eInputReg_Num,
};

/**
    Enumeration of Holding Registers
*/
enum eHoldingRegEnumeration
{
    eHoldingReg_PSU_Address,
    eHoldingReg_D2D2PFC_Status,
    eHoldingReg_D2D_Alive,
    eHoldingReg_Reserved7,
    eHoldingReg_Reserved6,
    eHoldingReg_Reserved5,
    eHoldingReg_Reserved4,
    eHoldingReg_Reserved3,
    eHoldingReg_Reserved2,
    eHoldingReg_Reserved1,
    eHoldingReg_Num,
};


enum eModBusDataGuardVar
{
	eModBusData_GuardVar_PSU_Address,
    eModBusData_GuardVar_D2D2PFC_Status,
    eModBusData_GuardVar_D2D_Alive,
    eModBusData_GuardVar_Reserved7,
    eModBusData_GuardVar_Reserved6,
    eModBusData_GuardVar_Reserved5,
    eModBusData_GuardVar_Reserved4,
    eModBusData_GuardVar_Reserved3,
    eModBusData_GuardVar_Reserved2,
    eModBusData_GuardVar_Reserved1,
    eModBusData_GuardVar_Num,
};


/****************************************************************************
	Private structure definition 
****************************************************************************/

/****************************************************************************
	Private function prototype
****************************************************************************/

// RAMLS0_6 : 64 -> 28
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
//#pragma CODE_SECTION(MBusData_SearchCoilRegNode, ".TI.ramfunc");
#pragma CODE_SECTION(MBusData_SearchInputRegNode, ".TI.ramfunc");
#pragma CODE_SECTION(MBusData_SearchHoldingRegNode, ".TI.ramfunc");
//#pragma CODE_SECTION(GuardVarDataCheckRequestHandler, ".TI.ramfunc");
//#pragma CODE_SECTION(GuardVarDataWriteRequestHandler, ".TI.ramfunc");
#endif

/****************************************************************************
	Private variable declare
****************************************************************************/
#ifdef SUPPORT_COIL_REGISTER
sCoilRegNode_t ptsCoilRegisters[eCoilReg_Num] =
{
    /*
    COIL_REG_ATTR(eCoilReg_McuStatus,           0x0000, 0x000F, eCoilBit0, eCoilBit15, &gtsDeviceAttribute.u16McuType),    
    COIL_REG_ATTR(eCoilReg_RevConflictStatus,   0x0010, 0x0011, eCoilBit0, eCoilBit15, &gtsDeviceAttribute.u16ConflictStatus),
    */
};
#endif

#ifdef SUPPORT_INPUT_REGISTER
sInputRegNode_t ptsInputRegisters[eInputReg_Num] =
{

    /*              Input Register enumeration,             Register Start Address,     Register End Address,   Register Pointer */
    INPUT_REG_ATTR(eInputReg_PFC_InputVoltage,              0x03E8,                     0x03E8,                 NULL),
    INPUT_REG_ATTR(eInputReg_PFC_InputCurrent,              0x03E9,                     0x03E9,                 NULL),
    INPUT_REG_ATTR(eInputReg_PFC_InputPower,                0x03EA,                     0x03EA,                 NULL),
    INPUT_REG_ATTR(eInputReg_PFC_Temperature,               0x03EB,                     0x03EB,                 NULL),
    INPUT_REG_ATTR(eInputReg_INLET_Temperature,            	0x03EC,                     0x03EC,                 NULL),
    INPUT_REG_ATTR(eInputReg_PFC_BulkCapVoltage,            0x03ED,                     0x03ED,                 NULL),
    INPUT_REG_ATTR(eInputReg_StatusInput,                   0x03EE,                     0x03EE,                 NULL),
    INPUT_REG_ATTR(eInputReg_LED_Status,                    0x03EF,                     0x03EF,                 NULL),
    INPUT_REG_ATTR(eInputReg_PFC2D2D_Status,                0x03F0,                     0x03F0,                 NULL),
    INPUT_REG_ATTR(eInputReg_AVG_Power,         			0x03F1,                     0x03F1,                 NULL),
	INPUT_REG_ATTR(eInputReg_MAX_Power,         			0x03F2,                     0x03F2,                 NULL),
	INPUT_REG_ATTR(eInputReg_PFC_Alive,         			0x03F3,                     0x03F3,                 NULL),
	INPUT_REG_ATTR(eInputReg_D2D_Temperature,         		0x03F4,                     0x03F4,                 NULL),
	INPUT_REG_ATTR(eInputReg_PIN_Derating,         			0x03F5,                     0x03F5,                 NULL),
	INPUT_REG_ATTR(eInputReg_PFC_Frequency,         		0x03F6,                     0x03F6,                 NULL),
	INPUT_REG_ATTR(eInputReg_StatusTransition,         		0x03F7,                     0x03F7,                 NULL),
	INPUT_REG_ATTR(eInputReg_WalkinTime_Out,         	    0x03F8,                     0x03F8,                 NULL),
	INPUT_REG_ATTR(eInputReg_Reserved3,         			0x03F9,                     0x03F9,                 NULL),
	INPUT_REG_ATTR(eInputReg_Reserved2,         			0x03FA,                     0x03FA,                 NULL),
	INPUT_REG_ATTR(eInputReg_Reserved1,         			0x03FB,                     0x03FB,                 NULL),
};
#endif

#ifdef SUPPORT_HOLDING_REGSITER
sHoldingRegNode_t ptsHoldingRegisters[eHoldingReg_Num] =
{
/*                  Input Register enumeration,             Register Start Address,     Register End Address,   Register Pointer */
    HOLDING_REG_ATTR(eHoldingReg_PSU_Address,           	0x0320,                     0x0320,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_D2D2PFC_Status,           	0x0321,                     0x0321,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_D2D_Alive,       			0x0322,                     0x0322,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_Reserved7,       			0x0323,                     0x0323,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_Reserved6,       			0x0324,                     0x0324,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_Reserved5,       			0x0325,                     0x0325,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_Reserved4,       			0x0326,                     0x0326,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_Reserved3,       			0x0327,                     0x0327,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_Reserved2,       			0x0328,                     0x0328,                 NULL),
    HOLDING_REG_ATTR(eHoldingReg_Reserved1,       			0x0329,                     0x0329,                 NULL),
};
#endif

sGuardVarNode_t ptsGuardVarNode_ModBus[eModBusData_GuardVar_Num];
sGuardVarList_t ptsGuardVarList_ModBus[eModBusData_GuardVar_Num];


/**
    @brief  Get specific Coil register node
    @param  u16Address: Specific Coil register address in ModBus database
    @retval Target coil register node
*/
sCoilRegNode_t* MBusData_SearchCoilRegNode(u16_t u16Address)
{
#ifdef SUPPORT_COIL_REGISTER    
    sCoilRegNode_t* psCoilRegNode = NULL;

	for (u16_t i=0; i<eCoilReg_Num; i++)
    {
        if ((u16Address >= ptsCoilRegisters[i].u16StartAddr) &&
            (u16Address <= ptsCoilRegisters[i].u16EndAddr))
        {
            break;
        }
    }
    
    return psCoilRegNode;
#else
    return NULL;
#endif    
}

/**
    @brief  Get specific Input register node
    @param  u16Address: Specific Input register address in ModBus database
    @retval Target input register node
*/
sInputRegNode_t* MBusData_SearchInputRegNode(u16_t u16Address)
{
    u16_t i;

#ifdef SUPPORT_INPUT_REGISTER    
    sInputRegNode_t* psInputRegNode = NULL;

    for (i=0; i<eInputReg_Num; i++)
    {
        if ((u16Address >= ptsInputRegisters[i].u16StartAddr) &&
            (u16Address <= ptsInputRegisters[i].u16EndAddr))
        {
            psInputRegNode = &ptsInputRegisters[i];
            break;
        }
    }
    
    return psInputRegNode;
#else
    return NULL;
#endif    
}

/**
    @brief  Get specific Holding register node
    @param  u16Address: Specific Holding register address in ModBus database
    @retval Target holding register node
*/
sHoldingRegNode_t* MBusData_SearchHoldingRegNode(u16_t u16Address)
{
    u16_t i;

#ifdef SUPPORT_HOLDING_REGSITER    
    sHoldingRegNode_t* psHoldingRegNode = NULL;

	for (i=0; i<eHoldingReg_Num; i++)
    {
        if ((u16Address >= ptsHoldingRegisters[i].u16StartAddr) &&
            (u16Address <= ptsHoldingRegisters[i].u16EndAddr))
        {
            psHoldingRegNode = &ptsHoldingRegisters[i];
            break;
        }
    }
    
    return psHoldingRegNode;
#else
    return NULL;
#endif    
}

/**
 *  @brief  Check guard variable data is valid or not
 *  @param  psNode: Pointer to a sGuardVarNode_t structure which is attempted to write
 *  @param  sRequest: Guard variable access request
 *  @retval RequestDenied: This access request is denied
 *  @retval RequestAccepted: This access request is accepted
 */
static u16_t GuardVarDataCheckRequestHandler(struct sGuardVarNode* psNode, sGuardVarAccessRequest_t sRequest)
{
    u16_t u16Response;

    if (sRequest.u16Offset+sRequest.u16Length > psNode->u16VarSize)
    {
        u16Response = RequestDenied;
    }
    else
    {
        switch (psNode->sLocalTag.u16PrivyIdentifier)
        {
			case eModBusData_GuardVar_PSU_Address:		
			case eModBusData_GuardVar_D2D2PFC_Status:
			case eModBusData_GuardVar_D2D_Alive:
			case eModBusData_GuardVar_Reserved7:
			case eModBusData_GuardVar_Reserved6:
        	case eModBusData_GuardVar_Reserved5:
        	case eModBusData_GuardVar_Reserved4:
        	case eModBusData_GuardVar_Reserved3:
        	case eModBusData_GuardVar_Reserved2:
        	case eModBusData_GuardVar_Reserved1:
                u16Response = RequestAccepted;
                break;
                		
            default:
                u16Response = RequestDenied;
                break;
        }       
    }
    return u16Response;
}

/**
 *  @brief  Write data of request to guard variable node after checked all guard variable accepted that request
 *  @param  psNode: Pointer to a sGuardVarNode_t structure which is attempted to write
 *  @param  sRequest: Guard variable access request
 *  @retval RequestDenied: This access request is denied
 *  @retval RequestAccepted: This access request is accepted
 */
static u16_t GuardVarDataWriteRequestHandler(struct sGuardVarNode* psNode, sGuardVarAccessRequest_t sRequest)
{
    u16_t u16Response = RequestAccepted;
	u16_t u16Data;

    switch (psNode->sLocalTag.u16PrivyIdentifier)
    {
		case eModBusData_GuardVar_PSU_Address:
			u16Data = __MByteToWord(sRequest.pu8Data);
			if ((u16Data > 0) && (u16Data < 7))
			{
				*((u16_t*)psNode->pVar) = u16Data;
			}
			break;

		case eModBusData_GuardVar_D2D2PFC_Status:
		case eModBusData_GuardVar_D2D_Alive:
		case eModBusData_GuardVar_Reserved7:
		case eModBusData_GuardVar_Reserved6:
		case eModBusData_GuardVar_Reserved5:
		case eModBusData_GuardVar_Reserved4:
		case eModBusData_GuardVar_Reserved3:
		case eModBusData_GuardVar_Reserved2:
		case eModBusData_GuardVar_Reserved1:
			u16Data = __MByteToWord(sRequest.pu8Data);
            *((u16_t*)psNode->pVar) = u16Data;
            break;

        default:
            u16Response = RequestDenied;
            break;
    }

    return u16Response;
}

/**
 *  @brief  Initial Guard Variable
 *  @retval None
 */
static void ModBusData_Initial_GuardVar(void)
{
	u16_t i;
	
	for (i=0; i<eModBusData_GuardVar_Num; i++)
	{
		memset(&ptsGuardVarNode_ModBus[i], 0, sizeof(ptsGuardVarNode_ModBus[i]));
		memset(&ptsGuardVarList_ModBus[i], 0, sizeof(ptsGuardVarList_ModBus[i]));
	}

    /* Configure Guard Variable Node and list */

    /* PSU_Address */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_PSU_Address].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_PSU_Address].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_PSU_Address;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_PSU_Address].pVar = &SET_CANBUS_DEVICE_ADDRESS_NUM;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_PSU_Address].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_PSU_Address].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_PSU_Address].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_PSU_Address], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_PSU_Address]);

    /* D2D2PFC_Status */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D2PFC_Status].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D2PFC_Status].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_D2D2PFC_Status;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D2PFC_Status].pVar = &GET_LOG_STATUS_D2P;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D2PFC_Status].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D2PFC_Status].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D2PFC_Status].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_D2D2PFC_Status], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D2PFC_Status]);

    /* D2D Alive */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D_Alive].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D_Alive].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_D2D_Alive;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D_Alive].pVar = &SET_LOG_D2DAliveCNT;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D_Alive].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D_Alive].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D_Alive].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_D2D_Alive], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_D2D_Alive]);

    /* Reserved */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved7].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved7].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_Reserved7;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved7].pVar = &GET_LOG_RESERVED;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved7].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved7].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved7].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved7], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved7]);

    /* Reserved */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved6].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved6].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_Reserved6;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved6].pVar = &GET_LOG_RESERVED;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved6].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved6].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved6].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved6], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved6]);

    /* Reserved */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved5].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved5].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_Reserved5;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved5].pVar = &GET_LOG_RESERVED;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved5].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved5].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved5].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved5], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved5]);

    /* Reserved */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved4].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved4].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_Reserved4;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved4].pVar = &GET_LOG_RESERVED;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved4].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved4].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved4].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved4], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved4]);

	/* Reserved */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved3].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved3].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_Reserved3;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved3].pVar = &GET_LOG_RESERVED;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved3].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved3].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved3].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved3], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved3]);

    /* Reserved */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved2].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved2].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_Reserved2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved2].pVar = &GET_LOG_RESERVED;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved2].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved2].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved2].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved2], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved2]);

	/* Reserved */
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved1].sLocalTag.u16HostIdentifier = 0;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved1].sLocalTag.u16PrivyIdentifier = eModBusData_GuardVar_Reserved1;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved1].pVar = &GET_LOG_RESERVED;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved1].u16VarSize = 2;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved1].pfDataCheckRequestHandler = GuardVarDataCheckRequestHandler;
    ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved1].pfDataWriteRequestHandler = GuardVarDataWriteRequestHandler;
    GuardVarList_AppendNode(&ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved1], &ptsGuardVarNode_ModBus[eModBusData_GuardVar_Reserved1]);

} 

/**
 *  @brief  Initial ModBus Data
 *  @retval None
 */
void MBusData_Initialize(void)
{
	ModBusData_Initial_GuardVar();

    /* Link input register */
    ptsInputRegisters[eInputReg_PFC_InputVoltage].pu16Reg = &GET_LOG_VAC;
    ptsInputRegisters[eInputReg_PFC_InputCurrent].pu16Reg = &GET_LOG_IAC;
    ptsInputRegisters[eInputReg_PFC_InputPower].pu16Reg = &GET_LOG_POWER;
    ptsInputRegisters[eInputReg_PFC_Temperature].pu16Reg = &GET_MOMITP_PFC_Temper_P;
	ptsInputRegisters[eInputReg_INLET_Temperature].pu16Reg = &GET_MOMITP_INLET_Temper_P;
    ptsInputRegisters[eInputReg_PFC_BulkCapVoltage].pu16Reg = &GET_MOMIDC_VBULK_RealInstant;
	ptsInputRegisters[eInputReg_StatusInput].pu16Reg = &GET_LOG_STATUS_INPUT;
	ptsInputRegisters[eInputReg_LED_Status].pu16Reg = (u16_t*)&GET_LED_STATUS_P2D;
    ptsInputRegisters[eInputReg_PFC2D2D_Status].pu16Reg = &GET_LOG_STATUS_P2D;
    ptsInputRegisters[eInputReg_AVG_Power].pu16Reg = &GET_LOG_AVGPOWER;
    ptsInputRegisters[eInputReg_MAX_Power].pu16Reg = &GET_LOG_MAXPOWER;
	ptsInputRegisters[eInputReg_PFC_Alive].pu16Reg = &GET_LOG_PFCAliveCNT;
	
	ptsInputRegisters[eInputReg_D2D_Temperature].pu16Reg = &GET_MOMITP_D2D_Temper_P;
	ptsInputRegisters[eInputReg_PIN_Derating].pu16Reg = &GET_LOG_PIN_Derating;
	ptsInputRegisters[eInputReg_PFC_Frequency].pu16Reg = &GET_MOMIAC_VPFC_FREQ_WF;
	ptsInputRegisters[eInputReg_StatusTransition].pu16Reg = (u16_t*)&GET_LOG_STATUS_TRANSITION;
	ptsInputRegisters[eInputReg_WalkinTime_Out].pu16Reg = (u16_t*)&GET_ATS_WalkinTimeOut_ToD2D;
	ptsInputRegisters[eInputReg_Reserved3].pu16Reg = &GET_LOG_RESERVED;
	ptsInputRegisters[eInputReg_Reserved2].pu16Reg = &GET_LOG_RESERVED;
	ptsInputRegisters[eInputReg_Reserved1].pu16Reg = &GET_LOG_RESERVED;
    
    /* Link Holding register */
    ptsHoldingRegisters[eHoldingReg_PSU_Address].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_PSU_Address];
    ptsHoldingRegisters[eHoldingReg_D2D2PFC_Status].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_D2D2PFC_Status];
	ptsHoldingRegisters[eHoldingReg_D2D_Alive].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_D2D_Alive];
	ptsHoldingRegisters[eHoldingReg_Reserved7].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved7];
	ptsHoldingRegisters[eHoldingReg_Reserved6].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved6];
	ptsHoldingRegisters[eHoldingReg_Reserved5].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved5];
	ptsHoldingRegisters[eHoldingReg_Reserved4].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved4];
	ptsHoldingRegisters[eHoldingReg_Reserved3].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved3];
	ptsHoldingRegisters[eHoldingReg_Reserved2].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved2];
	ptsHoldingRegisters[eHoldingReg_Reserved1].psGuardVarList = &ptsGuardVarList_ModBus[eModBusData_GuardVar_Reserved1];	
}
